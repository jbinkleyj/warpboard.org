/*
  PDD layer implementation for peripheral type FTFE
  (C) 2010 Freescale, Inc. All rights reserved.

  This file is static and it is generated from API-Factory
*/

#if !defined(FTFE_PDD_H_)
#define FTFE_PDD_H_

/* ----------------------------------------------------------------------------
   -- Test if supported MCU is active
   ---------------------------------------------------------------------------- */

#if !defined(MCU_ACTIVE)
  // No MCU is active
  #error FTFE PDD library: No derivative is active. Place proper #include with PDD memory map before including PDD library.
#elif \
      !defined(MCU_MK10F12) /* FTFE */ && \
      !defined(MCU_MK20F12) /* FTFE */ && \
      !defined(MCU_MK60F12) /* FTFE */ && \
      !defined(MCU_MK60F15) /* FTFE */ && \
      !defined(MCU_MK61F12) /* FTFE */ && \
      !defined(MCU_MK61F15) /* FTFE */ && \
      !defined(MCU_MK70F12) /* FTFE */ && \
      !defined(MCU_MK70F15) /* FTFE */
  // Unsupported MCU is active
  #error FTFE PDD library: Unsupported derivative is active.
#endif

#include "PDD_Types.h"

/* ----------------------------------------------------------------------------
   -- Method symbol definitions
   ---------------------------------------------------------------------------- */

/* ClearFlags constants */
#define FTFE_PDD_COMMAND_COMPLETE FTFE_FSTAT_CCIF_MASK /**< Command complete flag mask */
#define FTFE_PDD_READ_COLLISION_ERROR FTFE_FSTAT_RDCOLERR_MASK /**< Read collision error flag mask */
#define FTFE_PDD_ACCESS_ERROR FTFE_FSTAT_ACCERR_MASK /**< Access error flag mask */
#define FTFE_PDD_PROTECTION_VIOLATION FTFE_FSTAT_FPVIOL_MASK /**< Protection violation flag mask */
#define FTFE_PDD_COMMAND_COMPLETION_STATUS FTFE_FSTAT_MGSTAT0_MASK /**< Command completion ststus flag mask */

/* EnableInterrupts, DisableInterrupts constants */
#define FTFE_PDD_COMMAND_COMPLETE_INT FTFE_FCNFG_CCIE_MASK /**< Command complete interrupt mask */
#define FTFE_PDD_READ_COLLISION_ERROR_INT FTFE_FCNFG_RDCOLLIE_MASK /**< Read collision error interrupt mask */

/* SetFCCOBCommand constants */
#define FTFE_PDD_READ_1S_BLOCK 0U                /**< Read 1s Block command value */
#define FTFE_PDD_READ_1S_SECTION 0x1U            /**< Read 1s Section command value */
#define FTFE_PDD_PROGRAM_CHECK 0x2U              /**< Program Check command value */
#define FTFE_PDD_READ_RESOURCE 0x3U              /**< Read Resource command value */
#define FTFE_PDD_PROGRAM_PHRASE 0x7U             /**< Program 8 bytes command value */
#define FTFE_PDD_ERASE_FLASH_BLOCK 0x8U          /**< Erase Flash Block command value */
#define FTFE_PDD_ERASE_FLASH_SECTOR 0x9U         /**< Erase Flash Sector command value */
#define FTFE_PDD_PROGRAM_SECTION 0xBU            /**< Program Section command value */
#define FTFE_PDD_READ_1S_ALL_BLOCKS 0x40U        /**< Read 1s All Blocks command value */
#define FTFE_PDD_PDD_READ_ONCE 0x41U             /**< Read Once command value */
#define FTFE_PDD_PROGRAM_ONCE 0x43U              /**< Program Once command value */
#define FTFE_PDD_ERASE_ALL_BLOCKS 0x44U          /**< Erase All Blocks command value */
#define FTFE_PDD_VERIFY_BACKDOOR_ACCESS_KEY 0x45U /**< Verify Backdoor Access Key command value */
#define FTFE_PDD_PROGRAM_PARTITION 0x80U         /**< Program Partition command value */
#define FTFE_PDD_SET_EERAM_FUCTION 0x81U         /**< Set FlexRAM Function command value */

/* BackDoorKey constants */
#define FTFE_PDD_BACKDOOR_KEY_ENABLED 0U         /**< Backdoor key enable constant */
#define FTFE_PDD_BACKDOOR_KEY_DISABLED 0x1U      /**< Backdoor key disable constant */

/* Security state constants */
#define FTFE_PDD_UNSECURED 0U                    /**< Unsecure constant */
#define FTFE_PDD_SECURED 0x1U                    /**< Secure constant */

/* FlashProtection constants */
#define FTFE_PDD_UNPROTECTED 0U                  /**< Unprotect constant */
#define FTFE_PDD_PROTECTED 0x1U                  /**< Protect constant */


/* ----------------------------------------------------------------------------
   -- ReadStatusReg
   ---------------------------------------------------------------------------- */

/**
 * Returns value of the Flash status register.
 * @param peripheralBase Peripheral base address.
 */
#define FTFE_PDD_ReadStatusReg(peripheralBase) ( \
    FTFE_FSTAT_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteStatusReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the Flash status register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value written to the Flash status register.
 */
#define FTFE_PDD_WriteStatusReg(peripheralBase, Value) ( \
    FTFE_FSTAT_REG(peripheralBase) = \
     (uint8_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ClearCommandCompleteFlag
   ---------------------------------------------------------------------------- */

/**
 * Clears Command complete flag.
 * @param peripheralBase Peripheral base address.
 */
#define FTFE_PDD_ClearCommandCompleteFlag(peripheralBase) ( \
    FTFE_FSTAT_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(FTFE_FSTAT_REG(peripheralBase) | FTFE_FSTAT_CCIF_MASK)) & (( \
      (uint8_t)(~(uint8_t)FTFE_FSTAT_FPVIOL_MASK)) & (( \
      (uint8_t)(~(uint8_t)FTFE_FSTAT_ACCERR_MASK)) & ( \
      (uint8_t)(~(uint8_t)FTFE_FSTAT_RDCOLERR_MASK))))) \
  )

/* ----------------------------------------------------------------------------
   -- ClearReadCollisionErrorFlag
   ---------------------------------------------------------------------------- */

/**
 * Clears Read collision error flag.
 * @param peripheralBase Peripheral base address.
 */
#define FTFE_PDD_ClearReadCollisionErrorFlag(peripheralBase) ( \
    FTFE_FSTAT_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(FTFE_FSTAT_REG(peripheralBase) | FTFE_FSTAT_RDCOLERR_MASK)) & (( \
      (uint8_t)(~(uint8_t)FTFE_FSTAT_FPVIOL_MASK)) & (( \
      (uint8_t)(~(uint8_t)FTFE_FSTAT_ACCERR_MASK)) & ( \
      (uint8_t)(~(uint8_t)FTFE_FSTAT_CCIF_MASK))))) \
  )

/* ----------------------------------------------------------------------------
   -- ClearAccessErrorFlag
   ---------------------------------------------------------------------------- */

/**
 * Clears Access error flag.
 * @param peripheralBase Peripheral base address.
 */
#define FTFE_PDD_ClearAccessErrorFlag(peripheralBase) ( \
    FTFE_FSTAT_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(FTFE_FSTAT_REG(peripheralBase) | FTFE_FSTAT_ACCERR_MASK)) & (( \
      (uint8_t)(~(uint8_t)FTFE_FSTAT_FPVIOL_MASK)) & (( \
      (uint8_t)(~(uint8_t)FTFE_FSTAT_RDCOLERR_MASK)) & ( \
      (uint8_t)(~(uint8_t)FTFE_FSTAT_CCIF_MASK))))) \
  )

/* ----------------------------------------------------------------------------
   -- ClearProtectionViolationErrorFlag
   ---------------------------------------------------------------------------- */

/**
 * Clears Protection violation error flag.
 * @param peripheralBase Peripheral base address.
 */
#define FTFE_PDD_ClearProtectionViolationErrorFlag(peripheralBase) ( \
    FTFE_FSTAT_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(FTFE_FSTAT_REG(peripheralBase) | FTFE_FSTAT_FPVIOL_MASK)) & (( \
      (uint8_t)(~(uint8_t)FTFE_FSTAT_ACCERR_MASK)) & (( \
      (uint8_t)(~(uint8_t)FTFE_FSTAT_RDCOLERR_MASK)) & ( \
      (uint8_t)(~(uint8_t)FTFE_FSTAT_CCIF_MASK))))) \
  )

/* ----------------------------------------------------------------------------
   -- LaunchCommand
   ---------------------------------------------------------------------------- */

/**
 * Starts new command.
 * @param peripheralBase Peripheral base address.
 */
#define FTFE_PDD_LaunchCommand(peripheralBase) ( \
    FTFE_FSTAT_REG(peripheralBase) = \
     0x80U \
  )

/* ----------------------------------------------------------------------------
   -- ClearFlags
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the Flash status register.
 * @param peripheralBase Peripheral base address.
 * @param Flags Interrupt mask.
 */
#define FTFE_PDD_ClearFlags(peripheralBase, Flags) ( \
    FTFE_FSTAT_REG(peripheralBase) = \
     (uint8_t)(Flags) \
  )

/* ----------------------------------------------------------------------------
   -- GetFlags
   ---------------------------------------------------------------------------- */

/**
 * Returns value of the Flash status register.
 * @param peripheralBase Peripheral base address.
 */
#define FTFE_PDD_GetFlags(peripheralBase) ( \
    FTFE_FSTAT_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- ReadConfigReg
   ---------------------------------------------------------------------------- */

/**
 * Returns value of the Flash configuration register.
 * @param peripheralBase Peripheral base address.
 */
#define FTFE_PDD_ReadConfigReg(peripheralBase) ( \
    FTFE_FCNFG_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteConfigReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the Flash configuration register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value written to the Flash configuration register.
 */
#define FTFE_PDD_WriteConfigReg(peripheralBase, Value) ( \
    FTFE_FCNFG_REG(peripheralBase) = \
     (uint8_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- EnableInterrupts
   ---------------------------------------------------------------------------- */

/**
 * Enables Command commplete end Read collision error interrupts.
 * @param peripheralBase Peripheral base address.
 * @param Mask Interrupt mask Use constants from group "EnableInterrupts,
 *        DisableInterrupts constants".
 */
#define FTFE_PDD_EnableInterrupts(peripheralBase, Mask) ( \
    FTFE_FCNFG_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(( \
       FTFE_FCNFG_REG(peripheralBase)) & ( \
       (uint8_t)(~(uint8_t)(FTFE_FCNFG_CCIE_MASK | FTFE_FCNFG_RDCOLLIE_MASK))))) | ( \
      (uint8_t)(Mask))) \
  )

/* ----------------------------------------------------------------------------
   -- DisableInterrupts
   ---------------------------------------------------------------------------- */

/**
 * Disables Command commplete end Read collision error interrupts.
 * @param peripheralBase Peripheral base address.
 * @param Mask Interrupt mask Use constants from group "EnableInterrupts,
 *        DisableInterrupts constants".
 */
#define FTFE_PDD_DisableInterrupts(peripheralBase, Mask) ( \
    FTFE_FCNFG_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(( \
       FTFE_FCNFG_REG(peripheralBase)) & ( \
       (uint8_t)(~(uint8_t)(FTFE_FCNFG_CCIE_MASK | FTFE_FCNFG_RDCOLLIE_MASK))))) | ( \
      (uint8_t)(( \
       (uint8_t)(~(uint8_t)(Mask))) & ( \
       (uint8_t)(FTFE_FCNFG_CCIE_MASK | FTFE_FCNFG_RDCOLLIE_MASK))))) \
  )

/* ----------------------------------------------------------------------------
   -- SuspendErasing
   ---------------------------------------------------------------------------- */

/**
 * Suspends the current Erase Flash Sector command execution.
 * @param peripheralBase Peripheral base address.
 */
#define FTFE_PDD_SuspendErasing(peripheralBase) ( \
    FTFE_FCNFG_REG(peripheralBase) |= \
     FTFE_FCNFG_ERSSUSP_MASK \
  )

/* ----------------------------------------------------------------------------
   -- GetRAMReady
   ---------------------------------------------------------------------------- */

/**
 * Returns the value of the Ram ready bit.
 * @param peripheralBase Peripheral base address.
 */
#define FTFE_PDD_GetRAMReady(peripheralBase) ( \
    (uint8_t)(FTFE_FCNFG_REG(peripheralBase) & FTFE_FCNFG_RAMRDY_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetEEEReady
   ---------------------------------------------------------------------------- */

/**
 * Returns the value of the EEE ready bit.
 * @param peripheralBase Peripheral base address.
 */
#define FTFE_PDD_GetEEEReady(peripheralBase) ( \
    (uint8_t)(FTFE_FCNFG_REG(peripheralBase) & FTFE_FCNFG_EEERDY_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- ReadSecurityReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the value of the Security register.
 * @param peripheralBase Peripheral base address.
 */
#define FTFE_PDD_ReadSecurityReg(peripheralBase) ( \
    FTFE_FSEC_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- GetBackdoorEnable
   ---------------------------------------------------------------------------- */

/**
 * Returns the constant FTFL_PDD_BACKDOOR_KEY_ENABLED if backdoor key access is
 * enabled else returns the FTFL_PDD_BACKDOOR_KEY_DISABLED constant.
 * @param peripheralBase Peripheral base address.
 */
#define FTFE_PDD_GetBackdoorEnable(peripheralBase) ( \
    (( \
      (uint8_t)(( \
       (uint8_t)(FTFE_FSEC_REG(peripheralBase) & FTFE_FSEC_KEYEN_MASK)) >> ( \
       FTFE_FSEC_KEYEN_SHIFT))) == ( \
      0x2U)) ? ( \
      FTFE_PDD_BACKDOOR_KEY_ENABLED) : ( \
      FTFE_PDD_BACKDOOR_KEY_DISABLED) \
  )

/* ----------------------------------------------------------------------------
   -- GetSecurityState
   ---------------------------------------------------------------------------- */

/**
 * Returns the constant FTFL_PDD_SECURED if MCU is in secure state else returns
 * the FTFL_PDD_UNSECURED constant.
 * @param peripheralBase Peripheral base address.
 */
#define FTFE_PDD_GetSecurityState(peripheralBase) ( \
    ((uint8_t)(FTFE_FSEC_REG(peripheralBase) & FTFE_FSEC_SEC_MASK) == 0x2U) ? ( \
      FTFE_PDD_UNSECURED) : ( \
      FTFE_PDD_SECURED) \
  )

/* ----------------------------------------------------------------------------
   -- ReadOptionReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the value of the Optional register.
 * @param peripheralBase Peripheral base address.
 */
#define FTFE_PDD_ReadOptionReg(peripheralBase) ( \
    FTFE_FOPT_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- ReadFCCOB0Reg
   ---------------------------------------------------------------------------- */

/**
 * Returns the value of the Common command object register 0.
 * @param peripheralBase Peripheral base address.
 */
#define FTFE_PDD_ReadFCCOB0Reg(peripheralBase) ( \
    FTFE_FCCOB0_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- ReadFCCOB1Reg
   ---------------------------------------------------------------------------- */

/**
 * Returns the value of the Common command object register 1.
 * @param peripheralBase Peripheral base address.
 */
#define FTFE_PDD_ReadFCCOB1Reg(peripheralBase) ( \
    FTFE_FCCOB1_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- ReadFCCOB2Reg
   ---------------------------------------------------------------------------- */

/**
 * Returns the value of the Common command object register 2.
 * @param peripheralBase Peripheral base address.
 */
#define FTFE_PDD_ReadFCCOB2Reg(peripheralBase) ( \
    FTFE_FCCOB2_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- ReadFCCOB3Reg
   ---------------------------------------------------------------------------- */

/**
 * Returns the value of the Common command object register 3.
 * @param peripheralBase Peripheral base address.
 */
#define FTFE_PDD_ReadFCCOB3Reg(peripheralBase) ( \
    FTFE_FCCOB3_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- ReadFCCOB4Reg
   ---------------------------------------------------------------------------- */

/**
 * Returns the value of the Common command object register 4.
 * @param peripheralBase Peripheral base address.
 */
#define FTFE_PDD_ReadFCCOB4Reg(peripheralBase) ( \
    FTFE_FCCOB4_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- ReadFCCOB5Reg
   ---------------------------------------------------------------------------- */

/**
 * Returns the value of the Common command object register 5.
 * @param peripheralBase Peripheral base address.
 */
#define FTFE_PDD_ReadFCCOB5Reg(peripheralBase) ( \
    FTFE_FCCOB5_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- ReadFCCOB6Reg
   ---------------------------------------------------------------------------- */

/**
 * Returns the value of the Common command object register 6.
 * @param peripheralBase Peripheral base address.
 */
#define FTFE_PDD_ReadFCCOB6Reg(peripheralBase) ( \
    FTFE_FCCOB6_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- ReadFCCOB7Reg
   ---------------------------------------------------------------------------- */

/**
 * Returns the value of the Common command object register 7.
 * @param peripheralBase Peripheral base address.
 */
#define FTFE_PDD_ReadFCCOB7Reg(peripheralBase) ( \
    FTFE_FCCOB7_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- ReadFCCOB8Reg
   ---------------------------------------------------------------------------- */

/**
 * Returns the value of the Common command object register 8.
 * @param peripheralBase Peripheral base address.
 */
#define FTFE_PDD_ReadFCCOB8Reg(peripheralBase) ( \
    FTFE_FCCOB8_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- ReadFCCOB9Reg
   ---------------------------------------------------------------------------- */

/**
 * Returns the value of the Common command object register 9.
 * @param peripheralBase Peripheral base address.
 */
#define FTFE_PDD_ReadFCCOB9Reg(peripheralBase) ( \
    FTFE_FCCOB9_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- ReadFCCOBAReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the value of the Common command object register A.
 * @param peripheralBase Peripheral base address.
 */
#define FTFE_PDD_ReadFCCOBAReg(peripheralBase) ( \
    FTFE_FCCOBA_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- ReadFCCOBBReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the value of the Common command object register B.
 * @param peripheralBase Peripheral base address.
 */
#define FTFE_PDD_ReadFCCOBBReg(peripheralBase) ( \
    FTFE_FCCOBB_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteFCCOB0Reg
   ---------------------------------------------------------------------------- */

/**
 * Writes the value to the FCCOB0 register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value written to the FCCOB0 register.
 */
#define FTFE_PDD_WriteFCCOB0Reg(peripheralBase, Value) ( \
    FTFE_FCCOB0_REG(peripheralBase) = \
     (uint8_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- WriteFCCOB1Reg
   ---------------------------------------------------------------------------- */

/**
 * Writes the value to the FCCOB1 register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value written to the FCCOB1 register.
 */
#define FTFE_PDD_WriteFCCOB1Reg(peripheralBase, Value) ( \
    FTFE_FCCOB1_REG(peripheralBase) = \
     (uint8_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- WriteFCCOB2Reg
   ---------------------------------------------------------------------------- */

/**
 * Writes the value to the FCCOB2 register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value written to the FCCOB2 register.
 */
#define FTFE_PDD_WriteFCCOB2Reg(peripheralBase, Value) ( \
    FTFE_FCCOB2_REG(peripheralBase) = \
     (uint8_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- WriteFCCOB3Reg
   ---------------------------------------------------------------------------- */

/**
 * Writes the value to the FCCOB3register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value written to the FCCOB3 register.
 */
#define FTFE_PDD_WriteFCCOB3Reg(peripheralBase, Value) ( \
    FTFE_FCCOB3_REG(peripheralBase) = \
     (uint8_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- WriteFCCOB4Reg
   ---------------------------------------------------------------------------- */

/**
 * Writes the value to the FCCOB4 register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value written to the FCCOB4 register.
 */
#define FTFE_PDD_WriteFCCOB4Reg(peripheralBase, Value) ( \
    FTFE_FCCOB4_REG(peripheralBase) = \
     (uint8_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- WriteFCCOB5Reg
   ---------------------------------------------------------------------------- */

/**
 * Writes the value to the FCCOB5 register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value written to the FCCOB5 register.
 */
#define FTFE_PDD_WriteFCCOB5Reg(peripheralBase, Value) ( \
    FTFE_FCCOB5_REG(peripheralBase) = \
     (uint8_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- WriteFCCOB6Reg
   ---------------------------------------------------------------------------- */

/**
 * Writes the value to the FCCOB6 register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value written to the FCCOB6 register.
 */
#define FTFE_PDD_WriteFCCOB6Reg(peripheralBase, Value) ( \
    FTFE_FCCOB6_REG(peripheralBase) = \
     (uint8_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- WriteFCCOB7Reg
   ---------------------------------------------------------------------------- */

/**
 * Writes the value to the FCCOB7 register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value written to the FCCOB7 register.
 */
#define FTFE_PDD_WriteFCCOB7Reg(peripheralBase, Value) ( \
    FTFE_FCCOB7_REG(peripheralBase) = \
     (uint8_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- WriteFCCOB8Reg
   ---------------------------------------------------------------------------- */

/**
 * Writes the value to the FCCOB8 register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value written to the FCCOB8 register.
 */
#define FTFE_PDD_WriteFCCOB8Reg(peripheralBase, Value) ( \
    FTFE_FCCOB8_REG(peripheralBase) = \
     (uint8_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- WriteFCCOB9Reg
   ---------------------------------------------------------------------------- */

/**
 * Writes the value to the FCCOB9 register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value written to the FCCOB9 register.
 */
#define FTFE_PDD_WriteFCCOB9Reg(peripheralBase, Value) ( \
    FTFE_FCCOB9_REG(peripheralBase) = \
     (uint8_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- WriteFCCOBAReg
   ---------------------------------------------------------------------------- */

/**
 * Writes the value to the FCCOBA register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value written to the FCCOBA register.
 */
#define FTFE_PDD_WriteFCCOBAReg(peripheralBase, Value) ( \
    FTFE_FCCOBA_REG(peripheralBase) = \
     (uint8_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- WriteFCCOBBReg
   ---------------------------------------------------------------------------- */

/**
 * Writes the value to the FCCOBB register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value written to the FCCOBB register.
 */
#define FTFE_PDD_WriteFCCOBBReg(peripheralBase, Value) ( \
    FTFE_FCCOBB_REG(peripheralBase) = \
     (uint8_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- SetFCCOBCommand
   ---------------------------------------------------------------------------- */

/**
 * Writes the value to the FCCOB Command register.
 * @param peripheralBase Peripheral base address.
 * @param Command Value written to the FCCOB Command register.
 */
#define FTFE_PDD_SetFCCOBCommand(peripheralBase, Command) ( \
    FTFE_FCCOB0_REG(peripheralBase) = \
     (uint8_t)(Command) \
  )

/* ----------------------------------------------------------------------------
   -- SetFCCOBAddress
   ---------------------------------------------------------------------------- */

/**
 * Writes the value to the FCCOB Address register.
 * @param peripheralBase Peripheral base address.
 * @param Address Value written to the FCCOB Address register.
 */
#define FTFE_PDD_SetFCCOBAddress(peripheralBase, Address) ( \
    (FTFE_FCCOB3_REG(peripheralBase) = \
     (uint8_t)(Address)), \
    ((FTFE_FCCOB2_REG(peripheralBase) = \
     (uint8_t)((uint32_t)(Address) >> 8U)), \
    (FTFE_FCCOB1_REG(peripheralBase) = \
     (uint8_t)((uint32_t)(Address) >> 16U))) \
  )

/* ----------------------------------------------------------------------------
   -- WriteFCCOBData0
   ---------------------------------------------------------------------------- */

/**
 * Writes Data byte 0.
 * @param peripheralBase Peripheral base address.
 * @param Data Value written to the FCCOB Data 0 register.
 */
#define FTFE_PDD_WriteFCCOBData0(peripheralBase, Data) ( \
    FTFE_FCCOB4_REG(peripheralBase) = \
     (uint8_t)(Data) \
  )

/* ----------------------------------------------------------------------------
   -- WriteFCCOBData1
   ---------------------------------------------------------------------------- */

/**
 * Writes Data byte 1.
 * @param peripheralBase Peripheral base address.
 * @param Data Value written to the FCCOB Data 1 register.
 */
#define FTFE_PDD_WriteFCCOBData1(peripheralBase, Data) ( \
    FTFE_FCCOB5_REG(peripheralBase) = \
     (uint8_t)(Data) \
  )

/* ----------------------------------------------------------------------------
   -- WriteFCCOBData2
   ---------------------------------------------------------------------------- */

/**
 * Writes Data byte 2.
 * @param peripheralBase Peripheral base address.
 * @param Data Value written to the FCCOB Data 2 register.
 */
#define FTFE_PDD_WriteFCCOBData2(peripheralBase, Data) ( \
    FTFE_FCCOB6_REG(peripheralBase) = \
     (uint8_t)(Data) \
  )

/* ----------------------------------------------------------------------------
   -- WriteFCCOBData3
   ---------------------------------------------------------------------------- */

/**
 * Writes Data byte 3.
 * @param peripheralBase Peripheral base address.
 * @param Data Value written to the FCCOB Data 3 register.
 */
#define FTFE_PDD_WriteFCCOBData3(peripheralBase, Data) ( \
    FTFE_FCCOB7_REG(peripheralBase) = \
     (uint8_t)(Data) \
  )

/* ----------------------------------------------------------------------------
   -- WriteFCCOBData4
   ---------------------------------------------------------------------------- */

/**
 * Writes Data byte 4.
 * @param peripheralBase Peripheral base address.
 * @param Data Value written to the FCCOB Data 4 register.
 */
#define FTFE_PDD_WriteFCCOBData4(peripheralBase, Data) ( \
    FTFE_FCCOB8_REG(peripheralBase) = \
     (uint8_t)(Data) \
  )

/* ----------------------------------------------------------------------------
   -- WriteFCCOBData5
   ---------------------------------------------------------------------------- */

/**
 * Writes Data byte 5.
 * @param peripheralBase Peripheral base address.
 * @param Data Value written to the FCCOB Data 5 register.
 */
#define FTFE_PDD_WriteFCCOBData5(peripheralBase, Data) ( \
    FTFE_FCCOB9_REG(peripheralBase) = \
     (uint8_t)(Data) \
  )

/* ----------------------------------------------------------------------------
   -- WriteFCCOBData6
   ---------------------------------------------------------------------------- */

/**
 * Writes Data byte 6.
 * @param peripheralBase Peripheral base address.
 * @param Data Value written to the FCCOB Data 6 register.
 */
#define FTFE_PDD_WriteFCCOBData6(peripheralBase, Data) ( \
    FTFE_FCCOBA_REG(peripheralBase) = \
     (uint8_t)(Data) \
  )

/* ----------------------------------------------------------------------------
   -- WriteFCCOBData7
   ---------------------------------------------------------------------------- */

/**
 * Writes Data byte 7.
 * @param peripheralBase Peripheral base address.
 * @param Data Value written to the FCCOB Data 7 register.
 */
#define FTFE_PDD_WriteFCCOBData7(peripheralBase, Data) ( \
    FTFE_FCCOBB_REG(peripheralBase) = \
     (uint8_t)(Data) \
  )

/* ----------------------------------------------------------------------------
   -- WriteFCCOBLongWordData
   ---------------------------------------------------------------------------- */

/**
 * Sets longword data to be programmed.
 * @param peripheralBase Peripheral base address.
 * @param Data Value written to the Flash in the CPU native endian format.
 */
#define FTFE_PDD_WriteFCCOBLongWordData(peripheralBase, Data) ( \
    (FTFE_FCCOB4_REG(peripheralBase) = \
     (uint8_t)((uint32_t)(Data) >> 24U)), \
    ((FTFE_FCCOB5_REG(peripheralBase) = \
     (uint8_t)((uint32_t)(Data) >> 16U)), \
    ((FTFE_FCCOB6_REG(peripheralBase) = \
     (uint8_t)((uint32_t)(Data) >> 8U)), \
    (FTFE_FCCOB7_REG(peripheralBase) = \
     (uint8_t)(Data)))) \
  )

/* ----------------------------------------------------------------------------
   -- WriteFCCOBFirstLongWordData
   ---------------------------------------------------------------------------- */

/**
 * Sets first longword data to be programmed.
 * @param peripheralBase Peripheral base address.
 * @param Data Value written to the Flash in the CPU native endian format.
 */
#define FTFE_PDD_WriteFCCOBFirstLongWordData(peripheralBase, Data) ( \
    (FTFE_FCCOB4_REG(peripheralBase) = \
     (uint8_t)((uint32_t)(Data) >> 24U)), \
    ((FTFE_FCCOB5_REG(peripheralBase) = \
     (uint8_t)((uint32_t)(Data) >> 16U)), \
    ((FTFE_FCCOB6_REG(peripheralBase) = \
     (uint8_t)((uint32_t)(Data) >> 8U)), \
    (FTFE_FCCOB7_REG(peripheralBase) = \
     (uint8_t)(Data)))) \
  )

/* ----------------------------------------------------------------------------
   -- WriteFCCOBSecondLongWordData
   ---------------------------------------------------------------------------- */

/**
 * Sets second longword data to be programmed.
 * @param peripheralBase Peripheral base address.
 * @param Data Value written to the Flash in the CPU native endian format.
 */
#define FTFE_PDD_WriteFCCOBSecondLongWordData(peripheralBase, Data) ( \
    (FTFE_FCCOB8_REG(peripheralBase) = \
     (uint8_t)((uint32_t)(Data) >> 24U)), \
    ((FTFE_FCCOB9_REG(peripheralBase) = \
     (uint8_t)((uint32_t)(Data) >> 16U)), \
    ((FTFE_FCCOBA_REG(peripheralBase) = \
     (uint8_t)((uint32_t)(Data) >> 8U)), \
    (FTFE_FCCOBB_REG(peripheralBase) = \
     (uint8_t)(Data)))) \
  )

/* ----------------------------------------------------------------------------
   -- SetPFlashProtectionState
   ---------------------------------------------------------------------------- */

/**
 * Sets program Flash protection state.
 * @param peripheralBase Peripheral base address.
 * @param Regions Protected regions.
 * @param State Requested state.
 */
#define FTFE_PDD_SetPFlashProtectionState(peripheralBase, Regions, State) ( \
    ((State) == FTFE_PDD_UNPROTECTED) ? ( \
      *(uint32_t *)(void *)&(FTFE_FPROT3_REG(peripheralBase)) |= \
      (uint32_t)(Regions)) : ( \
      *(uint32_t *)(void *)&(FTFE_FPROT3_REG(peripheralBase)) &= \
      (uint32_t)(~(uint32_t)(Regions))) \
  )

/* ----------------------------------------------------------------------------
   -- GetPFlashProtectionState
   ---------------------------------------------------------------------------- */

/**
 * Returns program falsh protection state.
 * @param peripheralBase Peripheral base address.
 */
#define FTFE_PDD_GetPFlashProtectionState(peripheralBase) ( \
    (uint32_t)(~(*(uint32_t *)(void *)&(FTFE_FPROT3_REG(peripheralBase)))) \
  )

/* ----------------------------------------------------------------------------
   -- SetDFlashProtectionState
   ---------------------------------------------------------------------------- */

/**
 * Sets data Flash protection state.
 * @param peripheralBase Peripheral base address.
 * @param Regions FTFL_PDD_PROTECTED or FTFL_PDD_UNPROTECTED.
 * @param State Requested state.
 */
#define FTFE_PDD_SetDFlashProtectionState(peripheralBase, Regions, State) ( \
    ((State) == FTFE_PDD_UNPROTECTED) ? ( \
      FTFE_FDPROT_REG(peripheralBase) |= \
       (uint8_t)(Regions)) : ( \
      FTFE_FDPROT_REG(peripheralBase) &= \
       (uint8_t)(~(uint8_t)(Regions))) \
  )

/* ----------------------------------------------------------------------------
   -- GetDFlashProtectionState
   ---------------------------------------------------------------------------- */

/**
 * Each bit of the returned value represent 1/8 of the Data FLASH memory. If the
 * bit is set the region is protected else the region is unprotected.
 * @param peripheralBase Peripheral base address.
 */
#define FTFE_PDD_GetDFlashProtectionState(peripheralBase) ( \
    (uint8_t)(~(uint8_t)FTFE_FDPROT_REG(peripheralBase)) \
  )

/* ----------------------------------------------------------------------------
   -- SetEERAMProtectionState
   ---------------------------------------------------------------------------- */

/**
 * Each bit of the Region parameter represent 1/8 of the EERPROM memory. To
 * change the protection state of the region(s) select requested regions (Region
 * param) and set new state (State param).
 * @param peripheralBase Peripheral base address.
 * @param Regions Protected regions.
 * @param State Requested state.
 */
#define FTFE_PDD_SetEERAMProtectionState(peripheralBase, Regions, State) ( \
    ((State) == FTFE_PDD_UNPROTECTED) ? ( \
      FTFE_FEPROT_REG(peripheralBase) |= \
       (uint8_t)(Regions)) : ( \
      FTFE_FEPROT_REG(peripheralBase) &= \
       (uint8_t)(~(uint8_t)(Regions))) \
  )

/* ----------------------------------------------------------------------------
   -- GetEERAMProtectionState
   ---------------------------------------------------------------------------- */

/**
 * Each bit of the returned value represent 1/8 of the EERPROM memory. If the
 * bit is set the region is protected else the region is unprotected.
 * @param peripheralBase Peripheral base address.
 */
#define FTFE_PDD_GetEERAMProtectionState(peripheralBase) ( \
    (uint8_t)(~(uint8_t)FTFE_FEPROT_REG(peripheralBase)) \
  )
#endif  /* #if defined(FTFE_PDD_H_) */

/* FTFE_PDD.h, eof. */
