/*
  PDD layer implementation for peripheral type COP
  (C) 2010 Freescale, Inc. All rights reserved.

  This file is static and it is generated from API-Factory
*/

#if !defined(COP_PDD_H_)
#define COP_PDD_H_

/* ----------------------------------------------------------------------------
   -- Test if supported MCU is active
   ---------------------------------------------------------------------------- */

#if !defined(MCU_ACTIVE)
  // No MCU is active
  #error COP PDD library: No derivative is active. Place proper #include with PDD memory map before including PDD library.
#elif \
      !defined(MCU_MKL04Z4) /* COP */ && \
      !defined(MCU_MKL05Z4) /* COP */ && \
      !defined(MCU_MKL14Z4) /* COP */ && \
      !defined(MCU_MKL15Z4) /* COP */ && \
      !defined(MCU_MKL24Z4) /* COP */ && \
      !defined(MCU_MKL25Z4) /* COP */
  // Unsupported MCU is active
  #error COP PDD library: Unsupported derivative is active.
#endif

#include "PDD_Types.h"

/* ----------------------------------------------------------------------------
   -- Method symbol definitions
   ---------------------------------------------------------------------------- */

/* Service constants */
#define COP_PDD_KEY_1 0x55U                      /**< First key */
#define COP_PDD_KEY_2 0xAAU                      /**< Second key */


/* ----------------------------------------------------------------------------
   -- GetEnableDeviceStatus
   ---------------------------------------------------------------------------- */

/**
 * Returns current state of the COP device.
 * @param peripheralBase Peripheral base address.
 */
#define COP_PDD_GetEnableDeviceStatus(peripheralBase) ( \
    (uint8_t)(SIM_COPC_REG(peripheralBase) & SIM_COPC_COPT_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- WriteControlReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the control register.
 * @param peripheralBase Peripheral base address.
 * @param Value New content of the control register.
 */
#define COP_PDD_WriteControlReg(peripheralBase, Value) ( \
    SIM_COPC_REG(peripheralBase) = (Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadControlReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the control register.
 * @param peripheralBase Peripheral base address.
 */
#define COP_PDD_ReadControlReg(peripheralBase) ( \
    SIM_COPC_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteServiceReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the service COP register.
 * @param peripheralBase Peripheral base address.
 * @param Value Service constant.
 */
#define COP_PDD_WriteServiceReg(peripheralBase, Value) ( \
    SIM_SRVCOP_REG(peripheralBase) = (Value) \
  )
#endif  /* #if defined(COP_PDD_H_) */

/* COP_PDD.h, eof. */
