/*
  PDD layer implementation for peripheral type CMT
  (C) 2010 Freescale, Inc. All rights reserved.

  This file is static and it is generated from API-Factory
*/

#if !defined(CMT_PDD_H_)
#define CMT_PDD_H_

/* ----------------------------------------------------------------------------
   -- Test if supported MCU is active
   ---------------------------------------------------------------------------- */

#if !defined(MCU_ACTIVE)
  // No MCU is active
  #error CMT PDD library: No derivative is active. Place proper #include with PDD memory map before including PDD library.
#elif \
      !defined(MCU_MK10D10) /* CMT */ && \
      !defined(MCU_MK10D5) /* CMT */ && \
      !defined(MCU_MK10D7) /* CMT */ && \
      !defined(MCU_MK10F12) /* CMT */ && \
      !defined(MCU_MK10DZ10) /* CMT */ && \
      !defined(MCU_MK11D5) /* CMT */ && \
      !defined(MCU_MK12D5) /* CMT */ && \
      !defined(MCU_MK20D10) /* CMT */ && \
      !defined(MCU_MK20D5) /* CMT */ && \
      !defined(MCU_MK20D7) /* CMT */ && \
      !defined(MCU_MK20F12) /* CMT */ && \
      !defined(MCU_MK20DZ10) /* CMT */ && \
      !defined(MCU_MK21D5) /* CMT */ && \
      !defined(MCU_MK22D5) /* CMT */ && \
      !defined(MCU_MK30D10) /* CMT */ && \
      !defined(MCU_MK30D7) /* CMT */ && \
      !defined(MCU_MK30DZ10) /* CMT */ && \
      !defined(MCU_MK40D10) /* CMT */ && \
      !defined(MCU_MK40D7) /* CMT */ && \
      !defined(MCU_MK40DZ10) /* CMT */ && \
      !defined(MCU_MK40X256VMD100) /* CMT */ && \
      !defined(MCU_MK50D10) /* CMT */ && \
      !defined(MCU_MK50D7) /* CMT */ && \
      !defined(MCU_MK50DZ10) /* CMT */ && \
      !defined(MCU_MK51D10) /* CMT */ && \
      !defined(MCU_MK51D7) /* CMT */ && \
      !defined(MCU_MK51DZ10) /* CMT */ && \
      !defined(MCU_MK52D10) /* CMT */ && \
      !defined(MCU_MK52DZ10) /* CMT */ && \
      !defined(MCU_MK53D10) /* CMT */ && \
      !defined(MCU_MK53DZ10) /* CMT */ && \
      !defined(MCU_MK60D10) /* CMT */ && \
      !defined(MCU_MK60F12) /* CMT */ && \
      !defined(MCU_MK60F15) /* CMT */ && \
      !defined(MCU_MK60DZ10) /* CMT */ && \
      !defined(MCU_MK60N512VMD100) /* CMT */ && \
      !defined(MCU_MK61F12) /* CMT */ && \
      !defined(MCU_MK61F15) /* CMT */ && \
      !defined(MCU_MK70F12) /* CMT */ && \
      !defined(MCU_MK70F15) /* CMT */ && \
      !defined(MCU_PCK20L4) /* CMT */
  // Unsupported MCU is active
  #error CMT PDD library: Unsupported derivative is active.
#endif

#include "PDD_Types.h"

/* ----------------------------------------------------------------------------
   -- Method symbol definitions
   ---------------------------------------------------------------------------- */

/* Enable baseband constants */
#define CMT_PDD_BASEBAND_DISABLED 0U             /**< Disabled */
#define CMT_PDD_BASEBAND_ENABLED CMT_MSC_BASE_MASK /**< Enabled */

/* Enable FSK constants */
#define CMT_PDD_MODE_TIME_BASEBAND 0U            /**< Time baseband */
#define CMT_PDD_MODE_FSK CMT_MSC_FSK_MASK        /**< FSK */

/* Divider constants */
#define CMT_PDD_DIVIDER_1 0U                     /**< 1 */
#define CMT_PDD_DIVIDER_2 0x1U                   /**< 2 */
#define CMT_PDD_DIVIDER_4 0x2U                   /**< 4 */
#define CMT_PDD_DIVIDER_8 0x3U                   /**< 8 */

/* Prescaler constants */
#define CMT_PDD_PRESCALER_1 0U                   /**< 1 */
#define CMT_PDD_PRESCALER_2 0x1U                 /**< 2 */
#define CMT_PDD_PRESCALER_3 0x2U                 /**< 3 */
#define CMT_PDD_PRESCALER_4 0x3U                 /**< 4 */
#define CMT_PDD_PRESCALER_5 0x4U                 /**< 5 */
#define CMT_PDD_PRESCALER_6 0x5U                 /**< 6 */
#define CMT_PDD_PRESCALER_7 0x6U                 /**< 7 */
#define CMT_PDD_PRESCALER_8 0x7U                 /**< 8 */
#define CMT_PDD_PRESCALER_9 0x8U                 /**< 9 */
#define CMT_PDD_PRESCALER_10 0x9U                /**< 10 */
#define CMT_PDD_PRESCALER_11 0xAU                /**< 11 */
#define CMT_PDD_PRESCALER_12 0xBU                /**< 12 */
#define CMT_PDD_PRESCALER_13 0xCU                /**< 13 */
#define CMT_PDD_PRESCALER_14 0xDU                /**< 14 */
#define CMT_PDD_PRESCALER_15 0xEU                /**< 15 */
#define CMT_PDD_PRESCALER_16 0xFU                /**< 16 */

/* IRO pin constants */
#define CMT_PDD_PIN_DISABLED 0U                  /**< Disabled */
#define CMT_PDD_PIN_ENABLED CMT_OC_IROPEN_MASK   /**< Enabled */

/* CMT output polarity constants */
#define CMT_PDD_POLARITY_LOW 0U                  /**< Low */
#define CMT_PDD_POLARITY_HIGH CMT_OC_CMTPOL_MASK /**< High */

/* IRO latch constants */
#define CMT_PDD_LATCH_LOW 0U                     /**< Low */
#define CMT_PDD_LATCH_HIGH CMT_OC_IROL_MASK      /**< High */


/* ----------------------------------------------------------------------------
   -- GetInterruptMask
   ---------------------------------------------------------------------------- */

/**
 * Returns interrupt mask.
 * @param peripheralBase Peripheral base address.
 */
#define CMT_PDD_GetInterruptMask(peripheralBase) ( \
    (uint8_t)(CMT_MSC_REG(peripheralBase) & CMT_MSC_EOCIE_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Returns interrupt flag bit.
 * @param peripheralBase Peripheral base address.
 */
#define CMT_PDD_GetInterruptFlag(peripheralBase) ( \
    (uint8_t)(CMT_MSC_REG(peripheralBase) & CMT_MSC_EOCF_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- EnableInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables the CMT interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define CMT_PDD_EnableInterrupt(peripheralBase) ( \
    CMT_MSC_REG(peripheralBase) |= \
     CMT_MSC_EOCIE_MASK \
  )

/* ----------------------------------------------------------------------------
   -- DisableInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables the CMT interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define CMT_PDD_DisableInterrupt(peripheralBase) ( \
    CMT_MSC_REG(peripheralBase) &= \
     (uint8_t)(~(uint8_t)CMT_MSC_EOCIE_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- ClearInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Clears CMT interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define CMT_PDD_ClearInterruptFlag(peripheralBase) ( \
    (void)CMT_MSC_REG(peripheralBase), \
    (void)CMT_CMD2_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- EnableBaseband
   ---------------------------------------------------------------------------- */

/**
 * Configures the freerun mode.
 * @param peripheralBase Peripheral base address.
 * @param Baseband New value of the baseband.
 */
#define CMT_PDD_EnableBaseband(peripheralBase, Baseband) ( \
    CMT_MSC_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(CMT_MSC_REG(peripheralBase) & (uint8_t)(~(uint8_t)CMT_MSC_BASE_MASK))) | ( \
      (uint8_t)(Baseband))) \
  )

/* ----------------------------------------------------------------------------
   -- SelectFskMode
   ---------------------------------------------------------------------------- */

/**
 * Configures the mode operation.
 * @param peripheralBase Peripheral base address.
 * @param Mode New value of the mode.
 */
#define CMT_PDD_SelectFskMode(peripheralBase, Mode) ( \
    CMT_MSC_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(CMT_MSC_REG(peripheralBase) & (uint8_t)(~(uint8_t)CMT_MSC_FSK_MASK))) | ( \
      (uint8_t)(Mode))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableExtendedSpace
   ---------------------------------------------------------------------------- */

/**
 * Configures extended space.
 * @param peripheralBase Peripheral base address.
 * @param Extended Extended space enabled/disabled.
 */
#define CMT_PDD_EnableExtendedSpace(peripheralBase, Extended) ( \
    CMT_MSC_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(CMT_MSC_REG(peripheralBase) & (uint8_t)(~(uint8_t)CMT_MSC_EXSPC_MASK))) | ( \
      (uint8_t)((uint8_t)(Extended) << CMT_MSC_EXSPC_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableDevice
   ---------------------------------------------------------------------------- */

/**
 * Enables the CMT device.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state of CMT device.
 */
#define CMT_PDD_EnableDevice(peripheralBase, State) ( \
    CMT_MSC_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(CMT_MSC_REG(peripheralBase) & (uint8_t)(~(uint8_t)CMT_MSC_MCGEN_MASK))) | ( \
      (uint8_t)(State))) \
  )

/* ----------------------------------------------------------------------------
   -- GetEnableDeviceStatus
   ---------------------------------------------------------------------------- */

/**
 * Returns current state of CMT device.
 * @param peripheralBase Peripheral base address.
 */
#define CMT_PDD_GetEnableDeviceStatus(peripheralBase) ( \
    (uint8_t)(CMT_MSC_REG(peripheralBase) & CMT_MSC_MCGEN_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- SetDivider
   ---------------------------------------------------------------------------- */

/**
 * Sets clock divide prescale value.
 * @param peripheralBase Peripheral base address.
 * @param Divider New value of the divider.
 */
#define CMT_PDD_SetDivider(peripheralBase, Divider) ( \
    CMT_MSC_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(CMT_MSC_REG(peripheralBase) & (uint8_t)(~(uint8_t)CMT_MSC_CMTDIV_MASK))) | ( \
      (uint8_t)((uint8_t)(Divider) << CMT_MSC_CMTDIV_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- SetPrescaler
   ---------------------------------------------------------------------------- */

/**
 * Sets primary prescale value.
 * @param peripheralBase Peripheral base address.
 * @param Prescaler New value of the prescaler.
 */
#define CMT_PDD_SetPrescaler(peripheralBase, Prescaler) ( \
    CMT_PPS_REG(peripheralBase) = \
     (uint8_t)(Prescaler) \
  )

/* ----------------------------------------------------------------------------
   -- EnableIroPin
   ---------------------------------------------------------------------------- */

/**
 * Enables IRO signal.
 * @param peripheralBase Peripheral base address.
 * @param Pin New value of the IROpin.
 */
#define CMT_PDD_EnableIroPin(peripheralBase, Pin) ( \
    CMT_OC_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(CMT_OC_REG(peripheralBase) & (uint8_t)(~(uint8_t)CMT_OC_IROPEN_MASK))) | ( \
      (uint8_t)(Pin))) \
  )

/* ----------------------------------------------------------------------------
   -- SetPolarity
   ---------------------------------------------------------------------------- */

/**
 * Configures CMT output polarity.
 * @param peripheralBase Peripheral base address.
 * @param Polarity New value of the polarity.
 */
#define CMT_PDD_SetPolarity(peripheralBase, Polarity) ( \
    CMT_OC_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(CMT_OC_REG(peripheralBase) & (uint8_t)(~(uint8_t)CMT_OC_CMTPOL_MASK))) | ( \
      (uint8_t)(Polarity))) \
  )

/* ----------------------------------------------------------------------------
   -- SetLatch
   ---------------------------------------------------------------------------- */

/**
 * Configures IRO latch.
 * @param peripheralBase Peripheral base address.
 * @param State New value of the latch.
 */
#define CMT_PDD_SetLatch(peripheralBase, State) ( \
    CMT_OC_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(CMT_OC_REG(peripheralBase) & (uint8_t)(~(uint8_t)CMT_OC_IROL_MASK))) | ( \
      (uint8_t)(State))) \
  )

/* ----------------------------------------------------------------------------
   -- WriteHighData1Reg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the CGH1 register.
 * @param peripheralBase Peripheral base address.
 * @param Value New content of the CGH1 register.
 */
#define CMT_PDD_WriteHighData1Reg(peripheralBase, Value) ( \
    CMT_CGH1_REG(peripheralBase) = \
     (uint8_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadHighData1Reg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the CGH1 register.
 * @param peripheralBase Peripheral base address.
 */
#define CMT_PDD_ReadHighData1Reg(peripheralBase) ( \
    CMT_CGH1_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteLowData1Reg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the CGL1 register.
 * @param peripheralBase Peripheral base address.
 * @param Value New content of the CGL1 register.
 */
#define CMT_PDD_WriteLowData1Reg(peripheralBase, Value) ( \
    CMT_CGL1_REG(peripheralBase) = \
     (uint8_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadLowData1Reg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the CGL1 register.
 * @param peripheralBase Peripheral base address.
 */
#define CMT_PDD_ReadLowData1Reg(peripheralBase) ( \
    CMT_CGL1_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteHighData2Reg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the CGH2 register.
 * @param peripheralBase Peripheral base address.
 * @param Value New content of the CGH2 register.
 */
#define CMT_PDD_WriteHighData2Reg(peripheralBase, Value) ( \
    CMT_CGH2_REG(peripheralBase) = \
     (uint8_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadHighData2Reg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the CGH2 register.
 * @param peripheralBase Peripheral base address.
 */
#define CMT_PDD_ReadHighData2Reg(peripheralBase) ( \
    CMT_CGH2_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteLowData2Reg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the CGL2 register.
 * @param peripheralBase Peripheral base address.
 * @param Value New content of the CGL2 register.
 */
#define CMT_PDD_WriteLowData2Reg(peripheralBase, Value) ( \
    CMT_CGL2_REG(peripheralBase) = \
     (uint8_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadLowData2Reg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the CGL2 register.
 * @param peripheralBase Peripheral base address.
 */
#define CMT_PDD_ReadLowData2Reg(peripheralBase) ( \
    CMT_CGL2_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteMarkHighReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the CMD1 register.
 * @param peripheralBase Peripheral base address.
 * @param Value New content of the CMD1 register.
 */
#define CMT_PDD_WriteMarkHighReg(peripheralBase, Value) ( \
    CMT_CMD1_REG(peripheralBase) = \
     (uint8_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- WriteMarkLowReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the CMD2 register.
 * @param peripheralBase Peripheral base address.
 * @param Value New content of the CMD2 register.
 */
#define CMT_PDD_WriteMarkLowReg(peripheralBase, Value) ( \
    CMT_CMD2_REG(peripheralBase) = \
     (uint8_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- WriteSpaceHighReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the CMD3 register.
 * @param peripheralBase Peripheral base address.
 * @param Value New content of the CMD3 register.
 */
#define CMT_PDD_WriteSpaceHighReg(peripheralBase, Value) ( \
    CMT_CMD3_REG(peripheralBase) = \
     (uint8_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- WriteSpaceLowReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the CMD4 register.
 * @param peripheralBase Peripheral base address.
 * @param Value New content of the CMD4 register.
 */
#define CMT_PDD_WriteSpaceLowReg(peripheralBase, Value) ( \
    CMT_CMD4_REG(peripheralBase) = \
     (uint8_t)(Value) \
  )
#endif  /* #if defined(CMT_PDD_H_) */

/* CMT_PDD.h, eof. */
