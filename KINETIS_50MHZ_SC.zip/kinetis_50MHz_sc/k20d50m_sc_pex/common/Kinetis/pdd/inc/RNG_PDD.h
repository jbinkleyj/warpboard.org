/*
  PDD layer implementation for peripheral type RNG
  (C) 2010 Freescale, Inc. All rights reserved.

  This file is static and it is generated from API-Factory
*/

#if !defined(RNG_PDD_H_)
#define RNG_PDD_H_

/* ----------------------------------------------------------------------------
   -- Test if supported MCU is active
   ---------------------------------------------------------------------------- */

#if !defined(MCU_ACTIVE)
  // No MCU is active
  #error RNG PDD library: No derivative is active. Place proper #include with PDD memory map before including PDD library.
#elif \
      !defined(MCU_MK52DZ10) /* RNG */ && \
      !defined(MCU_MK53DZ10) /* RNG */ && \
      !defined(MCU_MK60DZ10) /* RNG */ && \
      !defined(MCU_MK60N512VMD100) /* RNG */
  // Unsupported MCU is active
  #error RNG PDD library: Unsupported derivative is active.
#endif

#include "PDD_Types.h"

/* ----------------------------------------------------------------------------
   -- Method symbol definitions
   ---------------------------------------------------------------------------- */

/* Auto-reseed constants */
#define RNG_PDD_RESEED_DISABLE 0U                /**< No automatic reseed. */
#define RNG_PDD_RESEED_ENABLE RNG_CR_AR_MASK     /**< Automatic reseed enabled. */

/* FIFO Underflow response mode constants. */
#define RNG_PDD_RET_ZERO 0U                      /**< Return zero. */
#define RNG_PDD_GEN_BUS_ERROR 0x2U               /**< Generate bus error. */
#define RNG_PDD_GEN_INT_RET_ZERO 0x3U            /**< Generate interrupt and return zero. */

/* Status of RNG. */
#define RNG_PDD_STATUS_ERROR 0xFFFFU             /**< Error occured. */
#define RNG_PDD_STATUS_NEW_SEED_DONE 0x40U       /**< New seed done. */
#define RNG_PDD_STATUS_SEED_DONE 0x20U           /**< Seed done. */
#define RNG_PDD_STATUS_SELF_TEST_DONE 0x10U      /**< Self-test done. */
#define RNG_PDD_STATUS_RESEED_NEEDED 0x8U        /**< Reseed needed. */
#define RNG_PDD_STATUS_SLEEP 0x4U                /**< RNG in sleep mode. */
#define RNG_PDD_STATUS_BUSY 0x2U                 /**< RNG is busy. */

/* Extended error mask for status register. */
#define RNG_PDD_SELF_TETS_RESEED_ERROR 0x200000U /**< Reseed error. */
#define RNG_PDD_SELF_TEST_PRNG_ERROR 0x400000U   /**< PRNG error. */
#define RNG_PDD_SELF_TEST_TRNG_ERROR 0x800000U   /**< TRNG error. */
#define RNG_PDD_MONOBIT_TEST_ERROR 0x1000000U    /**< Monobit test error. */
#define RNG_PDD_LENGTH_1_RUN_TEST_ERROR 0x2000000U /**< Length 1 test error. */
#define RNG_PDD_LENGTH_2_RUN_TEST_ERROR 0x4000000U /**< Length 2 test error. */
#define RNG_PDD_LENGTH_3_RUN_TEST_ERROR 0x8000000U /**< Length 3 test error. */
#define RNG_PDD_LENGTH_4_RUN_TEST_ERROR 0x10000000U /**< Length 4 test error. */
#define RNG_PDD_LENGTH_5_RUN_TEST_ERROR 0x20000000U /**< Length 5 test error. */
#define RNG_PDD_LENGTH_6_RUN_TEST_ERROR 0x40000000U /**< Length 6 test error. */
#define RNG_PDD_LONG_RUN_TEST_ERROR 0x80000000U  /**< Long run test error. */

/* Error mask for error status register. */
#define RNG_PDD_LFSR_ERROR 0x1U                  /**< LFSR error. */
#define RNG_PDD_OSCILLATOR_ERROR 0x2U            /**< Oscillator error. */
#define RNG_PDD_SELF_TEST_ERROR 0x4U             /**< Self-test error. */
#define RNG_PDD_FIFO_UNDERFLOW_ERROR 0x8U        /**< FIFO underflow error. */


/* ----------------------------------------------------------------------------
   -- EnableInterrupts
   ---------------------------------------------------------------------------- */

/**
 * Enables error and done interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define RNG_PDD_EnableInterrupts(peripheralBase) ( \
    (RNG_CR_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)RNG_CR_MASKERR_MASK)), \
    (RNG_CR_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)RNG_CR_MASKDONE_MASK)) \
  )

/* ----------------------------------------------------------------------------
   -- DisableInterrupts
   ---------------------------------------------------------------------------- */

/**
 * Disables error and done interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define RNG_PDD_DisableInterrupts(peripheralBase) ( \
    (RNG_CR_REG(peripheralBase) |= \
     RNG_CR_MASKERR_MASK), \
    (RNG_CR_REG(peripheralBase) |= \
     RNG_CR_MASKDONE_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetVersion
   ---------------------------------------------------------------------------- */

/**
 * Returns version of RNG module.
 * @param peripheralBase Peripheral base address.
 */
#define RNG_PDD_GetVersion(peripheralBase) ( \
    (uint16_t)(RNG_VER_REG(peripheralBase) & 0xFFFFU) \
  )

/* ----------------------------------------------------------------------------
   -- ErrorCondition
   ---------------------------------------------------------------------------- */

/**
 * Returns 1 if there is error in RNG module.
 * @param peripheralBase Peripheral base address.
 */
#define RNG_PDD_ErrorCondition(peripheralBase) ( \
    (uint8_t)((uint32_t)(RNG_SR_REG(peripheralBase) & RNG_SR_ERR_MASK) >> RNG_SR_ERR_SHIFT) \
  )

/* ----------------------------------------------------------------------------
   -- Busy
   ---------------------------------------------------------------------------- */

/**
 * Returns 1 if RNG is busy (generating seed, in self test mode...).
 * @param peripheralBase Peripheral base address.
 */
#define RNG_PDD_Busy(peripheralBase) ( \
    (uint8_t)((uint32_t)(RNG_SR_REG(peripheralBase) & RNG_SR_BUSY_MASK) >> RNG_SR_BUSY_SHIFT) \
  )

/* ----------------------------------------------------------------------------
   -- SeedGenerated
   ---------------------------------------------------------------------------- */

/**
 * Returns 1 if the seed was generated since last reset.
 * @param peripheralBase Peripheral base address.
 */
#define RNG_PDD_SeedGenerated(peripheralBase) ( \
    (uint8_t)((uint32_t)(RNG_SR_REG(peripheralBase) & RNG_SR_SDN_MASK) >> RNG_SR_SDN_SHIFT) \
  )

/* ----------------------------------------------------------------------------
   -- SoftReset
   ---------------------------------------------------------------------------- */

/**
 * Performs a software reset of the RNGB.
 * @param peripheralBase Peripheral base address.
 */
#define RNG_PDD_SoftReset(peripheralBase) ( \
    RNG_CMD_REG(peripheralBase) |= \
     RNG_CMD_SR_MASK \
  )

/* ----------------------------------------------------------------------------
   -- ClearErrorAndInterrupts
   ---------------------------------------------------------------------------- */

/**
 * Clears the errors in the RNG_ESR register and the RNGB interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define RNG_PDD_ClearErrorAndInterrupts(peripheralBase) ( \
    (RNG_CMD_REG(peripheralBase) |= \
     RNG_CMD_CE_MASK), \
    (RNG_CMD_REG(peripheralBase) |= \
     RNG_CMD_CI_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- ClearError
   ---------------------------------------------------------------------------- */

/**
 * Clears the errors in the RNG_ESR register.
 * @param peripheralBase Peripheral base address.
 */
#define RNG_PDD_ClearError(peripheralBase) ( \
    RNG_CMD_REG(peripheralBase) |= \
     RNG_CMD_CE_MASK \
  )

/* ----------------------------------------------------------------------------
   -- ClearInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Clears the RNGB interrupt if an error is not present.
 * @param peripheralBase Peripheral base address.
 */
#define RNG_PDD_ClearInterrupt(peripheralBase) ( \
    RNG_CMD_REG(peripheralBase) |= \
     RNG_CMD_CI_MASK \
  )

/* ----------------------------------------------------------------------------
   -- GenerateSeed
   ---------------------------------------------------------------------------- */

/**
 * Initiates the seed generation process.
 * @param peripheralBase Peripheral base address.
 */
#define RNG_PDD_GenerateSeed(peripheralBase) ( \
    RNG_CMD_REG(peripheralBase) |= \
     RNG_CMD_GS_MASK \
  )

/* ----------------------------------------------------------------------------
   -- SelfTest
   ---------------------------------------------------------------------------- */

/**
 * Initiates a self test of the RNGB's internal logic.
 * @param peripheralBase Peripheral base address.
 */
#define RNG_PDD_SelfTest(peripheralBase) ( \
    RNG_CMD_REG(peripheralBase) |= \
     RNG_CMD_ST_MASK \
  )

/* ----------------------------------------------------------------------------
   -- AutoReseed
   ---------------------------------------------------------------------------- */

/**
 * Configures automatic reseeding.
 * @param peripheralBase Peripheral base address.
 * @param Reseed Determines auto-reseed function. Use constants from group
 *        "Auto-reseed constants".
 */
#define RNG_PDD_AutoReseed(peripheralBase, Reseed) ( \
    RNG_CR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(RNG_CR_REG(peripheralBase) & (uint32_t)(~(uint32_t)RNG_CR_AR_MASK))) | ( \
      (uint32_t)(Reseed))) \
  )

/* ----------------------------------------------------------------------------
   -- SetFIFOUnderflow
   ---------------------------------------------------------------------------- */

/**
 * Sets FIFO underflow response mode.
 * @param peripheralBase Peripheral base address.
 * @param Mode Response mode. Use constants from group "FIFO Underflow response
 *        mode constants.".
 */
#define RNG_PDD_SetFIFOUnderflow(peripheralBase, Mode) ( \
    RNG_CR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(RNG_CR_REG(peripheralBase) & (uint32_t)(~(uint32_t)RNG_CR_FUFMOD_MASK))) | ( \
      (uint32_t)(Mode))) \
  )

/* ----------------------------------------------------------------------------
   -- GetFIFOUnderflow
   ---------------------------------------------------------------------------- */

/**
 * Returns FIFO underflow response mode.
 * @param peripheralBase Peripheral base address.
 */
#define RNG_PDD_GetFIFOUnderflow(peripheralBase) ( \
    (uint32_t)(RNG_CR_REG(peripheralBase) & RNG_CR_FUFMOD_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetStatusRegister
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the RNGB Status Register.
 * @param peripheralBase Peripheral base address.
 */
#define RNG_PDD_GetStatusRegister(peripheralBase) ( \
    RNG_SR_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- GetFIFOSize
   ---------------------------------------------------------------------------- */

/**
 * Returns the FIFO size.
 * @param peripheralBase Peripheral base address.
 */
#define RNG_PDD_GetFIFOSize(peripheralBase) ( \
    (uint8_t)(( \
     (uint32_t)(RNG_SR_REG(peripheralBase) & RNG_SR_FIFO_SIZE_MASK)) >> ( \
     RNG_SR_FIFO_SIZE_SHIFT)) \
  )

/* ----------------------------------------------------------------------------
   -- GetFIFOLevel
   ---------------------------------------------------------------------------- */

/**
 * Returns FIFO level.
 * @param peripheralBase Peripheral base address.
 */
#define RNG_PDD_GetFIFOLevel(peripheralBase) ( \
    (uint8_t)(( \
     (uint32_t)(RNG_SR_REG(peripheralBase) & RNG_SR_FIFO_LVL_MASK)) >> ( \
     RNG_SR_FIFO_LVL_SHIFT)) \
  )

/* ----------------------------------------------------------------------------
   -- GetExtendedError
   ---------------------------------------------------------------------------- */

/**
 * Returns the extended error from status register.
 * @param peripheralBase Peripheral base address.
 */
#define RNG_PDD_GetExtendedError(peripheralBase) ( \
    (uint32_t)(RNG_SR_REG(peripheralBase) & (uint32_t)((uint32_t)0x7FFU << 21U)) \
  )

/* ----------------------------------------------------------------------------
   -- GetErrorStatusRegister
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the RNGB Error Status Register.
 * @param peripheralBase Peripheral base address.
 */
#define RNG_PDD_GetErrorStatusRegister(peripheralBase) ( \
    RNG_ESR_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- GetOutValue
   ---------------------------------------------------------------------------- */

/**
 * Returns the random data generated by the RNGB.
 * @param peripheralBase Peripheral base address.
 */
#define RNG_PDD_GetOutValue(peripheralBase) ( \
    RNG_OUT_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- ReseedNeeded
   ---------------------------------------------------------------------------- */

/**
 * Returns 1 if manual reseeding is required.
 * @param peripheralBase Peripheral base address.
 */
#define RNG_PDD_ReseedNeeded(peripheralBase) ( \
    (uint8_t)((uint32_t)(RNG_SR_REG(peripheralBase) & RNG_SR_RS_MASK) >> RNG_SR_RS_SHIFT) \
  )
#endif  /* #if defined(RNG_PDD_H_) */

/* RNG_PDD.h, eof. */
