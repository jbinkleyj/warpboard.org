/*
  PDD layer implementation for peripheral type DAC
  (C) 2010 Freescale, Inc. All rights reserved.

  This file is static and it is generated from API-Factory
*/

#if !defined(DAC_PDD_H_)
#define DAC_PDD_H_

/* ----------------------------------------------------------------------------
   -- Test if supported MCU is active
   ---------------------------------------------------------------------------- */

#if !defined(MCU_ACTIVE)
  // No MCU is active
  #error DAC PDD library: No derivative is active. Place proper #include with PDD memory map before including PDD library.
#elif \
      !defined(MCU_MK10D10) /* DAC0, DAC1 */ && \
      !defined(MCU_MK10D7) /* DAC0 */ && \
      !defined(MCU_MK10F12) /* DAC0, DAC1 */ && \
      !defined(MCU_MK10DZ10) /* DAC0, DAC1 */ && \
      !defined(MCU_MK11D5) /* DAC0 */ && \
      !defined(MCU_MK12D5) /* DAC0 */ && \
      !defined(MCU_MK20D10) /* DAC0, DAC1 */ && \
      !defined(MCU_MK20D7) /* DAC0 */ && \
      !defined(MCU_MK20F12) /* DAC0, DAC1 */ && \
      !defined(MCU_MK20DZ10) /* DAC0, DAC1 */ && \
      !defined(MCU_MK21D5) /* DAC0 */ && \
      !defined(MCU_MK22D5) /* DAC0 */ && \
      !defined(MCU_MK30D10) /* DAC0, DAC1 */ && \
      !defined(MCU_MK30D7) /* DAC0 */ && \
      !defined(MCU_MK30DZ10) /* DAC0, DAC1 */ && \
      !defined(MCU_MK40D10) /* DAC0, DAC1 */ && \
      !defined(MCU_MK40D7) /* DAC0 */ && \
      !defined(MCU_MK40DZ10) /* DAC0, DAC1 */ && \
      !defined(MCU_MK40X256VMD100) /* DAC0, DAC1 */ && \
      !defined(MCU_MK50D10) /* DAC0, DAC1 */ && \
      !defined(MCU_MK50D7) /* DAC0 */ && \
      !defined(MCU_MK50DZ10) /* DAC0, DAC1 */ && \
      !defined(MCU_MK51D10) /* DAC0, DAC1 */ && \
      !defined(MCU_MK51D7) /* DAC0 */ && \
      !defined(MCU_MK51DZ10) /* DAC0, DAC1 */ && \
      !defined(MCU_MK52D10) /* DAC0, DAC1 */ && \
      !defined(MCU_MK52DZ10) /* DAC0, DAC1 */ && \
      !defined(MCU_MK53D10) /* DAC0, DAC1 */ && \
      !defined(MCU_MK53DZ10) /* DAC0, DAC1 */ && \
      !defined(MCU_MK60D10) /* DAC0, DAC1 */ && \
      !defined(MCU_MK60F12) /* DAC0, DAC1 */ && \
      !defined(MCU_MK60F15) /* DAC0, DAC1 */ && \
      !defined(MCU_MK60DZ10) /* DAC0, DAC1 */ && \
      !defined(MCU_MK60N512VMD100) /* DAC0, DAC1 */ && \
      !defined(MCU_MK61F12) /* DAC0, DAC1 */ && \
      !defined(MCU_MK61F15) /* DAC0, DAC1 */ && \
      !defined(MCU_MK70F12) /* DAC0, DAC1 */ && \
      !defined(MCU_MK70F15) /* DAC0, DAC1 */ && \
      !defined(MCU_MKL05Z4) /* DAC0 */ && \
      !defined(MCU_MKL15Z4) /* DAC0 */ && \
      !defined(MCU_MKL25Z4) /* DAC0 */
  // Unsupported MCU is active
  #error DAC PDD library: Unsupported derivative is active.
#endif

#include "PDD_Types.h"

/* ----------------------------------------------------------------------------
   -- Method symbol definitions
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MKL05Z4)) || (defined(MCU_MKL15Z4)) || (defined(MCU_MKL25Z4)))
/* Interrupts' masks. */
  #define DAC_PDD_BUFFER_START_INTERRUPT DAC_C0_DACBTIEN_MASK /**< Buffer start (top position) interrupt mask. */
  #define DAC_PDD_BUFFER_END_INTERRUPT DAC_C0_DACBBIEN_MASK /**< Buffer end (bottom position) interrupt mask. */

#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */
/* Interrupts' masks. */
  #define DAC_PDD_BUFFER_START_INTERRUPT DAC_C0_DACBTIEN_MASK /**< Buffer start (top position) interrupt mask. */
  #define DAC_PDD_BUFFER_END_INTERRUPT DAC_C0_DACBBIEN_MASK /**< Buffer end (bottom position) interrupt mask. */
  #define DAC_PDD_BUFFER_WATERMARK_INTERRUPT DAC_C0_DACBWIEN_MASK /**< Buffer watermark interrupt mask. */

#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */
#if ((defined(MCU_MKL05Z4)) || (defined(MCU_MKL15Z4)) || (defined(MCU_MKL25Z4)))
/* Interrupts' flags. */
  #define DAC_PDD_BUFFER_START_FLAG DAC_SR_DACBFRPTF_MASK /**< Buffer start (top position) flag. */
  #define DAC_PDD_BUFFER_END_FLAG DAC_SR_DACBFRPBF_MASK /**< Buffer end (bottom position) flag. */

#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */
/* Interrupts' flags. */
  #define DAC_PDD_BUFFER_START_FLAG DAC_SR_DACBFRPTF_MASK /**< Buffer start (top position) flag. */
  #define DAC_PDD_BUFFER_END_FLAG DAC_SR_DACBFRPBF_MASK /**< Buffer end (bottom position) flag. */
  #define DAC_PDD_BUFFER_WATERMARK_FLAG DAC_SR_DACBFWMF_MASK /**< Buffer watermark flag. */

#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */
/* D/A converter's trigger source constant. */
#define DAC_PDD_HW_TRIGGER 0U                    /**< HW trigger. */
#define DAC_PDD_SW_TRIGGER DAC_C0_DACTRGSEL_MASK /**< SW trigger. */

#if ((defined(MCU_MKL05Z4)) || (defined(MCU_MKL15Z4)) || (defined(MCU_MKL25Z4)))
/* D/A converter's buffer work mode constant. */
  #define DAC_PDD_BUFFER_NORMAL_MODE 0U            /**< Normal mode. */
  #define DAC_PDD_BUFFER_OTSCAN_MODE 0x2U          /**< One-time mode. */

#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */
/* D/A converter's buffer work mode constant. */
  #define DAC_PDD_BUFFER_NORMAL_MODE 0U            /**< Normal mode. */
  #define DAC_PDD_BUFFER_SWING_MODE 0x1U           /**< Swing mode. */
  #define DAC_PDD_BUFFER_OTSCAN_MODE 0x2U          /**< One-time mode. */

#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */
/* D/A converter's buffer watermark constant. For exact value representation see
   peripheral device documentation. */
#define DAC_PDD_BUFFER_WATERMARK_L1 0U           /**< Level 1 watermark (1 word). */
#define DAC_PDD_BUFFER_WATERMARK_L2 0x1U         /**< Level 2 watermark (2 words). */
#define DAC_PDD_BUFFER_WATERMARK_L3 0x2U         /**< Level 3 watermark (3 words). */
#define DAC_PDD_BUFFER_WATERMARK_L4 0x3U         /**< Level 4 watermark (4 words). */

/* D/A converter's buffer reference constant. */
#define DAC_PDD_V_REF_INTERNAL 0U                /**< Internal reference source. */
#define DAC_PDD_V_REF_EXTERNAL DAC_C0_DACRFS_MASK /**< External reference source. */

/* D/A converter's buffer low power mode constant. */
#define DAC_PDD_HIGH_POWER 0U                    /**< High power mode. */
#define DAC_PDD_LOW_POWER DAC_C0_LPEN_MASK       /**< Low power mode. */


/* ----------------------------------------------------------------------------
   -- EnableDevice
   ---------------------------------------------------------------------------- */

/**
 * Enables the D/A converter's device.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state of D/A converter.
 */
#define DAC_PDD_EnableDevice(peripheralBase, State) ( \
    DAC_C0_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(DAC_C0_REG(peripheralBase) & (uint8_t)(~(uint8_t)DAC_C0_DACEN_MASK))) | ( \
      (uint8_t)((uint8_t)(State) << DAC_C0_DACEN_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- GetDeviceEnabled
   ---------------------------------------------------------------------------- */

/**
 * Returns current state of D/A converter enable bit.
 * @param peripheralBase Peripheral base address.
 */
#define DAC_PDD_GetDeviceEnabled(peripheralBase) ( \
    (uint8_t)(DAC_C0_REG(peripheralBase) & DAC_C0_DACEN_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- EnableInterrupts
   ---------------------------------------------------------------------------- */

/**
 * Enables interrupts defined by mask parameter.
 * @param peripheralBase Peripheral base address.
 * @param Mask Mask of interrupts to enable. Use constants from group
 *        "Interrupts' masks.".
 */
#define DAC_PDD_EnableInterrupts(peripheralBase, Mask) ( \
    DAC_C0_REG(peripheralBase) |= \
     (uint8_t)(Mask) \
  )

/* ----------------------------------------------------------------------------
   -- DisableInterrupts
   ---------------------------------------------------------------------------- */

/**
 * Disables interrupts defined by mask parameter.
 * @param peripheralBase Peripheral base address.
 * @param Mask Mask of interrupts to disable. Use constants from group
 *        "Interrupts' masks.".
 */
#define DAC_PDD_DisableInterrupts(peripheralBase, Mask) ( \
    DAC_C0_REG(peripheralBase) &= \
     (uint8_t)(~(uint8_t)(Mask)) \
  )

/* ----------------------------------------------------------------------------
   -- SetInterruptMask
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MKL05Z4)) || (defined(MCU_MKL15Z4)) || (defined(MCU_MKL25Z4)))
/**
 * Sets all interrupts with value according to mask parameter.
 * @param peripheralBase Peripheral base address.
 * @param Mask Mask of interrupts to enable - rest will be disabled. Use
 *        constants from group "Interrupts' masks.".
 */
  #define DAC_PDD_SetInterruptMask(peripheralBase, Mask) ( \
      DAC_C0_REG(peripheralBase) = \
       (uint8_t)(( \
        (uint8_t)(( \
         DAC_C0_REG(peripheralBase)) & ( \
         (uint8_t)(~(uint8_t)(DAC_C0_DACBBIEN_MASK | DAC_C0_DACBTIEN_MASK))))) | ( \
        (uint8_t)(Mask))) \
    )
#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */
/**
 * Sets all interrupts with value according to mask parameter.
 * @param peripheralBase Peripheral base address.
 * @param Mask Mask of interrupts to enable - rest will be disabled. Use
 *        constants from group "Interrupts' masks.".
 */
  #define DAC_PDD_SetInterruptMask(peripheralBase, Mask) ( \
      DAC_C0_REG(peripheralBase) = \
       (uint8_t)(( \
        (uint8_t)(( \
         DAC_C0_REG(peripheralBase)) & ( \
         (uint8_t)(~(uint8_t)(DAC_C0_DACBBIEN_MASK | (DAC_C0_DACBTIEN_MASK | DAC_C0_DACBWIEN_MASK)))))) | ( \
        (uint8_t)(Mask))) \
    )
#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */

/* ----------------------------------------------------------------------------
   -- GetInterruptMask
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MKL05Z4)) || (defined(MCU_MKL15Z4)) || (defined(MCU_MKL25Z4)))
/**
 * Returns interrupts mask.
 * @param peripheralBase Peripheral base address.
 * @return Use constants from group "Interrupts' masks." for processing return
 *         value.
 */
  #define DAC_PDD_GetInterruptMask(peripheralBase) ( \
      (uint8_t)(( \
       DAC_C0_REG(peripheralBase)) & ( \
       (uint8_t)(DAC_C0_DACBBIEN_MASK | DAC_C0_DACBTIEN_MASK))) \
    )
#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */
/**
 * Returns interrupts mask.
 * @param peripheralBase Peripheral base address.
 * @return Use constants from group "Interrupts' masks." for processing return
 *         value.
 */
  #define DAC_PDD_GetInterruptMask(peripheralBase) ( \
      (uint8_t)(( \
       DAC_C0_REG(peripheralBase)) & ( \
       (uint8_t)(DAC_C0_DACBBIEN_MASK | (DAC_C0_DACBTIEN_MASK | DAC_C0_DACBWIEN_MASK)))) \
    )
#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */

/* ----------------------------------------------------------------------------
   -- GetInterruptFlags
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MKL05Z4)) || (defined(MCU_MKL15Z4)) || (defined(MCU_MKL25Z4)))
/**
 * Returns interrupt flag bits.
 * @param peripheralBase Peripheral base address.
 * @return Use constants from group "Interrupts' flags." for processing return
 *         value.
 */
  #define DAC_PDD_GetInterruptFlags(peripheralBase) ( \
      (uint8_t)(( \
       DAC_SR_REG(peripheralBase)) & ( \
       (uint8_t)(DAC_SR_DACBFRPBF_MASK | DAC_SR_DACBFRPTF_MASK))) \
    )
#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */
/**
 * Returns interrupt flag bits.
 * @param peripheralBase Peripheral base address.
 * @return Use constants from group "Interrupts' flags." for processing return
 *         value.
 */
  #define DAC_PDD_GetInterruptFlags(peripheralBase) ( \
      (uint8_t)(( \
       DAC_SR_REG(peripheralBase)) & ( \
       (uint8_t)(DAC_SR_DACBFRPBF_MASK | (DAC_SR_DACBFRPTF_MASK | DAC_SR_DACBFWMF_MASK)))) \
    )
#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */

/* ----------------------------------------------------------------------------
   -- ClearInterruptFlags
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MKL05Z4)) || (defined(MCU_MKL15Z4)) || (defined(MCU_MKL25Z4)))
/**
 * Clears interrupt flag bits defined by mask parameter.
 * @param peripheralBase Peripheral base address.
 * @param Mask Mask of interrupt's flags to clear. Use constants from group
 *        "Interrupts' flags.".
 */
  #define DAC_PDD_ClearInterruptFlags(peripheralBase, Mask) ( \
      DAC_SR_REG(peripheralBase) = \
       (uint8_t)(( \
        (uint8_t)(( \
         DAC_SR_REG(peripheralBase)) & ( \
         (uint8_t)(~(uint8_t)(DAC_SR_DACBFRPBF_MASK | DAC_SR_DACBFRPTF_MASK))))) | ( \
        (uint8_t)(( \
         (uint8_t)(~(uint8_t)(Mask))) & ( \
         (uint8_t)(DAC_SR_DACBFRPBF_MASK | DAC_SR_DACBFRPTF_MASK))))) \
    )
#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */
/**
 * Clears interrupt flag bits defined by mask parameter.
 * @param peripheralBase Peripheral base address.
 * @param Mask Mask of interrupt's flags to clear. Use constants from group
 *        "Interrupts' flags.".
 */
  #define DAC_PDD_ClearInterruptFlags(peripheralBase, Mask) ( \
      DAC_SR_REG(peripheralBase) = \
       (uint8_t)(( \
        (uint8_t)(( \
         DAC_SR_REG(peripheralBase)) & ( \
         (uint8_t)(~(uint8_t)(DAC_SR_DACBFRPBF_MASK | (DAC_SR_DACBFRPTF_MASK | DAC_SR_DACBFWMF_MASK)))))) | ( \
        (uint8_t)(( \
         (uint8_t)(~(uint8_t)(Mask))) & ( \
         (uint8_t)(DAC_SR_DACBFRPBF_MASK | (DAC_SR_DACBFRPTF_MASK | DAC_SR_DACBFWMF_MASK)))))) \
    )
#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */

/* ----------------------------------------------------------------------------
   -- SetData
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MKL05Z4)) || (defined(MCU_MKL15Z4)) || (defined(MCU_MKL25Z4)))
/**
 * Sets value of D/A converter's data buffer word defined by Index parameter.
 * @param peripheralBase Peripheral base address.
 * @param Data Data word value.
 * @param RegIndex Buffer word index.
 */
  #define DAC_PDD_SetData(peripheralBase, Data, RegIndex) ( \
      (DAC_DATL_REG(peripheralBase,(RegIndex)) = \
       (uint8_t)(Data)), \
      (DAC_DATH_REG(peripheralBase,(RegIndex)) = \
       (uint8_t)(( \
        (uint8_t)(( \
         DAC_DATH_REG(peripheralBase,(RegIndex))) & ( \
         (uint8_t)(~(uint8_t)DAC_DATH_DATA1_MASK)))) | ( \
        (uint8_t)((uint16_t)(Data) >> 8U)))) \
    )
#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */
/**
 * Sets value of D/A converter's data buffer word defined by Index parameter.
 * @param peripheralBase Peripheral base address.
 * @param Data Data word value.
 * @param RegIndex Buffer word index.
 */
  #define DAC_PDD_SetData(peripheralBase, Data, RegIndex) ( \
      (DAC_DATL_REG(peripheralBase,(RegIndex)) = \
       (uint8_t)(Data)), \
      (DAC_DATH_REG(peripheralBase,(RegIndex)) = \
       (uint8_t)(( \
        (uint8_t)(( \
         DAC_DATH_REG(peripheralBase,(RegIndex))) & ( \
         (uint8_t)(~(uint8_t)DAC_DATH_DATA_MASK)))) | ( \
        (uint8_t)((uint16_t)(Data) >> 8U)))) \
    )
#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */

/* ----------------------------------------------------------------------------
   -- EnableBuffer
   ---------------------------------------------------------------------------- */

/**
 * D/A converter's buffer enable.
 * @param peripheralBase Peripheral base address.
 * @param State Parameter specifying if D/A converter's buffer will be enabled
 *        or disabled.
 */
#define DAC_PDD_EnableBuffer(peripheralBase, State) ( \
    DAC_C1_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(DAC_C1_REG(peripheralBase) & (uint8_t)(~(uint8_t)DAC_C1_DACBFEN_MASK))) | ( \
      (uint8_t)(State))) \
  )

/* ----------------------------------------------------------------------------
   -- GetBufferEnabled
   ---------------------------------------------------------------------------- */

/**
 * Returns current data buffer state.
 * @param peripheralBase Peripheral base address.
 */
#define DAC_PDD_GetBufferEnabled(peripheralBase) ( \
    (uint8_t)(DAC_C1_REG(peripheralBase) & DAC_C1_DACBFEN_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- SetTrigger
   ---------------------------------------------------------------------------- */

/**
 * Selects D/A converter's trigger.
 * @param peripheralBase Peripheral base address.
 * @param Trigger Parameter specifying which trigger source will be used.
 */
#define DAC_PDD_SetTrigger(peripheralBase, Trigger) ( \
    DAC_C0_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(DAC_C0_REG(peripheralBase) & (uint8_t)(~(uint8_t)DAC_C0_DACTRGSEL_MASK))) | ( \
      (uint8_t)(Trigger))) \
  )

/* ----------------------------------------------------------------------------
   -- GetTriggerSource
   ---------------------------------------------------------------------------- */

/**
 * Returns current trigger source.
 * @param peripheralBase Peripheral base address.
 */
#define DAC_PDD_GetTriggerSource(peripheralBase) ( \
    (uint8_t)(DAC_C0_REG(peripheralBase) & DAC_C0_DACTRGSEL_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- ForceSwTrigger
   ---------------------------------------------------------------------------- */

/**
 * Forces D/A converter's software trigger.
 * @param peripheralBase Peripheral base address.
 */
#define DAC_PDD_ForceSwTrigger(peripheralBase) ( \
    DAC_C0_REG(peripheralBase) |= \
     DAC_C0_DACSWTRG_MASK \
  )

/* ----------------------------------------------------------------------------
   -- SetBufferMode
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MKL05Z4)) || (defined(MCU_MKL15Z4)) || (defined(MCU_MKL25Z4)))
/**
 * Selects D/A converter's buffer work mode.
 * @param peripheralBase Peripheral base address.
 * @param Mode Parameter specifying which data buffer work mode will be used.
 */
  #define DAC_PDD_SetBufferMode(peripheralBase, Mode) ( \
      ((Mode) == DAC_PDD_BUFFER_NORMAL_MODE) ? ( \
        DAC_C1_REG(peripheralBase) &= \
         (uint8_t)(~(uint8_t)DAC_C1_DACBFMD_MASK)) : ( \
        DAC_C1_REG(peripheralBase) |= \
         (uint8_t)((uint8_t)0x1U << DAC_C1_DACBFMD_SHIFT)) \
    )
#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */
/**
 * Selects D/A converter's buffer work mode.
 * @param peripheralBase Peripheral base address.
 * @param Mode Parameter specifying which data buffer work mode will be used.
 */
  #define DAC_PDD_SetBufferMode(peripheralBase, Mode) ( \
      DAC_C1_REG(peripheralBase) = \
       (uint8_t)(( \
        (uint8_t)(DAC_C1_REG(peripheralBase) & (uint8_t)(~(uint8_t)DAC_C1_DACBFMD_MASK))) | ( \
        (uint8_t)((uint8_t)(Mode) << DAC_C1_DACBFMD_SHIFT))) \
    )
#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */

/* ----------------------------------------------------------------------------
   -- SetBufferWatermark
   ---------------------------------------------------------------------------- */

/**
 * Sets D/A converter's buffer watermark.
 * @param peripheralBase Peripheral base address.
 * @param Watermark Parameter specifying data buffer watermark level.
 */
#define DAC_PDD_SetBufferWatermark(peripheralBase, Watermark) ( \
    DAC_C1_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(DAC_C1_REG(peripheralBase) & (uint8_t)(~(uint8_t)DAC_C1_DACBFWM_MASK))) | ( \
      (uint8_t)((uint8_t)(Watermark) << DAC_C1_DACBFWM_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- SetBufferReadPointer
   ---------------------------------------------------------------------------- */

/**
 * Sets D/A converter's buffer read pointer.
 * @param peripheralBase Peripheral base address.
 * @param Pointer Parameter specifying new data buffer read pointer value.
 */
#define DAC_PDD_SetBufferReadPointer(peripheralBase, Pointer) ( \
    DAC_C2_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(DAC_C2_REG(peripheralBase) & (uint8_t)(~(uint8_t)DAC_C2_DACBFRP_MASK))) | ( \
      (uint8_t)((uint8_t)(Pointer) << DAC_C2_DACBFRP_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- GetBufferReadPointer
   ---------------------------------------------------------------------------- */

/**
 * Returns current data buffer read pointer value.
 * @param peripheralBase Peripheral base address.
 */
#define DAC_PDD_GetBufferReadPointer(peripheralBase) ( \
    (uint8_t)(( \
     (uint8_t)(DAC_C2_REG(peripheralBase) & DAC_C2_DACBFRP_MASK)) >> ( \
     DAC_C2_DACBFRP_SHIFT)) \
  )

/* ----------------------------------------------------------------------------
   -- SetBufferSize
   ---------------------------------------------------------------------------- */

/**
 * Sets D/A converter's buffer upper limit.
 * @param peripheralBase Peripheral base address.
 * @param Size Buffer upper limit (buffer register maximal index).
 */
#define DAC_PDD_SetBufferSize(peripheralBase, Size) ( \
    DAC_C2_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(DAC_C2_REG(peripheralBase) & (uint8_t)(~(uint8_t)DAC_C2_DACBFUP_MASK))) | ( \
      (uint8_t)(Size))) \
  )

/* ----------------------------------------------------------------------------
   -- GetBufferSize
   ---------------------------------------------------------------------------- */

/**
 * Returns current data buffer size.
 * @param peripheralBase Peripheral base address.
 */
#define DAC_PDD_GetBufferSize(peripheralBase) ( \
    (uint8_t)(DAC_C2_REG(peripheralBase) & DAC_C2_DACBFUP_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- SetReference
   ---------------------------------------------------------------------------- */

/**
 * Selects D/A converter's reference.
 * @param peripheralBase Peripheral base address.
 * @param Reference Parameter specifying if internal or external voltage
 *        reference source will be used.
 */
#define DAC_PDD_SetReference(peripheralBase, Reference) ( \
    DAC_C0_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(DAC_C0_REG(peripheralBase) & (uint8_t)(~(uint8_t)DAC_C0_DACRFS_MASK))) | ( \
      (uint8_t)(Reference))) \
  )

/* ----------------------------------------------------------------------------
   -- SetPowerMode
   ---------------------------------------------------------------------------- */

/**
 * Selects D/A converter's low power mode.
 * @param peripheralBase Peripheral base address.
 * @param Mode Parameter specifying if high or low power mode will be used.
 */
#define DAC_PDD_SetPowerMode(peripheralBase, Mode) ( \
    DAC_C0_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(DAC_C0_REG(peripheralBase) & (uint8_t)(~(uint8_t)DAC_C0_LPEN_MASK))) | ( \
      (uint8_t)(Mode))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableDmaRequest
   ---------------------------------------------------------------------------- */

/**
 * DMA enable control.
 * @param peripheralBase Peripheral base address.
 * @param State Parameter specifying if DMA requests will be enabled or disabled.
 */
#define DAC_PDD_EnableDmaRequest(peripheralBase, State) ( \
    DAC_C1_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(DAC_C1_REG(peripheralBase) & (uint8_t)(~(uint8_t)DAC_C1_DMAEN_MASK))) | ( \
      (uint8_t)((uint8_t)(State) << DAC_C1_DMAEN_SHIFT))) \
  )
#endif  /* #if defined(DAC_PDD_H_) */

/* DAC_PDD.h, eof. */
