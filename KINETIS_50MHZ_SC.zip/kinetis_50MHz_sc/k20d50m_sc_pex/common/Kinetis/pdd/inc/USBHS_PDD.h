/*
  PDD layer implementation for peripheral type USBHS
  (C) 2010 Freescale, Inc. All rights reserved.

  This file is static and it is generated from API-Factory
*/

#if !defined(USBHS_PDD_H_)
#define USBHS_PDD_H_

/* ----------------------------------------------------------------------------
   -- Test if supported MCU is active
   ---------------------------------------------------------------------------- */

#if !defined(MCU_ACTIVE)
  // No MCU is active
  #error USBHS PDD library: No derivative is active. Place proper #include with PDD memory map before including PDD library.
#elif \
      !defined(MCU_MK20F12) /* USBHS */ && \
      !defined(MCU_MK60F12) /* USBHS */ && \
      !defined(MCU_MK60F15) /* USBHS */ && \
      !defined(MCU_MK61F12) /* USBHS */ && \
      !defined(MCU_MK61F15) /* USBHS */ && \
      !defined(MCU_MK70F12) /* USBHS */ && \
      !defined(MCU_MK70F15) /* USBHS */
  // Unsupported MCU is active
  #error USBHS PDD library: Unsupported derivative is active.
#endif

#include "PDD_Types.h"

/* ----------------------------------------------------------------------------
   -- Method symbol definitions
   ---------------------------------------------------------------------------- */

/* Otg interrupt masks. */
#define USBHS_PDD_DATA_PULS_INT USBHS_OTGSC_DPIS_MASK /**< Data Pulse Interrupt/Itnettupt status/Status mask */
#define USBHS_PDD_1_MSEC_INT USBHS_OTGSC_MSS_MASK /**< 1 ms interrupt mask */
#define USBHS_PDD_B_SESS_END_INT USBHS_OTGSC_BSEIS_MASK /**< B session change interrupt mask */
#define USBHS_PDD_SESS_VLD_CHG_INT USBHS_OTGSC_BSVIS_MASK /**< Session valid change interrupt mask */
#define USBHS_PDD_B_SESS_VLD_CHG_INT USBHS_OTGSC_BSVIS_MASK /**< Session valid change interrupt mask */
#define USBHS_PDD_A_SESS_VLD_CHG_INT USBHS_OTGSC_ASVIS_MASK /**< Session valid change interrupt mask */
#define USBHS_PDD_A_VBUS_VLD_CHG_INT USBHS_OTGSC_AVVIS_MASK /**< Vbus change interrupt mask */
#define USBHS_PDD_ID_CHG_INT USBHS_OTGSC_IDIS_MASK /**< ID change interrupt mask */

/* Usb interrupt masks. */
#define USBHS_PDD_NAK_INT USBHS_USBSTS_NAKI_MASK /**< NAK interrupt mask */
#define USBHS_PDD_ULPI_INT USBHS_USBSTS_ULPII_MASK /**< ULPI interrupt mask */
#define USBHS_PDD_SLEEP_INT USBHS_USBSTS_SLI_MASK /**< Sleep interrupt mask */
#define USBHS_PDD_SOF_INT USBHS_USBSTS_SRI_MASK  /**< SOF interrupt mask */
#define USBHS_PDD_BUS_RESET_INT USBHS_USBSTS_URI_MASK /**< USB bus reset interrupt mask */
#define USBHS_PDD_ASYNC_ADVANCE_INT USBHS_USBSTS_AAI_MASK /**< Async advance interrupt mask */
#define USBHS_PDD_SYSTEM_ERROR_INT USBHS_USBSTS_SEI_MASK /**< System error interrupt mask */
#define USBHS_PDD_FRAME_LIST_ROLLOVER_INT USBHS_USBSTS_FRI_MASK /**< Frame list pollover interrupt mask */
#define USBHS_PDD_PORT_CHANGE_DETECT_INT USBHS_USBSTS_PCI_MASK /**< port change detect interrupt mask */
#define USBHS_PDD_USB_ERROR_INT USBHS_USBSTS_UEI_MASK /**< USB error interrupt mask */
#define USBHS_PDD_USB_TRANSFER_DONE USBHS_USBSTS_UI_MASK /**< USB transfer done mask */

/* USB bus masks. */
#define USBHS_PDD_LOW_SPEED 0x1U                 /**< Low speed constant */
#define USBHS_PDD_FULL_SPEED 0U                  /**< Full speed constant */
#define USBHS_PDD_HIGH_SPEED 0x2U                /**< High speed constant */


/* ----------------------------------------------------------------------------
   -- GetOtgInterruptMask
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the Usb interrupt enable register.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_GetOtgInterruptMask(peripheralBase) ( \
    (uint32_t)((uint32_t)(USBHS_OTGSC_REG(peripheralBase) & 0x7F000000U) >> 8U) \
  )

/* ----------------------------------------------------------------------------
   -- SetOtgInterruptMask
   ---------------------------------------------------------------------------- */

/**
 * Enables interrupts defined by the Mask parameter.
 * @param peripheralBase Peripheral base address.
 * @param Mask Interrupt mask.
 */
#define USBHS_PDD_SetOtgInterruptMask(peripheralBase, Mask) ( \
    USBHS_OTGSC_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(USBHS_OTGSC_REG(peripheralBase) & 0x3FU)) | ( \
      (uint32_t)((uint32_t)(Mask) << 8U))) \
  )

/* ----------------------------------------------------------------------------
   -- GetOtgInterruptFlags
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the USB interrupt status register.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_GetOtgInterruptFlags(peripheralBase) ( \
    (uint32_t)(USBHS_OTGSC_REG(peripheralBase) & 0x7F0000U) \
  )

/* ----------------------------------------------------------------------------
   -- ClearOtgInterruptFlags
   ---------------------------------------------------------------------------- */

/**
 * Clears flags defined by the Mask parameter.
 * @param peripheralBase Peripheral base address.
 * @param Mask Interrupt mask.
 */
#define USBHS_PDD_ClearOtgInterruptFlags(peripheralBase, Mask) ( \
    USBHS_OTGSC_REG(peripheralBase) = \
     (uint32_t)((uint32_t)(USBHS_OTGSC_REG(peripheralBase) & 0x7F00003FU) | (uint32_t)(Mask)) \
  )

/* ----------------------------------------------------------------------------
   -- GetEnabledOtgInterruptFlags
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the USB interrupt status register.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_GetEnabledOtgInterruptFlags(peripheralBase) ( \
    (uint32_t)(( \
     (uint32_t)(( \
      USBHS_OTGSC_REG(peripheralBase)) & ( \
      (uint32_t)(USBHS_OTGSC_REG(peripheralBase) >> 8U)))) & ( \
     0x7F0000U)) \
  )

/* ----------------------------------------------------------------------------
   -- EnableDataPulsInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables the data pulsing changed interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_EnableDataPulsInterrupt(peripheralBase) ( \
    USBHS_OTGSC_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(USBHS_OTGSC_REG(peripheralBase) | USBHS_OTGSC_DPIE_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_IDIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_AVVIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_ASVIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_BSVIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_BSEIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_MSS_MASK)) & ( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_DPIS_MASK))))))))) \
  )

/* ----------------------------------------------------------------------------
   -- Enable1msInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables the 1 ms interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_Enable1msInterrupt(peripheralBase) ( \
    USBHS_OTGSC_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(USBHS_OTGSC_REG(peripheralBase) | USBHS_OTGSC_MSE_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_IDIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_AVVIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_ASVIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_BSVIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_BSEIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_MSS_MASK)) & ( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_DPIS_MASK))))))))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableBsessEndInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables the B session end interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_EnableBsessEndInterrupt(peripheralBase) ( \
    USBHS_OTGSC_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(USBHS_OTGSC_REG(peripheralBase) | USBHS_OTGSC_BSEIE_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_IDIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_AVVIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_ASVIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_BSVIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_BSEIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_MSS_MASK)) & ( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_DPIS_MASK))))))))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableBsessVldInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables the B session valid interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_EnableBsessVldInterrupt(peripheralBase) ( \
    USBHS_OTGSC_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(USBHS_OTGSC_REG(peripheralBase) | USBHS_OTGSC_BSVIE_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_IDIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_AVVIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_ASVIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_BSVIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_BSEIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_MSS_MASK)) & ( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_DPIS_MASK))))))))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableAsessVldInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables the A session valid interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_EnableAsessVldInterrupt(peripheralBase) ( \
    USBHS_OTGSC_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(USBHS_OTGSC_REG(peripheralBase) | USBHS_OTGSC_ASVIE_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_IDIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_AVVIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_ASVIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_BSVIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_BSEIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_MSS_MASK)) & ( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_DPIS_MASK))))))))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableAVbusVldInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables the A VBUS valid interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_EnableAVbusVldInterrupt(peripheralBase) ( \
    USBHS_OTGSC_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(USBHS_OTGSC_REG(peripheralBase) | USBHS_OTGSC_AVVIE_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_IDIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_AVVIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_ASVIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_BSVIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_BSEIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_MSS_MASK)) & ( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_DPIS_MASK))))))))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableIdInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables the ID changed interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_EnableIdInterrupt(peripheralBase) ( \
    USBHS_OTGSC_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(USBHS_OTGSC_REG(peripheralBase) | USBHS_OTGSC_IDIE_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_IDIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_AVVIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_ASVIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_BSVIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_BSEIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_MSS_MASK)) & ( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_DPIS_MASK))))))))) \
  )

/* ----------------------------------------------------------------------------
   -- DisableDataPulsInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables the data pulsing changed interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_DisableDataPulsInterrupt(peripheralBase) ( \
    USBHS_OTGSC_REG(peripheralBase) &= \
     (uint32_t)(( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_DPIE_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_IDIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_AVVIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_ASVIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_BSVIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_BSEIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_MSS_MASK)) & ( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_DPIS_MASK))))))))) \
  )

/* ----------------------------------------------------------------------------
   -- Disable1msInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables the 1 ms interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_Disable1msInterrupt(peripheralBase) ( \
    USBHS_OTGSC_REG(peripheralBase) &= \
     (uint32_t)(( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_MSE_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_IDIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_AVVIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_ASVIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_BSVIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_BSEIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_MSS_MASK)) & ( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_DPIS_MASK))))))))) \
  )

/* ----------------------------------------------------------------------------
   -- DisableBsessEndInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables the B session end interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_DisableBsessEndInterrupt(peripheralBase) ( \
    USBHS_OTGSC_REG(peripheralBase) &= \
     (uint32_t)(( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_BSEIE_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_IDIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_AVVIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_ASVIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_BSVIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_BSEIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_MSS_MASK)) & ( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_DPIS_MASK))))))))) \
  )

/* ----------------------------------------------------------------------------
   -- DisableBsessVldInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables the B session valid interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_DisableBsessVldInterrupt(peripheralBase) ( \
    USBHS_OTGSC_REG(peripheralBase) &= \
     (uint32_t)(( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_BSVIE_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_IDIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_AVVIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_ASVIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_BSVIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_BSEIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_MSS_MASK)) & ( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_DPIS_MASK))))))))) \
  )

/* ----------------------------------------------------------------------------
   -- DisableAsessVldInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables the A session valid interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_DisableAsessVldInterrupt(peripheralBase) ( \
    USBHS_OTGSC_REG(peripheralBase) &= \
     (uint32_t)(( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_ASVIE_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_IDIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_AVVIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_ASVIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_BSVIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_BSEIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_MSS_MASK)) & ( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_DPIS_MASK))))))))) \
  )

/* ----------------------------------------------------------------------------
   -- DisableAVbusVldInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables the A VBUS valid interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_DisableAVbusVldInterrupt(peripheralBase) ( \
    USBHS_OTGSC_REG(peripheralBase) &= \
     (uint32_t)(( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_AVVIE_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_IDIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_AVVIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_ASVIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_BSVIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_BSEIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_MSS_MASK)) & ( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_DPIS_MASK))))))))) \
  )

/* ----------------------------------------------------------------------------
   -- DisableIdInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables the ID changed interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_DisableIdInterrupt(peripheralBase) ( \
    USBHS_OTGSC_REG(peripheralBase) &= \
     (uint32_t)(( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_IDIE_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_IDIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_AVVIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_ASVIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_BSVIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_BSEIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_MSS_MASK)) & ( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_DPIS_MASK))))))))) \
  )

/* ----------------------------------------------------------------------------
   -- DisableAllOtgInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables all Otg interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_DisableAllOtgInterrupt(peripheralBase) ( \
    USBHS_OTGSC_REG(peripheralBase) &= \
     (uint32_t)(( \
      (uint32_t)(~(uint32_t)((uint32_t)0x7FU << 24U))) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_IDIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_AVVIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_ASVIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_BSVIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_BSEIS_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_MSS_MASK)) & ( \
      (uint32_t)(~(uint32_t)USBHS_OTGSC_DPIS_MASK))))))))) \
  )

/* ----------------------------------------------------------------------------
   -- GetDataBusPulsingSignalState
   ---------------------------------------------------------------------------- */

/**
 * Gets the Data bus pulsing signal state.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_GetDataBusPulsingSignalState(peripheralBase) ( \
    (uint32_t)(USBHS_OTGSC_REG(peripheralBase) & USBHS_OTGSC_DPS_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetBSessionEndSignalState
   ---------------------------------------------------------------------------- */

/**
 * Gets the B session end signal state.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_GetBSessionEndSignalState(peripheralBase) ( \
    (uint32_t)(USBHS_OTGSC_REG(peripheralBase) & USBHS_OTGSC_BSE_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetBSessionValidSignalState
   ---------------------------------------------------------------------------- */

/**
 * Gets the B session valid signal state.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_GetBSessionValidSignalState(peripheralBase) ( \
    (uint32_t)(USBHS_OTGSC_REG(peripheralBase) & USBHS_OTGSC_BSV_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetASessionValidSignalState
   ---------------------------------------------------------------------------- */

/**
 * Gets the A session valid signal state.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_GetASessionValidSignalState(peripheralBase) ( \
    (uint32_t)(USBHS_OTGSC_REG(peripheralBase) & USBHS_OTGSC_ASV_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetAVbusValidSignalState
   ---------------------------------------------------------------------------- */

/**
 * Gets the A V-bus valid signal state.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_GetAVbusValidSignalState(peripheralBase) ( \
    (uint32_t)(USBHS_OTGSC_REG(peripheralBase) & USBHS_OTGSC_AVV_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetIdSignalState
   ---------------------------------------------------------------------------- */

/**
 * Gets the ID signal state.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_GetIdSignalState(peripheralBase) ( \
    (uint32_t)(USBHS_OTGSC_REG(peripheralBase) & USBHS_OTGSC_ID_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetUsbInterruptMask
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the Usb interrupt enable register.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_GetUsbInterruptMask(peripheralBase) ( \
    USBHS_USBINTR_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- SetUsbInterruptMask
   ---------------------------------------------------------------------------- */

/**
 * Enables interrupts defined by the Mask parameter.
 * @param peripheralBase Peripheral base address.
 * @param Mask Interrupt mask.
 */
#define USBHS_PDD_SetUsbInterruptMask(peripheralBase, Mask) ( \
    USBHS_USBINTR_REG(peripheralBase) = \
     (uint32_t)(Mask) \
  )

/* ----------------------------------------------------------------------------
   -- DisableAllUsbInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables all Usb interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_DisableAllUsbInterrupt(peripheralBase) ( \
    USBHS_USBINTR_REG(peripheralBase) = \
     0U \
  )

/* ----------------------------------------------------------------------------
   -- EnableNakInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables the NAK interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_EnableNakInterrupt(peripheralBase) ( \
    USBHS_USBINTR_REG(peripheralBase) |= \
     USBHS_USBINTR_NAKE_MASK \
  )

/* ----------------------------------------------------------------------------
   -- EnableUlpiInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables the ULPI interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_EnableUlpiInterrupt(peripheralBase) ( \
    USBHS_USBINTR_REG(peripheralBase) |= \
     USBHS_USBINTR_ULPIE_MASK \
  )

/* ----------------------------------------------------------------------------
   -- EnableSleepInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables the Sleep interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_EnableSleepInterrupt(peripheralBase) ( \
    USBHS_USBINTR_REG(peripheralBase) |= \
     USBHS_USBINTR_SLE_MASK \
  )

/* ----------------------------------------------------------------------------
   -- EnableSofInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables the SOF interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_EnableSofInterrupt(peripheralBase) ( \
    USBHS_USBINTR_REG(peripheralBase) |= \
     USBHS_USBINTR_SRE_MASK \
  )

/* ----------------------------------------------------------------------------
   -- EnableBusResetInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables the USB bus reset interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_EnableBusResetInterrupt(peripheralBase) ( \
    USBHS_USBINTR_REG(peripheralBase) |= \
     USBHS_USBINTR_URE_MASK \
  )

/* ----------------------------------------------------------------------------
   -- EnableAsyncAdvanceInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables the Async advance interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_EnableAsyncAdvanceInterrupt(peripheralBase) ( \
    USBHS_USBINTR_REG(peripheralBase) |= \
     USBHS_USBINTR_AAE_MASK \
  )

/* ----------------------------------------------------------------------------
   -- EnableSystemErrorInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables the System error interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_EnableSystemErrorInterrupt(peripheralBase) ( \
    USBHS_USBINTR_REG(peripheralBase) |= \
     USBHS_USBINTR_SEE_MASK \
  )

/* ----------------------------------------------------------------------------
   -- EnableFrameListRollOverInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables the Frame list rollover interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_EnableFrameListRollOverInterrupt(peripheralBase) ( \
    USBHS_USBINTR_REG(peripheralBase) |= \
     USBHS_USBINTR_FRE_MASK \
  )

/* ----------------------------------------------------------------------------
   -- EnablePortChangeDetectInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables the Port change detect interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_EnablePortChangeDetectInterrupt(peripheralBase) ( \
    USBHS_USBINTR_REG(peripheralBase) |= \
     USBHS_USBINTR_PCE_MASK \
  )

/* ----------------------------------------------------------------------------
   -- EnableUsbErrorInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables the USB error interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_EnableUsbErrorInterrupt(peripheralBase) ( \
    USBHS_USBINTR_REG(peripheralBase) |= \
     USBHS_USBINTR_UEE_MASK \
  )

/* ----------------------------------------------------------------------------
   -- EnableTranaferDoneInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables the Transfer done interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_EnableTranaferDoneInterrupt(peripheralBase) ( \
    USBHS_USBINTR_REG(peripheralBase) |= \
     USBHS_USBINTR_UE_MASK \
  )

/* ----------------------------------------------------------------------------
   -- DisableNakInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables the NAK interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_DisableNakInterrupt(peripheralBase) ( \
    USBHS_USBINTR_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)USBHS_USBINTR_NAKE_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- DisableUlpiInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables the ULPI interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_DisableUlpiInterrupt(peripheralBase) ( \
    USBHS_USBINTR_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)USBHS_USBINTR_ULPIE_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- DisableSleepInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables the Sleep interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_DisableSleepInterrupt(peripheralBase) ( \
    USBHS_USBINTR_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)USBHS_USBINTR_SLE_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- DisableSofInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables the SOF interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_DisableSofInterrupt(peripheralBase) ( \
    USBHS_USBINTR_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)USBHS_USBINTR_SRE_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- DisableBusResetInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables the USB bus reset interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_DisableBusResetInterrupt(peripheralBase) ( \
    USBHS_USBINTR_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)USBHS_USBINTR_URE_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- DisableAsyncAdvanceInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables the Async advance interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_DisableAsyncAdvanceInterrupt(peripheralBase) ( \
    USBHS_USBINTR_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)USBHS_USBINTR_AAE_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- DisableSystemErrorInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables the System error interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_DisableSystemErrorInterrupt(peripheralBase) ( \
    USBHS_USBINTR_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)USBHS_USBINTR_SEE_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- DisableFrameListRollOverInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables the Frame list rollover interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_DisableFrameListRollOverInterrupt(peripheralBase) ( \
    USBHS_USBINTR_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)USBHS_USBINTR_FRE_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- DisablePortChangeDetectInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables the Port change detect interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_DisablePortChangeDetectInterrupt(peripheralBase) ( \
    USBHS_USBINTR_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)USBHS_USBINTR_PCE_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- DisableUsbErrorInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables the USB error interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_DisableUsbErrorInterrupt(peripheralBase) ( \
    USBHS_USBINTR_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)USBHS_USBINTR_UEE_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- DisableTransferDoneInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables the Transfer done interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_DisableTransferDoneInterrupt(peripheralBase) ( \
    USBHS_USBINTR_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)USBHS_USBINTR_UE_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetUsbInterruptFlags
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the USB interrupt status register.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_GetUsbInterruptFlags(peripheralBase) ( \
    USBHS_USBSTS_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- ClearUsbInterruptFlags
   ---------------------------------------------------------------------------- */

/**
 * Clears flags defined by the Mask parameter.
 * @param peripheralBase Peripheral base address.
 * @param Mask Interrupt mask.
 */
#define USBHS_PDD_ClearUsbInterruptFlags(peripheralBase, Mask) ( \
    USBHS_USBSTS_REG(peripheralBase) = \
     (uint32_t)(Mask) \
  )

/* ----------------------------------------------------------------------------
   -- ClearAllUsbInterruptFlags
   ---------------------------------------------------------------------------- */

/**
 * Clears all USB interrupt flags.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_ClearAllUsbInterruptFlags(peripheralBase) ( \
    USBHS_USBSTS_REG(peripheralBase) = \
     0xFFFFFFFFU \
  )

/* ----------------------------------------------------------------------------
   -- ClearNakInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Clears the NAK interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_ClearNakInterruptFlag(peripheralBase) ( \
    USBHS_USBSTS_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(USBHS_USBSTS_REG(peripheralBase) | USBHS_USBSTS_NAKI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_UI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_UEI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_PCI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_FRI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_SEI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_AAI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_URI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_SRI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_SLI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_TI0_MASK)) & ( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_TI1_MASK))))))))))))) \
  )

/* ----------------------------------------------------------------------------
   -- ClearUlpiInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Clears the ULPI interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_ClearUlpiInterruptFlag(peripheralBase) ( \
    USBHS_USBSTS_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(USBHS_USBSTS_REG(peripheralBase) | USBHS_USBSTS_ULPII_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_UI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_UEI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_PCI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_FRI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_SEI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_AAI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_URI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_SRI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_SLI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_TI0_MASK)) & ( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_TI1_MASK))))))))))))) \
  )

/* ----------------------------------------------------------------------------
   -- ClearSleepInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Clears the Sleep interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_ClearSleepInterruptFlag(peripheralBase) ( \
    USBHS_USBSTS_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(USBHS_USBSTS_REG(peripheralBase) | USBHS_USBSTS_SLI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_UI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_UEI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_PCI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_FRI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_SEI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_AAI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_URI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_SRI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_TI0_MASK)) & ( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_TI1_MASK)))))))))))) \
  )

/* ----------------------------------------------------------------------------
   -- ClearSofInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Clears the SOF interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_ClearSofInterruptFlag(peripheralBase) ( \
    USBHS_USBSTS_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(USBHS_USBSTS_REG(peripheralBase) | USBHS_USBSTS_SRI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_UI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_UEI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_PCI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_FRI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_SEI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_AAI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_URI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_SLI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_TI0_MASK)) & ( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_TI1_MASK)))))))))))) \
  )

/* ----------------------------------------------------------------------------
   -- ClearBusResetInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Clears the USB bus reset interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_ClearBusResetInterruptFlag(peripheralBase) ( \
    USBHS_USBSTS_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(USBHS_USBSTS_REG(peripheralBase) | USBHS_USBSTS_URI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_UI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_UEI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_PCI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_FRI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_SEI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_AAI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_SRI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_SLI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_TI0_MASK)) & ( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_TI1_MASK)))))))))))) \
  )

/* ----------------------------------------------------------------------------
   -- ClearAsyncAdvanceInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Clears the Async advance interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_ClearAsyncAdvanceInterruptFlag(peripheralBase) ( \
    USBHS_USBSTS_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(USBHS_USBSTS_REG(peripheralBase) | USBHS_USBSTS_AAI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_UI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_UEI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_PCI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_FRI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_SEI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_URI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_SRI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_SLI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_TI0_MASK)) & ( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_TI1_MASK)))))))))))) \
  )

/* ----------------------------------------------------------------------------
   -- ClearSystemErrorInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Clears the System error interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_ClearSystemErrorInterruptFlag(peripheralBase) ( \
    USBHS_USBSTS_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(USBHS_USBSTS_REG(peripheralBase) | USBHS_USBSTS_SEI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_UI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_UEI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_PCI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_FRI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_AAI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_URI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_SRI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_SLI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_TI0_MASK)) & ( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_TI1_MASK)))))))))))) \
  )

/* ----------------------------------------------------------------------------
   -- ClearFrameListRollOverInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Clears the Frame list rollover interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_ClearFrameListRollOverInterruptFlag(peripheralBase) ( \
    USBHS_USBSTS_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(USBHS_USBSTS_REG(peripheralBase) | USBHS_USBSTS_FRI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_UI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_UEI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_PCI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_SEI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_AAI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_URI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_SRI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_SLI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_TI0_MASK)) & ( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_TI1_MASK)))))))))))) \
  )

/* ----------------------------------------------------------------------------
   -- ClearPortChangeDetectInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Clears the Port change detect interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_ClearPortChangeDetectInterruptFlag(peripheralBase) ( \
    USBHS_USBSTS_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(USBHS_USBSTS_REG(peripheralBase) | USBHS_USBSTS_PCI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_UI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_UEI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_FRI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_SEI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_AAI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_URI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_SRI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_SLI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_TI0_MASK)) & ( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_TI1_MASK)))))))))))) \
  )

/* ----------------------------------------------------------------------------
   -- ClearUsbErrorInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Clears the USB error interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_ClearUsbErrorInterruptFlag(peripheralBase) ( \
    USBHS_USBSTS_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(USBHS_USBSTS_REG(peripheralBase) | USBHS_USBSTS_UEI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_UI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_PCI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_FRI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_SEI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_AAI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_URI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_SRI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_SLI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_TI0_MASK)) & ( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_TI1_MASK)))))))))))) \
  )

/* ----------------------------------------------------------------------------
   -- ClearTransferDoneInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Clears the Transfer done interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_ClearTransferDoneInterruptFlag(peripheralBase) ( \
    USBHS_USBSTS_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(USBHS_USBSTS_REG(peripheralBase) | USBHS_USBSTS_UI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_UEI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_PCI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_FRI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_SEI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_AAI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_URI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_SRI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_SLI_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_TI0_MASK)) & ( \
      (uint32_t)(~(uint32_t)USBHS_USBSTS_TI1_MASK)))))))))))) \
  )

/* ----------------------------------------------------------------------------
   -- GetNakInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Gets the NAK interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_GetNakInterruptFlag(peripheralBase) ( \
    (uint32_t)(USBHS_USBSTS_REG(peripheralBase) & USBHS_USBSTS_NAKI_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetUlpiInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Gets the ULPI interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_GetUlpiInterruptFlag(peripheralBase) ( \
    (uint32_t)(USBHS_USBSTS_REG(peripheralBase) & USBHS_USBSTS_ULPII_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetSleepInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Gets the Sleep interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_GetSleepInterruptFlag(peripheralBase) ( \
    (uint32_t)(USBHS_USBSTS_REG(peripheralBase) & USBHS_USBSTS_SLI_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetSofInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Gets the SOF interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_GetSofInterruptFlag(peripheralBase) ( \
    (uint32_t)(USBHS_USBSTS_REG(peripheralBase) & USBHS_USBSTS_SRI_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetBusResetInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Gets the USB bus reset interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_GetBusResetInterruptFlag(peripheralBase) ( \
    (uint32_t)(USBHS_USBSTS_REG(peripheralBase) & USBHS_USBSTS_URI_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetAsyncAdvanceInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Gets the Async advance interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_GetAsyncAdvanceInterruptFlag(peripheralBase) ( \
    (uint32_t)(USBHS_USBSTS_REG(peripheralBase) & USBHS_USBSTS_AAI_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetSystemErrorInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Gets the System error interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_GetSystemErrorInterruptFlag(peripheralBase) ( \
    (uint32_t)(USBHS_USBSTS_REG(peripheralBase) & USBHS_USBSTS_SEI_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetFrameListRollOverInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Gets the Frame list rollover interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_GetFrameListRollOverInterruptFlag(peripheralBase) ( \
    (uint32_t)(USBHS_USBSTS_REG(peripheralBase) & USBHS_USBSTS_FRI_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetPortChangeDetectInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Gets the Port change detect interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_GetPortChangeDetectInterruptFlag(peripheralBase) ( \
    (uint32_t)(USBHS_USBSTS_REG(peripheralBase) & USBHS_USBSTS_PCI_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetUsbErrorInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Gets the USB error interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_GetUsbErrorInterruptFlag(peripheralBase) ( \
    (uint32_t)(USBHS_USBSTS_REG(peripheralBase) & USBHS_USBSTS_UEI_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetTransferDoneInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Gets the Transfer done interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_GetTransferDoneInterruptFlag(peripheralBase) ( \
    (uint32_t)(USBHS_USBSTS_REG(peripheralBase) & USBHS_USBSTS_UI_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- SetSetupTripwire
   ---------------------------------------------------------------------------- */

/**
 * Sets Setup tripwire bit.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_SetSetupTripwire(peripheralBase) ( \
    USBHS_USBCMD_REG(peripheralBase) |= \
     USBHS_USBCMD_SUTW_MASK \
  )

/* ----------------------------------------------------------------------------
   -- ClrSetupTripwire
   ---------------------------------------------------------------------------- */

/**
 * Clears Setup tripwire bit.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_ClrSetupTripwire(peripheralBase) ( \
    USBHS_USBCMD_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)USBHS_USBCMD_SUTW_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetSetupTripwire
   ---------------------------------------------------------------------------- */

/**
 * Returns state of Setup tripwire bit.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_GetSetupTripwire(peripheralBase) ( \
    (uint32_t)(USBHS_USBCMD_REG(peripheralBase) & USBHS_USBCMD_SUTW_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- SetAddTdTripwire
   ---------------------------------------------------------------------------- */

/**
 * Sets Add device TD tripwire bit.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_SetAddTdTripwire(peripheralBase) ( \
    USBHS_USBCMD_REG(peripheralBase) |= \
     USBHS_USBCMD_ATDTW_MASK \
  )

/* ----------------------------------------------------------------------------
   -- ClrAddTdTripwire
   ---------------------------------------------------------------------------- */

/**
 * Clears Add device TD tripwire bit.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_ClrAddTdTripwire(peripheralBase) ( \
    USBHS_USBCMD_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)USBHS_USBCMD_ATDTW_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetAddTdTripwire
   ---------------------------------------------------------------------------- */

/**
 * Returns state of Add device TD tripwire bit.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_GetAddTdTripwire(peripheralBase) ( \
    (uint32_t)(USBHS_USBCMD_REG(peripheralBase) & USBHS_USBCMD_ATDTW_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- ResetController
   ---------------------------------------------------------------------------- */

/**
 * Starts controller reset.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_ResetController(peripheralBase) ( \
    USBHS_USBCMD_REG(peripheralBase) |= \
     USBHS_USBCMD_RST_MASK \
  )

/* ----------------------------------------------------------------------------
   -- GetControllerResetPendingFlag
   ---------------------------------------------------------------------------- */

/**
 * Returns state of RST bit.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_GetControllerResetPendingFlag(peripheralBase) ( \
    (uint32_t)(USBHS_USBCMD_REG(peripheralBase) & USBHS_USBCMD_RST_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- StartController
   ---------------------------------------------------------------------------- */

/**
 * Starts controller.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_StartController(peripheralBase) ( \
    USBHS_USBCMD_REG(peripheralBase) |= \
     USBHS_USBCMD_RS_MASK \
  )

/* ----------------------------------------------------------------------------
   -- GetControllerHaltedFlag
   ---------------------------------------------------------------------------- */

/**
 * Returns state of HCH bit.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_GetControllerHaltedFlag(peripheralBase) ( \
    (uint32_t)(USBHS_USBSTS_REG(peripheralBase) & USBHS_USBSTS_HCH_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- StopController
   ---------------------------------------------------------------------------- */

/**
 * Stops controller.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_StopController(peripheralBase) ( \
    USBHS_USBCMD_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)USBHS_USBCMD_RS_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetFrameNumber
   ---------------------------------------------------------------------------- */

/**
 * Returns frame number.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_GetFrameNumber(peripheralBase) ( \
    USBHS_FRINDEX_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- SetDeviceAddress
   ---------------------------------------------------------------------------- */

/**
 * Sets device address.
 * @param peripheralBase Peripheral base address.
 * @param Address Mask of endpoints to clear complete fllag.
 */
#define USBHS_PDD_SetDeviceAddress(peripheralBase, Address) ( \
    USBHS_DEVICEADDR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       USBHS_DEVICEADDR_REG(peripheralBase)) & ( \
       (uint32_t)(~(uint32_t)USBHS_DEVICEADDR_USBADR_MASK)))) | ( \
      (uint32_t)((uint32_t)(Address) << USBHS_DEVICEADDR_USBADR_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- GetBusSpeed
   ---------------------------------------------------------------------------- */

/**
 * Returns current bus speed.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_GetBusSpeed(peripheralBase) ( \
    (uint8_t)(( \
     (uint32_t)(USBHS_PORTSC1_REG(peripheralBase) & USBHS_PORTSC1_PSPD_MASK)) >> ( \
     USBHS_PORTSC1_PSPD_SHIFT)) \
  )

/* ----------------------------------------------------------------------------
   -- GetHighSpeedFlag
   ---------------------------------------------------------------------------- */

/**
 * Returns the value of the second bit of the PSPD (Port speed) bit in the
 * PORTSC register.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_GetHighSpeedFlag(peripheralBase) ( \
    (uint32_t)(USBHS_PORTSC1_REG(peripheralBase) & (uint32_t)((uint32_t)0x1U << 27U)) \
  )

/* ----------------------------------------------------------------------------
   -- GetBusResetPendingFlag
   ---------------------------------------------------------------------------- */

/**
 * Returns the value of the PR (Port reset) bit in the PORTSC register.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_GetBusResetPendingFlag(peripheralBase) ( \
    (uint32_t)(USBHS_PORTSC1_REG(peripheralBase) & USBHS_PORTSC1_PR_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetCurrentConnectStatusFlag
   ---------------------------------------------------------------------------- */

/**
 * Returns the value of the CCS (Current connect status) bit in the PORTSC
 * register.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_GetCurrentConnectStatusFlag(peripheralBase) ( \
    (uint32_t)(USBHS_PORTSC1_REG(peripheralBase) & USBHS_PORTSC1_CCS_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- SuspendPhy
   ---------------------------------------------------------------------------- */

/**
 * Suspends PHY.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_SuspendPhy(peripheralBase) ( \
    USBHS_PORTSC1_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(USBHS_PORTSC1_REG(peripheralBase) | USBHS_PORTSC1_PHCD_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_PORTSC1_CSC_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_PORTSC1_PEC_MASK)) & ( \
      (uint32_t)(~(uint32_t)USBHS_PORTSC1_OCC_MASK))))) \
  )

/* ----------------------------------------------------------------------------
   -- WakeUpPhy
   ---------------------------------------------------------------------------- */

/**
 * Wake-ups PHY.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_WakeUpPhy(peripheralBase) ( \
    USBHS_PORTSC1_REG(peripheralBase) &= \
     (uint32_t)(( \
      (uint32_t)(~(uint32_t)USBHS_PORTSC1_PHCD_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_PORTSC1_CSC_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_PORTSC1_PEC_MASK)) & ( \
      (uint32_t)(~(uint32_t)USBHS_PORTSC1_OCC_MASK))))) \
  )

/* ----------------------------------------------------------------------------
   -- ForceResume
   ---------------------------------------------------------------------------- */

/**
 * Forces resume.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_ForceResume(peripheralBase) ( \
    USBHS_PORTSC1_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(USBHS_PORTSC1_REG(peripheralBase) | USBHS_PORTSC1_FPR_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_PORTSC1_CSC_MASK)) & (( \
      (uint32_t)(~(uint32_t)USBHS_PORTSC1_PEC_MASK)) & ( \
      (uint32_t)(~(uint32_t)USBHS_PORTSC1_OCC_MASK))))) \
  )

/* ----------------------------------------------------------------------------
   -- GetEndpointSetupFlag
   ---------------------------------------------------------------------------- */

/**
 * Returns setup flags.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_GetEndpointSetupFlag(peripheralBase) ( \
    USBHS_EPSETUPSR_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- GetAllEndpointSetupFlag
   ---------------------------------------------------------------------------- */

/**
 * Returns prime pending flags of all endpoints.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_GetAllEndpointSetupFlag(peripheralBase) ( \
    USBHS_EPSETUPSR_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- ClearEndpointSetupFlag
   ---------------------------------------------------------------------------- */

/**
 * Clears setup flag of endpoints addressed by the EndpointMask parameter.
 * @param peripheralBase Peripheral base address.
 * @param EndpointsMask Mask of endpoints to clear complete fllag.
 */
#define USBHS_PDD_ClearEndpointSetupFlag(peripheralBase, EndpointsMask) ( \
    USBHS_EPSETUPSR_REG(peripheralBase) = \
     (uint32_t)(EndpointsMask) \
  )

/* ----------------------------------------------------------------------------
   -- ClearAllEndpointSetupFlags
   ---------------------------------------------------------------------------- */

/**
 * Clears setup flag of all endpoints.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_ClearAllEndpointSetupFlags(peripheralBase) ( \
    USBHS_EPSETUPSR_REG(peripheralBase) = \
     USBHS_EPSETUPSR_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- PrimeEndpoint
   ---------------------------------------------------------------------------- */

/**
 * Starts prime of endpoints addressed by the EndpointMask parameter.
 * @param peripheralBase Peripheral base address.
 * @param EndpointsMask Mask of endpoints to prime.
 */
#define USBHS_PDD_PrimeEndpoint(peripheralBase, EndpointsMask) ( \
    USBHS_EPPRIME_REG(peripheralBase) = \
     (uint32_t)(EndpointsMask) \
  )

/* ----------------------------------------------------------------------------
   -- GetPrimeEndpointPendingFlag
   ---------------------------------------------------------------------------- */

/**
 * Returns prime pending flags for endpoints addressed by the EndpointMask
 * parameter.
 * @param peripheralBase Peripheral base address.
 * @param EndpointsMask Mask of endpoints to return flag.
 */
#define USBHS_PDD_GetPrimeEndpointPendingFlag(peripheralBase, EndpointsMask) ( \
    (uint32_t)((uint32_t)(EndpointsMask) & USBHS_EPPRIME_REG(peripheralBase)) \
  )

/* ----------------------------------------------------------------------------
   -- GetAllPrimeEndpointPendingFlags
   ---------------------------------------------------------------------------- */

/**
 * Returns prime pending flags of all endpoints.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_GetAllPrimeEndpointPendingFlags(peripheralBase) ( \
    USBHS_EPPRIME_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- FlushEndpoint
   ---------------------------------------------------------------------------- */

/**
 * Starts flush of endpoints addressed by the EndpointMask parameter.
 * @param peripheralBase Peripheral base address.
 * @param EndpointsMask Mask of endpoints to flush.
 */
#define USBHS_PDD_FlushEndpoint(peripheralBase, EndpointsMask) ( \
    USBHS_EPFLUSH_REG(peripheralBase) = \
     (uint32_t)(EndpointsMask) \
  )

/* ----------------------------------------------------------------------------
   -- GetFlushEndpointPendingFlag
   ---------------------------------------------------------------------------- */

/**
 * Returns flush pending flags af endpoints addressed by the EndpointMask
 * parameter.
 * @param peripheralBase Peripheral base address.
 * @param EndpointsMask Mask of endpoints to return flag.
 */
#define USBHS_PDD_GetFlushEndpointPendingFlag(peripheralBase, EndpointsMask) ( \
    (uint32_t)((uint32_t)(EndpointsMask) & USBHS_EPFLUSH_REG(peripheralBase)) \
  )

/* ----------------------------------------------------------------------------
   -- FlushAllEndpoints
   ---------------------------------------------------------------------------- */

/**
 * Starts flush of all endpoints.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_FlushAllEndpoints(peripheralBase) ( \
    USBHS_EPFLUSH_REG(peripheralBase) = \
     0xFFFFFFFFU \
  )

/* ----------------------------------------------------------------------------
   -- GetAllFlushEndpointPendingFlags
   ---------------------------------------------------------------------------- */

/**
 * Returns flush pending flags.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_GetAllFlushEndpointPendingFlags(peripheralBase) ( \
    USBHS_EPFLUSH_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- GetEndpointStatusFlag
   ---------------------------------------------------------------------------- */

/**
 * Returns status flags of endpoints addressed by the EndpointMask parameter.
 * @param peripheralBase Peripheral base address.
 * @param EndpointsMask Mask of endpoints to return flag.
 */
#define USBHS_PDD_GetEndpointStatusFlag(peripheralBase, EndpointsMask) ( \
    (uint32_t)((uint32_t)(EndpointsMask) & USBHS_EPSR_REG(peripheralBase)) \
  )

/* ----------------------------------------------------------------------------
   -- GetAllEndpointStatusFlags
   ---------------------------------------------------------------------------- */

/**
 * Returns flush pending flags.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_GetAllEndpointStatusFlags(peripheralBase) ( \
    USBHS_EPSR_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- GetEndpointCompleteFlag
   ---------------------------------------------------------------------------- */

/**
 * Returns complete flags of endpoints addressed by the EndpointMask parameter.
 * @param peripheralBase Peripheral base address.
 * @param EndpointsMask Mask of endpoints to return flag.
 */
#define USBHS_PDD_GetEndpointCompleteFlag(peripheralBase, EndpointsMask) ( \
    (uint32_t)((uint32_t)(EndpointsMask) & USBHS_EPCOMPLETE_REG(peripheralBase)) \
  )

/* ----------------------------------------------------------------------------
   -- GetAllEndpointCompleteFlags
   ---------------------------------------------------------------------------- */

/**
 * Returns flush pending flags.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_GetAllEndpointCompleteFlags(peripheralBase) ( \
    USBHS_EPCOMPLETE_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- ClearEndpointCompleteFlag
   ---------------------------------------------------------------------------- */

/**
 * Clears complete flag of endpoints addressed by the EndpointMask parameter.
 * @param peripheralBase Peripheral base address.
 * @param EndpointsMask Mask of endpoints to clear complete fllag.
 */
#define USBHS_PDD_ClearEndpointCompleteFlag(peripheralBase, EndpointsMask) ( \
    USBHS_EPCOMPLETE_REG(peripheralBase) = \
     (uint32_t)(EndpointsMask) \
  )

/* ----------------------------------------------------------------------------
   -- ClearAllEndpointCompleteFlags
   ---------------------------------------------------------------------------- */

/**
 * Clears complete flag of all endpoints.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_ClearAllEndpointCompleteFlags(peripheralBase) ( \
    USBHS_EPCOMPLETE_REG(peripheralBase) = \
     USBHS_EPCOMPLETE_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- GetEp0CtrlRegAddr
   ---------------------------------------------------------------------------- */

/**
 * Returns the address of the EP_x register.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_GetEp0CtrlRegAddr(peripheralBase) ( \
    (uint32_t *)&(USBHS_EPCR0_REG(peripheralBase)) \
  )

/* ----------------------------------------------------------------------------
   -- ReadEp0CtrlReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the Endpoint control 0 register.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_ReadEp0CtrlReg(peripheralBase) ( \
    USBHS_EPCR0_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteEp0CtrlReg
   ---------------------------------------------------------------------------- */

/**
 * Writes Value to the Endpoint control 0 register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value written to the Endpoint control 0 register.
 */
#define USBHS_PDD_WriteEp0CtrlReg(peripheralBase, Value) ( \
    USBHS_EPCR0_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadEp1CtrlReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the Endpoint control 1 register.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_ReadEp1CtrlReg(peripheralBase) ( \
    USBHS_EPCR_REG(peripheralBase,0U) \
  )

/* ----------------------------------------------------------------------------
   -- WriteEp1CtrlReg
   ---------------------------------------------------------------------------- */

/**
 * Writes Value to the Endpoint control 1 register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value written to the Endpoint control 1 register.
 */
#define USBHS_PDD_WriteEp1CtrlReg(peripheralBase, Value) ( \
    USBHS_EPCR_REG(peripheralBase,0U) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadEp2CtrlReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the Endpoint control 1 register.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_ReadEp2CtrlReg(peripheralBase) ( \
    USBHS_EPCR_REG(peripheralBase,1U) \
  )

/* ----------------------------------------------------------------------------
   -- WriteEp2CtrlReg
   ---------------------------------------------------------------------------- */

/**
 * Writes Value to the Endpoint control 2 register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value written to the Endpoint control 2 register.
 */
#define USBHS_PDD_WriteEp2CtrlReg(peripheralBase, Value) ( \
    USBHS_EPCR_REG(peripheralBase,1U) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadEp3CtrlReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the Endpoint control 3 register.
 * @param peripheralBase Peripheral base address.
 */
#define USBHS_PDD_ReadEp3CtrlReg(peripheralBase) ( \
    USBHS_EPCR_REG(peripheralBase,2U) \
  )

/* ----------------------------------------------------------------------------
   -- WriteEp3CtrlReg
   ---------------------------------------------------------------------------- */

/**
 * Writes Value to the Endpoint control 3 register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value written to the Endpoint control 3 register.
 */
#define USBHS_PDD_WriteEp3CtrlReg(peripheralBase, Value) ( \
    USBHS_EPCR_REG(peripheralBase,2U) = \
     (uint32_t)(Value) \
  )
#endif  /* #if defined(USBHS_PDD_H_) */

/* USBHS_PDD.h, eof. */
