/*
  PDD layer implementation for peripheral type CMP
  (C) 2010 Freescale, Inc. All rights reserved.

  This file is static and it is generated from API-Factory
*/

#if !defined(CMP_PDD_H_)
#define CMP_PDD_H_

/* ----------------------------------------------------------------------------
   -- Test if supported MCU is active
   ---------------------------------------------------------------------------- */

#if !defined(MCU_ACTIVE)
  // No MCU is active
  #error CMP PDD library: No derivative is active. Place proper #include with PDD memory map before including PDD library.
#elif \
      !defined(MCU_MK10D10) /* CMP0, CMP1, CMP2 */ && \
      !defined(MCU_MK10D5) /* CMP0, CMP1 */ && \
      !defined(MCU_MK10D7) /* CMP0, CMP1, CMP2 */ && \
      !defined(MCU_MK10F12) /* CMP0, CMP1, CMP2, CMP3 */ && \
      !defined(MCU_MK10DZ10) /* CMP0, CMP1, CMP2 */ && \
      !defined(MCU_MK11D5) /* CMP0, CMP1 */ && \
      !defined(MCU_MK12D5) /* CMP0, CMP1 */ && \
      !defined(MCU_MK20D10) /* CMP0, CMP1, CMP2 */ && \
      !defined(MCU_MK20D5) /* CMP0, CMP1 */ && \
      !defined(MCU_MK20D7) /* CMP0, CMP1, CMP2 */ && \
      !defined(MCU_MK20F12) /* CMP0, CMP1, CMP2, CMP3 */ && \
      !defined(MCU_MK20DZ10) /* CMP0, CMP1, CMP2 */ && \
      !defined(MCU_MK21D5) /* CMP0, CMP1 */ && \
      !defined(MCU_MK22D5) /* CMP0, CMP1 */ && \
      !defined(MCU_MK30D10) /* CMP0, CMP1, CMP2 */ && \
      !defined(MCU_MK30D7) /* CMP0, CMP1, CMP2 */ && \
      !defined(MCU_MK30DZ10) /* CMP0, CMP1, CMP2 */ && \
      !defined(MCU_MK40D10) /* CMP0, CMP1, CMP2 */ && \
      !defined(MCU_MK40D7) /* CMP0, CMP1, CMP2 */ && \
      !defined(MCU_MK40DZ10) /* CMP0, CMP1, CMP2 */ && \
      !defined(MCU_MK40X256VMD100) /* CMP0, CMP1, CMP2 */ && \
      !defined(MCU_MK50D10) /* CMP0, CMP1, CMP2 */ && \
      !defined(MCU_MK50D7) /* CMP0, CMP1, CMP2 */ && \
      !defined(MCU_MK50DZ10) /* CMP0, CMP1, CMP2 */ && \
      !defined(MCU_MK51D10) /* CMP0, CMP1, CMP2 */ && \
      !defined(MCU_MK51D7) /* CMP0, CMP1, CMP2 */ && \
      !defined(MCU_MK51DZ10) /* CMP0, CMP1, CMP2 */ && \
      !defined(MCU_MK52D10) /* CMP0, CMP1, CMP2 */ && \
      !defined(MCU_MK52DZ10) /* CMP0, CMP1, CMP2 */ && \
      !defined(MCU_MK53D10) /* CMP0, CMP1, CMP2 */ && \
      !defined(MCU_MK53DZ10) /* CMP0, CMP1, CMP2 */ && \
      !defined(MCU_MK60D10) /* CMP0, CMP1, CMP2 */ && \
      !defined(MCU_MK60F12) /* CMP0, CMP1, CMP2, CMP3 */ && \
      !defined(MCU_MK60F15) /* CMP0, CMP1, CMP2, CMP3 */ && \
      !defined(MCU_MK60DZ10) /* CMP0, CMP1, CMP2 */ && \
      !defined(MCU_MK60N512VMD100) /* CMP0, CMP1, CMP2 */ && \
      !defined(MCU_MK61F12) /* CMP0, CMP1, CMP2, CMP3 */ && \
      !defined(MCU_MK61F15) /* CMP0, CMP1, CMP2, CMP3 */ && \
      !defined(MCU_MK70F12) /* CMP0, CMP1, CMP2, CMP3 */ && \
      !defined(MCU_MK70F15) /* CMP0, CMP1, CMP2, CMP3 */ && \
      !defined(MCU_MKL04Z4) /* CMP0 */ && \
      !defined(MCU_MKL05Z4) /* CMP0 */ && \
      !defined(MCU_MKL14Z4) /* CMP0 */ && \
      !defined(MCU_MKL15Z4) /* CMP0 */ && \
      !defined(MCU_MKL24Z4) /* CMP0 */ && \
      !defined(MCU_MKL25Z4) /* CMP0 */ && \
      !defined(MCU_PCK20L4) /* CMP0, CMP1 */
  // Unsupported MCU is active
  #error CMP PDD library: Unsupported derivative is active.
#endif

#include "PDD_Types.h"

/* ----------------------------------------------------------------------------
   -- Method symbol definitions
   ---------------------------------------------------------------------------- */

/* Interrupts' mask. */
#define CMP_PDD_FALLING_EDGE_INTERRUPT CMP_SCR_IEF_MASK /**< Falling edge interrupt enable mask. */
#define CMP_PDD_RISING_EDGE_INTERRUPT CMP_SCR_IER_MASK /**< Rising edge interrupt enable mask. */

/* Interrupts' flags. */
#define CMP_PDD_FALLING_EDGE_FLAG CMP_SCR_CFF_MASK /**< Falling edge flag. */
#define CMP_PDD_RISING_EDGE_FLAG CMP_SCR_CFR_MASK /**< Rising edge flag. */

/* Comparator modes. */
#define CMP_PDD_FALLING_EDGE_MODE CMP_SCR_IEF_MASK /**< Falling edge detection mode. */
#define CMP_PDD_RISING_EDGE_MODE CMP_SCR_IER_MASK /**< Rising edge detection mode. */
#define CMP_PDD_BOTH_EDGES_MODE 0x6U             /**< Both falling and rising edge detection mode. */

/* Deprecated: Hysteresis constants. Please use HYSTERESIS_LEVEL_X constants. */
#define CMP_PDD_HYSTERESIS_DISABLE 0U            /**< Hysteresis not used. */
#define CMP_PDD_HYSTERESIS_20MV 0x1U             /**< 20 mV hysteresis used. */
#define CMP_PDD_HYSTERESIS_40MV 0x2U             /**< 40 mV hysteresis used. */
#define CMP_PDD_HYSTERESIS_60MV 0x3U             /**< 60 mV hysteresis used. */

/* Hysteresis constants. For exact value representation see peripheral device
   documentation. */
#define CMP_PDD_HYSTERESIS_LEVEL_0 0U            /**< Level 0 hysteresis used. */
#define CMP_PDD_HYSTERESIS_LEVEL_1 0x1U          /**< Level 1 hysteresis used. */
#define CMP_PDD_HYSTERESIS_LEVEL_2 0x2U          /**< Level 2 hysteresis used. */
#define CMP_PDD_HYSTERESIS_LEVEL_3 0x3U          /**< Level 3 hysteresis used. */

/* Filter sample count constants. */
#define CMP_PDD_FILTER_DISABLED 0U               /**< Filter disabled. */
#define CMP_PDD_FILTER_1_SAMPLE 0x10U            /**< 1 consecutive sample must agree. */
#define CMP_PDD_FILTER_2_SAMPLES 0x20U           /**< 2 consecutive samples must agree. */
#define CMP_PDD_FILTER_3_SAMPLES 0x30U           /**< 3 consecutive samples must agree. */
#define CMP_PDD_FILTER_4_SAMPLES 0x40U           /**< 4 consecutive samples must agree. */
#define CMP_PDD_FILTER_5_SAMPLES 0x50U           /**< 5 consecutive samples must agree. */
#define CMP_PDD_FILTER_6_SAMPLES 0x60U           /**< 6 consecutive samples must agree. */
#define CMP_PDD_FILTER_7_SAMPLES 0x70U           /**< 7 consecutive samples must agree. */

/* Comparator output filtration constant. */
#define CMP_PDD_FILTERED_OUTPUT 0U               /**< Filtered comparator output. */
#define CMP_PDD_UNFILTERED_OUTPUT CMP_CR1_COS_MASK /**< Filter on comparator output is bypassed. */

/* Comparator output inversion constant. */
#define CMP_PDD_NOT_INVERTED_OUTPUT 0U           /**< Comparator output is not inverted. */
#define CMP_PDD_INVERTED_OUTPUT CMP_CR1_INV_MASK /**< Comparator output is inverted. */

/* Comparator power mode constant. */
#define CMP_PDD_LOW_POWER_MODE 0U                /**< Low power/low speed mode. */
#define CMP_PDD_HIGH_SPEED_MODE CMP_CR1_PMODE_MASK /**< High power/high speed mode. */

#if ((defined(MCU_MK10DZ10)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60N512VMD100)))
/* Comparator's interrupt stop mode constant. */
  #define CMP_PDD_LEVEL_SENSITIVE_MODE 0U          /**< Comparator is level sensitive in stop mode */
  #define CMP_PDD_EDGE_SENSITIVE_MODE CMP_SCR_SMELB_MASK /**< Comparator is edge sensitive in stop mode */

#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK52D10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_MKL04Z4)) || (defined(MCU_MKL05Z4)) || (defined(MCU_MKL14Z4)) || (defined(MCU_MKL15Z4)) || (defined(MCU_MKL24Z4)) || (defined(MCU_MKL25Z4)) || (defined(MCU_PCK20L4)) */
/* Comparator's interrupt stop mode constant. */
  #define CMP_PDD_LEVEL_SENSITIVE_MODE 0U          /**< Comparator is level sensitive in stop mode */
  #define CMP_PDD_EDGE_SENSITIVE_MODE 0x1U         /**< Comparator is edge sensitive in stop mode */

#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK52D10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_MKL04Z4)) || (defined(MCU_MKL05Z4)) || (defined(MCU_MKL14Z4)) || (defined(MCU_MKL15Z4)) || (defined(MCU_MKL24Z4)) || (defined(MCU_MKL25Z4)) || (defined(MCU_PCK20L4)) */
/* Analog comparator 6-bit DAC supply voltage reference source constant. */
#define CMP_PDD_V_REF_INPUT_1 0U                 /**< Vin1 reference. */
#define CMP_PDD_V_REF_INPUT_2 CMP_DACCR_VRSEL_MASK /**< Vin2 reference */

/* Negative input constant. */
#define CMP_PDD_NEGATIVE_INPUT_0 0U              /**< Negative input 0. */
#define CMP_PDD_NEGATIVE_INPUT_1 0x1U            /**< Negative input 1. */
#define CMP_PDD_NEGATIVE_INPUT_2 0x2U            /**< Negative input 2. */
#define CMP_PDD_NEGATIVE_INPUT_3 0x3U            /**< Negative input 3. */
#define CMP_PDD_NEGATIVE_INPUT_4 0x4U            /**< Negative input 4. */
#define CMP_PDD_NEGATIVE_INPUT_5 0x5U            /**< Negative input 5. */
#define CMP_PDD_NEGATIVE_INPUT_6 0x6U            /**< Negative input 6. */
#define CMP_PDD_NEGATIVE_INPUT_7 0x7U            /**< Negative input 7. */

/* Positive input constant. */
#define CMP_PDD_POSITIVE_INPUT_0 0U              /**< Positive input 0. */
#define CMP_PDD_POSITIVE_INPUT_1 0x8U            /**< Positive input 1. */
#define CMP_PDD_POSITIVE_INPUT_2 0x10U           /**< Positive input 2. */
#define CMP_PDD_POSITIVE_INPUT_3 0x18U           /**< Positive input 3. */
#define CMP_PDD_POSITIVE_INPUT_4 0x20U           /**< Positive input 4. */
#define CMP_PDD_POSITIVE_INPUT_5 0x28U           /**< Positive input 5. */
#define CMP_PDD_POSITIVE_INPUT_6 0x30U           /**< Positive input 6. */
#define CMP_PDD_POSITIVE_INPUT_7 0x38U           /**< Positive input 7. */


/* ----------------------------------------------------------------------------
   -- EnableDevice
   ---------------------------------------------------------------------------- */

/**
 * Enables the comparator's device.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state of comparator.
 */
#define CMP_PDD_EnableDevice(peripheralBase, State) ( \
    CMP_CR1_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(CMP_CR1_REG(peripheralBase) & (uint8_t)(~(uint8_t)CMP_CR1_EN_MASK))) | ( \
      (uint8_t)(State))) \
  )

/* ----------------------------------------------------------------------------
   -- GetDeviceEnabled
   ---------------------------------------------------------------------------- */

/**
 * Returns current state of comparator's enable bit.
 * @param peripheralBase Peripheral base address.
 */
#define CMP_PDD_GetDeviceEnabled(peripheralBase) ( \
    (uint8_t)(CMP_CR1_REG(peripheralBase) & CMP_CR1_EN_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- EnableInterrupts
   ---------------------------------------------------------------------------- */

/**
 * Enables interrupts defined by mask parameter.
 * @param peripheralBase Peripheral base address.
 * @param Mask Mask of interrupts to enable.
 */
#define CMP_PDD_EnableInterrupts(peripheralBase, Mask) ( \
    CMP_SCR_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(CMP_SCR_REG(peripheralBase) | (uint8_t)(Mask))) & (( \
      (uint8_t)(~(uint8_t)CMP_SCR_CFF_MASK)) & ( \
      (uint8_t)(~(uint8_t)CMP_SCR_CFR_MASK)))) \
  )

/* ----------------------------------------------------------------------------
   -- DisableInterrupts
   ---------------------------------------------------------------------------- */

/**
 * Disables interrupts defined by mask parameter.
 * @param peripheralBase Peripheral base address.
 * @param Mask Mask of interrupts to disable.
 */
#define CMP_PDD_DisableInterrupts(peripheralBase, Mask) ( \
    CMP_SCR_REG(peripheralBase) &= \
     (uint8_t)(( \
      (uint8_t)(~(uint8_t)(Mask))) & (( \
      (uint8_t)(~(uint8_t)CMP_SCR_CFF_MASK)) & ( \
      (uint8_t)(~(uint8_t)CMP_SCR_CFR_MASK)))) \
  )

/* ----------------------------------------------------------------------------
   -- SetInterruptMask
   ---------------------------------------------------------------------------- */

/**
 * Sets all interrupts with value according to mask parameter.
 * @param peripheralBase Peripheral base address.
 * @param Mask Mask of interrupts to enable - rest will be disabled.
 */
#define CMP_PDD_SetInterruptMask(peripheralBase, Mask) ( \
    CMP_SCR_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(( \
       CMP_SCR_REG(peripheralBase)) & (( \
       (uint8_t)(~(uint8_t)(CMP_SCR_IEF_MASK | CMP_SCR_IER_MASK))) & (( \
       (uint8_t)(~(uint8_t)CMP_SCR_CFF_MASK)) & ( \
       (uint8_t)(~(uint8_t)CMP_SCR_CFR_MASK)))))) | ( \
      (uint8_t)(Mask))) \
  )

/* ----------------------------------------------------------------------------
   -- GetInterruptMask
   ---------------------------------------------------------------------------- */

/**
 * Returns interrupts mask.
 * @param peripheralBase Peripheral base address.
 */
#define CMP_PDD_GetInterruptMask(peripheralBase) ( \
    (uint8_t)(CMP_SCR_REG(peripheralBase) & (uint8_t)(CMP_SCR_IEF_MASK | CMP_SCR_IER_MASK)) \
  )

/* ----------------------------------------------------------------------------
   -- GetInterruptFlags
   ---------------------------------------------------------------------------- */

/**
 * Returns interrupt flag bits.
 * @param peripheralBase Peripheral base address.
 */
#define CMP_PDD_GetInterruptFlags(peripheralBase) ( \
    (uint8_t)(CMP_SCR_REG(peripheralBase) & (uint8_t)(CMP_SCR_CFF_MASK | CMP_SCR_CFR_MASK)) \
  )

/* ----------------------------------------------------------------------------
   -- ClearInterruptFlags
   ---------------------------------------------------------------------------- */

/**
 * Clears interrupt flag bits defined by mask parameter.
 * @param peripheralBase Peripheral base address.
 * @param Mask Mask of interrupt's flags to clear.
 */
#define CMP_PDD_ClearInterruptFlags(peripheralBase, Mask) ( \
    CMP_SCR_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(( \
       CMP_SCR_REG(peripheralBase)) & ( \
       (uint8_t)(~(uint8_t)(CMP_SCR_CFF_MASK | CMP_SCR_CFR_MASK))))) | ( \
      (uint8_t)(Mask))) \
  )

/* ----------------------------------------------------------------------------
   -- SetHysteresis
   ---------------------------------------------------------------------------- */

/**
 * Sets comparator hard block hysteresis control bits.
 * @param peripheralBase Peripheral base address.
 * @param Hysteresis Hysteresis value.
 */
#define CMP_PDD_SetHysteresis(peripheralBase, Hysteresis) ( \
    CMP_CR0_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(CMP_CR0_REG(peripheralBase) & (uint8_t)(~(uint8_t)CMP_CR0_HYSTCTR_MASK))) | ( \
      (uint8_t)(Hysteresis))) \
  )

/* ----------------------------------------------------------------------------
   -- SetFilterCount
   ---------------------------------------------------------------------------- */

/**
 * Sets filter sample count bits.
 * @param peripheralBase Peripheral base address.
 * @param Count Filter sample count.
 */
#define CMP_PDD_SetFilterCount(peripheralBase, Count) ( \
    CMP_CR0_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(CMP_CR0_REG(peripheralBase) & (uint8_t)(~(uint8_t)CMP_CR0_FILTER_CNT_MASK))) | ( \
      (uint8_t)(Count))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableOutputPin
   ---------------------------------------------------------------------------- */

/**
 * Comparator output pin enable.
 * @param peripheralBase Peripheral base address.
 * @param State Parameter specifying if output pin will be enabled or disabled.
 */
#define CMP_PDD_EnableOutputPin(peripheralBase, State) ( \
    CMP_CR1_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(CMP_CR1_REG(peripheralBase) & (uint8_t)(~(uint8_t)CMP_CR1_OPE_MASK))) | ( \
      (uint8_t)((uint8_t)(State) << CMP_CR1_OPE_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- SetComparatorOutputFilter
   ---------------------------------------------------------------------------- */

/**
 * Selects comparator output filtration.
 * @param peripheralBase Peripheral base address.
 * @param Output Parameter specifying if output will be filtered or not.
 */
#define CMP_PDD_SetComparatorOutputFilter(peripheralBase, Output) ( \
    CMP_CR1_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(CMP_CR1_REG(peripheralBase) & (uint8_t)(~(uint8_t)CMP_CR1_COS_MASK))) | ( \
      (uint8_t)(Output))) \
  )

/* ----------------------------------------------------------------------------
   -- SetComparatorOutputInversion
   ---------------------------------------------------------------------------- */

/**
 * Selects comparator output inversion.
 * @param peripheralBase Peripheral base address.
 * @param Output Parameter specifying if output will be inverted or not.
 */
#define CMP_PDD_SetComparatorOutputInversion(peripheralBase, Output) ( \
    CMP_CR1_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(CMP_CR1_REG(peripheralBase) & (uint8_t)(~(uint8_t)CMP_CR1_INV_MASK))) | ( \
      (uint8_t)(Output))) \
  )

/* ----------------------------------------------------------------------------
   -- SetPowerMode
   ---------------------------------------------------------------------------- */

/**
 * Selects comparator power mode.
 * @param peripheralBase Peripheral base address.
 * @param Mode Power mode.
 */
#define CMP_PDD_SetPowerMode(peripheralBase, Mode) ( \
    CMP_CR1_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(CMP_CR1_REG(peripheralBase) & (uint8_t)(~(uint8_t)CMP_CR1_PMODE_MASK))) | ( \
      (uint8_t)(Mode))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableWindowing
   ---------------------------------------------------------------------------- */

/**
 * Windowing enable.
 * @param peripheralBase Peripheral base address.
 * @param State Parameter specifying if windowing will be enabled or disabled.
 */
#define CMP_PDD_EnableWindowing(peripheralBase, State) ( \
    CMP_CR1_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(CMP_CR1_REG(peripheralBase) & (uint8_t)(~(uint8_t)CMP_CR1_WE_MASK))) | ( \
      (uint8_t)((uint8_t)(State) << CMP_CR1_WE_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableSampling
   ---------------------------------------------------------------------------- */

/**
 * Sampling enable.
 * @param peripheralBase Peripheral base address.
 * @param State Parameter specifying if sampling will be enabled or disabled.
 */
#define CMP_PDD_EnableSampling(peripheralBase, State) ( \
    CMP_CR1_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(CMP_CR1_REG(peripheralBase) & (uint8_t)(~(uint8_t)CMP_CR1_SE_MASK))) | ( \
      (uint8_t)((uint8_t)(State) << CMP_CR1_SE_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- SetFilterPeriod
   ---------------------------------------------------------------------------- */

/**
 * Sets filter sample period.
 * @param peripheralBase Peripheral base address.
 * @param Period Filter sample period value.
 */
#define CMP_PDD_SetFilterPeriod(peripheralBase, Period) ( \
    CMP_FPR_REG(peripheralBase) = \
     (uint8_t)(Period) \
  )

/* ----------------------------------------------------------------------------
   -- GetComparatorOutput
   ---------------------------------------------------------------------------- */

/**
 * Returns current comparator output state.
 * @param peripheralBase Peripheral base address.
 */
#define CMP_PDD_GetComparatorOutput(peripheralBase) ( \
    (uint8_t)(CMP_SCR_REG(peripheralBase) & CMP_SCR_COUT_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- EnableDmaRequest
   ---------------------------------------------------------------------------- */

/**
 * DMA enable control.
 * @param peripheralBase Peripheral base address.
 * @param State Parameter specifying if DMA requests will be enabled or disabled.
 */
#define CMP_PDD_EnableDmaRequest(peripheralBase, State) ( \
    CMP_SCR_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(( \
       CMP_SCR_REG(peripheralBase)) & (( \
       (uint8_t)(~(uint8_t)CMP_SCR_DMAEN_MASK)) & (( \
       (uint8_t)(~(uint8_t)CMP_SCR_CFF_MASK)) & ( \
       (uint8_t)(~(uint8_t)CMP_SCR_CFR_MASK)))))) | ( \
      (uint8_t)((uint8_t)(State) << CMP_SCR_DMAEN_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- SetComparatorMode
   ---------------------------------------------------------------------------- */

/**
 * Sets comparator's interrupt mode.
 * @param peripheralBase Peripheral base address.
 * @param Mode Comparator interrupt mode.
 */
#define CMP_PDD_SetComparatorMode(peripheralBase, Mode) ( \
    CMP_PDD_SetInterruptMask(peripheralBase, (uint8_t)(Mode)) \
  )

/* ----------------------------------------------------------------------------
   -- GetCompareStatus
   ---------------------------------------------------------------------------- */

/**
 * Returns last detected edge on comparator's output.
 * @param peripheralBase Peripheral base address.
 */
#define CMP_PDD_GetCompareStatus(peripheralBase) ( \
    CMP_PDD_GetInterruptFlags(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- SetVoltage
   ---------------------------------------------------------------------------- */

/**
 * Sets DAC6b output voltage.
 * @param peripheralBase Peripheral base address.
 * @param Value Output voltage value.
 */
#define CMP_PDD_SetVoltage(peripheralBase, Value) ( \
    CMP_DACCR_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(CMP_DACCR_REG(peripheralBase) & (uint8_t)(~(uint8_t)CMP_DACCR_VOSEL_MASK))) | ( \
      (uint8_t)(Value))) \
  )

/* ----------------------------------------------------------------------------
   -- SetReference
   ---------------------------------------------------------------------------- */

/**
 * Selects analog comparator 6-bit DAC supply voltage reference source.
 * @param peripheralBase Peripheral base address.
 * @param Reference Supply voltage source.
 */
#define CMP_PDD_SetReference(peripheralBase, Reference) ( \
    CMP_DACCR_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(CMP_DACCR_REG(peripheralBase) & (uint8_t)(~(uint8_t)CMP_DACCR_VRSEL_MASK))) | ( \
      (uint8_t)(Reference))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableDac
   ---------------------------------------------------------------------------- */

/**
 * Analog comparator 6-bit DAC enable control.
 * @param peripheralBase Peripheral base address.
 * @param State Parameter specifying if DAC will be enabled or disabled.
 */
#define CMP_PDD_EnableDac(peripheralBase, State) ( \
    CMP_DACCR_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(CMP_DACCR_REG(peripheralBase) & (uint8_t)(~(uint8_t)CMP_DACCR_DACEN_MASK))) | ( \
      (uint8_t)((uint8_t)(State) << CMP_DACCR_DACEN_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- GetDacEnabled
   ---------------------------------------------------------------------------- */

/**
 * Returns current state of analog comparator 6-bit DAC enable bit.
 * @param peripheralBase Peripheral base address.
 */
#define CMP_PDD_GetDacEnabled(peripheralBase) ( \
    (uint8_t)(CMP_DACCR_REG(peripheralBase) & CMP_DACCR_DACEN_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- SetNegativeInput
   ---------------------------------------------------------------------------- */

/**
 * Sets negative comparator input.
 * @param peripheralBase Peripheral base address.
 * @param NegativeInput Negative input number.
 */
#define CMP_PDD_SetNegativeInput(peripheralBase, NegativeInput) ( \
    CMP_MUXCR_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(CMP_MUXCR_REG(peripheralBase) & (uint8_t)(~(uint8_t)CMP_MUXCR_MSEL_MASK))) | ( \
      (uint8_t)(NegativeInput))) \
  )

/* ----------------------------------------------------------------------------
   -- SetPositiveInput
   ---------------------------------------------------------------------------- */

/**
 * Sets positive comparator input.
 * @param peripheralBase Peripheral base address.
 * @param PositiveInput Positive input number.
 */
#define CMP_PDD_SetPositiveInput(peripheralBase, PositiveInput) ( \
    CMP_MUXCR_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(CMP_MUXCR_REG(peripheralBase) & (uint8_t)(~(uint8_t)CMP_MUXCR_PSEL_MASK))) | ( \
      (uint8_t)(PositiveInput))) \
  )

/* ----------------------------------------------------------------------------
   -- SetStopMode
   ---------------------------------------------------------------------------- */

/**
 * Selects stop mode edge/level interrupt control.
 * @param peripheralBase Peripheral base address.
 * @param Mode Parameter specifying if edge or level stop mode will be used.
 */
#define CMP_PDD_SetStopMode(peripheralBase, Mode) ( \
    CMP_SCR_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(( \
       CMP_SCR_REG(peripheralBase)) & (( \
       (uint8_t)(~(uint8_t)CMP_SCR_SMELB_MASK)) & (( \
       (uint8_t)(~(uint8_t)CMP_SCR_CFF_MASK)) & ( \
       (uint8_t)(~(uint8_t)CMP_SCR_CFR_MASK)))))) | ( \
      (uint8_t)(Mode))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableNegativeInput
   ---------------------------------------------------------------------------- */

/**
 * Negative MUX enable control.
 * @param peripheralBase Peripheral base address.
 * @param State Parameter specifying if negative input will be enabled or
 *        disabled.
 */
#define CMP_PDD_EnableNegativeInput(peripheralBase, State) ( \
    CMP_MUXCR_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(CMP_MUXCR_REG(peripheralBase) & (uint8_t)(~(uint8_t)CMP_MUXCR_MEN_MASK))) | ( \
      (uint8_t)((uint8_t)(State) << CMP_MUXCR_MEN_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- EnablePositiveInput
   ---------------------------------------------------------------------------- */

/**
 * Postive MUX enable control.
 * @param peripheralBase Peripheral base address.
 * @param State Parameter specifying if positive input will be enabled or
 *        disabled.
 */
#define CMP_PDD_EnablePositiveInput(peripheralBase, State) ( \
    CMP_MUXCR_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(CMP_MUXCR_REG(peripheralBase) & (uint8_t)(~(uint8_t)CMP_MUXCR_PEN_MASK))) | ( \
      (uint8_t)((uint8_t)(State) << CMP_MUXCR_PEN_SHIFT))) \
  )
#endif  /* #if defined(CMP_PDD_H_) */

/* CMP_PDD.h, eof. */
