/*
  PDD layer implementation for peripheral type SDHC
  (C) 2010 Freescale, Inc. All rights reserved.

  This file is static and it is generated from API-Factory
*/

#if !defined(SDHC_PDD_H_)
#define SDHC_PDD_H_

/* ----------------------------------------------------------------------------
   -- Test if supported MCU is active
   ---------------------------------------------------------------------------- */

#if !defined(MCU_ACTIVE)
  // No MCU is active
  #error SDHC PDD library: No derivative is active. Place proper #include with PDD memory map before including PDD library.
#elif \
      !defined(MCU_MK10D10) /* SDHC */ && \
      !defined(MCU_MK10F12) /* SDHC */ && \
      !defined(MCU_MK10DZ10) /* SDHC */ && \
      !defined(MCU_MK20D10) /* SDHC */ && \
      !defined(MCU_MK20F12) /* SDHC */ && \
      !defined(MCU_MK20DZ10) /* SDHC */ && \
      !defined(MCU_MK30D10) /* SDHC */ && \
      !defined(MCU_MK30DZ10) /* SDHC */ && \
      !defined(MCU_MK40D10) /* SDHC */ && \
      !defined(MCU_MK40DZ10) /* SDHC */ && \
      !defined(MCU_MK40X256VMD100) /* SDHC */ && \
      !defined(MCU_MK50D10) /* SDHC */ && \
      !defined(MCU_MK50DZ10) /* SDHC */ && \
      !defined(MCU_MK51D10) /* SDHC */ && \
      !defined(MCU_MK51DZ10) /* SDHC */ && \
      !defined(MCU_MK52D10) /* SDHC */ && \
      !defined(MCU_MK52DZ10) /* SDHC */ && \
      !defined(MCU_MK53D10) /* SDHC */ && \
      !defined(MCU_MK53DZ10) /* SDHC */ && \
      !defined(MCU_MK60D10) /* SDHC */ && \
      !defined(MCU_MK60F12) /* SDHC */ && \
      !defined(MCU_MK60F15) /* SDHC */ && \
      !defined(MCU_MK60DZ10) /* SDHC */ && \
      !defined(MCU_MK60N512VMD100) /* SDHC */ && \
      !defined(MCU_MK61F12) /* SDHC */ && \
      !defined(MCU_MK61F15) /* SDHC */ && \
      !defined(MCU_MK70F12) /* SDHC */ && \
      !defined(MCU_MK70F15) /* SDHC */
  // Unsupported MCU is active
  #error SDHC PDD library: Unsupported derivative is active.
#endif

#include "PDD_Types.h"

/* ----------------------------------------------------------------------------
   -- Method symbol definitions
   ---------------------------------------------------------------------------- */

/* Transfer DMA usage */
#define SDHC_PDD_ENABLE_DMA SDHC_XFERTYP_DMAEN_MASK /**< Enable DMA. */
#define SDHC_PDD_DISABLE_DMA 0U                  /**< Disable DMA. */

/* Transfer block count */
#define SDHC_PDD_ENABLE_BLOCK_COUNT SDHC_XFERTYP_BCEN_MASK /**< Enable block count. */
#define SDHC_PDD_DISABLE_BLOCK_COUNT 0U          /**< Disable block count. */

/* Transfer auto CMD12 */
#define SDHC_PDD_ENABLE_AUTO_CMD12 SDHC_XFERTYP_AC12EN_MASK /**< Enable auto CMD12. */
#define SDHC_PDD_DISABLE_AUTO_CMD12 0U           /**< Disable auto CMD12. */

/* Transfer data direction */
#define SDHC_PDD_DATA_READ SDHC_XFERTYP_DTDSEL_MASK /**< Data read. */
#define SDHC_PDD_DATA_WRITE 0U                   /**< Data write. */

/* Transfer multi/single block */
#define SDHC_PDD_SINGLE_BLOCK 0U                 /**< Single block. */
#define SDHC_PDD_MULTIPLE_BLOCK SDHC_XFERTYP_MSBSEL_MASK /**< Multiple block. */

/* Command response type */
#define SDHC_PDD_NO_RESPONSE 0U                  /**< No response. */
#define SDHC_PDD_RESPONSE_LENGTH_136 0x10000U    /**< Response of length 136 bit. */
#define SDHC_PDD_RESPONSE_LENGTH_48 0x20000U     /**< Response of length 48 bit. */
#define SDHC_PDD_RESPONSE_LENGTH_48_BUSY_CHECK 0x30000U /**< Response of length 48 bit with busy check. */

/* Command CRC check */
#define SDHC_PDD_ENABLE_CRC_CHECK SDHC_XFERTYP_CCCEN_MASK /**< Enable CRC check. */
#define SDHC_PDD_DISABLE_CRC_CHECK 0U            /**< Disable CRC check. */

/* Command index check */
#define SDHC_PDD_ENABLE_INDEX_CHECK SDHC_XFERTYP_CICEN_MASK /**< Enable index check. */
#define SDHC_PDD_DISABLE_INDEX_CHECK 0U          /**< Disable index check. */

/* Command data present */
#define SDHC_PDD_DATA_PRESENT SDHC_XFERTYP_DPSEL_MASK /**< Data present. */
#define SDHC_PDD_NO_DATA_PRESENT 0U              /**< No data present. */

/* Command type */
#define SDHC_PDD_NORMAL_CMD 0U                   /**< Normal command. */
#define SDHC_PDD_SUSPEND_CMD 0x400000U           /**< Suspend command. */
#define SDHC_PDD_RESUME_CMD 0x800000U            /**< Resume command. */
#define SDHC_PDD_ABORT_CMD 0xC00000U             /**< Abort command. */

/* Command class 0 - basic */
#define SDHC_PDD_CMD0_GO_IDLE_STATE 0U           /**< Go idle state. */
#define SDHC_PDD_CMD1_SEND_OP_COND 0x1U          /**< Send operation conditions. */
#define SDHC_PDD_CMD2_ALL_SEND_CID 0x2U          /**< All send CID (card identification register). */
#define SDHC_PDD_CMD3_SET_RELATIVE_ADDR 0x3U     /**< Set/send relative address. */
#define SDHC_PDD_CMD4_SET_DSR 0x4U               /**< Set DSR (driver stage register). */
#define SDHC_PDD_CMD5_IO_SEND_OP_COND 0x5U       /**< Send IO conditions. */
#define SDHC_PDD_CMD6_SWITCH 0x6U                /**< Switch function. */
#define SDHC_PDD_CMD7_SELECT_CARD 0x7U           /**< Select/deselect card. */
#define SDHC_PDD_CMD8_SEND_EXT_CSD 0x8U          /**< Send EXT_CSD (extended card specific data register). */
#define SDHC_PDD_CMD9_SEND_CSD 0x9U              /**< Send CSD (card specific data register). */
#define SDHC_PDD_CMD10_SEND_CID 0xAU             /**< Send CID (card identification register). */
#define SDHC_PDD_CMD12_STOP_TRANSMISSION 0xCU    /**< Stop transmission. */
#define SDHC_PDD_CMD13_SEND_STATUS 0xDU          /**< Send status. */
#define SDHC_PDD_CMD14_BUS_TEST_READ 0xEU        /**< Bus test pattern read. */
#define SDHC_PDD_CMD15_GO_INACTIVE_STATE 0xFU    /**< Go inactive state. */
#define SDHC_PDD_CMD19_BUS_TEST_WRITE 0x13U      /**< Bus test pattern write. */

/* Command class 1 - stream read */
#define SDHC_PDD_CMD11_READ_DAT_UNTIL_STOP 0xBU  /**< Read data until stop. */

/* Command class 2 - block read */
#define SDHC_PDD_CMD16_SET_BLOCKLEN 0x10U        /**< Set block length. */
#define SDHC_PDD_CMD17_READ_SINGLE_BLOCK 0x11U   /**< Read single block. */
#define SDHC_PDD_CMD18_READ_MULTIPLE_BLOCK 0x12U /**< Read multiple block. */

/* Command class 3 - stream write */
#define SDHC_PDD_CMD20_WRITE_DAT_UNTIL_STOP 0x14U /**< Write data until stop. */

/* Command class 4 - block write */
#define SDHC_PDD_CMD24_WRITE_BLOCK 0x18U         /**< Write block. */
#define SDHC_PDD_CMD25_WRITE_MULTIPLE_BLOCK 0x19U /**< Write multiple block. */
#define SDHC_PDD_CMD26_PROGRAM_CID 0x1AU         /**< Program CID (card identification register). */
#define SDHC_PDD_CMD27_PROGRAM_CSD 0x1BU         /**< Program CSD (card specific data register). */

/* Command class 5 - erase */
#define SDHC_PDD_CMD32_TAG_SECTOR_START 0x20U    /**< Tag sector start [SD]. */
#define SDHC_PDD_CMD33_TAG_SECTOR_END 0x21U      /**< Tag sector end [SD]. */
#define SDHC_PDD_CMD34_UNTAG_SECTOR 0x22U        /**< Untag sector. */
#define SDHC_PDD_CMD35_TAG_ERASE_GROUP_START 0x23U /**< Tag erase group start [MMC]. */
#define SDHC_PDD_CMD36_TAG_ERASE_GROUP_END 0x24U /**< Tag erase group end [MMC]. */
#define SDHC_PDD_CMD37_UNTAG_ERASE_GROUP 0x25U   /**< Untag erase group. */
#define SDHC_PDD_CMD38_ERASE 0x26U               /**< Erase. */

/* Command class 6 - write protection */
#define SDHC_PDD_CMD28_SET_WRITE_PROT 0x1CU      /**< Set write protection. */
#define SDHC_PDD_CMD29_CLR_WRITE_PROT 0x1DU      /**< Clear write protection. */
#define SDHC_PDD_CMD30_SEND_WRITE_PROT 0x1EU     /**< Send write protection. */

/* Command class 7 - lock card */
#define SDHC_PDD_CMD42_LOCK_UNLOCK 0x2AU         /**< Lock/unlock card. */

/* Command class 8 - application specific */
#define SDHC_PDD_CMD55_APP_CMD 0x37U             /**< Application specific command. */
#define SDHC_PDD_CMD56_GEN_CMD 0x38U             /**< General purpose command. */

/* Command class 9 - IO mode */
#define SDHC_PDD_CMD39_FAST_IO 0x27U             /**< Fast IO [MMC]. */
#define SDHC_PDD_CMD40_GO_IRQ_STATE 0x28U        /**< Go IRQ state [MMC]. */
#define SDHC_PDD_CMD52_IO_RW_DIRECT 0x34U        /**< IO direct read/write [SD]. */
#define SDHC_PDD_CMD53_IO_RW_EXTENDED 0x35U      /**< IO extended read/write [SD]. */

/* Command class 10 - switch [SD] */
#define SDHC_PDD_CMD60_RW_MULTIPLE_REG 0x3CU     /**< Read/write multiple register. */
#define SDHC_PDD_CMD61_RW_MULTIPLE_BLOCK 0x3DU   /**< Read/write multiple block. */

/* Application specific commands [SD] */
#define SDHC_PDD_ACMD6_SET_BUS_WIDTH 0x6U        /**< Set bus width. */
#define SDHC_PDD_ACMD13_SD_STATUS 0xDU           /**< Send SD status. */
#define SDHC_PDD_ACMD22_SEND_NUM_WR_SECTORS 0x16U /**< Send number of written sectors. */
#define SDHC_PDD_ACMD23_SET_WR_BLK_ERASE_COUNT 0x17U /**< Set write block erase count. */
#define SDHC_PDD_ACMD41_SD_APP_OP_COND 0x29U     /**< Send operational conditions. */
#define SDHC_PDD_ACMD42_SET_CLR_CARD_DETECT 0x2AU /**< Set/clear card detection. */
#define SDHC_PDD_ACMD51_SEND_SCR 0x33U           /**< Send SCR (SD configuration register). */

/* Interrupt masks */
#define SDHC_PDD_COMMAND_COMPLETE_INT SDHC_IRQSTAT_CC_MASK /**< The end bit of the command response is received (except Auto CMD12). */
#define SDHC_PDD_TRANSFER_COMPLETE_INT SDHC_IRQSTAT_TC_MASK /**< Read or write transfer is completed. */
#define SDHC_PDD_BLOCK_GAP_EVENT_INT SDHC_IRQSTAT_BGE_MASK /**< Read or write transaction is stopped at a block gap. */
#define SDHC_PDD_DMA_INT SDHC_IRQSTAT_DINT_MASK  /**< The internal DMA (simple or advanced) finished the data transfer successfully. */
#define SDHC_PDD_BUFFER_WRITE_READY_INT SDHC_IRQSTAT_BWR_MASK /**< Ready to write buffer. */
#define SDHC_PDD_BUFFER_READ_READY_INT SDHC_IRQSTAT_BRR_MASK /**< Ready to read buffer. */
#define SDHC_PDD_CARD_INSERTION_INT SDHC_IRQSTAT_CINS_MASK /**< Card inserted. */
#define SDHC_PDD_CARD_REMOVAL_INT SDHC_IRQSTAT_CRM_MASK /**< Card removed. */
#define SDHC_PDD_CARD_INT SDHC_IRQSTAT_CINT_MASK /**< Card interrupt. */
#define SDHC_PDD_COMMAND_TIMEOUT_ERROR_INT SDHC_IRQSTAT_CTOE_MASK /**< No response is returned within 64 SDHC_CLK cycles from the end bit of the command or SDHC detects a SDHC_CMD line conflict. */
#define SDHC_PDD_COMMAND_CRC_ERROR_INT SDHC_IRQSTAT_CCE_MASK /**< CRC error in the command response is detected or SDHC_CMD line conflict is detected when a command is issued. */
#define SDHC_PDD_COMMAND_END_BIT_ERROR_INT SDHC_IRQSTAT_CEBE_MASK /**< The end bit of a command response is 0. */
#define SDHC_PDD_COMMAND_INDEX_ERROR_INT SDHC_IRQSTAT_CIE_MASK /**< Command index error occured in the command response. */
#define SDHC_PDD_DATA_TIMEOUT_ERROR_INT SDHC_IRQSTAT_DTOE_MASK /**< Data timeout error. */
#define SDHC_PDD_DATA_CRC_ERROR_INT SDHC_IRQSTAT_DCE_MASK /**< CRC error detected when transferring read data on the SDHC_DAT line or the write CRC status having a value other than 0b010 detected. */
#define SDHC_PDD_DATA_END_BIT_ERROR_INT SDHC_IRQSTAT_DEBE_MASK /**< Zero at the end bit position of read data on the SDHC_DAT line or at the end bit position of the CRC detected. */
#define SDHC_PDD_AUTO_CMD12_ERROR_INT SDHC_IRQSTAT_AC12E_MASK /**< Auto CMD12 error. */
#define SDHC_PDD_DMA_ERROR_INT SDHC_IRQSTAT_DMAE_MASK /**< Internal DMA (simple or advanced) transfer failed. */

/* Filter modes */
#define SDHC_PDD_AUTO_CMD12_NOT_EXECUTED SDHC_AC12ERR_AC12NE_MASK /**< Auto CMD12 not executed. */
#define SDHC_PDD_AUTO_CMD12_TIMEOUT_ERROR SDHC_AC12ERR_AC12TOE_MASK /**< Auto CMD12 timeout error. */
#define SDHC_PDD_AUTO_CMD12_END_BIT_ERROR SDHC_AC12ERR_AC12EBE_MASK /**< Auto CMD12 end bit error. */
#define SDHC_PDD_AUTO_CMD12_CRC_ERROR SDHC_AC12ERR_AC12CE_MASK /**< Auto CMD12 CRC error. */
#define SDHC_PDD_AUTO_CMD12_INDEX_ERROR SDHC_AC12ERR_AC12IE_MASK /**< Auto CMD12 index error. */
#define SDHC_PDD_CMD_NOT_ISSUED_BY_AUTO_CMD12_ERROR SDHC_AC12ERR_CNIBAC12E_MASK /**< Command not issued by Auto CMD12 error. */

/* Host capabilities flags */
#define SDHC_PDD_ADMA_SUPPORT SDHC_HTCAPBLT_ADMAS_MASK /**< Advanced DMA support. */
#define SDHC_PDD_HIGH_SPEED_SUPPORT SDHC_HTCAPBLT_HSS_MASK /**< High speed support. */
#define SDHC_PDD_DMA_SUPPORT SDHC_HTCAPBLT_DMAS_MASK /**< DMA support. */
#define SDHC_PDD_SUSPEND_RESUME_SUPPORT SDHC_HTCAPBLT_SRS_MASK /**< Suspend/resume support. */
#define SDHC_PDD_3_3_V_SUPPORT SDHC_HTCAPBLT_VS33_MASK /**< Voltage support 3.3V. */
#define SDHC_PDD_3_0_V_SUPPORT SDHC_HTCAPBLT_VS30_MASK /**< Voltage support 3.0V. */
#define SDHC_PDD_1_8_V_SUPPORT SDHC_HTCAPBLT_VS18_MASK /**< Voltage support 1.8V. */

/* Force event masks */
#define SDHC_PDD_AUTO_CMD12_NOT_EXECUTED_EVENT SDHC_FEVT_AC12NE_MASK /**< Auto CMD12 not executed event. */
#define SDHC_PDD_AUTO_CMD12_TIMEOUT_ERROR_EVENT SDHC_FEVT_AC12TOE_MASK /**< Auto CMD12 timeout error event. */
#define SDHC_PDD_AUTO_CMD12_CRC_ERROR_EVENT SDHC_FEVT_AC12CE_MASK /**< Auto CMD12 CRC error event. */
#define SDHC_PDD_AUTO_CMD12_END_BIT_ERROR_EVENT SDHC_FEVT_AC12EBE_MASK /**< Auto CMD12 end bit error event. */
#define SDHC_PDD_AUTO_CMD12_INDEX_ERROR_EVENT SDHC_FEVT_AC12IE_MASK /**< Auto CMD12 index error event. */
#define SDHC_PDD_CMD_NOT_ISSUED_BY_AUTO_CMD12_ERROR_EVENT SDHC_FEVT_CNIBAC12E_MASK /**< Command not executed by Auto CMD12 error event. */
#define SDHC_PDD_COMMAND_TIMEOUT_ERROR_EVENT SDHC_FEVT_CTOE_MASK /**< Command time out error event. */
#define SDHC_PDD_COMMAND_CRC_ERROR_EVENT SDHC_FEVT_CCE_MASK /**< Command CRC error event. */
#define SDHC_PDD_COMMAND_END_BIT_ERROR_EVENT SDHC_FEVT_CEBE_MASK /**< Command end bit error event. */
#define SDHC_PDD_COMMAND_INDEX_ERROR_EVENT SDHC_FEVT_CIE_MASK /**< Command index error event. */
#define SDHC_PDD_DATA_TIMEOUT_ERROR_EVENT SDHC_FEVT_DTOE_MASK /**< Data time out error event. */
#define SDHC_PDD_DATA_CRC_ERROR_EVENT SDHC_FEVT_DCE_MASK /**< Data CRC error event. */
#define SDHC_PDD_DATA_END_BIT_ERROR_EVENT SDHC_FEVT_DEBE_MASK /**< Data end bit error event. */
#define SDHC_PDD_AUTO_CMD12_ERROR_EVENT SDHC_FEVT_AC12E_MASK /**< Auto CMD12 error event. */
#define SDHC_PDD_DMA_ERROR_EVENT SDHC_FEVT_DMAE_MASK /**< DMA error event. */
#define SDHC_PDD_CARD_INTERRUPT_EVENT SDHC_FEVT_CINT_MASK /**< Card interrupt event. */

/* Clock sources */
#define SDHC_PDD_CORE_SYSTEM_CLOCK 0U            /**< Core/system clock. */
#define SDHC_PDD_PLL_FLL_CLOCK 0x1U              /**< PLL or FLL clock. */
#define SDHC_PDD_EXTAL_CLOCK 0x2U                /**< Extal clock. */
#define SDHC_PDD_EXTERNAL_CLOCK 0x3U             /**< External clock. */

/* LED states */
#define SDHC_PDD_LED_ON 0x1U                     /**< LED on. */
#define SDHC_PDD_LED_OFF 0U                      /**< LED off. */

/* Data transfer widths */
#define SDHC_PDD_1_BIT_MODE 0U                   /**< 1 bit data width. */
#define SDHC_PDD_4_BIT_MODE 0x2U                 /**< 4 bit data width. */
#define SDHC_PDD_8_BIT_MODE 0x4U                 /**< 8 bit data width. */

/* Endian modes */
#define SDHC_PDD_BIG_ENDIAN_MODE 0U              /**< Big endian. */
#define SDHC_PDD_HALF_WORD_BIG_ENDIAN_MODE 0x10U /**< Half word big endian. */
#define SDHC_PDD_LITTLE_ENDIAN_MODE 0x20U        /**< Little endian. */

/* DMA modes */
#define SDHC_PDD_NO_OR_SIMPLE_DMA_MODE 0U        /**< No DMA or simple DMA. */
#define SDHC_PDD_ADVANCED_DMA_1_MODE 0x100U      /**< Advanced DMA version 1. */
#define SDHC_PDD_ADVANCED_DMA_2_MODE 0x200U      /**< Advanced DMA version 2. */

/* ADMA error states */
#define SDHC_PDD_ADMA_STOP 0U                    /**< Stop DMA. */
#define SDHC_PDD_ADMA_FETCH_DESCRIPTOR 0x1U      /**< Fetch descriptor. */
#define SDHC_PDD_ADMA_CHANGE_ADDRESS 0x2U        /**< Change address. */
#define SDHC_PDD_ADMA_TRANSFER_DATA 0x3U         /**< Transfer data. */

/* MMC boot modes */
#define SDHC_PDD_NORMAL_BOOT 0U                  /**< Normal boot. */
#define SDHC_PDD_ALTERNATIVE_BOOT 0x20U          /**< Alternative boot. */

/* Specification version numbers */
#define SDHC_PDD_SD_HOST_SPECIFICATION_V_2_0 0x1U /**< SD host specification version 2.0. */

/* Vendor version numbers */
#define SDHC_PDD_FREESCALE_ESDHC_V_1_0 0U        /**< Freescale eSDHC version 1.0. */
#define SDHC_PDD_FREESCALE_ESDHC_V_2_0 0x100U    /**< Freescale eSDHC version 2.0. */
#define SDHC_PDD_FREESCALE_ESDHC_V_2_1 0x1100U   /**< Freescale eSDHC version 2.1. */
#define SDHC_PDD_FREESCALE_ESDHC_V_2_2 0x1200U   /**< Freescale eSDHC version 2.2. */


/* ----------------------------------------------------------------------------
   -- SetDMAAddress
   ---------------------------------------------------------------------------- */

/**
 * Sets the DMA system address containing the physical system memory address
 * used for DMA transfers. Should be called only when no transactions are executing
 * (after transactions have stopped).
 * @param peripheralBase Peripheral base address.
 * @param Address DMA system address. Should be aligned to a 4 byte boundary.
 */
#define SDHC_PDD_SetDMAAddress(peripheralBase, Address) ( \
    SDHC_DSADDR_REG(peripheralBase) = \
     (uint32_t)(Address) \
  )

/* ----------------------------------------------------------------------------
   -- GetDMAAddress
   ---------------------------------------------------------------------------- */

/**
 * Returns the DMA system address containing the system address of the next
 * contiguous data position after the last DMA transfer.
 * @param peripheralBase Peripheral base address.
 */
#define SDHC_PDD_GetDMAAddress(peripheralBase) ( \
    SDHC_DSADDR_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- SetBlockSize
   ---------------------------------------------------------------------------- */

/**
 * Sets the block size for block data transfers. Should be called only when no
 * transactions are executing (after transactions have stopped).
 * @param peripheralBase Peripheral base address.
 * @param Size Transfer block size. Should be aligned to a 4 byte boundary.
 *        Possible values: 0-4096.
 */
#define SDHC_PDD_SetBlockSize(peripheralBase, Size) ( \
    SDHC_BLKATTR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       SDHC_BLKATTR_REG(peripheralBase)) & ( \
       (uint32_t)(~(uint32_t)SDHC_BLKATTR_BLKSIZE_MASK)))) | ( \
      (uint32_t)(Size))) \
  )

/* ----------------------------------------------------------------------------
   -- SetBlockCount
   ---------------------------------------------------------------------------- */

/**
 * Sets the block count for multiple block transfers.
 * @param peripheralBase Peripheral base address.
 * @param Count Block count for current transfer.
 */
#define SDHC_PDD_SetBlockCount(peripheralBase, Count) ( \
    SDHC_BLKATTR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       SDHC_BLKATTR_REG(peripheralBase)) & ( \
       (uint32_t)(~(uint32_t)SDHC_BLKATTR_BLKCNT_MASK)))) | ( \
      (uint32_t)((uint32_t)(Count) << SDHC_BLKATTR_BLKCNT_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- GetBlockCount
   ---------------------------------------------------------------------------- */

/**
 * Returns the block count left for the current transfer.
 * @param peripheralBase Peripheral base address.
 */
#define SDHC_PDD_GetBlockCount(peripheralBase) ( \
    (uint16_t)(( \
     (uint32_t)(SDHC_BLKATTR_REG(peripheralBase) & SDHC_BLKATTR_BLKCNT_MASK)) >> ( \
     SDHC_BLKATTR_BLKCNT_SHIFT)) \
  )

/* ----------------------------------------------------------------------------
   -- SetCommandArgument
   ---------------------------------------------------------------------------- */

/**
 * Sets the command argument specified as bits 39-8 of the SD/MMC command format.
 * @param peripheralBase Peripheral base address.
 * @param Argument Command argument.
 */
#define SDHC_PDD_SetCommandArgument(peripheralBase, Argument) ( \
    SDHC_CMDARG_REG(peripheralBase) = \
     (uint32_t)(Argument) \
  )

/* ----------------------------------------------------------------------------
   -- SendCommand
   ---------------------------------------------------------------------------- */

/**
 * Sends a command through the CMD bus line.
 * @param peripheralBase Peripheral base address.
 * @param Index Command index. Possible values: SDHC_PDD_CMD0-SDHC_PDD_CMD63,
 *        SDHC_PDD_ACMD0-SDHC_PDD_ACMD63.
 * @param Options Command options. Possible values (OR mask from):
 *        ENABLE_DMA/DISABLE_DMA, ENABLE_BLOCK_COUNT/DISABLE_BLOCK_COUNT,
 *        ENABLE_AUTO_CMD12/DISABLE_AUTO_CMD12, DATA_READ/DATA_WRITE, SINGLE_BLOCK/MULTIPLE_BLOCK,
 *        NO_RESPONSE/RESPONSE_LENGTH_136/RESPONSE_LENGTH_48/RESPONSE_LENGTH_48_BUSY_CHECK,
 *        ENABLE_CRC_CHECK/DISABLE_CRC_CHECK,
 *        ENABLE_INDEX_CHECK/DISABLE_INDEX_CHECK, DATA_PRESENT/NO_DATA_PRESENT,
 *        NORMAL_CMD/SUSPEND_CMD/RESUME_CMD/ABORT_CMD.
 */
#define SDHC_PDD_SendCommand(peripheralBase, Index, Options) ( \
    SDHC_XFERTYP_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(Options)) | ( \
      (uint32_t)((uint32_t)(Index) << SDHC_XFERTYP_CMDINX_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- GetCommandResponse
   ---------------------------------------------------------------------------- */

/**
 * Returns the command response.
 * @param peripheralBase Peripheral base address.
 * @param Response A four 32-bit values array variable, where to store the
 *        response.
 */
#define SDHC_PDD_GetCommandResponse(peripheralBase, Response) ( \
    Response[0] = SDHC_CMDRSP_REG(peripheralBase,0U), \
    (Response[1] = SDHC_CMDRSP_REG(peripheralBase,1U), \
    (Response[2] = SDHC_CMDRSP_REG(peripheralBase,2U), \
    Response[3] = SDHC_CMDRSP_REG(peripheralBase,3U))) \
  )

/* ----------------------------------------------------------------------------
   -- SetBufferData
   ---------------------------------------------------------------------------- */

/**
 * Writes the internal buffer data content if the internal DMA is not used.
 * @param peripheralBase Peripheral base address.
 * @param Data Data content.
 */
#define SDHC_PDD_SetBufferData(peripheralBase, Data) ( \
    SDHC_DATPORT_REG(peripheralBase) = \
     (uint32_t)(Data) \
  )

/* ----------------------------------------------------------------------------
   -- GetBufferData
   ---------------------------------------------------------------------------- */

/**
 * Reads the internal buffer data content if the internal DMA is not used.
 * @param peripheralBase Peripheral base address.
 */
#define SDHC_PDD_GetBufferData(peripheralBase) ( \
    SDHC_DATPORT_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- IsCommandInhibited
   ---------------------------------------------------------------------------- */

/**
 * Returns true if a command is in progress (SDHC_CMD line is in use) until a
 * command response is received.
 * @param peripheralBase Peripheral base address.
 */
#define SDHC_PDD_IsCommandInhibited(peripheralBase) ( \
    (uint32_t)(SDHC_PRSSTAT_REG(peripheralBase) & SDHC_PRSSTAT_CIHB_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- IsDataCommandInhibited
   ---------------------------------------------------------------------------- */

/**
 * Returns true if a command with data transfer is in progress (SDHC_DAT line is
 * in use) until data transfer is completed.
 * @param peripheralBase Peripheral base address.
 */
#define SDHC_PDD_IsDataCommandInhibited(peripheralBase) ( \
    (uint32_t)(SDHC_PRSSTAT_REG(peripheralBase) & SDHC_PRSSTAT_CDIHB_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- IsDataLineActive
   ---------------------------------------------------------------------------- */

/**
 * Returns true if any of the data lines are in use.
 * @param peripheralBase Peripheral base address.
 */
#define SDHC_PDD_IsDataLineActive(peripheralBase) ( \
    (uint32_t)(SDHC_PRSSTAT_REG(peripheralBase) & SDHC_PRSSTAT_DLA_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- IsSDClockStable
   ---------------------------------------------------------------------------- */

/**
 * Indicates whether the SD clock is stable.
 * @param peripheralBase Peripheral base address.
 */
#define SDHC_PDD_IsSDClockStable(peripheralBase) ( \
    (uint32_t)(SDHC_PRSSTAT_REG(peripheralBase) & SDHC_PRSSTAT_SDSTB_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- IsControllerClockGatedOff
   ---------------------------------------------------------------------------- */

/**
 * Indicates whether the controller clock is gated off internally.
 * @param peripheralBase Peripheral base address.
 */
#define SDHC_PDD_IsControllerClockGatedOff(peripheralBase) ( \
    (uint32_t)(SDHC_PRSSTAT_REG(peripheralBase) & SDHC_PRSSTAT_IPGOFF_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- IsCrossbarClockGatedOff
   ---------------------------------------------------------------------------- */

/**
 * Indicates whether the crossbar switch master clock is gated off internally.
 * @param peripheralBase Peripheral base address.
 */
#define SDHC_PDD_IsCrossbarClockGatedOff(peripheralBase) ( \
    (uint32_t)(SDHC_PRSSTAT_REG(peripheralBase) & SDHC_PRSSTAT_HCKOFF_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- IsPeripheralClockGatedOff
   ---------------------------------------------------------------------------- */

/**
 * Indicates whether the crossbar switch master clock is gated off internally.
 * @param peripheralBase Peripheral base address.
 */
#define SDHC_PDD_IsPeripheralClockGatedOff(peripheralBase) ( \
    (uint32_t)(SDHC_PRSSTAT_REG(peripheralBase) & SDHC_PRSSTAT_PEROFF_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- IsSDHCClockGatedOff
   ---------------------------------------------------------------------------- */

/**
 * Indicates whether the SDHC clock is gated off internally.
 * @param peripheralBase Peripheral base address.
 */
#define SDHC_PDD_IsSDHCClockGatedOff(peripheralBase) ( \
    (uint32_t)(SDHC_PRSSTAT_REG(peripheralBase) & SDHC_PRSSTAT_SDOFF_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- IsWriteTransferActive
   ---------------------------------------------------------------------------- */

/**
 * Indicates whether a write transfer is active.
 * @param peripheralBase Peripheral base address.
 */
#define SDHC_PDD_IsWriteTransferActive(peripheralBase) ( \
    (uint32_t)(SDHC_PRSSTAT_REG(peripheralBase) & SDHC_PRSSTAT_WTA_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- IsReadTransferActive
   ---------------------------------------------------------------------------- */

/**
 * Indicates whether a read transfer is active.
 * @param peripheralBase Peripheral base address.
 */
#define SDHC_PDD_IsReadTransferActive(peripheralBase) ( \
    (uint32_t)(SDHC_PRSSTAT_REG(peripheralBase) & SDHC_PRSSTAT_RTA_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- IsBufferWriteEnabled
   ---------------------------------------------------------------------------- */

/**
 * Indicates whether there is space for write data in the internal buffer. Used
 * for non-DMA write transfers.
 * @param peripheralBase Peripheral base address.
 */
#define SDHC_PDD_IsBufferWriteEnabled(peripheralBase) ( \
    (uint32_t)(SDHC_PRSSTAT_REG(peripheralBase) & SDHC_PRSSTAT_BWEN_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- IsBufferReadEnabled
   ---------------------------------------------------------------------------- */

/**
 * Indicates whether there is space for read data in the internal buffer. Used
 * for non-DMA read transfers.
 * @param peripheralBase Peripheral base address.
 */
#define SDHC_PDD_IsBufferReadEnabled(peripheralBase) ( \
    (uint32_t)(SDHC_PRSSTAT_REG(peripheralBase) & SDHC_PRSSTAT_BREN_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- IsCardInserted
   ---------------------------------------------------------------------------- */

/**
 * Indicates whether a card is inserted.
 * @param peripheralBase Peripheral base address.
 */
#define SDHC_PDD_IsCardInserted(peripheralBase) ( \
    (uint32_t)(SDHC_PRSSTAT_REG(peripheralBase) & SDHC_PRSSTAT_CINS_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetCMDLineLevel
   ---------------------------------------------------------------------------- */

/**
 * Returns the SDHC_CMD line signal level.
 * @param peripheralBase Peripheral base address.
 */
#define SDHC_PDD_GetCMDLineLevel(peripheralBase) ( \
    (uint32_t)(SDHC_PRSSTAT_REG(peripheralBase) & SDHC_PRSSTAT_CLSL_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetDATLineLevel
   ---------------------------------------------------------------------------- */

/**
 * Returns the SDHC_DAT line signal levels.
 * @param peripheralBase Peripheral base address.
 */
#define SDHC_PDD_GetDATLineLevel(peripheralBase) ( \
    (uint32_t)(SDHC_PRSSTAT_REG(peripheralBase) & SDHC_PRSSTAT_DLSL_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- SetLEDState
   ---------------------------------------------------------------------------- */

/**
 * Controls the LED state.
 * @param peripheralBase Peripheral base address.
 * @param State LED state. Possible values (one of): SDHC_PDD_LED_ON,
 *        SDHC_PDD_LED_OFF.
 */
#define SDHC_PDD_SetLEDState(peripheralBase, State) ( \
    SDHC_PROCTL_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(SDHC_PROCTL_REG(peripheralBase) & (uint32_t)(~(uint32_t)SDHC_PROCTL_LCTL_MASK))) | ( \
      (uint32_t)(State))) \
  )

/* ----------------------------------------------------------------------------
   -- SetDataTransferWidth
   ---------------------------------------------------------------------------- */

/**
 * Sets the data transfer width (data width of the SD bus).
 * @param peripheralBase Peripheral base address.
 * @param Width Data transfer width. Possible values (one of):
 *        SDHC_PDD_1_BIT_MODE, SDHC_PDD_4_BIT_MODE, SDHC_PDD_8_BIT_MODE.
 */
#define SDHC_PDD_SetDataTransferWidth(peripheralBase, Width) ( \
    SDHC_PROCTL_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(SDHC_PROCTL_REG(peripheralBase) & (uint32_t)(~(uint32_t)SDHC_PROCTL_DTW_MASK))) | ( \
      (uint32_t)(Width))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableDAT3AsCardDetectionPin
   ---------------------------------------------------------------------------- */

/**
 * Enables card detection on the DAT3 pin.
 * @param peripheralBase Peripheral base address.
 * @param Enable Enable flag. Possible values: PDD_ENABLE, PDD_DISABLE.
 */
#define SDHC_PDD_EnableDAT3AsCardDetectionPin(peripheralBase, Enable) ( \
    ((uint32_t)(Enable) == 0U) ? ( \
      SDHC_PROCTL_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)SDHC_PROCTL_D3CD_MASK)) : ( \
      SDHC_PROCTL_REG(peripheralBase) |= \
       SDHC_PROCTL_D3CD_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- SetEndianMode
   ---------------------------------------------------------------------------- */

/**
 * Sets the endian mode.
 * @param peripheralBase Peripheral base address.
 * @param Mode Endian mode. Possible values (one of): SDHC_PDD_BIG_ENDIAN_MODE,
 *        SDHC_PDD_HALF_WORD_BIG_ENDIAN_MODE, SDHC_PDD_LITTLE_ENDIAN_MODE.
 */
#define SDHC_PDD_SetEndianMode(peripheralBase, Mode) ( \
    SDHC_PROCTL_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       SDHC_PROCTL_REG(peripheralBase)) & ( \
       (uint32_t)(~(uint32_t)SDHC_PROCTL_EMODE_MASK)))) | ( \
      (uint32_t)(Mode))) \
  )

/* ----------------------------------------------------------------------------
   -- GetCardDetectTestLevel
   ---------------------------------------------------------------------------- */

/**
 * Determines card insertion status when card detection test level is enabled.
 * @param peripheralBase Peripheral base address.
 */
#define SDHC_PDD_GetCardDetectTestLevel(peripheralBase) ( \
    (uint32_t)(SDHC_PROCTL_REG(peripheralBase) & SDHC_PROCTL_CDTL_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- EnableCardDetectionTestLevel
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables card detection test level (for test purpose).
 * @param peripheralBase Peripheral base address.
 * @param Enable Enable flag. Possible values: PDD_ENABLE, PDD_DISABLE.
 */
#define SDHC_PDD_EnableCardDetectionTestLevel(peripheralBase, Enable) ( \
    ((uint32_t)(Enable) == 0U) ? ( \
      SDHC_PROCTL_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)SDHC_PROCTL_CDSS_MASK)) : ( \
      SDHC_PROCTL_REG(peripheralBase) |= \
       SDHC_PROCTL_CDSS_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- SetDMAMode
   ---------------------------------------------------------------------------- */

/**
 * Sets the DMA mode when DMA is enabled.
 * @param peripheralBase Peripheral base address.
 * @param Mode DMA mode. Possible values (one of):
 *        SDHC_PDD_NO_OR_SIMPLE_DMA_MODE, SDHC_PDD_ADVANCED_1_DMA_MODE, SDHC_PDD_ADVANCED_2_DMA_MODE.
 */
#define SDHC_PDD_SetDMAMode(peripheralBase, Mode) ( \
    SDHC_PROCTL_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(SDHC_PROCTL_REG(peripheralBase) & (uint32_t)(~(uint32_t)SDHC_PROCTL_DMAS_MASK))) | ( \
      (uint32_t)(Mode))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableStopAtBlockGapRequest
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables transaction execution stop at the next block gap for both
 * DMA and non-DMA transfers.
 * @param peripheralBase Peripheral base address.
 * @param Enable Enable flag. Possible values: PDD_ENABLE, PDD_DISABLE.
 */
#define SDHC_PDD_EnableStopAtBlockGapRequest(peripheralBase, Enable) ( \
    ((uint32_t)(Enable) == 0U) ? ( \
      SDHC_PROCTL_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)SDHC_PROCTL_SABGREQ_MASK)) : ( \
      SDHC_PROCTL_REG(peripheralBase) |= \
       SDHC_PROCTL_SABGREQ_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- ContinueRequest
   ---------------------------------------------------------------------------- */

/**
 * Restarts a transaction which was stopped using the stop-at-block-gap request.
 * @param peripheralBase Peripheral base address.
 */
#define SDHC_PDD_ContinueRequest(peripheralBase) ( \
    SDHC_PROCTL_REG(peripheralBase) |= \
     SDHC_PROCTL_CREQ_MASK \
  )

/* ----------------------------------------------------------------------------
   -- EnableReadWaitControl
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables read wait control. Should be enabled only if the card
 * supports this feature.
 * @param peripheralBase Peripheral base address.
 * @param Enable Enable flag. Possible values: PDD_ENABLE, PDD_DISABLE.
 */
#define SDHC_PDD_EnableReadWaitControl(peripheralBase, Enable) ( \
    ((uint32_t)(Enable) == 0U) ? ( \
      SDHC_PROCTL_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)SDHC_PROCTL_RWCTL_MASK)) : ( \
      SDHC_PROCTL_REG(peripheralBase) |= \
       SDHC_PROCTL_RWCTL_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- EnableInterruptAtBlockGap
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables interrupt at block gap. Interrupt enable is valid only in
 * 4-bit mode and the SD card should support this feature.
 * @param peripheralBase Peripheral base address.
 * @param Enable Enable flag. Possible values: PDD_ENABLE, PDD_DISABLE.
 */
#define SDHC_PDD_EnableInterruptAtBlockGap(peripheralBase, Enable) ( \
    ((uint32_t)(Enable) == 0U) ? ( \
      SDHC_PROCTL_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)SDHC_PROCTL_IABG_MASK)) : ( \
      SDHC_PROCTL_REG(peripheralBase) |= \
       SDHC_PROCTL_IABG_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- EnableWakeUpOnCardInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables wake-up event on card interrupt. Can be enabled if wake-up
 * support is enabled.
 * @param peripheralBase Peripheral base address.
 * @param Enable Enable flag. Possible values: PDD_ENABLE, PDD_DISABLE.
 */
#define SDHC_PDD_EnableWakeUpOnCardInterrupt(peripheralBase, Enable) ( \
    ((uint32_t)(Enable) == 0U) ? ( \
      SDHC_PROCTL_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)SDHC_PROCTL_WECINT_MASK)) : ( \
      SDHC_PROCTL_REG(peripheralBase) |= \
       SDHC_PROCTL_WECINT_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- EnableWakeUpOnCardInsertion
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables wake-up event on card insertion. Can be enabled if wake-up
 * support is enabled.
 * @param peripheralBase Peripheral base address.
 * @param Enable Enable flag. Possible values: PDD_ENABLE, PDD_DISABLE.
 */
#define SDHC_PDD_EnableWakeUpOnCardInsertion(peripheralBase, Enable) ( \
    ((uint32_t)(Enable) == 0U) ? ( \
      SDHC_PROCTL_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)SDHC_PROCTL_WECINS_MASK)) : ( \
      SDHC_PROCTL_REG(peripheralBase) |= \
       SDHC_PROCTL_WECINS_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- EnableWakeUpOnCardRemoval
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables wake-up event on card removal. Can be enabled if wake-up
 * support is enabled.
 * @param peripheralBase Peripheral base address.
 * @param Enable Enable flag. Possible values: PDD_ENABLE, PDD_DISABLE.
 */
#define SDHC_PDD_EnableWakeUpOnCardRemoval(peripheralBase, Enable) ( \
    ((uint32_t)(Enable) == 0U) ? ( \
      SDHC_PROCTL_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)SDHC_PROCTL_WECRM_MASK)) : ( \
      SDHC_PROCTL_REG(peripheralBase) |= \
       SDHC_PROCTL_WECRM_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- EnableControllerClock
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables controller clock. If enabled, the controller clock is always
 * active and no automatic gating is applied.
 * @param peripheralBase Peripheral base address.
 * @param Enable Enable flag. Possible values: PDD_ENABLE, PDD_DISABLE.
 */
#define SDHC_PDD_EnableControllerClock(peripheralBase, Enable) ( \
    ((uint32_t)(Enable) == 0U) ? ( \
      SDHC_SYSCTL_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)SDHC_SYSCTL_IPGEN_MASK)) : ( \
      SDHC_SYSCTL_REG(peripheralBase) |= \
       SDHC_SYSCTL_IPGEN_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- EnableCrossbarClock
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables crossbar switch master clock. If enabled, the clock is
 * always active and no automatic gating is applied.
 * @param peripheralBase Peripheral base address.
 * @param Enable Enable flag. Possible values: PDD_ENABLE, PDD_DISABLE.
 */
#define SDHC_PDD_EnableCrossbarClock(peripheralBase, Enable) ( \
    ((uint32_t)(Enable) == 0U) ? ( \
      SDHC_SYSCTL_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)SDHC_SYSCTL_HCKEN_MASK)) : ( \
      SDHC_SYSCTL_REG(peripheralBase) |= \
       SDHC_SYSCTL_HCKEN_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- EnablePeripheralClock
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables peripheral clock. If enabled, the peripheral clock is always
 * active and no automatic gating is applied, thus SDHC_CLK is active only
 * except auto gating-off during buffer danger.
 * @param peripheralBase Peripheral base address.
 * @param Enable Enable flag. Possible values: PDD_ENABLE, PDD_DISABLE.
 */
#define SDHC_PDD_EnablePeripheralClock(peripheralBase, Enable) ( \
    ((uint32_t)(Enable) == 0U) ? ( \
      SDHC_SYSCTL_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)SDHC_SYSCTL_PEREN_MASK)) : ( \
      SDHC_SYSCTL_REG(peripheralBase) |= \
       SDHC_SYSCTL_PEREN_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- EnableSDHCClock
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables SDHC clock. The SDHC_CLK frequency should be changed only if
 * SDHC clock is disabled.
 * @param peripheralBase Peripheral base address.
 * @param Enable Enable flag. Possible values: PDD_ENABLE, PDD_DISABLE.
 */
#define SDHC_PDD_EnableSDHCClock(peripheralBase, Enable) ( \
    ((uint32_t)(Enable) == 0U) ? ( \
      SDHC_SYSCTL_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)SDHC_SYSCTL_SDCLKEN_MASK)) : ( \
      SDHC_SYSCTL_REG(peripheralBase) |= \
       SDHC_SYSCTL_SDCLKEN_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- SetSDHCClockDivisor
   ---------------------------------------------------------------------------- */

/**
 * Sets the SDHC clock divisor.
 * @param peripheralBase Peripheral base address.
 * @param Divisor SDHC clock divisor. Possible values: 1-16.
 */
#define SDHC_PDD_SetSDHCClockDivisor(peripheralBase, Divisor) ( \
    SDHC_SYSCTL_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(SDHC_SYSCTL_REG(peripheralBase) & (uint32_t)(~(uint32_t)SDHC_SYSCTL_DVS_MASK))) | ( \
      (uint32_t)((uint32_t)(Divisor) << SDHC_SYSCTL_DVS_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- SetSDHCClockFrequency
   ---------------------------------------------------------------------------- */

/**
 * Sets the SDHC clock frequency.
 * @param peripheralBase Peripheral base address.
 * @param Frequency SDHC clock frequency. Possible values (one of):
 *        SDHC_PDD_BASE_DIV_BY_2, SDHC_PDD_BASE_DIV_BY_4, SDHC_PDD_BASE_DIV_BY_8,
 *        SDHC_PDD_BASE_DIV_BY_16, SDHC_PDD_BASE_DIV_BY_32, SDHC_PDD_BASE_DIV_BY_64,
 *        SDHC_PDD_BASE_DIV_BY_128, SDHC_PDD_BASE_DIV_BY_256.
 */
#define SDHC_PDD_SetSDHCClockFrequency(peripheralBase, Frequency) ( \
    SDHC_SYSCTL_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       SDHC_SYSCTL_REG(peripheralBase)) & ( \
       (uint32_t)(~(uint32_t)SDHC_SYSCTL_SDCLKFS_MASK)))) | ( \
      (uint32_t)((uint32_t)(Frequency) << SDHC_SYSCTL_SDCLKFS_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- SetDataTimeout
   ---------------------------------------------------------------------------- */

/**
 * Sets the data timeout counter value. Determines the interval by which
 * SDHC_DAT line timeouts are detected.
 * @param peripheralBase Peripheral base address.
 * @param Timeout Data timeout counter value. Specifies the timeout value as
 *        2^(13 + Timeout) SDHC clock cycles. Possible values: 0-14.
 */
#define SDHC_PDD_SetDataTimeout(peripheralBase, Timeout) ( \
    SDHC_SYSCTL_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       SDHC_SYSCTL_REG(peripheralBase)) & ( \
       (uint32_t)(~(uint32_t)SDHC_SYSCTL_DTOCV_MASK)))) | ( \
      (uint32_t)((uint32_t)(Timeout) << SDHC_SYSCTL_DTOCV_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- ResetDevice
   ---------------------------------------------------------------------------- */

/**
 * Resets the device.
 * @param peripheralBase Peripheral base address.
 */
#define SDHC_PDD_ResetDevice(peripheralBase) ( \
    SDHC_SYSCTL_REG(peripheralBase) |= \
     SDHC_SYSCTL_RSTA_MASK \
  )

/* ----------------------------------------------------------------------------
   -- ResetCMDLine
   ---------------------------------------------------------------------------- */

/**
 * Resets the SDHC_CMD line. Only part of the command circuit is reset.
 * @param peripheralBase Peripheral base address.
 */
#define SDHC_PDD_ResetCMDLine(peripheralBase) ( \
    SDHC_SYSCTL_REG(peripheralBase) |= \
     SDHC_SYSCTL_RSTC_MASK \
  )

/* ----------------------------------------------------------------------------
   -- ResetDATLine
   ---------------------------------------------------------------------------- */

/**
 * Resets the SDHC_DAT line. The DMA and part of the data circuit are reset.
 * @param peripheralBase Peripheral base address.
 */
#define SDHC_PDD_ResetDATLine(peripheralBase) ( \
    SDHC_SYSCTL_REG(peripheralBase) |= \
     SDHC_SYSCTL_RSTD_MASK \
  )

/* ----------------------------------------------------------------------------
   -- InitCard
   ---------------------------------------------------------------------------- */

/**
 * Send 80 SD clocks to the card. Should be used during the card power-up period.
 * @param peripheralBase Peripheral base address.
 */
#define SDHC_PDD_InitCard(peripheralBase) ( \
    SDHC_SYSCTL_REG(peripheralBase) |= \
     SDHC_SYSCTL_INITA_MASK \
  )

/* ----------------------------------------------------------------------------
   -- IsCardInitComplete
   ---------------------------------------------------------------------------- */

/**
 * Indicates whether card initialization is completed.
 * @param peripheralBase Peripheral base address.
 */
#define SDHC_PDD_IsCardInitComplete(peripheralBase) ( \
    (uint32_t)(( \
     (uint32_t)(SDHC_SYSCTL_REG(peripheralBase) & SDHC_SYSCTL_INITA_MASK)) ^ ( \
     SDHC_SYSCTL_INITA_MASK)) \
  )

/* ----------------------------------------------------------------------------
   -- GetInterruptFlags
   ---------------------------------------------------------------------------- */

/**
 * Returns the interrupt flags. The returned value can be masked with predefined
 * macros.
 * @param peripheralBase Peripheral base address.
 */
#define SDHC_PDD_GetInterruptFlags(peripheralBase) ( \
    SDHC_IRQSTAT_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- ClearInterruptFlags
   ---------------------------------------------------------------------------- */

/**
 * Clears the specified interrupt flags.
 * @param peripheralBase Peripheral base address.
 * @param Mask Interrupt mask. Possible values (OR mask from):
 *        SDHC_PDD_COMMAND_COMPLETE_INT, SDHC_PDD_TRANSFER_COMPLETE_INT,
 *        SDHC_PDD_BLOCK_GAP_EVENT_INT, SDHC_PDD_DMA_INT, SDHC_PDD_BUFFER_WRITE_READY_INT,
 *        SDHC_PDD_BUFFER_READ_READY_INT, SDHC_PDD_CARD_INSERTION_INT,
 *        SDHC_PDD_CARD_REMOVAL_INT, SDHC_PDD_CARD_INT, SDHC_PDD_COMMAND_TIMEOUT_ERROR_INT,
 *        SDHC_PDD_COMMAND_CRC_ERROR_INT, SDHC_PDD_COMMAND_END_BIT_ERROR_INT,
 *        SDHC_PDD_COMMAND_INDEX_ERROR_INT, SDHC_PDD_DATA_TIMEOUT_ERROR_INT,
 *        SDHC_PDD_DATA_CRC_ERROR_INT, SDHC_PDD_DATA_END_BIT_ERROR_INT, SDHC_PDD_AUTO_CMD12_ERROR_INT,
 *        SDHC_PDD_DMA_ERROR_INT.
 */
#define SDHC_PDD_ClearInterruptFlags(peripheralBase, Mask) ( \
    SDHC_IRQSTAT_REG(peripheralBase) = \
     (uint32_t)(Mask) \
  )

/* ----------------------------------------------------------------------------
   -- EnableInterrupts
   ---------------------------------------------------------------------------- */

/**
 * Enables interrupts specified by the mask.
 * @param peripheralBase Peripheral base address.
 * @param Mask Interrupt mask. Possible values (OR mask from):
 *        SDHC_PDD_COMMAND_COMPLETE_INT, SDHC_PDD_TRANSFER_COMPLETE_INT,
 *        SDHC_PDD_BLOCK_GAP_EVENT_INT, SDHC_PDD_DMA_INT, SDHC_PDD_BUFFER_WRITE_READY_INT,
 *        SDHC_PDD_BUFFER_READ_READY_INT, SDHC_PDD_CARD_INSERTION_INT,
 *        SDHC_PDD_CARD_REMOVAL_INT, SDHC_PDD_CARD_INT, SDHC_PDD_COMMAND_TIMEOUT_ERROR_INT,
 *        SDHC_PDD_COMMAND_CRC_ERROR_INT, SDHC_PDD_COMMAND_END_BIT_ERROR_INT,
 *        SDHC_PDD_COMMAND_INDEX_ERROR_INT, SDHC_PDD_DATA_TIMEOUT_ERROR_INT,
 *        SDHC_PDD_DATA_CRC_ERROR_INT, SDHC_PDD_DATA_END_BIT_ERROR_INT, SDHC_PDD_AUTO_CMD12_ERROR_INT,
 *        SDHC_PDD_DMA_ERROR_INT.
 */
#define SDHC_PDD_EnableInterrupts(peripheralBase, Mask) ( \
    SDHC_IRQSIGEN_REG(peripheralBase) |= \
     (uint32_t)(Mask) \
  )

/* ----------------------------------------------------------------------------
   -- DisableInterrupts
   ---------------------------------------------------------------------------- */

/**
 * Disables interrupts specified by the mask.
 * @param peripheralBase Peripheral base address.
 * @param Mask Interrupt mask. Possible values (OR mask from):
 *        SDHC_PDD_COMMAND_COMPLETE_INT, SDHC_PDD_TRANSFER_COMPLETE_INT,
 *        SDHC_PDD_BLOCK_GAP_EVENT_INT, SDHC_PDD_DMA_INT, SDHC_PDD_BUFFER_WRITE_READY_INT,
 *        SDHC_PDD_BUFFER_READ_READY_INT, SDHC_PDD_CARD_INSERTION_INT,
 *        SDHC_PDD_CARD_REMOVAL_INT, SDHC_PDD_CARD_INT, SDHC_PDD_COMMAND_TIMEOUT_ERROR_INT,
 *        SDHC_PDD_COMMAND_CRC_ERROR_INT, SDHC_PDD_COMMAND_END_BIT_ERROR_INT,
 *        SDHC_PDD_COMMAND_INDEX_ERROR_INT, SDHC_PDD_DATA_TIMEOUT_ERROR_INT,
 *        SDHC_PDD_DATA_CRC_ERROR_INT, SDHC_PDD_DATA_END_BIT_ERROR_INT, SDHC_PDD_AUTO_CMD12_ERROR_INT,
 *        SDHC_PDD_DMA_ERROR_INT.
 */
#define SDHC_PDD_DisableInterrupts(peripheralBase, Mask) ( \
    SDHC_IRQSIGEN_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)(Mask)) \
  )

/* ----------------------------------------------------------------------------
   -- EnableInterruptFlags
   ---------------------------------------------------------------------------- */

/**
 * Enables interrupt flags specified by the mask.
 * @param peripheralBase Peripheral base address.
 * @param Mask Interrupt flag mask. Possible values (OR mask from):
 *        SDHC_PDD_COMMAND_COMPLETE_INT, SDHC_PDD_TRANSFER_COMPLETE_INT,
 *        SDHC_PDD_BLOCK_GAP_EVENT_INT, SDHC_PDD_DMA_INT, SDHC_PDD_BUFFER_WRITE_READY_INT,
 *        SDHC_PDD_BUFFER_READ_READY_INT, SDHC_PDD_CARD_INSERTION_INT,
 *        SDHC_PDD_CARD_REMOVAL_INT, SDHC_PDD_CARD_INT, SDHC_PDD_COMMAND_TIMEOUT_ERROR_INT,
 *        SDHC_PDD_COMMAND_CRC_ERROR_INT, SDHC_PDD_COMMAND_END_BIT_ERROR_INT,
 *        SDHC_PDD_COMMAND_INDEX_ERROR_INT, SDHC_PDD_DATA_TIMEOUT_ERROR_INT,
 *        SDHC_PDD_DATA_CRC_ERROR_INT, SDHC_PDD_DATA_END_BIT_ERROR_INT,
 *        SDHC_PDD_AUTO_CMD12_ERROR_INT, SDHC_PDD_DMA_ERROR_INT.
 */
#define SDHC_PDD_EnableInterruptFlags(peripheralBase, Mask) ( \
    SDHC_IRQSTATEN_REG(peripheralBase) |= \
     (uint32_t)(Mask) \
  )

/* ----------------------------------------------------------------------------
   -- DisableInterruptFlags
   ---------------------------------------------------------------------------- */

/**
 * Disables interrupt flags specified by the mask.
 * @param peripheralBase Peripheral base address.
 * @param Mask Interrupt flag mask. Possible values (OR mask from):
 *        SDHC_PDD_COMMAND_COMPLETE_INT, SDHC_PDD_TRANSFER_COMPLETE_INT,
 *        SDHC_PDD_BLOCK_GAP_EVENT_INT, SDHC_PDD_DMA_INT, SDHC_PDD_BUFFER_WRITE_READY_INT,
 *        SDHC_PDD_BUFFER_READ_READY_INT, SDHC_PDD_CARD_INSERTION_INT,
 *        SDHC_PDD_CARD_REMOVAL_INT, SDHC_PDD_CARD_INT, SDHC_PDD_COMMAND_TIMEOUT_ERROR_INT,
 *        SDHC_PDD_COMMAND_CRC_ERROR_INT, SDHC_PDD_COMMAND_END_BIT_ERROR_INT,
 *        SDHC_PDD_COMMAND_INDEX_ERROR_INT, SDHC_PDD_DATA_TIMEOUT_ERROR_INT,
 *        SDHC_PDD_DATA_CRC_ERROR_INT, SDHC_PDD_DATA_END_BIT_ERROR_INT,
 *        SDHC_PDD_AUTO_CMD12_ERROR_INT, SDHC_PDD_DMA_ERROR_INT.
 */
#define SDHC_PDD_DisableInterruptFlags(peripheralBase, Mask) ( \
    SDHC_IRQSTATEN_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)(Mask)) \
  )

/* ----------------------------------------------------------------------------
   -- GetAutoCMD12ErrorFlags
   ---------------------------------------------------------------------------- */

/**
 * Returns the Auto CMD12 error flags. The return value can be mask with:
 * AUTO_CMD12_NOT_EXECUTED, AUTO_CMD12_TIMEOUT_ERROR, AUTO_CMD12_END_BIT_ERROR,
 * AUTO_CMD12_CRC_ERROR, AUTO_CMD12_INDEX_ERROR, CMD_NOT_ISSUED_BY_AUTO_CMD12_ERROR.
 * @param peripheralBase Peripheral base address.
 */
#define SDHC_PDD_GetAutoCMD12ErrorFlags(peripheralBase) ( \
    SDHC_AC12ERR_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- GetHostCapabilities
   ---------------------------------------------------------------------------- */

/**
 * Returns host controller capabilities flags.
 * @param peripheralBase Peripheral base address.
 */
#define SDHC_PDD_GetHostCapabilities(peripheralBase) ( \
    SDHC_HTCAPBLT_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- GetMaxBlockLength
   ---------------------------------------------------------------------------- */

/**
 * Indicates the maximum block size that the host driver can read and write to
 * the buffer in the SDHC.
 * @param peripheralBase Peripheral base address.
 */
#define SDHC_PDD_GetMaxBlockLength(peripheralBase) ( \
    512 << (uint8_t)(( \
     (uint32_t)(SDHC_HTCAPBLT_REG(peripheralBase) & SDHC_HTCAPBLT_MBL_MASK)) >> ( \
     SDHC_HTCAPBLT_MBL_SHIFT)) \
  )

/* ----------------------------------------------------------------------------
   -- SetWriteWatermark
   ---------------------------------------------------------------------------- */

/**
 * Sets the watermark level in DMA write operation.
 * @param peripheralBase Peripheral base address.
 * @param Watermark Write watermark level. Number of 4-byte words of watermark
 *        level in DMA write operation. Possible values: 0-255.
 */
#define SDHC_PDD_SetWriteWatermark(peripheralBase, Watermark) ( \
    SDHC_WML_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(SDHC_WML_REG(peripheralBase) & (uint32_t)(~(uint32_t)SDHC_WML_WRWML_MASK))) | ( \
      (uint32_t)((uint32_t)(Watermark) << SDHC_WML_WRWML_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- SetReadWatermark
   ---------------------------------------------------------------------------- */

/**
 * Sets the watermark level in DMA read operation.
 * @param peripheralBase Peripheral base address.
 * @param Watermark Read watermark level. Number of 4-byte words of watermark
 *        level in DMA read operation. Possible values: 0-16.
 */
#define SDHC_PDD_SetReadWatermark(peripheralBase, Watermark) ( \
    SDHC_WML_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(SDHC_WML_REG(peripheralBase) & (uint32_t)(~(uint32_t)SDHC_WML_RDWML_MASK))) | ( \
      (uint32_t)(Watermark))) \
  )

/* ----------------------------------------------------------------------------
   -- ForceEvents
   ---------------------------------------------------------------------------- */

/**
 * Forces events specified by the mask.
 * @param peripheralBase Peripheral base address.
 * @param Mask Event mask. Possible values (OR mask from):
 *        SDHC_PDD_AUTO_CMD12_NOT_EXECUTED_EVENT, SDHC_PDD_AUTO_CMD12_TIMEOUT_ERROR_EVENT,
 *        SDHC_PDD_AUTO_CMD12_CRC_ERROR_EVENT, SDHC_PDD_AUTO_CMD12_END_BIT_ERROR_EVENT,
 *        SDHC_PDD_AUTO_CMD12_INDEX_ERROR_EVENT,
 *        SDHC_PDD_CMD_NOT_ISSUED_BY_AUTO_CMD12_ERROR_EVENT, SDHC_PDD_COMMAND_TIMEOUT_ERROR_EVENT,
 *        SDHC_PDD_COMMAND_CRC_ERROR_EVENT, SDHC_PDD_COMMAND_END_BIT_ERROR_EVENT,
 *        SDHC_PDD_COMMAND_INDEX_ERROR_EVENT, SDHC_PDD_DATA_TIMEOUT_ERROR_EVENT,
 *        SDHC_PDD_DATA_CRC_ERROR_EVENT, SDHC_PDD_DATA_END_BIT_ERROR_EVENT,
 *        SDHC_PDD_AUTO_CMD12_ERROR_EVENT, SDHC_PDD_DMA_ERROR_EVENT, SDHC_PDD_CARD_INTERRUPT_EVENT.
 */
#define SDHC_PDD_ForceEvents(peripheralBase, Mask) ( \
    SDHC_FEVT_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(SDHC_FEVT_REG(peripheralBase) | (uint32_t)(Mask))) & (( \
      (uint32_t)(~(uint32_t)0x60U)) & (( \
      (uint32_t)(~(uint32_t)0xFF00U)) & (( \
      (uint32_t)(~(uint32_t)0x800000U)) & (( \
      (uint32_t)(~(uint32_t)0xE000000U)) & ( \
      (uint32_t)(~(uint32_t)0x60000000U))))))) \
  )

/* ----------------------------------------------------------------------------
   -- GetADMALengthMismatchErrorFlag
   ---------------------------------------------------------------------------- */

/**
 * Returns the ADMA length mismatch error flag.
 * @param peripheralBase Peripheral base address.
 */
#define SDHC_PDD_GetADMALengthMismatchErrorFlag(peripheralBase) ( \
    (uint32_t)(SDHC_ADMAES_REG(peripheralBase) & SDHC_ADMAES_ADMALME_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetADMADescriptorErrorFlag
   ---------------------------------------------------------------------------- */

/**
 * Returns the ADMA descriptor error flag.
 * @param peripheralBase Peripheral base address.
 */
#define SDHC_PDD_GetADMADescriptorErrorFlag(peripheralBase) ( \
    (uint32_t)(SDHC_ADMAES_REG(peripheralBase) & SDHC_ADMAES_ADMADCE_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetADMAErrorState
   ---------------------------------------------------------------------------- */

/**
 * Returns the ADMA error state. The return value can be compared with
 * predefined macros.
 * @param peripheralBase Peripheral base address.
 */
#define SDHC_PDD_GetADMAErrorState(peripheralBase) ( \
    (uint32_t)(SDHC_ADMAES_REG(peripheralBase) & SDHC_ADMAES_ADMAES_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- SetADMAAddress
   ---------------------------------------------------------------------------- */

/**
 * Sets the ADMA system address containing the physical system memory address
 * used for ADMA transfers.
 * @param peripheralBase Peripheral base address.
 * @param Address ADMA system address.
 */
#define SDHC_PDD_SetADMAAddress(peripheralBase, Address) ( \
    SDHC_ADSADDR_REG(peripheralBase) = \
     (uint32_t)(Address) \
  )

/* ----------------------------------------------------------------------------
   -- GetADMAAddress
   ---------------------------------------------------------------------------- */

/**
 * Returns the ADMA system address containing the address of the executing
 * command of the descriptor table.
 * @param peripheralBase Peripheral base address.
 */
#define SDHC_PDD_GetADMAAddress(peripheralBase) ( \
    SDHC_ADSADDR_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- EnableExternalDMARequest
   ---------------------------------------------------------------------------- */

/**
 * Enables the external DMA request.
 * @param peripheralBase Peripheral base address.
 * @param Enable Enable flag. Possible values: PDD_ENABLE, PDD_DISABLE.
 */
#define SDHC_PDD_EnableExternalDMARequest(peripheralBase, Enable) ( \
    ((uint32_t)(Enable) == 0U) ? ( \
      SDHC_VENDOR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)SDHC_VENDOR_EXTDMAEN_MASK)) : ( \
      SDHC_VENDOR_REG(peripheralBase) |= \
       SDHC_VENDOR_EXTDMAEN_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- EnableExactBlockNum
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables exact block number for SDIO CMD53.
 * @param peripheralBase Peripheral base address.
 * @param Enable Enable flag. Possible values: PDD_ENABLE, PDD_DISABLE.
 */
#define SDHC_PDD_EnableExactBlockNum(peripheralBase, Enable) ( \
    ((uint32_t)(Enable) == 0U) ? ( \
      SDHC_VENDOR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)SDHC_VENDOR_EXBLKNU_MASK)) : ( \
      SDHC_VENDOR_REG(peripheralBase) |= \
       SDHC_VENDOR_EXBLKNU_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- SetBootAckTimeout
   ---------------------------------------------------------------------------- */

/**
 * Sets the boot acknowled timeout counter value.
 * @param peripheralBase Peripheral base address.
 * @param Timeout Boot ack timeout counter value. Specifies the timeout value as
 *        2^(8 + Timeout) SD clock cycles. Possible values: 0-14.
 */
#define SDHC_PDD_SetBootAckTimeout(peripheralBase, Timeout) ( \
    SDHC_MMCBOOT_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       SDHC_MMCBOOT_REG(peripheralBase)) & ( \
       (uint32_t)(~(uint32_t)SDHC_MMCBOOT_DTOCVACK_MASK)))) | ( \
      (uint32_t)(Timeout))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableBootAck
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables boot acknowledge.
 * @param peripheralBase Peripheral base address.
 * @param Enable Enable flag. Possible values: PDD_ENABLE, PDD_DISABLE.
 */
#define SDHC_PDD_EnableBootAck(peripheralBase, Enable) ( \
    ((uint32_t)(Enable) == 0U) ? ( \
      SDHC_MMCBOOT_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)SDHC_MMCBOOT_BOOTACK_MASK)) : ( \
      SDHC_MMCBOOT_REG(peripheralBase) |= \
       SDHC_MMCBOOT_BOOTACK_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- SetBootMode
   ---------------------------------------------------------------------------- */

/**
 * Sets the boot mode.
 * @param peripheralBase Peripheral base address.
 * @param Mode Boot mode. Possible values (one of): SDHC_PDD_NORMAL,
 *        SDHC_PDD_ALTERNATIVE.
 */
#define SDHC_PDD_SetBootMode(peripheralBase, Mode) ( \
    SDHC_MMCBOOT_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       SDHC_MMCBOOT_REG(peripheralBase)) & ( \
       (uint32_t)(~(uint32_t)SDHC_MMCBOOT_BOOTMODE_MASK)))) | ( \
      (uint32_t)(Mode))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableBootMode
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables the boot mode.
 * @param peripheralBase Peripheral base address.
 * @param Enable Enable flag. Possible values: PDD_ENABLE, PDD_DISABLE.
 */
#define SDHC_PDD_EnableBootMode(peripheralBase, Enable) ( \
    ((uint32_t)(Enable) == 0U) ? ( \
      SDHC_MMCBOOT_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)SDHC_MMCBOOT_BOOTEN_MASK)) : ( \
      SDHC_MMCBOOT_REG(peripheralBase) |= \
       SDHC_MMCBOOT_BOOTEN_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- EnableAutoStopAtBlockGap
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables auto stop at block gap function when boot.
 * @param peripheralBase Peripheral base address.
 * @param Enable Enable flag. Possible values: PDD_ENABLE, PDD_DISABLE.
 */
#define SDHC_PDD_EnableAutoStopAtBlockGap(peripheralBase, Enable) ( \
    ((uint32_t)(Enable) == 0U) ? ( \
      SDHC_MMCBOOT_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)SDHC_MMCBOOT_AUTOSABGEN_MASK)) : ( \
      SDHC_MMCBOOT_REG(peripheralBase) |= \
       SDHC_MMCBOOT_AUTOSABGEN_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- SetBootBlockCount
   ---------------------------------------------------------------------------- */

/**
 * Sets the received boot block count after which 'stop at block gap' occurs.
 * @param peripheralBase Peripheral base address.
 * @param Count Boot block count. Possible values: 0-65534.
 */
#define SDHC_PDD_SetBootBlockCount(peripheralBase, Count) ( \
    SDHC_MMCBOOT_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       SDHC_MMCBOOT_REG(peripheralBase)) & ( \
       (uint32_t)(~(uint32_t)SDHC_MMCBOOT_BOOTBLKCNT_MASK)))) | ( \
      (uint32_t)((uint32_t)(Count) << SDHC_MMCBOOT_BOOTBLKCNT_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- GetSpecificationVersion
   ---------------------------------------------------------------------------- */

/**
 * Returns the specification version number. The return value can be compared
 * with predefined macros.
 * @param peripheralBase Peripheral base address.
 */
#define SDHC_PDD_GetSpecificationVersion(peripheralBase) ( \
    (uint32_t)(SDHC_HOSTVER_REG(peripheralBase) & SDHC_HOSTVER_SVN_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetVendorVersion
   ---------------------------------------------------------------------------- */

/**
 * Returns the vendor version number. The return value can be compared with
 * predefined macros.
 * @param peripheralBase Peripheral base address.
 */
#define SDHC_PDD_GetVendorVersion(peripheralBase) ( \
    (uint32_t)(SDHC_HOSTVER_REG(peripheralBase) & SDHC_HOSTVER_VVN_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- SetClockSource
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MK10F12)) || (defined(MCU_MK20F12)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)))
/**
 * Selects the clock source (in the SIM module).
 * @param peripheralBase Peripheral base address.
 * @param Source Clock source. Possible values: CORE_SYSTEM_CLOCK,
 *        PLL_FLL_CLOCK, EXTERNAL_CLOCK, EXTERNAL_CLOCK. Use constants from group "Clock
 *        sources".
 */
  #define SDHC_PDD_SetClockSource(peripheralBase, Source) ( \
      SIM_SOPT2_REG(SIM_BASE_PTR) = \
       (( \
        (uint32_t)(SIM_SOPT2_REG(SIM_BASE_PTR) & (uint32_t)(~(uint32_t)SIM_SOPT2_ESDHCSRC_MASK))) | ( \
        (uint32_t)((uint32_t)(Source) << SIM_SOPT2_ESDHCSRC_SHIFT))) \
    )
#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60N512VMD100)) */
/**
 * Selects the clock source (in the SIM module).
 * @param peripheralBase Peripheral base address.
 * @param Source Clock source. Possible values: CORE_SYSTEM_CLOCK,
 *        PLL_FLL_CLOCK, EXTERNAL_CLOCK, EXTERNAL_CLOCK. Use constants from group "Clock
 *        sources".
 */
  #define SDHC_PDD_SetClockSource(peripheralBase, Source) ( \
      SIM_SOPT2_REG(SIM_BASE_PTR) = \
       (( \
        (uint32_t)(SIM_SOPT2_REG(SIM_BASE_PTR) & (uint32_t)(~(uint32_t)SIM_SOPT2_SDHCSRC_MASK))) | ( \
        (uint32_t)((uint32_t)(Source) << SIM_SOPT2_SDHCSRC_SHIFT))) \
    )
#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60N512VMD100)) */
#endif  /* #if defined(SDHC_PDD_H_) */

/* SDHC_PDD.h, eof. */
