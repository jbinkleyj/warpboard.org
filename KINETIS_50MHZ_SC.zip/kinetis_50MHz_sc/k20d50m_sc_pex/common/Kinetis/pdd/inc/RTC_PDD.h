/*
  PDD layer implementation for peripheral type RTC
  (C) 2010 Freescale, Inc. All rights reserved.

  This file is static and it is generated from API-Factory
*/

#if !defined(RTC_PDD_H_)
#define RTC_PDD_H_

/* ----------------------------------------------------------------------------
   -- Test if supported MCU is active
   ---------------------------------------------------------------------------- */

#if !defined(MCU_ACTIVE)
  // No MCU is active
  #error RTC PDD library: No derivative is active. Place proper #include with PDD memory map before including PDD library.
#elif \
      !defined(MCU_MK10D10) /* RTC */ && \
      !defined(MCU_MK10D5) /* RTC */ && \
      !defined(MCU_MK10D7) /* RTC */ && \
      !defined(MCU_MK10F12) /* RTC */ && \
      !defined(MCU_MK10DZ10) /* RTC */ && \
      !defined(MCU_MK11D5) /* RTC */ && \
      !defined(MCU_MK12D5) /* RTC */ && \
      !defined(MCU_MK20D10) /* RTC */ && \
      !defined(MCU_MK20D5) /* RTC */ && \
      !defined(MCU_MK20D7) /* RTC */ && \
      !defined(MCU_MK20F12) /* RTC */ && \
      !defined(MCU_MK20DZ10) /* RTC */ && \
      !defined(MCU_MK21D5) /* RTC */ && \
      !defined(MCU_MK22D5) /* RTC */ && \
      !defined(MCU_MK30D10) /* RTC */ && \
      !defined(MCU_MK30D7) /* RTC */ && \
      !defined(MCU_MK30DZ10) /* RTC */ && \
      !defined(MCU_MK40D10) /* RTC */ && \
      !defined(MCU_MK40D7) /* RTC */ && \
      !defined(MCU_MK40DZ10) /* RTC */ && \
      !defined(MCU_MK40X256VMD100) /* RTC */ && \
      !defined(MCU_MK50D10) /* RTC */ && \
      !defined(MCU_MK50D7) /* RTC */ && \
      !defined(MCU_MK50DZ10) /* RTC */ && \
      !defined(MCU_MK51D10) /* RTC */ && \
      !defined(MCU_MK51D7) /* RTC */ && \
      !defined(MCU_MK51DZ10) /* RTC */ && \
      !defined(MCU_MK52D10) /* RTC */ && \
      !defined(MCU_MK52DZ10) /* RTC */ && \
      !defined(MCU_MK53D10) /* RTC */ && \
      !defined(MCU_MK53DZ10) /* RTC */ && \
      !defined(MCU_MK60D10) /* RTC */ && \
      !defined(MCU_MK60F12) /* RTC */ && \
      !defined(MCU_MK60F15) /* RTC */ && \
      !defined(MCU_MK60DZ10) /* RTC */ && \
      !defined(MCU_MK60N512VMD100) /* RTC */ && \
      !defined(MCU_MK61F12) /* RTC */ && \
      !defined(MCU_MK61F15) /* RTC */ && \
      !defined(MCU_MK70F12) /* RTC */ && \
      !defined(MCU_MK70F15) /* RTC */ && \
      !defined(MCU_MKL04Z4) /* RTC */ && \
      !defined(MCU_MKL05Z4) /* RTC */ && \
      !defined(MCU_MKL14Z4) /* RTC */ && \
      !defined(MCU_MKL15Z4) /* RTC */ && \
      !defined(MCU_MKL24Z4) /* RTC */ && \
      !defined(MCU_MKL25Z4) /* RTC */ && \
      !defined(MCU_PCK20L4) /* RTC */
  // Unsupported MCU is active
  #error RTC PDD library: Unsupported derivative is active.
#endif

#include "PDD_Types.h"

/* ----------------------------------------------------------------------------
   -- Method symbol definitions
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)))
/* Interrupt masks */
  #define RTC_PDD_MOF_INT RTC_SR_MOF_MASK          /**< Monotonic overflow interrupt mask */
  #define RTC_PDD_TAF_INT RTC_SR_TAF_MASK          /**< Alarm interrupt mask */
  #define RTC_PDD_TOF_INT RTC_SR_TOF_MASK          /**< Timer overflow interrupt mask */
  #define RTC_PDD_TIF_INT RTC_SR_TIF_MASK          /**< Time invalid interrupt mask */

#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MKL04Z4)) || (defined(MCU_MKL05Z4)) || (defined(MCU_MKL14Z4)) || (defined(MCU_MKL15Z4)) || (defined(MCU_MKL24Z4)) || (defined(MCU_MKL25Z4)) || (defined(MCU_PCK20L4)) */
/* Interrupt masks */
  #define RTC_PDD_TAF_INT RTC_SR_TAF_MASK          /**< Alarm interrupt mask */
  #define RTC_PDD_TOF_INT RTC_SR_TOF_MASK          /**< Timer overflow interrupt mask */
  #define RTC_PDD_TIF_INT RTC_SR_TIF_MASK          /**< Time invalid interrupt mask */

#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MKL04Z4)) || (defined(MCU_MKL05Z4)) || (defined(MCU_MKL14Z4)) || (defined(MCU_MKL15Z4)) || (defined(MCU_MKL24Z4)) || (defined(MCU_MKL25Z4)) || (defined(MCU_PCK20L4)) */
#if ((defined(MCU_MK10F12)) || (defined(MCU_MK20F12)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)))
/* Tamper interrupt masks */
  #define RTC_PDD_TMF_INT RTC_TDR_TMF_MASK         /**< Test mode tamper interrupt mask */
  #define RTC_PDD_FSF_INT RTC_TDR_FSF_MASK         /**< Flash security tamper interrupt mask */
  #define RTC_PDD_TTF_INT RTC_TDR_TTF_MASK         /**< Temperature tamper interrupt mask */
  #define RTC_PDD_CTF_INT RTC_TDR_CTF_MASK         /**< Clock tamper interrupt mask */
  #define RTC_PDD_VTF_INT RTC_TDR_VTF_MASK         /**< Volatge tamper interrupt mask */

#else /* (defined(MCU_MK11D5)) || (defined(MCU_MK21D5)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */
/* Tamper interrupt masks */
  #define RTC_PDD_TMF_INT RTC_TDR_TMF_MASK         /**< Test mode tamper interrupt mask */
  #define RTC_PDD_FSF_INT RTC_TDR_FSF_MASK         /**< Flash security tamper interrupt mask */
  #define RTC_PDD_TTF_INT RTC_TDR_TTF_MASK         /**< Temperature tamper interrupt mask */
  #define RTC_PDD_CTF_INT RTC_TDR_CTF_MASK         /**< Clock tamper interrupt mask */
  #define RTC_PDD_VTF_INT RTC_TDR_VTF_MASK         /**< Volatge tamper interrupt mask */
  #define RTC_PDD_DTF_INT RTC_TDR_DTF_MASK         /**< DryIce tamper interrupt mask */

#endif /* (defined(MCU_MK11D5)) || (defined(MCU_MK21D5)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */

/* ----------------------------------------------------------------------------
   -- ReadTimeSecondsReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the Time seconds register.
 * @param peripheralBase Peripheral base address.
 */
#define RTC_PDD_ReadTimeSecondsReg(peripheralBase) ( \
    RTC_TSR_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteTimeSecondsReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the Time seconds register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value written to the Time seconds register.
 */
#define RTC_PDD_WriteTimeSecondsReg(peripheralBase, Value) ( \
    RTC_TSR_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadTimePrescalerReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the Time prescaler register.
 * @param peripheralBase Peripheral base address.
 */
#define RTC_PDD_ReadTimePrescalerReg(peripheralBase) ( \
    RTC_TPR_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteTimePrescalerReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the Time prescaler register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value written to the Time prescaler register.
 */
#define RTC_PDD_WriteTimePrescalerReg(peripheralBase, Value) ( \
    RTC_TPR_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadTimeAlarmReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the Time alarm register.
 * @param peripheralBase Peripheral base address.
 */
#define RTC_PDD_ReadTimeAlarmReg(peripheralBase) ( \
    RTC_TAR_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteTimeAlarmReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the Time alarm register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value written to the Time alarm register.
 */
#define RTC_PDD_WriteTimeAlarmReg(peripheralBase, Value) ( \
    RTC_TAR_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadTimeCompensationReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the Time compensation register.
 * @param peripheralBase Peripheral base address.
 */
#define RTC_PDD_ReadTimeCompensationReg(peripheralBase) ( \
    RTC_TCR_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteTimeCompensationReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the Time compensation register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value written to the Time compensation register.
 */
#define RTC_PDD_WriteTimeCompensationReg(peripheralBase, Value) ( \
    RTC_TCR_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadControlReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the Control register.
 * @param peripheralBase Peripheral base address.
 */
#define RTC_PDD_ReadControlReg(peripheralBase) ( \
    RTC_CR_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteControlReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the Control register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value written to the Control register.
 */
#define RTC_PDD_WriteControlReg(peripheralBase, Value) ( \
    RTC_CR_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- EnableUpdateMode
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables update mode.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state.
 */
#define RTC_PDD_EnableUpdateMode(peripheralBase, State) ( \
    ((State) == PDD_DISABLE) ? ( \
      RTC_CR_REG(peripheralBase) = \
       (uint32_t)(( \
        (uint32_t)(RTC_CR_REG(peripheralBase) | (uint32_t)((uint32_t)0x1U << RTC_CR_UM_SHIFT))) & ( \
        (uint32_t)(~(uint32_t)0x4000U)))) : ( \
      RTC_CR_REG(peripheralBase) &= \
       (uint32_t)((uint32_t)(~(uint32_t)RTC_CR_UM_MASK) & (uint32_t)(~(uint32_t)0x4000U))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableSupervisorAccess
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables supervisor accesss.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state.
 */
#define RTC_PDD_EnableSupervisorAccess(peripheralBase, State) ( \
    ((State) == PDD_DISABLE) ? ( \
      RTC_CR_REG(peripheralBase) = \
       (uint32_t)(( \
        (uint32_t)(RTC_CR_REG(peripheralBase) | (uint32_t)((uint32_t)0x1U << RTC_CR_SUP_SHIFT))) & ( \
        (uint32_t)(~(uint32_t)0x4000U)))) : ( \
      RTC_CR_REG(peripheralBase) &= \
       (uint32_t)((uint32_t)(~(uint32_t)RTC_CR_SUP_MASK) & (uint32_t)(~(uint32_t)0x4000U))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableWakeupPin
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables wakeup pin.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state.
 */
#define RTC_PDD_EnableWakeupPin(peripheralBase, State) ( \
    ((State) == PDD_DISABLE) ? ( \
      RTC_CR_REG(peripheralBase) = \
       (uint32_t)(( \
        (uint32_t)(RTC_CR_REG(peripheralBase) | (uint32_t)((uint32_t)0x1U << RTC_CR_WPE_SHIFT))) & ( \
        (uint32_t)(~(uint32_t)0x4000U)))) : ( \
      RTC_CR_REG(peripheralBase) &= \
       (uint32_t)((uint32_t)(~(uint32_t)RTC_CR_WPE_MASK) & (uint32_t)(~(uint32_t)0x4000U))) \
  )

/* ----------------------------------------------------------------------------
   -- ForceSwReset
   ---------------------------------------------------------------------------- */

/**
 * Forces the equivalent of a VBAT POR to the rest of the RTC module, except the
 * access control registers.
 * @param peripheralBase Peripheral base address.
 */
#define RTC_PDD_ForceSwReset(peripheralBase) ( \
    (RTC_CR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(RTC_CR_REG(peripheralBase) | RTC_CR_SWR_MASK)) & ( \
      (uint32_t)(~(uint32_t)0x4000U)))), \
    (RTC_CR_REG(peripheralBase) &= \
     (uint32_t)((uint32_t)(~(uint32_t)RTC_CR_SWR_MASK) & (uint32_t)(~(uint32_t)0x4000U))) \
  )

/* ----------------------------------------------------------------------------
   -- GetRtcInterruptMask
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the RTC interrupt enable register.
 * @param peripheralBase Peripheral base address.
 */
#define RTC_PDD_GetRtcInterruptMask(peripheralBase) ( \
    RTC_IER_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- SetRtcInterruptMask
   ---------------------------------------------------------------------------- */

/**
 * Enables RTC interrupts defined by the Mask parameter.
 * @param peripheralBase Peripheral base address.
 * @param Mask Imterrupt mask.
 */
#define RTC_PDD_SetRtcInterruptMask(peripheralBase, Mask) ( \
    RTC_IER_REG(peripheralBase) = \
     (uint32_t)(Mask) \
  )

/* ----------------------------------------------------------------------------
   -- EnableSecondsInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables the Seconds interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define RTC_PDD_EnableSecondsInterrupt(peripheralBase) ( \
    RTC_IER_REG(peripheralBase) |= \
     RTC_IER_TSIE_MASK \
  )

/* ----------------------------------------------------------------------------
   -- EnableAlarmInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables the Alarm interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define RTC_PDD_EnableAlarmInterrupt(peripheralBase) ( \
    RTC_IER_REG(peripheralBase) |= \
     RTC_IER_TAIE_MASK \
  )

/* ----------------------------------------------------------------------------
   -- EnableTimeOverflowInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables the Time overflow interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define RTC_PDD_EnableTimeOverflowInterrupt(peripheralBase) ( \
    RTC_IER_REG(peripheralBase) |= \
     RTC_IER_TOIE_MASK \
  )

/* ----------------------------------------------------------------------------
   -- EnableTimeInvalidInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables the Time invalid interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define RTC_PDD_EnableTimeInvalidInterrupt(peripheralBase) ( \
    RTC_IER_REG(peripheralBase) |= \
     RTC_IER_TIIE_MASK \
  )

/* ----------------------------------------------------------------------------
   -- DisableSecondsInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables the Seconds interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define RTC_PDD_DisableSecondsInterrupt(peripheralBase) ( \
    RTC_IER_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)RTC_IER_TSIE_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- DisableAlarmInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables the Alarm interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define RTC_PDD_DisableAlarmInterrupt(peripheralBase) ( \
    RTC_IER_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)RTC_IER_TAIE_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- DisableTimeOverflowInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables the Time overflow interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define RTC_PDD_DisableTimeOverflowInterrupt(peripheralBase) ( \
    RTC_IER_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)RTC_IER_TOIE_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- DisableTimeInvalidInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables the Time invalid interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define RTC_PDD_DisableTimeInvalidInterrupt(peripheralBase) ( \
    RTC_IER_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)RTC_IER_TIIE_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- ReadStatusReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the Status register.
 * @param peripheralBase Peripheral base address.
 */
#define RTC_PDD_ReadStatusReg(peripheralBase) ( \
    RTC_SR_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteStatusReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the Status register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value written to the Status register.
 */
#define RTC_PDD_WriteStatusReg(peripheralBase, Value) ( \
    RTC_SR_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- EnableCounter
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables seconds counter.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state.
 */
#define RTC_PDD_EnableCounter(peripheralBase, State) ( \
    ((State) == PDD_DISABLE) ? ( \
      RTC_SR_REG(peripheralBase) = \
       0U) : ( \
      RTC_SR_REG(peripheralBase) = \
       0x10U) \
  )

/* ----------------------------------------------------------------------------
   -- GetEnableCounterStatus
   ---------------------------------------------------------------------------- */

/**
 * Returns zero if the Time counter is disabled else return non-zero value.
 * @param peripheralBase Peripheral base address.
 */
#define RTC_PDD_GetEnableCounterStatus(peripheralBase) ( \
    (uint32_t)(RTC_SR_REG(peripheralBase) & RTC_SR_TCE_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- ReadLockReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the Lock register.
 * @param peripheralBase Peripheral base address.
 */
#define RTC_PDD_ReadLockReg(peripheralBase) ( \
    RTC_LR_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteLockReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the Lock register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value written to the Lock register.
 */
#define RTC_PDD_WriteLockReg(peripheralBase, Value) ( \
    RTC_LR_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- LockStatusReg
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MK12D5)) || (defined(MCU_MK22D5)))
/**
 * The lock register is used to block write accesses to certain registers until
 * the next VBAT_POR or software reset.Write accesses to a locked register are
 * ignored and do not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_LockStatusReg(peripheralBase) ( \
      RTC_LR_REG(peripheralBase) = \
       (uint32_t)(( \
        (uint32_t)(RTC_LR_REG(peripheralBase) & (uint32_t)(~(uint32_t)RTC_LR_SRL_MASK))) | ( \
        0xF000U)) \
    )
#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_MKL04Z4)) || (defined(MCU_MKL05Z4)) || (defined(MCU_MKL14Z4)) || (defined(MCU_MKL15Z4)) || (defined(MCU_MKL24Z4)) || (defined(MCU_MKL25Z4)) || (defined(MCU_PCK20L4)) */
/**
 * The lock register is used to block write accesses to certain registers until
 * the next VBAT_POR or software reset.Write accesses to a locked register are
 * ignored and do not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_LockStatusReg(peripheralBase) ( \
      RTC_LR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)RTC_LR_SRL_MASK) \
    )
#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_MKL04Z4)) || (defined(MCU_MKL05Z4)) || (defined(MCU_MKL14Z4)) || (defined(MCU_MKL15Z4)) || (defined(MCU_MKL24Z4)) || (defined(MCU_MKL25Z4)) || (defined(MCU_PCK20L4)) */

/* ----------------------------------------------------------------------------
   -- LockControlReg
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MK12D5)) || (defined(MCU_MK22D5)))
/**
 * The lock register is used to block write accesses to certain registers until
 * the next VBAT_POR or software reset.Write accesses to a locked register are
 * ignored and do not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_LockControlReg(peripheralBase) ( \
      RTC_LR_REG(peripheralBase) = \
       (uint32_t)(( \
        (uint32_t)(RTC_LR_REG(peripheralBase) & (uint32_t)(~(uint32_t)RTC_LR_CRL_MASK))) | ( \
        0xF000U)) \
    )
#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_MKL04Z4)) || (defined(MCU_MKL05Z4)) || (defined(MCU_MKL14Z4)) || (defined(MCU_MKL15Z4)) || (defined(MCU_MKL24Z4)) || (defined(MCU_MKL25Z4)) || (defined(MCU_PCK20L4)) */
/**
 * The lock register is used to block write accesses to certain registers until
 * the next VBAT_POR or software reset.Write accesses to a locked register are
 * ignored and do not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_LockControlReg(peripheralBase) ( \
      RTC_LR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)RTC_LR_CRL_MASK) \
    )
#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_MKL04Z4)) || (defined(MCU_MKL05Z4)) || (defined(MCU_MKL14Z4)) || (defined(MCU_MKL15Z4)) || (defined(MCU_MKL24Z4)) || (defined(MCU_MKL25Z4)) || (defined(MCU_PCK20L4)) */

/* ----------------------------------------------------------------------------
   -- LockTimeComensationReg
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MK12D5)) || (defined(MCU_MK22D5)))
/**
 * The lock register is used to block write accesses to certain registers until
 * the next VBAT_POR or software reset.Write accesses to a locked register are
 * ignored and do not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_LockTimeComensationReg(peripheralBase) ( \
      RTC_LR_REG(peripheralBase) = \
       (uint32_t)(( \
        (uint32_t)(RTC_LR_REG(peripheralBase) & (uint32_t)(~(uint32_t)RTC_LR_TCL_MASK))) | ( \
        0xF000U)) \
    )
#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_MKL04Z4)) || (defined(MCU_MKL05Z4)) || (defined(MCU_MKL14Z4)) || (defined(MCU_MKL15Z4)) || (defined(MCU_MKL24Z4)) || (defined(MCU_MKL25Z4)) || (defined(MCU_PCK20L4)) */
/**
 * The lock register is used to block write accesses to certain registers until
 * the next VBAT_POR or software reset.Write accesses to a locked register are
 * ignored and do not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_LockTimeComensationReg(peripheralBase) ( \
      RTC_LR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)RTC_LR_TCL_MASK) \
    )
#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_MKL04Z4)) || (defined(MCU_MKL05Z4)) || (defined(MCU_MKL14Z4)) || (defined(MCU_MKL15Z4)) || (defined(MCU_MKL24Z4)) || (defined(MCU_MKL25Z4)) || (defined(MCU_PCK20L4)) */

/* ----------------------------------------------------------------------------
   -- ReadWriteAccessReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the Write access register.
 * @param peripheralBase Peripheral base address.
 */
#define RTC_PDD_ReadWriteAccessReg(peripheralBase) ( \
    RTC_WAR_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteWriteAccessReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the Write access register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value written to the Write access register.
 */
#define RTC_PDD_WriteWriteAccessReg(peripheralBase, Value) ( \
    RTC_WAR_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- DisableInterruptEnableRegWrite
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MK12D5)) || (defined(MCU_MK22D5)))
/**
 * Disables write accesses to the register until the next chip system reset.
 * When accesses are blocked the bus access is not seen in the VBAT power supply and
 * does not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_DisableInterruptEnableRegWrite(peripheralBase) ( \
      RTC_WAR_REG(peripheralBase) = \
       (uint32_t)(( \
        (uint32_t)(RTC_WAR_REG(peripheralBase) & (uint32_t)(~(uint32_t)RTC_WAR_IERW_MASK))) | ( \
        0xF000U)) \
    )
#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_PCK20L4)) */
/**
 * Disables write accesses to the register until the next chip system reset.
 * When accesses are blocked the bus access is not seen in the VBAT power supply and
 * does not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_DisableInterruptEnableRegWrite(peripheralBase) ( \
      RTC_WAR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)RTC_WAR_IERW_MASK) \
    )
#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_PCK20L4)) */

/* ----------------------------------------------------------------------------
   -- DisableLockRegWrite
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MK12D5)) || (defined(MCU_MK22D5)))
/**
 * Disables write accesses to the register until the next chip system reset.
 * When accesses are blocked the bus access is not seen in the VBAT power supply and
 * does not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_DisableLockRegWrite(peripheralBase) ( \
      RTC_WAR_REG(peripheralBase) = \
       (uint32_t)(( \
        (uint32_t)(RTC_WAR_REG(peripheralBase) & (uint32_t)(~(uint32_t)RTC_WAR_LRW_MASK))) | ( \
        0xF000U)) \
    )
#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_PCK20L4)) */
/**
 * Disables write accesses to the register until the next chip system reset.
 * When accesses are blocked the bus access is not seen in the VBAT power supply and
 * does not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_DisableLockRegWrite(peripheralBase) ( \
      RTC_WAR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)RTC_WAR_LRW_MASK) \
    )
#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_PCK20L4)) */

/* ----------------------------------------------------------------------------
   -- DisableStatusRegWrite
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MK12D5)) || (defined(MCU_MK22D5)))
/**
 * Disables write accesses to the register until the next chip system reset.
 * When accesses are blocked the bus access is not seen in the VBAT power supply and
 * does not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_DisableStatusRegWrite(peripheralBase) ( \
      RTC_WAR_REG(peripheralBase) = \
       (uint32_t)(( \
        (uint32_t)(RTC_WAR_REG(peripheralBase) & (uint32_t)(~(uint32_t)RTC_WAR_SRW_MASK))) | ( \
        0xF000U)) \
    )
#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_PCK20L4)) */
/**
 * Disables write accesses to the register until the next chip system reset.
 * When accesses are blocked the bus access is not seen in the VBAT power supply and
 * does not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_DisableStatusRegWrite(peripheralBase) ( \
      RTC_WAR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)RTC_WAR_SRW_MASK) \
    )
#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_PCK20L4)) */

/* ----------------------------------------------------------------------------
   -- DisableControlRegWrite
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MK12D5)) || (defined(MCU_MK22D5)))
/**
 * Disables write accesses to the register until the next chip system reset.
 * When accesses are blocked the bus access is not seen in the VBAT power supply and
 * does not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_DisableControlRegWrite(peripheralBase) ( \
      RTC_WAR_REG(peripheralBase) = \
       (uint32_t)(( \
        (uint32_t)(RTC_WAR_REG(peripheralBase) & (uint32_t)(~(uint32_t)RTC_WAR_CRW_MASK))) | ( \
        0xF000U)) \
    )
#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_PCK20L4)) */
/**
 * Disables write accesses to the register until the next chip system reset.
 * When accesses are blocked the bus access is not seen in the VBAT power supply and
 * does not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_DisableControlRegWrite(peripheralBase) ( \
      RTC_WAR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)RTC_WAR_CRW_MASK) \
    )
#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_PCK20L4)) */

/* ----------------------------------------------------------------------------
   -- DisableTimeCompensationRegWrite
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MK12D5)) || (defined(MCU_MK22D5)))
/**
 * Disables write accesses to the register until the next chip system reset.
 * When accesses are blocked the bus access is not seen in the VBAT power supply and
 * does not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_DisableTimeCompensationRegWrite(peripheralBase) ( \
      RTC_WAR_REG(peripheralBase) = \
       (uint32_t)(( \
        (uint32_t)(RTC_WAR_REG(peripheralBase) & (uint32_t)(~(uint32_t)RTC_WAR_TCRW_MASK))) | ( \
        0xF000U)) \
    )
#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_PCK20L4)) */
/**
 * Disables write accesses to the register until the next chip system reset.
 * When accesses are blocked the bus access is not seen in the VBAT power supply and
 * does not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_DisableTimeCompensationRegWrite(peripheralBase) ( \
      RTC_WAR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)RTC_WAR_TCRW_MASK) \
    )
#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_PCK20L4)) */

/* ----------------------------------------------------------------------------
   -- DisableTimeAlarmRegWrite
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MK12D5)) || (defined(MCU_MK22D5)))
/**
 * Disables write accesses to the register until the next chip system reset.
 * When accesses are blocked the bus access is not seen in the VBAT power supply and
 * does not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_DisableTimeAlarmRegWrite(peripheralBase) ( \
      RTC_WAR_REG(peripheralBase) = \
       (uint32_t)(( \
        (uint32_t)(RTC_WAR_REG(peripheralBase) & (uint32_t)(~(uint32_t)RTC_WAR_TARW_MASK))) | ( \
        0xF000U)) \
    )
#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_PCK20L4)) */
/**
 * Disables write accesses to the register until the next chip system reset.
 * When accesses are blocked the bus access is not seen in the VBAT power supply and
 * does not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_DisableTimeAlarmRegWrite(peripheralBase) ( \
      RTC_WAR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)RTC_WAR_TARW_MASK) \
    )
#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_PCK20L4)) */

/* ----------------------------------------------------------------------------
   -- DisableTimePrescalerRegWrite
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MK12D5)) || (defined(MCU_MK22D5)))
/**
 * Disables write accesses to the register until the next chip system reset.
 * When accesses are blocked the bus access is not seen in the VBAT power supply and
 * does not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_DisableTimePrescalerRegWrite(peripheralBase) ( \
      RTC_WAR_REG(peripheralBase) = \
       (uint32_t)(( \
        (uint32_t)(RTC_WAR_REG(peripheralBase) & (uint32_t)(~(uint32_t)RTC_WAR_TPRW_MASK))) | ( \
        0xF000U)) \
    )
#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_PCK20L4)) */
/**
 * Disables write accesses to the register until the next chip system reset.
 * When accesses are blocked the bus access is not seen in the VBAT power supply and
 * does not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_DisableTimePrescalerRegWrite(peripheralBase) ( \
      RTC_WAR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)RTC_WAR_TPRW_MASK) \
    )
#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_PCK20L4)) */

/* ----------------------------------------------------------------------------
   -- DisableTimeSecondsRegWrite
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MK12D5)) || (defined(MCU_MK22D5)))
/**
 * Disables write accesses to the register until the next chip system reset.
 * When accesses are blocked the bus access is not seen in the VBAT power supply and
 * does not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_DisableTimeSecondsRegWrite(peripheralBase) ( \
      RTC_WAR_REG(peripheralBase) = \
       (uint32_t)(( \
        (uint32_t)(RTC_WAR_REG(peripheralBase) & (uint32_t)(~(uint32_t)RTC_WAR_TSRW_MASK))) | ( \
        0xF000U)) \
    )
#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_PCK20L4)) */
/**
 * Disables write accesses to the register until the next chip system reset.
 * When accesses are blocked the bus access is not seen in the VBAT power supply and
 * does not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_DisableTimeSecondsRegWrite(peripheralBase) ( \
      RTC_WAR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)RTC_WAR_TSRW_MASK) \
    )
#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_PCK20L4)) */

/* ----------------------------------------------------------------------------
   -- ReadReadAccessReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the Read access register.
 * @param peripheralBase Peripheral base address.
 */
#define RTC_PDD_ReadReadAccessReg(peripheralBase) ( \
    RTC_RAR_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteReadAccessReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the Read access register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value written to the Read access register.
 */
#define RTC_PDD_WriteReadAccessReg(peripheralBase, Value) ( \
    RTC_RAR_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- DisableInterruptEnableRegRead
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MK12D5)) || (defined(MCU_MK22D5)))
/**
 * Disables read accesses to the register until the next chip system reset. When
 * accesses are blocked the bus access is not seen in the VBAT power supply and
 * does not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_DisableInterruptEnableRegRead(peripheralBase) ( \
      RTC_RAR_REG(peripheralBase) = \
       (uint32_t)(( \
        (uint32_t)(RTC_RAR_REG(peripheralBase) & (uint32_t)(~(uint32_t)RTC_RAR_IERR_MASK))) | ( \
        0xF000U)) \
    )
#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_PCK20L4)) */
/**
 * Disables read accesses to the register until the next chip system reset. When
 * accesses are blocked the bus access is not seen in the VBAT power supply and
 * does not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_DisableInterruptEnableRegRead(peripheralBase) ( \
      RTC_RAR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)RTC_RAR_IERR_MASK) \
    )
#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_PCK20L4)) */

/* ----------------------------------------------------------------------------
   -- DisableLockRegRead
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MK12D5)) || (defined(MCU_MK22D5)))
/**
 * Disables read accesses to the register until the next chip system reset. When
 * accesses are blocked the bus access is not seen in the VBAT power supply and
 * does not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_DisableLockRegRead(peripheralBase) ( \
      RTC_RAR_REG(peripheralBase) = \
       (uint32_t)(( \
        (uint32_t)(RTC_RAR_REG(peripheralBase) & (uint32_t)(~(uint32_t)RTC_RAR_LRR_MASK))) | ( \
        0xF000U)) \
    )
#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_PCK20L4)) */
/**
 * Disables read accesses to the register until the next chip system reset. When
 * accesses are blocked the bus access is not seen in the VBAT power supply and
 * does not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_DisableLockRegRead(peripheralBase) ( \
      RTC_RAR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)RTC_RAR_LRR_MASK) \
    )
#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_PCK20L4)) */

/* ----------------------------------------------------------------------------
   -- DisableStatusRegRead
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MK12D5)) || (defined(MCU_MK22D5)))
/**
 * Disables read accesses to the register until the next chip system reset. When
 * accesses are blocked the bus access is not seen in the VBAT power supply and
 * does not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_DisableStatusRegRead(peripheralBase) ( \
      RTC_RAR_REG(peripheralBase) = \
       (uint32_t)(( \
        (uint32_t)(RTC_RAR_REG(peripheralBase) & (uint32_t)(~(uint32_t)RTC_RAR_SRR_MASK))) | ( \
        0xF000U)) \
    )
#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_PCK20L4)) */
/**
 * Disables read accesses to the register until the next chip system reset. When
 * accesses are blocked the bus access is not seen in the VBAT power supply and
 * does not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_DisableStatusRegRead(peripheralBase) ( \
      RTC_RAR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)RTC_RAR_SRR_MASK) \
    )
#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_PCK20L4)) */

/* ----------------------------------------------------------------------------
   -- DisableControlRegRead
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MK12D5)) || (defined(MCU_MK22D5)))
/**
 * Disables read accesses to the register until the next chip system reset. When
 * accesses are blocked the bus access is not seen in the VBAT power supply and
 * does not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_DisableControlRegRead(peripheralBase) ( \
      RTC_RAR_REG(peripheralBase) = \
       (uint32_t)(( \
        (uint32_t)(RTC_RAR_REG(peripheralBase) & (uint32_t)(~(uint32_t)RTC_RAR_CRR_MASK))) | ( \
        0xF000U)) \
    )
#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_PCK20L4)) */
/**
 * Disables read accesses to the register until the next chip system reset. When
 * accesses are blocked the bus access is not seen in the VBAT power supply and
 * does not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_DisableControlRegRead(peripheralBase) ( \
      RTC_RAR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)RTC_RAR_CRR_MASK) \
    )
#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_PCK20L4)) */

/* ----------------------------------------------------------------------------
   -- DisableTimeCompensationRegRead
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MK12D5)) || (defined(MCU_MK22D5)))
/**
 * Disables read accesses to the register until the next chip system reset. When
 * accesses are blocked the bus access is not seen in the VBAT power supply and
 * does not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_DisableTimeCompensationRegRead(peripheralBase) ( \
      RTC_RAR_REG(peripheralBase) = \
       (uint32_t)(( \
        (uint32_t)(RTC_RAR_REG(peripheralBase) & (uint32_t)(~(uint32_t)RTC_RAR_TCRR_MASK))) | ( \
        0xF000U)) \
    )
#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_PCK20L4)) */
/**
 * Disables read accesses to the register until the next chip system reset. When
 * accesses are blocked the bus access is not seen in the VBAT power supply and
 * does not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_DisableTimeCompensationRegRead(peripheralBase) ( \
      RTC_RAR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)RTC_RAR_TCRR_MASK) \
    )
#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_PCK20L4)) */

/* ----------------------------------------------------------------------------
   -- DisableTimeAlarmRegRead
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MK12D5)) || (defined(MCU_MK22D5)))
/**
 * Disables read accesses to the register until the next chip system reset. When
 * accesses are blocked the bus access is not seen in the VBAT power supply and
 * does not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_DisableTimeAlarmRegRead(peripheralBase) ( \
      RTC_RAR_REG(peripheralBase) = \
       (uint32_t)(( \
        (uint32_t)(RTC_RAR_REG(peripheralBase) & (uint32_t)(~(uint32_t)RTC_RAR_TARR_MASK))) | ( \
        0xF000U)) \
    )
#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_PCK20L4)) */
/**
 * Disables read accesses to the register until the next chip system reset. When
 * accesses are blocked the bus access is not seen in the VBAT power supply and
 * does not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_DisableTimeAlarmRegRead(peripheralBase) ( \
      RTC_RAR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)RTC_RAR_TARR_MASK) \
    )
#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_PCK20L4)) */

/* ----------------------------------------------------------------------------
   -- DisableTimePrescalerRegRead
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MK12D5)) || (defined(MCU_MK22D5)))
/**
 * Disables read accesses to the register until the next chip system reset. When
 * accesses are blocked the bus access is not seen in the VBAT power supply and
 * does not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_DisableTimePrescalerRegRead(peripheralBase) ( \
      RTC_RAR_REG(peripheralBase) = \
       (uint32_t)(( \
        (uint32_t)(RTC_RAR_REG(peripheralBase) & (uint32_t)(~(uint32_t)RTC_RAR_TPRR_MASK))) | ( \
        0xF000U)) \
    )
#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_PCK20L4)) */
/**
 * Disables read accesses to the register until the next chip system reset. When
 * accesses are blocked the bus access is not seen in the VBAT power supply and
 * does not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_DisableTimePrescalerRegRead(peripheralBase) ( \
      RTC_RAR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)RTC_RAR_TPRR_MASK) \
    )
#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_PCK20L4)) */

/* ----------------------------------------------------------------------------
   -- DisableTimeSecondsRegRead
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MK12D5)) || (defined(MCU_MK22D5)))
/**
 * Disables read accesses to the register until the next chip system reset. When
 * accesses are blocked the bus access is not seen in the VBAT power supply and
 * does not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_DisableTimeSecondsRegRead(peripheralBase) ( \
      RTC_RAR_REG(peripheralBase) = \
       (uint32_t)(( \
        (uint32_t)(RTC_RAR_REG(peripheralBase) & (uint32_t)(~(uint32_t)RTC_RAR_TSRR_MASK))) | ( \
        0xF000U)) \
    )
#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_PCK20L4)) */
/**
 * Disables read accesses to the register until the next chip system reset. When
 * accesses are blocked the bus access is not seen in the VBAT power supply and
 * does not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_DisableTimeSecondsRegRead(peripheralBase) ( \
      RTC_RAR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)RTC_RAR_TSRR_MASK) \
    )
#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_PCK20L4)) */

/* ----------------------------------------------------------------------------
   -- EnableMonotonicOverflowInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables the Monotonic counter overflow interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define RTC_PDD_EnableMonotonicOverflowInterrupt(peripheralBase) ( \
    RTC_IER_REG(peripheralBase) |= \
     RTC_IER_MOIE_MASK \
  )

/* ----------------------------------------------------------------------------
   -- DisableMonotonicOverflowInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables the Monotonic counter overflow interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define RTC_PDD_DisableMonotonicOverflowInterrupt(peripheralBase) ( \
    RTC_IER_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)RTC_IER_MOIE_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- LockTamperInterruptReg
   ---------------------------------------------------------------------------- */

/**
 * The lock register is used to block write accesses to certain registers until
 * the next VBAT_POR or software reset.Write accesses to a locked register are
 * ignored and do not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
#define RTC_PDD_LockTamperInterruptReg(peripheralBase) ( \
    RTC_LR_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)RTC_LR_TIL_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- LockTamperTrimReg
   ---------------------------------------------------------------------------- */

/**
 * The lock register is used to block write accesses to certain registers until
 * the next VBAT_POR or software reset.Write accesses to a locked register are
 * ignored and do not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
#define RTC_PDD_LockTamperTrimReg(peripheralBase) ( \
    RTC_LR_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)RTC_LR_TTL_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- LockTamperDetectReg
   ---------------------------------------------------------------------------- */

/**
 * The lock register is used to block write accesses to certain registers until
 * the next VBAT_POR or software reset.Write accesses to a locked register are
 * ignored and do not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
#define RTC_PDD_LockTamperDetectReg(peripheralBase) ( \
    RTC_LR_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)RTC_LR_TDL_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- LockTamperEnableReg
   ---------------------------------------------------------------------------- */

/**
 * The lock register is used to block write accesses to certain registers until
 * the next VBAT_POR or software reset.Write accesses to a locked register are
 * ignored and do not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
#define RTC_PDD_LockTamperEnableReg(peripheralBase) ( \
    RTC_LR_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)RTC_LR_TEL_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- LockMonotonicCounterHighReg
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MK12D5)) || (defined(MCU_MK22D5)))
/**
 * The lock register is used to block write accesses to certain registers until
 * the next VBAT_POR or software reset.Write accesses to a locked register are
 * ignored and do not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_LockMonotonicCounterHighReg(peripheralBase) ( \
      RTC_LR_REG(peripheralBase) = \
       (uint32_t)(( \
        (uint32_t)(RTC_LR_REG(peripheralBase) & (uint32_t)(~(uint32_t)RTC_LR_MCHL_MASK))) | ( \
        0xF000U)) \
    )
#else /* (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */
/**
 * The lock register is used to block write accesses to certain registers until
 * the next VBAT_POR or software reset.Write accesses to a locked register are
 * ignored and do not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_LockMonotonicCounterHighReg(peripheralBase) ( \
      RTC_LR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)RTC_LR_MCHL_MASK) \
    )
#endif /* (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */

/* ----------------------------------------------------------------------------
   -- LockMonotonicCounterLowReg
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MK12D5)) || (defined(MCU_MK22D5)))
/**
 * The lock register is used to block write accesses to certain registers until
 * the next VBAT_POR or software reset.Write accesses to a locked register are
 * ignored and do not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_LockMonotonicCounterLowReg(peripheralBase) ( \
      RTC_LR_REG(peripheralBase) = \
       (uint32_t)(( \
        (uint32_t)(RTC_LR_REG(peripheralBase) & (uint32_t)(~(uint32_t)RTC_LR_MCLL_MASK))) | ( \
        0xF000U)) \
    )
#else /* (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */
/**
 * The lock register is used to block write accesses to certain registers until
 * the next VBAT_POR or software reset.Write accesses to a locked register are
 * ignored and do not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_LockMonotonicCounterLowReg(peripheralBase) ( \
      RTC_LR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)RTC_LR_MCLL_MASK) \
    )
#endif /* (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */

/* ----------------------------------------------------------------------------
   -- LockMonotonicEnableReg
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MK12D5)) || (defined(MCU_MK22D5)))
/**
 * The lock register is used to block write accesses to certain registers until
 * the next VBAT_POR or software reset.Write accesses to a locked register are
 * ignored and do not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_LockMonotonicEnableReg(peripheralBase) ( \
      RTC_LR_REG(peripheralBase) = \
       (uint32_t)(( \
        (uint32_t)(RTC_LR_REG(peripheralBase) & (uint32_t)(~(uint32_t)RTC_LR_MEL_MASK))) | ( \
        0xF000U)) \
    )
#else /* (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */
/**
 * The lock register is used to block write accesses to certain registers until
 * the next VBAT_POR or software reset.Write accesses to a locked register are
 * ignored and do not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_LockMonotonicEnableReg(peripheralBase) ( \
      RTC_LR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)RTC_LR_MEL_MASK) \
    )
#endif /* (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */

/* ----------------------------------------------------------------------------
   -- LockTamperTimeSecondsReg
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MK12D5)) || (defined(MCU_MK22D5)))
/**
 * The lock register is used to block write accesses to certain registers until
 * the next VBAT_POR or software reset.Write accesses to a locked register are
 * ignored and do not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_LockTamperTimeSecondsReg(peripheralBase) ( \
      RTC_LR_REG(peripheralBase) = \
       (uint32_t)(( \
        (uint32_t)(RTC_LR_REG(peripheralBase) & (uint32_t)(~(uint32_t)RTC_LR_TTSL_MASK))) | ( \
        0xF000U)) \
    )
#else /* (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */
/**
 * The lock register is used to block write accesses to certain registers until
 * the next VBAT_POR or software reset.Write accesses to a locked register are
 * ignored and do not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_LockTamperTimeSecondsReg(peripheralBase) ( \
      RTC_LR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)RTC_LR_TTSL_MASK) \
    )
#endif /* (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */

/* ----------------------------------------------------------------------------
   -- ReadTamperTimeSecondsReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the Tamper time seconds register.
 * @param peripheralBase Peripheral base address.
 */
#define RTC_PDD_ReadTamperTimeSecondsReg(peripheralBase) ( \
    RTC_TTSR_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- GetTamperTime
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the Tamper time in seconds.
 * @param peripheralBase Peripheral base address.
 */
#define RTC_PDD_GetTamperTime(peripheralBase) ( \
    RTC_TTSR_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- ReadMonotonicEnableReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the Monotonic enable register.
 * @param peripheralBase Peripheral base address.
 */
#define RTC_PDD_ReadMonotonicEnableReg(peripheralBase) ( \
    RTC_MER_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteMonotonicEnableReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the Monotonic enable register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value written to the Monotonic enable register.
 */
#define RTC_PDD_WriteMonotonicEnableReg(peripheralBase, Value) ( \
    RTC_MER_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- EnableMonotonicCounter
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables Monotonis counter counter.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state.
 */
#define RTC_PDD_EnableMonotonicCounter(peripheralBase, State) ( \
    ((State) == PDD_DISABLE) ? ( \
      RTC_MER_REG(peripheralBase) = \
       0U) : ( \
      RTC_MER_REG(peripheralBase) = \
       0x10U) \
  )

/* ----------------------------------------------------------------------------
   -- GetMonotonicCounterEnableStatus
   ---------------------------------------------------------------------------- */

/**
 * Returns zero if the Monotonic counter is disabled else return non-zero value.
 * @param peripheralBase Peripheral base address.
 */
#define RTC_PDD_GetMonotonicCounterEnableStatus(peripheralBase) ( \
    (uint32_t)(RTC_MER_REG(peripheralBase) & RTC_MER_MCE_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- ReadMonotonicCounterHighReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the Monotonic counter high register.
 * @param peripheralBase Peripheral base address.
 */
#define RTC_PDD_ReadMonotonicCounterHighReg(peripheralBase) ( \
    RTC_MCHR_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteMonotonicCounterHigReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the Monotonic counter high register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value written to the Monotonic counter high register.
 */
#define RTC_PDD_WriteMonotonicCounterHigReg(peripheralBase, Value) ( \
    RTC_MCHR_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadMonotonicCounterLowReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the Monotonic counter low register.
 * @param peripheralBase Peripheral base address.
 */
#define RTC_PDD_ReadMonotonicCounterLowReg(peripheralBase) ( \
    RTC_MCLR_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteMonotonicCounterLowgReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the Monotonic counter low register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value written to the Monotonic counter low register.
 */
#define RTC_PDD_WriteMonotonicCounterLowgReg(peripheralBase, Value) ( \
    RTC_MCLR_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- GetRtcTamperInterruptMask
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the RTC tamper interrupt register.
 * @param peripheralBase Peripheral base address.
 */
#define RTC_PDD_GetRtcTamperInterruptMask(peripheralBase) ( \
    RTC_TIR_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- SetRtcTamperInterruptMask
   ---------------------------------------------------------------------------- */

/**
 * Enables RTC tamper interrupts defined by the Mask parameter.
 * @param peripheralBase Peripheral base address.
 * @param Mask Imterrupt mask.
 */
#define RTC_PDD_SetRtcTamperInterruptMask(peripheralBase, Mask) ( \
    RTC_TIR_REG(peripheralBase) = \
     (uint32_t)(Mask) \
  )

/* ----------------------------------------------------------------------------
   -- EnableTestModeInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables the Test mode interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define RTC_PDD_EnableTestModeInterrupt(peripheralBase) ( \
    RTC_TIR_REG(peripheralBase) |= \
     RTC_TIR_TMIE_MASK \
  )

/* ----------------------------------------------------------------------------
   -- EnableFlashSecurityInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables the Flash security interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define RTC_PDD_EnableFlashSecurityInterrupt(peripheralBase) ( \
    RTC_TIR_REG(peripheralBase) |= \
     RTC_TIR_FSIE_MASK \
  )

/* ----------------------------------------------------------------------------
   -- EnableTemperatureTamperInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables the Temperature tamper interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define RTC_PDD_EnableTemperatureTamperInterrupt(peripheralBase) ( \
    RTC_TIR_REG(peripheralBase) |= \
     RTC_TIR_TTIE_MASK \
  )

/* ----------------------------------------------------------------------------
   -- EnableClockTamperInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables the Clock tamper interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define RTC_PDD_EnableClockTamperInterrupt(peripheralBase) ( \
    RTC_TIR_REG(peripheralBase) |= \
     RTC_TIR_CTIE_MASK \
  )

/* ----------------------------------------------------------------------------
   -- EnableVolatgeTamperInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables the Voltage tamper interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define RTC_PDD_EnableVolatgeTamperInterrupt(peripheralBase) ( \
    RTC_TIR_REG(peripheralBase) |= \
     RTC_TIR_VTIE_MASK \
  )

/* ----------------------------------------------------------------------------
   -- DisableTestModeInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables the Test mode interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define RTC_PDD_DisableTestModeInterrupt(peripheralBase) ( \
    RTC_TIR_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)RTC_TIR_TMIE_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- DisableFlashSecurityInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables the Flash security interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define RTC_PDD_DisableFlashSecurityInterrupt(peripheralBase) ( \
    RTC_TIR_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)RTC_TIR_FSIE_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- DisableTemperatureTamperInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables the Temperature tamper interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define RTC_PDD_DisableTemperatureTamperInterrupt(peripheralBase) ( \
    RTC_TIR_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)RTC_TIR_TTIE_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- DisableClockTamperInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables the Clock tamper interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define RTC_PDD_DisableClockTamperInterrupt(peripheralBase) ( \
    RTC_TIR_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)RTC_TIR_CTIE_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- DisableVolatgeTamperInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables the Voltage tamper interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define RTC_PDD_DisableVolatgeTamperInterrupt(peripheralBase) ( \
    RTC_TIR_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)RTC_TIR_VTIE_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- ReadTamperDetectReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the Tamper detect register.
 * @param peripheralBase Peripheral base address.
 */
#define RTC_PDD_ReadTamperDetectReg(peripheralBase) ( \
    RTC_TDR_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteTamperDetectReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the Tamper detect register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value written to the Tamper detect register.
 */
#define RTC_PDD_WriteTamperDetectReg(peripheralBase, Value) ( \
    RTC_TDR_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- DisableTamperInterruptRegWrite
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MK12D5)) || (defined(MCU_MK22D5)))
/**
 * Disables write accesses to the register until the next chip system reset.
 * When accesses are blocked the bus access is not seen in the VBAT power supply and
 * does not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_DisableTamperInterruptRegWrite(peripheralBase) ( \
      RTC_WAR_REG(peripheralBase) = \
       (uint32_t)(( \
        (uint32_t)(RTC_WAR_REG(peripheralBase) & (uint32_t)(~(uint32_t)((uint32_t)0x1U << 15U)))) | (( \
        0x1000U) | (( \
        0x2000U) | ( \
        0x4000U)))) \
    )
#else /* (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */
/**
 * Disables write accesses to the register until the next chip system reset.
 * When accesses are blocked the bus access is not seen in the VBAT power supply and
 * does not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_DisableTamperInterruptRegWrite(peripheralBase) ( \
      RTC_WAR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)RTC_WAR_TIRW_MASK) \
    )
#endif /* (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */

/* ----------------------------------------------------------------------------
   -- DisableTamperTrimRegWrite
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MK12D5)) || (defined(MCU_MK22D5)))
/**
 * Disables write accesses to the register until the next chip system reset.
 * When accesses are blocked the bus access is not seen in the VBAT power supply and
 * does not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_DisableTamperTrimRegWrite(peripheralBase) ( \
      RTC_WAR_REG(peripheralBase) = \
       (uint32_t)(( \
        (uint32_t)(RTC_WAR_REG(peripheralBase) & (uint32_t)(~(uint32_t)((uint32_t)0x1U << 14U)))) | (( \
        0x1000U) | (( \
        0x2000U) | ( \
        0x8000U)))) \
    )
#else /* (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */
/**
 * Disables write accesses to the register until the next chip system reset.
 * When accesses are blocked the bus access is not seen in the VBAT power supply and
 * does not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_DisableTamperTrimRegWrite(peripheralBase) ( \
      RTC_WAR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)RTC_WAR_TTRW_MASK) \
    )
#endif /* (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */

/* ----------------------------------------------------------------------------
   -- DisableTamperDetectRegWrite
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MK12D5)) || (defined(MCU_MK22D5)))
/**
 * Disables write accesses to the register until the next chip system reset.
 * When accesses are blocked the bus access is not seen in the VBAT power supply and
 * does not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_DisableTamperDetectRegWrite(peripheralBase) ( \
      RTC_WAR_REG(peripheralBase) = \
       (uint32_t)(( \
        (uint32_t)(RTC_WAR_REG(peripheralBase) & (uint32_t)(~(uint32_t)((uint32_t)0x1U << 13U)))) | (( \
        0x1000U) | (( \
        0x4000U) | ( \
        0x8000U)))) \
    )
#else /* (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */
/**
 * Disables write accesses to the register until the next chip system reset.
 * When accesses are blocked the bus access is not seen in the VBAT power supply and
 * does not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_DisableTamperDetectRegWrite(peripheralBase) ( \
      RTC_WAR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)RTC_WAR_TDRW_MASK) \
    )
#endif /* (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */

/* ----------------------------------------------------------------------------
   -- DisableTamperEnableRegWrite
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MK12D5)) || (defined(MCU_MK22D5)))
/**
 * Disables write accesses to the register until the next chip system reset.
 * When accesses are blocked the bus access is not seen in the VBAT power supply and
 * does not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_DisableTamperEnableRegWrite(peripheralBase) ( \
      RTC_WAR_REG(peripheralBase) = \
       (uint32_t)(( \
        (uint32_t)(RTC_WAR_REG(peripheralBase) & (uint32_t)(~(uint32_t)((uint32_t)0x1U << 12U)))) | (( \
        0x2000U) | (( \
        0x4000U) | ( \
        0x8000U)))) \
    )
#else /* (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */
/**
 * Disables write accesses to the register until the next chip system reset.
 * When accesses are blocked the bus access is not seen in the VBAT power supply and
 * does not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_DisableTamperEnableRegWrite(peripheralBase) ( \
      RTC_WAR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)RTC_WAR_TERW_MASK) \
    )
#endif /* (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */

/* ----------------------------------------------------------------------------
   -- DisableMonotonicCounterHighRegWrite
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MK12D5)) || (defined(MCU_MK22D5)))
/**
 * Disables write accesses to the register until the next chip system reset.
 * When accesses are blocked the bus access is not seen in the VBAT power supply and
 * does not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_DisableMonotonicCounterHighRegWrite(peripheralBase) ( \
      RTC_WAR_REG(peripheralBase) = \
       (uint32_t)(( \
        (uint32_t)(RTC_WAR_REG(peripheralBase) & (uint32_t)(~(uint32_t)RTC_WAR_MCHW_MASK))) | ( \
        0xF000U)) \
    )
#else /* (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */
/**
 * Disables write accesses to the register until the next chip system reset.
 * When accesses are blocked the bus access is not seen in the VBAT power supply and
 * does not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_DisableMonotonicCounterHighRegWrite(peripheralBase) ( \
      RTC_WAR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)RTC_WAR_MCHW_MASK) \
    )
#endif /* (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */

/* ----------------------------------------------------------------------------
   -- DisableMonotonicCounterLowRegWrite
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MK12D5)) || (defined(MCU_MK22D5)))
/**
 * Disables write accesses to the register until the next chip system reset.
 * When accesses are blocked the bus access is not seen in the VBAT power supply and
 * does not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_DisableMonotonicCounterLowRegWrite(peripheralBase) ( \
      RTC_WAR_REG(peripheralBase) = \
       (uint32_t)(( \
        (uint32_t)(RTC_WAR_REG(peripheralBase) & (uint32_t)(~(uint32_t)RTC_WAR_MCLW_MASK))) | ( \
        0xF000U)) \
    )
#else /* (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */
/**
 * Disables write accesses to the register until the next chip system reset.
 * When accesses are blocked the bus access is not seen in the VBAT power supply and
 * does not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_DisableMonotonicCounterLowRegWrite(peripheralBase) ( \
      RTC_WAR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)RTC_WAR_MCLW_MASK) \
    )
#endif /* (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */

/* ----------------------------------------------------------------------------
   -- DisableMonotonicEnableRegWrite
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MK12D5)) || (defined(MCU_MK22D5)))
/**
 * Disables write accesses to the register until the next chip system reset.
 * When accesses are blocked the bus access is not seen in the VBAT power supply and
 * does not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_DisableMonotonicEnableRegWrite(peripheralBase) ( \
      RTC_WAR_REG(peripheralBase) = \
       (uint32_t)(( \
        (uint32_t)(RTC_WAR_REG(peripheralBase) & (uint32_t)(~(uint32_t)RTC_WAR_MERW_MASK))) | ( \
        0xF000U)) \
    )
#else /* (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */
/**
 * Disables write accesses to the register until the next chip system reset.
 * When accesses are blocked the bus access is not seen in the VBAT power supply and
 * does not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_DisableMonotonicEnableRegWrite(peripheralBase) ( \
      RTC_WAR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)RTC_WAR_MERW_MASK) \
    )
#endif /* (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */

/* ----------------------------------------------------------------------------
   -- DisableTamperTimeSecondsRegWrite
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MK12D5)) || (defined(MCU_MK22D5)))
/**
 * Disables write accesses to the register until the next chip system reset.
 * When accesses are blocked the bus access is not seen in the VBAT power supply and
 * does not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_DisableTamperTimeSecondsRegWrite(peripheralBase) ( \
      RTC_WAR_REG(peripheralBase) = \
       (uint32_t)(( \
        (uint32_t)(RTC_WAR_REG(peripheralBase) & (uint32_t)(~(uint32_t)RTC_WAR_TTSW_MASK))) | ( \
        0xF000U)) \
    )
#else /* (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */
/**
 * Disables write accesses to the register until the next chip system reset.
 * When accesses are blocked the bus access is not seen in the VBAT power supply and
 * does not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_DisableTamperTimeSecondsRegWrite(peripheralBase) ( \
      RTC_WAR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)RTC_WAR_TTSW_MASK) \
    )
#endif /* (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */

/* ----------------------------------------------------------------------------
   -- ReadTamperTrimReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the Tamper trim register.
 * @param peripheralBase Peripheral base address.
 */
#define RTC_PDD_ReadTamperTrimReg(peripheralBase) ( \
    RTC_TTR_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteTamperTrimReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the Tamper trim register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value written to the Tamper trim register.
 */
#define RTC_PDD_WriteTamperTrimReg(peripheralBase, Value) ( \
    RTC_TTR_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- DisableTamperInterruptRegRead
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MK12D5)) || (defined(MCU_MK22D5)))
/**
 * Disables read accesses to the register until the next chip system reset. When
 * accesses are blocked the bus access is not seen in the VBAT power supply and
 * does not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_DisableTamperInterruptRegRead(peripheralBase) ( \
      RTC_RAR_REG(peripheralBase) = \
       (uint32_t)(( \
        (uint32_t)(RTC_RAR_REG(peripheralBase) & (uint32_t)(~(uint32_t)((uint32_t)0x1U << 15U)))) | (( \
        0x1000U) | (( \
        0x2000U) | ( \
        0x4000U)))) \
    )
#else /* (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */
/**
 * Disables read accesses to the register until the next chip system reset. When
 * accesses are blocked the bus access is not seen in the VBAT power supply and
 * does not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_DisableTamperInterruptRegRead(peripheralBase) ( \
      RTC_RAR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)RTC_RAR_TIRR_MASK) \
    )
#endif /* (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */

/* ----------------------------------------------------------------------------
   -- DisableTamperTrimRegRead
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MK12D5)) || (defined(MCU_MK22D5)))
/**
 * Disables read accesses to the register until the next chip system reset. When
 * accesses are blocked the bus access is not seen in the VBAT power supply and
 * does not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_DisableTamperTrimRegRead(peripheralBase) ( \
      RTC_RAR_REG(peripheralBase) = \
       (uint32_t)(( \
        (uint32_t)(RTC_RAR_REG(peripheralBase) & (uint32_t)(~(uint32_t)((uint32_t)0x1U << 14U)))) | (( \
        0x1000U) | (( \
        0x2000U) | ( \
        0x8000U)))) \
    )
#else /* (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */
/**
 * Disables read accesses to the register until the next chip system reset. When
 * accesses are blocked the bus access is not seen in the VBAT power supply and
 * does not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_DisableTamperTrimRegRead(peripheralBase) ( \
      RTC_RAR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)RTC_RAR_TTRR_MASK) \
    )
#endif /* (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */

/* ----------------------------------------------------------------------------
   -- DisableTamperDetectRegRead
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MK12D5)) || (defined(MCU_MK22D5)))
/**
 * Disables read accesses to the register until the next chip system reset. When
 * accesses are blocked the bus access is not seen in the VBAT power supply and
 * does not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_DisableTamperDetectRegRead(peripheralBase) ( \
      RTC_RAR_REG(peripheralBase) = \
       (uint32_t)(( \
        (uint32_t)(RTC_RAR_REG(peripheralBase) & (uint32_t)(~(uint32_t)((uint32_t)0x1U << 13U)))) | (( \
        0x1000U) | (( \
        0x4000U) | ( \
        0x8000U)))) \
    )
#else /* (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */
/**
 * Disables read accesses to the register until the next chip system reset. When
 * accesses are blocked the bus access is not seen in the VBAT power supply and
 * does not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_DisableTamperDetectRegRead(peripheralBase) ( \
      RTC_RAR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)RTC_RAR_TDRR_MASK) \
    )
#endif /* (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */

/* ----------------------------------------------------------------------------
   -- DisableTamperEnableRegRead
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MK12D5)) || (defined(MCU_MK22D5)))
/**
 * Disables read accesses to the register until the next chip system reset. When
 * accesses are blocked the bus access is not seen in the VBAT power supply and
 * does not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_DisableTamperEnableRegRead(peripheralBase) ( \
      RTC_RAR_REG(peripheralBase) = \
       (uint32_t)(( \
        (uint32_t)(RTC_RAR_REG(peripheralBase) & (uint32_t)(~(uint32_t)((uint32_t)0x1U << 12U)))) | (( \
        0x2000U) | (( \
        0x4000U) | ( \
        0x8000U)))) \
    )
#else /* (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */
/**
 * Disables read accesses to the register until the next chip system reset. When
 * accesses are blocked the bus access is not seen in the VBAT power supply and
 * does not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_DisableTamperEnableRegRead(peripheralBase) ( \
      RTC_RAR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)RTC_RAR_TERR_MASK) \
    )
#endif /* (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */

/* ----------------------------------------------------------------------------
   -- DisableMonotonicCounterHighRegRead
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MK12D5)) || (defined(MCU_MK22D5)))
/**
 * Disables read accesses to the register until the next chip system reset. When
 * accesses are blocked the bus access is not seen in the VBAT power supply and
 * does not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_DisableMonotonicCounterHighRegRead(peripheralBase) ( \
      RTC_RAR_REG(peripheralBase) = \
       (uint32_t)(( \
        (uint32_t)(RTC_RAR_REG(peripheralBase) & (uint32_t)(~(uint32_t)RTC_RAR_MCHR_MASK))) | ( \
        0xF000U)) \
    )
#else /* (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */
/**
 * Disables read accesses to the register until the next chip system reset. When
 * accesses are blocked the bus access is not seen in the VBAT power supply and
 * does not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_DisableMonotonicCounterHighRegRead(peripheralBase) ( \
      RTC_RAR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)RTC_RAR_MCHR_MASK) \
    )
#endif /* (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */

/* ----------------------------------------------------------------------------
   -- DisableMonotonicCounterLowRegRead
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MK12D5)) || (defined(MCU_MK22D5)))
/**
 * Disables read accesses to the register until the next chip system reset. When
 * accesses are blocked the bus access is not seen in the VBAT power supply and
 * does not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_DisableMonotonicCounterLowRegRead(peripheralBase) ( \
      RTC_RAR_REG(peripheralBase) = \
       (uint32_t)(( \
        (uint32_t)(RTC_RAR_REG(peripheralBase) & (uint32_t)(~(uint32_t)RTC_RAR_MCLR_MASK))) | ( \
        0xF000U)) \
    )
#else /* (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */
/**
 * Disables read accesses to the register until the next chip system reset. When
 * accesses are blocked the bus access is not seen in the VBAT power supply and
 * does not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_DisableMonotonicCounterLowRegRead(peripheralBase) ( \
      RTC_RAR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)RTC_RAR_MCLR_MASK) \
    )
#endif /* (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */

/* ----------------------------------------------------------------------------
   -- DisableMonotonicEnableRegRead
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MK12D5)) || (defined(MCU_MK22D5)))
/**
 * Disables read accesses to the register until the next chip system reset. When
 * accesses are blocked the bus access is not seen in the VBAT power supply and
 * does not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_DisableMonotonicEnableRegRead(peripheralBase) ( \
      RTC_RAR_REG(peripheralBase) = \
       (uint32_t)(( \
        (uint32_t)(RTC_RAR_REG(peripheralBase) & (uint32_t)(~(uint32_t)RTC_RAR_MERR_MASK))) | ( \
        0xF000U)) \
    )
#else /* (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */
/**
 * Disables read accesses to the register until the next chip system reset. When
 * accesses are blocked the bus access is not seen in the VBAT power supply and
 * does not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_DisableMonotonicEnableRegRead(peripheralBase) ( \
      RTC_RAR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)RTC_RAR_MERR_MASK) \
    )
#endif /* (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */

/* ----------------------------------------------------------------------------
   -- DisableTamperTimeSecondsRegRead
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MK12D5)) || (defined(MCU_MK22D5)))
/**
 * Disables read accesses to the register until the next chip system reset. When
 * accesses are blocked the bus access is not seen in the VBAT power supply and
 * does not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_DisableTamperTimeSecondsRegRead(peripheralBase) ( \
      RTC_RAR_REG(peripheralBase) = \
       (uint32_t)(( \
        (uint32_t)(RTC_RAR_REG(peripheralBase) & (uint32_t)(~(uint32_t)RTC_RAR_TTSR_MASK))) | ( \
        0xF000U)) \
    )
#else /* (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */
/**
 * Disables read accesses to the register until the next chip system reset. When
 * accesses are blocked the bus access is not seen in the VBAT power supply and
 * does not generate a bus error.
 * @param peripheralBase Peripheral base address.
 */
  #define RTC_PDD_DisableTamperTimeSecondsRegRead(peripheralBase) ( \
      RTC_RAR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)RTC_RAR_TTSR_MASK) \
    )
#endif /* (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */

/* ----------------------------------------------------------------------------
   -- EnableDryIceTamperInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables the DryIce tamper interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define RTC_PDD_EnableDryIceTamperInterrupt(peripheralBase) ( \
    RTC_TIR_REG(peripheralBase) |= \
     RTC_TIR_DTIE_MASK \
  )

/* ----------------------------------------------------------------------------
   -- DisableDryIceTamperInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables the DryIce tamper interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define RTC_PDD_DisableDryIceTamperInterrupt(peripheralBase) ( \
    RTC_TIR_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)RTC_TIR_DTIE_MASK) \
  )
#endif  /* #if defined(RTC_PDD_H_) */

/* RTC_PDD.h, eof. */
