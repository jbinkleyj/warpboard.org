/*
  PDD layer implementation for peripheral type CAN
  (C) 2010 Freescale, Inc. All rights reserved.

  This file is static and it is generated from API-Factory
*/

#if !defined(CAN_PDD_H_)
#define CAN_PDD_H_

/* ----------------------------------------------------------------------------
   -- Test if supported MCU is active
   ---------------------------------------------------------------------------- */

#if !defined(MCU_ACTIVE)
  // No MCU is active
  #error CAN PDD library: No derivative is active. Place proper #include with PDD memory map before including PDD library.
#elif \
      !defined(MCU_MK10D10) /* CAN0, CAN1 */ && \
      !defined(MCU_MK10D7) /* CAN0 */ && \
      !defined(MCU_MK10F12) /* CAN0, CAN1 */ && \
      !defined(MCU_MK10DZ10) /* CAN0, CAN1 */ && \
      !defined(MCU_MK20D10) /* CAN0, CAN1 */ && \
      !defined(MCU_MK20D7) /* CAN0 */ && \
      !defined(MCU_MK20F12) /* CAN0, CAN1 */ && \
      !defined(MCU_MK20DZ10) /* CAN0, CAN1 */ && \
      !defined(MCU_MK30D10) /* CAN0, CAN1 */ && \
      !defined(MCU_MK30D7) /* CAN0 */ && \
      !defined(MCU_MK30DZ10) /* CAN0, CAN1 */ && \
      !defined(MCU_MK40D10) /* CAN0, CAN1 */ && \
      !defined(MCU_MK40D7) /* CAN0 */ && \
      !defined(MCU_MK40DZ10) /* CAN0, CAN1 */ && \
      !defined(MCU_MK40X256VMD100) /* CAN0, CAN1 */ && \
      !defined(MCU_MK60D10) /* CAN0, CAN1 */ && \
      !defined(MCU_MK60F12) /* CAN0, CAN1 */ && \
      !defined(MCU_MK60F15) /* CAN0, CAN1 */ && \
      !defined(MCU_MK60DZ10) /* CAN0, CAN1 */ && \
      !defined(MCU_MK60N512VMD100) /* CAN0, CAN1 */ && \
      !defined(MCU_MK61F12) /* CAN0, CAN1 */ && \
      !defined(MCU_MK61F15) /* CAN0, CAN1 */ && \
      !defined(MCU_MK70F12) /* CAN0, CAN1 */ && \
      !defined(MCU_MK70F15) /* CAN0, CAN1 */
  // Unsupported MCU is active
  #error CAN PDD library: Unsupported derivative is active.
#endif

#include "PDD_Types.h"

/* ----------------------------------------------------------------------------
   -- Method symbol definitions
   ---------------------------------------------------------------------------- */

/* Warning interrupt mask (for EnableWarningInterruptsMask,
   DisableWarningInterruptsMask macros). */
#define CAN_PDD_TX_WARNING_INT_MASK CAN_CTRL1_TWRNMSK_MASK /**< Tx warning interrupt mask. */
#define CAN_PDD_RX_WARNING_INT_MASK CAN_CTRL1_RWRNMSK_MASK /**< Rx warning interrupt mask. */

/* Status flags constants (for GetStatusInterruptFlags1,
   ClearStatusInterruptFlags1 macros). */
#define CAN_PDD_SYNCHRONIZED_TO_CAN_BUS CAN_ESR1_SYNCH_MASK /**< CAN synchronization status flag */
#define CAN_PDD_TX_WARNING_INT CAN_ESR1_TWRNINT_MASK /**< Tx warning interrupt Flag */
#define CAN_PDD_RX_WARNING_INT CAN_ESR1_RWRNINT_MASK /**< Rx warning interrupt Flag */
#define CAN_PDD_BIT1_ERROR CAN_ESR1_BIT1ERR_MASK /**< Bit1 error flag */
#define CAN_PDD_BIT0_ERROR CAN_ESR1_BIT0ERR_MASK /**< Bit0 error flag */
#define CAN_PDD_ACKNOWLEDGE_ERROR CAN_ESR1_ACKERR_MASK /**< Acknowledge error flag */
#define CAN_PDD_CRC_ERROR CAN_ESR1_CRCERR_MASK   /**< Cyclic redundancy check error flag */
#define CAN_PDD_FORM_ERROR CAN_ESR1_FRMERR_MASK  /**< Form error detected */
#define CAN_PDD_SUFFTING_ERROR CAN_ESR1_STFERR_MASK /**< Stuffing error flag */
#define CAN_PDD_TX_ERROR_WARNING CAN_ESR1_TXWRN_MASK /**< Tx error warning - repetitive errors are occurring during message transmission */
#define CAN_PDD_RX_ERROR_WARNING CAN_ESR1_RXWRN_MASK /**< Rx error warning - repetitive errors are occurring during message reception */
#define CAN_PDD_CAN_BUS_IDLE CAN_ESR1_IDLE_MASK  /**< CAN bus IDLE state. */
#define CAN_PDD_TRANSMITTING_MESSAGE CAN_ESR1_TX_MASK /**< FlexCAN in transmission */
#define CAN_PDD_RECEIVING_MESSAGE CAN_ESR1_RX_MASK /**< FlexCAN in reception */
#define CAN_PDD_BUS_OFF_INT CAN_ESR1_BOFFINT_MASK /**< FlexCAN enters Bus Off state */
#define CAN_PDD_ERROR_INT CAN_ESR1_ERRINT_MASK   /**< Error interrupt */
#define CAN_PDD_WAKEUP_INT CAN_ESR1_WAKINT_MASK  /**< Wake-Up interrupt */

/* CAN device state mode constants (for GetReadyStatus macro). */
#define CAN_PDD_IS_READY 0x8000000U              /**< CAN module is either in Disable Mode, Doze Mode, Stop Mode or Freeze Mode. */
#define CAN_PDD_NOT_READY 0U                     /**< CAN module is either in Normal Mode, Listen-Only Mode or Loop-Back Mode. */

/* CAN device soft reset state constants (for GetSoftReset macro). */
#define CAN_PDD_IS_RESET 0U                      /**< No reset request */
#define CAN_PDD_NOT_RESET 0x2000000U             /**< Resets the registers affected by soft reset. */

/* CAN device freeze state constants (for GetFreezeAck macro). */
#define CAN_PDD_IS_FREEZE 0x1000000U             /**< CAN in Freeze Mode, prescaler stopped */
#define CAN_PDD_NOT_FREEZE 0U                    /**< CAN not in Freeze Mode, prescaler running */

/* CAN device low power mode constants (for GetLowPowerAcknowledge macro). */
#define CAN_PDD_IS_LOW_POWER_MODE 0x100000U      /**< CAN is either in Disable Mode, Doze Mode or Stop mode */
#define CAN_PDD_NOT_LOW_POWER_MODE 0U            /**< CAN is not in any of the low power modes */

/* Rx FIFO Acceptance ID Mode constants (for SetRxFIFOAcceptanceIDMode macro). */
#define CAN_PDD_FORMAT_A 0U                      /**< One full ID (standard and extended) per ID Filter Table element */
#define CAN_PDD_FORMAT_B 0x1U                    /**< Two full standard IDs or two partial 14-bit (standard and extended) IDs per ID Filter Tableelement */
#define CAN_PDD_FORMAT_C 0x2U                    /**< Four partial 8-bit Standard IDs per ID Filter Table element */
#define CAN_PDD_FORMAT_D 0x3U                    /**< All frames rejected */

/* CAN Engine Clock Source constants (for SetClockSource macro). */
#define CAN_PDD_XTAL_CLOCK 0U                    /**< The CAN engine clock source is the oscillator clock */
#define CAN_PDD_BUS_CLOCK 0x2000U                /**< The CAN engine clock source is the peripheral clock */

/* Rx sampling mode constants (for SetBitSampling macro). */
#define CAN_PDD_ONE_SAMPLE 0U                    /**< Just one sample is used to determine the bit value */
#define CAN_PDD_THREE_SAMPLES 0x80U              /**< Three samples are used to determine the value of the received bit */

/* Message buffer interrupt and flag mask constant constants (for
   EnableMessageBufferInterruptMask1, DisableMessageBufferInterruptMask1 macros). */
#define CAN_PDD_MESSAGE_BUFFER_0 0x1U            /**< Buffer MB0 interrupt mask */
#define CAN_PDD_MESSAGE_BUFFER_1 0x2U            /**< Buffer MB1 interrupt mask */
#define CAN_PDD_MESSAGE_BUFFER_2 0x4U            /**< Buffer MB2 interrupt mask */
#define CAN_PDD_MESSAGE_BUFFER_3 0x8U            /**< Buffer MB3 interrupt mask */
#define CAN_PDD_MESSAGE_BUFFER_4 0x10U           /**< Buffer MB4 interrupt mask */
#define CAN_PDD_MESSAGE_BUFFER_5 0x20U           /**< Buffer MB5 interrupt mask */
#define CAN_PDD_MESSAGE_BUFFER_6 0x40U           /**< Buffer MB6 interrupt mask */
#define CAN_PDD_MESSAGE_BUFFER_7 0x80U           /**< Buffer MB7 interrupt mask */
#define CAN_PDD_MESSAGE_BUFFER_8 0x100U          /**< Buffer MB8 interrupt mask */
#define CAN_PDD_MESSAGE_BUFFER_9 0x200U          /**< Buffer MB9 interrupt mask */
#define CAN_PDD_MESSAGE_BUFFER_10 0x400U         /**< Buffer MB10 interrupt mask */
#define CAN_PDD_MESSAGE_BUFFER_11 0x800U         /**< Buffer MB11 interrupt mask */
#define CAN_PDD_MESSAGE_BUFFER_12 0x1000U        /**< Buffer MB12 interrupt mask */
#define CAN_PDD_MESSAGE_BUFFER_13 0x2000U        /**< Buffer MB13 interrupt mask */
#define CAN_PDD_MESSAGE_BUFFER_14 0x4000U        /**< Buffer MB14 interrupt mask */
#define CAN_PDD_MESSAGE_BUFFER_15 0x8000U        /**< Buffer MB15 interrupt mask */
#define CAN_PDD_MESSAGE_BUFFER_16 0x10000U       /**< Buffer MB16 interrupt mask */
#define CAN_PDD_MESSAGE_BUFFER_17 0x20000U       /**< Buffer MB17 interrupt mask */
#define CAN_PDD_MESSAGE_BUFFER_18 0x40000U       /**< Buffer MB18 interrupt mask */
#define CAN_PDD_MESSAGE_BUFFER_19 0x80000U       /**< Buffer MB19 interrupt mask */
#define CAN_PDD_MESSAGE_BUFFER_20 0x100000U      /**< Buffer MB20 interrupt mask */
#define CAN_PDD_MESSAGE_BUFFER_21 0x200000U      /**< Buffer MB21 interrupt mask */
#define CAN_PDD_MESSAGE_BUFFER_22 0x400000U      /**< Buffer MB22 interrupt mask */
#define CAN_PDD_MESSAGE_BUFFER_23 0x800000U      /**< Buffer MB23 interrupt mask */
#define CAN_PDD_MESSAGE_BUFFER_24 0x1000000U     /**< Buffer MB24 interrupt mask */
#define CAN_PDD_MESSAGE_BUFFER_25 0x2000000U     /**< Buffer MB25 interrupt mask */
#define CAN_PDD_MESSAGE_BUFFER_26 0x4000000U     /**< Buffer MB26 interrupt mask */
#define CAN_PDD_MESSAGE_BUFFER_27 0x8000000U     /**< Buffer MB27 interrupt mask */
#define CAN_PDD_MESSAGE_BUFFER_28 0x10000000U    /**< Buffer MB28 interrupt mask */
#define CAN_PDD_MESSAGE_BUFFER_29 0x20000000U    /**< Buffer MB29 interrupt mask */
#define CAN_PDD_MESSAGE_BUFFER_30 0x40000000U    /**< Buffer MB30 interrupt mask */
#define CAN_PDD_MESSAGE_BUFFER_31 0x80000000U    /**< Buffer MB31 interrupt mask */

/* Message buffer interrupt and flag mask constant constants (for
   EnableMessageBufferInterruptMask2, DisableMessageBufferInterruptMask2 macros). */
#define CAN_PDD_MESSAGE_BUFFER_32 0x1U           /**< Buffer MB32 interrupt mask */
#define CAN_PDD_MESSAGE_BUFFER_33 0x2U           /**< Buffer MB33 interrupt mask */
#define CAN_PDD_MESSAGE_BUFFER_34 0x4U           /**< Buffer MB34 interrupt mask */
#define CAN_PDD_MESSAGE_BUFFER_35 0x8U           /**< Buffer MB35 interrupt mask */
#define CAN_PDD_MESSAGE_BUFFER_36 0x10U          /**< Buffer MB36 interrupt mask */
#define CAN_PDD_MESSAGE_BUFFER_37 0x20U          /**< Buffer MB37 interrupt mask */
#define CAN_PDD_MESSAGE_BUFFER_38 0x40U          /**< Buffer MB38 interrupt mask */
#define CAN_PDD_MESSAGE_BUFFER_39 0x80U          /**< Buffer MB39 interrupt mask */
#define CAN_PDD_MESSAGE_BUFFER_40 0x100U         /**< Buffer MB40 interrupt mask */
#define CAN_PDD_MESSAGE_BUFFER_41 0x200U         /**< Buffer MB41 interrupt mask */
#define CAN_PDD_MESSAGE_BUFFER_42 0x400U         /**< Buffer MB42 interrupt mask */
#define CAN_PDD_MESSAGE_BUFFER_43 0x800U         /**< Buffer MB43 interrupt mask */
#define CAN_PDD_MESSAGE_BUFFER_44 0x1000U        /**< Buffer MB44 interrupt mask */
#define CAN_PDD_MESSAGE_BUFFER_45 0x2000U        /**< Buffer MB45 interrupt mask */
#define CAN_PDD_MESSAGE_BUFFER_46 0x4000U        /**< Buffer MB46 interrupt mask */
#define CAN_PDD_MESSAGE_BUFFER_47 0x8000U        /**< Buffer MB47 interrupt mask */
#define CAN_PDD_MESSAGE_BUFFER_48 0x10000U       /**< Buffer MB48 interrupt mask */
#define CAN_PDD_MESSAGE_BUFFER_49 0x20000U       /**< Buffer MB49 interrupt mask */
#define CAN_PDD_MESSAGE_BUFFER_50 0x40000U       /**< Buffer MB50 interrupt mask */
#define CAN_PDD_MESSAGE_BUFFER_51 0x80000U       /**< Buffer MB51 interrupt mask */
#define CAN_PDD_MESSAGE_BUFFER_52 0x100000U      /**< Buffer MB52 interrupt mask */
#define CAN_PDD_MESSAGE_BUFFER_53 0x200000U      /**< Buffer MB53 interrupt mask */
#define CAN_PDD_MESSAGE_BUFFER_54 0x400000U      /**< Buffer MB54 interrupt mask */
#define CAN_PDD_MESSAGE_BUFFER_55 0x800000U      /**< Buffer MB55 interrupt mask */
#define CAN_PDD_MESSAGE_BUFFER_56 0x1000000U     /**< Buffer MB56 interrupt mask */
#define CAN_PDD_MESSAGE_BUFFER_57 0x2000000U     /**< Buffer MB57 interrupt mask */
#define CAN_PDD_MESSAGE_BUFFER_58 0x4000000U     /**< Buffer MB58 interrupt mask */
#define CAN_PDD_MESSAGE_BUFFER_59 0x8000000U     /**< Buffer MB59 interrupt mask */
#define CAN_PDD_MESSAGE_BUFFER_60 0x10000000U    /**< Buffer MB60 interrupt mask */
#define CAN_PDD_MESSAGE_BUFFER_61 0x20000000U    /**< Buffer MB61 interrupt mask */
#define CAN_PDD_MESSAGE_BUFFER_62 0x40000000U    /**< Buffer MB62 interrupt mask */
#define CAN_PDD_MESSAGE_BUFFER_63 0x80000000U    /**< Buffer MB63 interrupt mask */

/* Number Rx FIFO filter constants (for SetNumberRxFIFOFilter macro). */
#define CAN_PDD_RX_FIFO_FILTERS_8 0U             /**< 8 Rx FIFO Filters */
#define CAN_PDD_RX_FIFO_FILTERS_16 0x1U          /**< 16 Rx FIFO Filters */
#define CAN_PDD_RX_FIFO_FILTERS_24 0x2U          /**< 24 Rx FIFO Filters */
#define CAN_PDD_RX_FIFO_FILTERS_32 0x3U          /**< 32 Rx FIFO Filters */
#define CAN_PDD_RX_FIFO_FILTERS_40 0x4U          /**< 40 Rx FIFO Filters */
#define CAN_PDD_RX_FIFO_FILTERS_48 0x5U          /**< 48 Rx FIFO Filters */
#define CAN_PDD_RX_FIFO_FILTERS_56 0x6U          /**< 56 Rx FIFO Filters */
#define CAN_PDD_RX_FIFO_FILTERS_64 0x7U          /**< 64 Rx FIFO Filters */
#define CAN_PDD_RX_FIFO_FILTERS_72 0x8U          /**< 72 Rx FIFO Filters */
#define CAN_PDD_RX_FIFO_FILTERS_80 0x9U          /**< 80 Rx FIFO Filters */
#define CAN_PDD_RX_FIFO_FILTERS_88 0xAU          /**< 88 Rx FIFO Filters */
#define CAN_PDD_RX_FIFO_FILTERS_96 0xBU          /**< 96 Rx FIFO Filters */
#define CAN_PDD_RX_FIFO_FILTERS_104 0xCU         /**< 104 Rx FIFO Filters */
#define CAN_PDD_RX_FIFO_FILTERS_112 0xDU         /**< 112 Rx FIFO Filters */
#define CAN_PDD_RX_FIFO_FILTERS_120 0xEU         /**< 120 Rx FIFO Filters */
#define CAN_PDD_RX_FIFO_FILTERS_128 0xFU         /**< 128 Rx FIFO Filters */

/* Mailboxes reception priority constants (for SetReceptionPriority macro). */
#define CAN_PDD_START_FIFO_THEN_MAILBOXES 0U     /**< Matching starts from Rx FIFO and continues on Mailboxes */
#define CAN_PDD_START_MAILBOXES_THEN_FIFO 0x40000U /**< Matching starts from Mailboxes and continues on Rx FIFO */

/* Remote request priority constants (for SetRemoteRequestPriority macro). */
#define CAN_PDD_GENERATE_REMOTE_RESPONSE_FRAME 0U /**< Remote Response Frame is generated */
#define CAN_PDD_STORE_REMOTE_REQUEST_FRANE 0x20000U /**< Remote Request Frame is stored */

/* Rx message buffer codes constants (for SetMessageBufferCode,
   GetMessageBufferCode macros) */
#define CAN_PDD_MB_RX_NOT_ACTIVE 0U              /**< MB is not active */
#define CAN_PDD_MB_RX_FULL 0x2U                  /**< MB is full */
#define CAN_PDD_MB_RX_EMPTY 0x4U                 /**< MB is active and empty */
#define CAN_PDD_MB_RX_OVERRUN 0x6U               /**< MB is being overwritten into a full buffer */
#define CAN_PDD_MB_RX_BUSY 0x1U                  /**< FlexCAN is updating the contents of the MB */
#define CAN_PDD_MB_RX_RANSWER 0xAU               /**< A frame was configured to recognize a Remote Request Frame and transmit a ResponseFrame in return */

/* Tx message buffer codes constants (for SetMessageBufferCode,
   GetMessageBufferCode macros) */
#define CAN_PDD_MB_TX_NOT_ACTIVE 0x8U            /**< MB is not active */
#define CAN_PDD_MB_TX_ABORT 0x9U                 /**< MB is aborted */
#define CAN_PDD_MB_TX_DATA_FRAME 0xCU            /**< MB is a Tx Data Frame */
#define CAN_PDD_MB_TX_REMOTE_FRAME 0xCU          /**< MB is a Tx Remote Request Frame */
#define CAN_PDD_MB_TX_RESPONSE_FRAME 0xAU        /**< MB is a Tx Response Frame from an incoming Remote Request Frame */

/* Type of message buffer ID constants (for SetMessageBufferID,
   GetMessageBufferID macros). */
#define CAN_PDD_BUFFER_ID_EXT 0U                 /**< Extended frame format */
#define CAN_PDD_BUFFER_ID_STD 0x1U               /**< Standard frame format */


/* ----------------------------------------------------------------------------
   -- EnableDevice
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables CAN device.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state of device.
 */
#define CAN_PDD_EnableDevice(peripheralBase, State) ( \
    ((State) == PDD_ENABLE) ? ( \
      CAN_MCR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)CAN_MCR_MDIS_MASK)) : ( \
      CAN_MCR_REG(peripheralBase) |= \
       (uint32_t)((uint32_t)0x1U << CAN_MCR_MDIS_SHIFT)) \
  )

/* ----------------------------------------------------------------------------
   -- EnterFreezeMode
   ---------------------------------------------------------------------------- */

/**
 * Enter CAN device to freeze mode.
 * @param peripheralBase Peripheral base address.
 */
#define CAN_PDD_EnterFreezeMode(peripheralBase) ( \
    (CAN_MCR_REG(peripheralBase) |= \
     CAN_MCR_FRZ_MASK), \
    (CAN_MCR_REG(peripheralBase) |= \
     CAN_MCR_HALT_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- ExitFreezeMode
   ---------------------------------------------------------------------------- */

/**
 * Return CAN device from freeze mode.
 * @param peripheralBase Peripheral base address.
 */
#define CAN_PDD_ExitFreezeMode(peripheralBase) ( \
    (CAN_MCR_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)CAN_MCR_HALT_MASK)), \
    (CAN_MCR_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)CAN_MCR_FRZ_MASK)) \
  )

/* ----------------------------------------------------------------------------
   -- EnableRxFIFO
   ---------------------------------------------------------------------------- */

/**
 * Enables or disables receive FIFO.
 * @param peripheralBase Peripheral base address.
 * @param State Parameter specifying if Rx FIFO will be enabled or disabled.
 */
#define CAN_PDD_EnableRxFIFO(peripheralBase, State) ( \
    CAN_MCR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(CAN_MCR_REG(peripheralBase) & (uint32_t)(~(uint32_t)CAN_MCR_RFEN_MASK))) | ( \
      (uint32_t)((uint32_t)(State) << CAN_MCR_RFEN_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- GetReadyStatus
   ---------------------------------------------------------------------------- */

/**
 * Returns the ready state of CAN device.
 * @param peripheralBase Peripheral base address.
 */
#define CAN_PDD_GetReadyStatus(peripheralBase) ( \
    (uint32_t)(CAN_MCR_REG(peripheralBase) & CAN_MCR_NOTRDY_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- EnableWakeUpInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables the WakeUp interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define CAN_PDD_EnableWakeUpInterrupt(peripheralBase) ( \
    CAN_MCR_REG(peripheralBase) |= \
     CAN_MCR_WAKMSK_MASK \
  )

/* ----------------------------------------------------------------------------
   -- DisableWakeUpInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables the WakeUp interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define CAN_PDD_DisableWakeUpInterrupt(peripheralBase) ( \
    CAN_MCR_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)CAN_MCR_WAKMSK_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- SetSoftReset
   ---------------------------------------------------------------------------- */

/**
 * Enters to the soft reset mode.
 * @param peripheralBase Peripheral base address.
 */
#define CAN_PDD_SetSoftReset(peripheralBase) ( \
    CAN_MCR_REG(peripheralBase) |= \
     CAN_MCR_SOFTRST_MASK \
  )

/* ----------------------------------------------------------------------------
   -- GetSoftResetState
   ---------------------------------------------------------------------------- */

/**
 * Returns the soft reset operation state of CAN device.
 * @param peripheralBase Peripheral base address.
 */
#define CAN_PDD_GetSoftResetState(peripheralBase) ( \
    (uint32_t)(CAN_MCR_REG(peripheralBase) & CAN_MCR_SOFTRST_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetFreezeAck
   ---------------------------------------------------------------------------- */

/**
 * Returns the acknowledge of freeze operation state.
 * @param peripheralBase Peripheral base address.
 */
#define CAN_PDD_GetFreezeAck(peripheralBase) ( \
    (uint32_t)(CAN_MCR_REG(peripheralBase) & CAN_MCR_FRZACK_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- EnableSupervizorMode
   ---------------------------------------------------------------------------- */

/**
 * Enables or disables supervisor mode.
 * @param peripheralBase Peripheral base address.
 * @param State Parameter specifying if supervisor mode will be enabled or
 *        disabled.
 */
#define CAN_PDD_EnableSupervizorMode(peripheralBase, State) ( \
    CAN_MCR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(CAN_MCR_REG(peripheralBase) & (uint32_t)(~(uint32_t)CAN_MCR_SUPV_MASK))) | ( \
      (uint32_t)((uint32_t)(State) << CAN_MCR_SUPV_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableSelfWakeUp
   ---------------------------------------------------------------------------- */

/**
 * Enables or disables self wake up feature.
 * @param peripheralBase Peripheral base address.
 * @param State Parameter specifying if self wake up will be enabled or disabled.
 */
#define CAN_PDD_EnableSelfWakeUp(peripheralBase, State) ( \
    CAN_MCR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(CAN_MCR_REG(peripheralBase) & (uint32_t)(~(uint32_t)CAN_MCR_SLFWAK_MASK))) | ( \
      (uint32_t)((uint32_t)(State) << CAN_MCR_SLFWAK_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableWarningInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables the warning interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define CAN_PDD_EnableWarningInterrupt(peripheralBase) ( \
    CAN_MCR_REG(peripheralBase) |= \
     CAN_MCR_WRNEN_MASK \
  )

/* ----------------------------------------------------------------------------
   -- DisableWarningInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables the warning interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define CAN_PDD_DisableWarningInterrupt(peripheralBase) ( \
    CAN_MCR_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)CAN_MCR_WRNEN_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetLowPowerAcknowledge
   ---------------------------------------------------------------------------- */

/**
 * Returns the low power state of CAN device.
 * @param peripheralBase Peripheral base address.
 */
#define CAN_PDD_GetLowPowerAcknowledge(peripheralBase) ( \
    (uint32_t)(CAN_MCR_REG(peripheralBase) & CAN_MCR_LPMACK_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- EnableSelfReception
   ---------------------------------------------------------------------------- */

/**
 * Enables or disables self reception.
 * @param peripheralBase Peripheral base address.
 * @param State Parameter specifying if self reception will be enabled or
 *        disabled.
 */
#define CAN_PDD_EnableSelfReception(peripheralBase, State) ( \
    ((State) == PDD_ENABLE) ? ( \
      CAN_MCR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)CAN_MCR_SRXDIS_MASK)) : ( \
      CAN_MCR_REG(peripheralBase) |= \
       (uint32_t)((uint32_t)0x1U << CAN_MCR_SRXDIS_SHIFT)) \
  )

/* ----------------------------------------------------------------------------
   -- EnableInvidualRxMasking
   ---------------------------------------------------------------------------- */

/**
 * Enables or disables invidual Rx masking.
 * @param peripheralBase Peripheral base address.
 * @param State Parameter specifying if invidual Rx masking will be enabled or
 *        disabled.
 */
#define CAN_PDD_EnableInvidualRxMasking(peripheralBase, State) ( \
    CAN_MCR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(CAN_MCR_REG(peripheralBase) & (uint32_t)(~(uint32_t)CAN_MCR_IRMQ_MASK))) | ( \
      (uint32_t)((uint32_t)(State) << CAN_MCR_IRMQ_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableLocalPriority
   ---------------------------------------------------------------------------- */

/**
 * Enables or disables local priority.
 * @param peripheralBase Peripheral base address.
 * @param State Parameter specifying if local priority will be enabled or
 *        disabled.
 */
#define CAN_PDD_EnableLocalPriority(peripheralBase, State) ( \
    CAN_MCR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(CAN_MCR_REG(peripheralBase) & (uint32_t)(~(uint32_t)CAN_MCR_LPRIOEN_MASK))) | ( \
      (uint32_t)((uint32_t)(State) << CAN_MCR_LPRIOEN_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableAbort
   ---------------------------------------------------------------------------- */

/**
 * Enables or disables abort a pending transmission.
 * @param peripheralBase Peripheral base address.
 * @param State Parameter specifying if abort a pending transmission will be
 *        enabled or disabled.
 */
#define CAN_PDD_EnableAbort(peripheralBase, State) ( \
    CAN_MCR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(CAN_MCR_REG(peripheralBase) & (uint32_t)(~(uint32_t)CAN_MCR_AEN_MASK))) | ( \
      (uint32_t)((uint32_t)(State) << CAN_MCR_AEN_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- SetRxFIFOAcceptanceIDMode
   ---------------------------------------------------------------------------- */

/**
 * Sets the Rx FIFO acceptance ID mode.
 * @param peripheralBase Peripheral base address.
 * @param Mode Rx FIFO acceptance ID mode value[0..3].
 */
#define CAN_PDD_SetRxFIFOAcceptanceIDMode(peripheralBase, Mode) ( \
    CAN_MCR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(CAN_MCR_REG(peripheralBase) & (uint32_t)(~(uint32_t)CAN_MCR_IDAM_MASK))) | ( \
      (uint32_t)((uint32_t)(Mode) << CAN_MCR_IDAM_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- SetNumberOfLastMessageBuffer
   ---------------------------------------------------------------------------- */

/**
 * Sets the number of the last Message Buffer that will take part in the
 * matching and arbitration processes.
 * @param peripheralBase Peripheral base address.
 * @param Value Number of the last Message Buffer value[0..127].
 */
#define CAN_PDD_SetNumberOfLastMessageBuffer(peripheralBase, Value) ( \
    CAN_MCR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(CAN_MCR_REG(peripheralBase) & (uint32_t)(~(uint32_t)CAN_MCR_MAXMB_MASK))) | ( \
      (uint32_t)(Value))) \
  )

/* ----------------------------------------------------------------------------
   -- SetPrescalerValue
   ---------------------------------------------------------------------------- */

/**
 * Sets the value of the prescaler division factor.
 * @param peripheralBase Peripheral base address.
 * @param Value Prescaler division factor value[0..255].
 */
#define CAN_PDD_SetPrescalerValue(peripheralBase, Value) ( \
    CAN_CTRL1_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(CAN_CTRL1_REG(peripheralBase) & (uint32_t)(~(uint32_t)CAN_CTRL1_PRESDIV_MASK))) | ( \
      (uint32_t)((uint32_t)(Value) << CAN_CTRL1_PRESDIV_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- SetResyncJumpWidthValue
   ---------------------------------------------------------------------------- */

/**
 * Sets the value of the resync jump width.
 * @param peripheralBase Peripheral base address.
 * @param Value Resync jump width value[0..3].
 */
#define CAN_PDD_SetResyncJumpWidthValue(peripheralBase, Value) ( \
    CAN_CTRL1_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(CAN_CTRL1_REG(peripheralBase) & (uint32_t)(~(uint32_t)CAN_CTRL1_RJW_MASK))) | ( \
      (uint32_t)((uint32_t)(Value) << CAN_CTRL1_RJW_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- SetPhaseSegment1Value
   ---------------------------------------------------------------------------- */

/**
 * Sets the value of phase segment 1.
 * @param peripheralBase Peripheral base address.
 * @param Value Phase segment 1 value[0..7].
 */
#define CAN_PDD_SetPhaseSegment1Value(peripheralBase, Value) ( \
    CAN_CTRL1_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(CAN_CTRL1_REG(peripheralBase) & (uint32_t)(~(uint32_t)CAN_CTRL1_PSEG1_MASK))) | ( \
      (uint32_t)((uint32_t)(Value) << CAN_CTRL1_PSEG1_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- SetPhaseSegment2Value
   ---------------------------------------------------------------------------- */

/**
 * Sets the value of phase segment 2.
 * @param peripheralBase Peripheral base address.
 * @param Value Phase segment 2 value[0..7].
 */
#define CAN_PDD_SetPhaseSegment2Value(peripheralBase, Value) ( \
    CAN_CTRL1_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(CAN_CTRL1_REG(peripheralBase) & (uint32_t)(~(uint32_t)CAN_CTRL1_PSEG2_MASK))) | ( \
      (uint32_t)((uint32_t)(Value) << CAN_CTRL1_PSEG2_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableBusOffInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables the Bus Off interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define CAN_PDD_EnableBusOffInterrupt(peripheralBase) ( \
    CAN_CTRL1_REG(peripheralBase) |= \
     CAN_CTRL1_BOFFMSK_MASK \
  )

/* ----------------------------------------------------------------------------
   -- DisableBusOffInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables the Bus Off interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define CAN_PDD_DisableBusOffInterrupt(peripheralBase) ( \
    CAN_CTRL1_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)CAN_CTRL1_BOFFMSK_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- EnableErrorInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables the Error interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define CAN_PDD_EnableErrorInterrupt(peripheralBase) ( \
    CAN_CTRL1_REG(peripheralBase) |= \
     CAN_CTRL1_ERRMSK_MASK \
  )

/* ----------------------------------------------------------------------------
   -- DisableErrorInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables the Error interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define CAN_PDD_DisableErrorInterrupt(peripheralBase) ( \
    CAN_CTRL1_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)CAN_CTRL1_ERRMSK_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- SetClockSource
   ---------------------------------------------------------------------------- */

/**
 * Set CAN Engine Clock Source.
 * @param peripheralBase Peripheral base address.
 * @param ClkSource Parameter specifying clock source of CAN Engine.
 */
#define CAN_PDD_SetClockSource(peripheralBase, ClkSource) ( \
    CAN_CTRL1_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(CAN_CTRL1_REG(peripheralBase) & (uint32_t)(~(uint32_t)CAN_CTRL1_CLKSRC_MASK))) | ( \
      (uint32_t)(ClkSource))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableLoopBack
   ---------------------------------------------------------------------------- */

/**
 * Enables or disables Loop Back mode.
 * @param peripheralBase Peripheral base address.
 * @param State Parameter specifying if Loop Back will be enabled or disabled.
 */
#define CAN_PDD_EnableLoopBack(peripheralBase, State) ( \
    CAN_CTRL1_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(CAN_CTRL1_REG(peripheralBase) & (uint32_t)(~(uint32_t)CAN_CTRL1_LPB_MASK))) | ( \
      (uint32_t)((uint32_t)(State) << CAN_CTRL1_LPB_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableWarningInterruptsMask
   ---------------------------------------------------------------------------- */

/**
 * Enables Warning Interrupts Mask defined by mask parameter.
 * @param peripheralBase Peripheral base address.
 * @param Mask Mask of interrupt requests.
 */
#define CAN_PDD_EnableWarningInterruptsMask(peripheralBase, Mask) ( \
    CAN_CTRL1_REG(peripheralBase) |= \
     (uint32_t)(Mask) \
  )

/* ----------------------------------------------------------------------------
   -- DisableWarningInterruptsMask
   ---------------------------------------------------------------------------- */

/**
 * Disables Warning Interrupts Mask defined by mask parameter.
 * @param peripheralBase Peripheral base address.
 * @param Mask Mask of interrupt requests.
 */
#define CAN_PDD_DisableWarningInterruptsMask(peripheralBase, Mask) ( \
    CAN_CTRL1_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)(Mask)) \
  )

/* ----------------------------------------------------------------------------
   -- SetBitSampling
   ---------------------------------------------------------------------------- */

/**
 * Set CAN bit sampling at the Rx input.
 * @param peripheralBase Peripheral base address.
 * @param Sampling Parameter specifying bit sampling at the Rx input.
 */
#define CAN_PDD_SetBitSampling(peripheralBase, Sampling) ( \
    CAN_CTRL1_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(CAN_CTRL1_REG(peripheralBase) & (uint32_t)(~(uint32_t)CAN_CTRL1_SMP_MASK))) | ( \
      (uint32_t)(Sampling))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableBusOffRecovery
   ---------------------------------------------------------------------------- */

/**
 * Enables or disables Bus Off Recovery.
 * @param peripheralBase Peripheral base address.
 * @param State Parameter specifying if Bus Off Recovery will be enabled or
 *        disabled.
 */
#define CAN_PDD_EnableBusOffRecovery(peripheralBase, State) ( \
    ((State) == PDD_ENABLE) ? ( \
      CAN_CTRL1_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)CAN_CTRL1_BOFFREC_MASK)) : ( \
      CAN_CTRL1_REG(peripheralBase) |= \
       (uint32_t)((uint32_t)0x1U << CAN_CTRL1_BOFFREC_SHIFT)) \
  )

/* ----------------------------------------------------------------------------
   -- EnableTimerSynchronization
   ---------------------------------------------------------------------------- */

/**
 * Enables or disables Timer Synchronization.
 * @param peripheralBase Peripheral base address.
 * @param State Parameter specifying if Timer Synchronization will be enabled or
 *        disabled.
 */
#define CAN_PDD_EnableTimerSynchronization(peripheralBase, State) ( \
    CAN_CTRL1_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(CAN_CTRL1_REG(peripheralBase) & (uint32_t)(~(uint32_t)CAN_CTRL1_TSYN_MASK))) | ( \
      (uint32_t)((uint32_t)(State) << CAN_CTRL1_TSYN_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableLowestBufferTransmitFirst
   ---------------------------------------------------------------------------- */

/**
 * Enables or disables Lowest Buffer Transmit First.
 * @param peripheralBase Peripheral base address.
 * @param State Parameter specifying if Lowest Buffer Transmit First will be
 *        enabled or disabled.
 */
#define CAN_PDD_EnableLowestBufferTransmitFirst(peripheralBase, State) ( \
    CAN_CTRL1_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(CAN_CTRL1_REG(peripheralBase) & (uint32_t)(~(uint32_t)CAN_CTRL1_LBUF_MASK))) | ( \
      (uint32_t)((uint32_t)(State) << CAN_CTRL1_LBUF_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableListenOnlyMode
   ---------------------------------------------------------------------------- */

/**
 * Enables or disables Listen Only Mode.
 * @param peripheralBase Peripheral base address.
 * @param State Parameter specifying if Listen Only Mode will be enabled or
 *        disabled.
 */
#define CAN_PDD_EnableListenOnlyMode(peripheralBase, State) ( \
    CAN_CTRL1_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(CAN_CTRL1_REG(peripheralBase) & (uint32_t)(~(uint32_t)CAN_CTRL1_LOM_MASK))) | ( \
      (uint32_t)((uint32_t)(State) << CAN_CTRL1_LOM_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- SetPropagationSegment
   ---------------------------------------------------------------------------- */

/**
 * Sets the value of Propagation Segment.
 * @param peripheralBase Peripheral base address.
 * @param Value Propagation Segment value[0..7].
 */
#define CAN_PDD_SetPropagationSegment(peripheralBase, Value) ( \
    CAN_CTRL1_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(CAN_CTRL1_REG(peripheralBase) & (uint32_t)(~(uint32_t)CAN_CTRL1_PROPSEG_MASK))) | ( \
      (uint32_t)(Value))) \
  )

/* ----------------------------------------------------------------------------
   -- SetTimerValue
   ---------------------------------------------------------------------------- */

/**
 * Sets the value of Timer.
 * @param peripheralBase Peripheral base address.
 * @param Value Value of the Timer, value[0..65535].
 */
#define CAN_PDD_SetTimerValue(peripheralBase, Value) ( \
    CAN_TIMER_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(CAN_TIMER_REG(peripheralBase) & (uint32_t)(~(uint32_t)CAN_TIMER_TIMER_MASK))) | ( \
      (uint32_t)(Value))) \
  )

/* ----------------------------------------------------------------------------
   -- GetTimerValue
   ---------------------------------------------------------------------------- */

/**
 * Returns the value of Timer.
 * @param peripheralBase Peripheral base address.
 */
#define CAN_PDD_GetTimerValue(peripheralBase) ( \
    (uint16_t)(CAN_TIMER_REG(peripheralBase) & CAN_TIMER_TIMER_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- SetGlobalAcceptanceMask
   ---------------------------------------------------------------------------- */

/**
 * Sets the value of Global Acceptance Mask for mailboxes.
 * @param peripheralBase Peripheral base address.
 * @param AccMask Global Acceptance Mask value[0..0x1FFFFFFF].
 */
#define CAN_PDD_SetGlobalAcceptanceMask(peripheralBase, AccMask) ( \
    CAN_RXMGMASK_REG(peripheralBase) = \
     (uint32_t)(AccMask) \
  )

/* ----------------------------------------------------------------------------
   -- GetGlobalAcceptanceMask
   ---------------------------------------------------------------------------- */

/**
 * Returns the value of Global Acceptance Mask.
 * @param peripheralBase Peripheral base address.
 */
#define CAN_PDD_GetGlobalAcceptanceMask(peripheralBase) ( \
    CAN_RXMGMASK_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- SetAcceptanceMask14
   ---------------------------------------------------------------------------- */

/**
 * Sets the value of Acceptance Mask for message buffer 14.
 * @param peripheralBase Peripheral base address.
 * @param AccMask Acceptance Mask for message bugger 14 value[0..0x1FFFFFFF].
 */
#define CAN_PDD_SetAcceptanceMask14(peripheralBase, AccMask) ( \
    CAN_RX14MASK_REG(peripheralBase) = \
     (uint32_t)(AccMask) \
  )

/* ----------------------------------------------------------------------------
   -- GetAcceptanceMask14
   ---------------------------------------------------------------------------- */

/**
 * Returns the value of Acceptance Mask for message buffer 14.
 * @param peripheralBase Peripheral base address.
 */
#define CAN_PDD_GetAcceptanceMask14(peripheralBase) ( \
    CAN_RX14MASK_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- SetAcceptanceMask15
   ---------------------------------------------------------------------------- */

/**
 * Sets the value of Acceptance Mask for message buffer 15.
 * @param peripheralBase Peripheral base address.
 * @param AccMask Acceptance Mask for message bugger 15 value[0..0x1FFFFFFF].
 */
#define CAN_PDD_SetAcceptanceMask15(peripheralBase, AccMask) ( \
    CAN_RX15MASK_REG(peripheralBase) = \
     (uint32_t)(AccMask) \
  )

/* ----------------------------------------------------------------------------
   -- GetAcceptanceMask15
   ---------------------------------------------------------------------------- */

/**
 * Returns the value of Acceptance Mask for message buffer 15.
 * @param peripheralBase Peripheral base address.
 */
#define CAN_PDD_GetAcceptanceMask15(peripheralBase) ( \
    CAN_RX15MASK_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- SetTxErrorCounter
   ---------------------------------------------------------------------------- */

/**
 * Sets the value of the transmit error counter.
 * @param peripheralBase Peripheral base address.
 * @param Value Transmit error counter value[0..255].
 */
#define CAN_PDD_SetTxErrorCounter(peripheralBase, Value) ( \
    CAN_ECR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(CAN_ECR_REG(peripheralBase) & (uint32_t)(~(uint32_t)CAN_ECR_TXERRCNT_MASK))) | ( \
      (uint32_t)(Value))) \
  )

/* ----------------------------------------------------------------------------
   -- GetTxErrorCounter
   ---------------------------------------------------------------------------- */

/**
 * Returns the value of the transmit error counter register.
 * @param peripheralBase Peripheral base address.
 */
#define CAN_PDD_GetTxErrorCounter(peripheralBase) ( \
    (uint8_t)(CAN_ECR_REG(peripheralBase) & CAN_ECR_TXERRCNT_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- SetRxErrorCounter
   ---------------------------------------------------------------------------- */

/**
 * Sets the value of the receive error counter.
 * @param peripheralBase Peripheral base address.
 * @param Value Receive error counter value[0..255].
 */
#define CAN_PDD_SetRxErrorCounter(peripheralBase, Value) ( \
    CAN_ECR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(CAN_ECR_REG(peripheralBase) & (uint32_t)(~(uint32_t)CAN_ECR_RXERRCNT_MASK))) | ( \
      (uint32_t)((uint32_t)(Value) << CAN_ECR_RXERRCNT_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- GetRxErrorCounter
   ---------------------------------------------------------------------------- */

/**
 * Returns the value of the receive error counter register.
 * @param peripheralBase Peripheral base address.
 */
#define CAN_PDD_GetRxErrorCounter(peripheralBase) ( \
    (uint8_t)(( \
     (uint32_t)(CAN_ECR_REG(peripheralBase) & CAN_ECR_RXERRCNT_MASK)) >> ( \
     CAN_ECR_RXERRCNT_SHIFT)) \
  )

/* ----------------------------------------------------------------------------
   -- GetStatusInterruptFlags1
   ---------------------------------------------------------------------------- */

/**
 * Returns the value of the status register 1.
 * @param peripheralBase Peripheral base address.
 * @return Use constants from group "Status flags constants (for
 *         GetStatusInterruptFlags1, ClearStatusInterruptFlags1 macros)." for processing return
 *         value.
 */
#define CAN_PDD_GetStatusInterruptFlags1(peripheralBase) ( \
    CAN_ESR1_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- ClearStatusInterruptFlags1
   ---------------------------------------------------------------------------- */

/**
 * Clears interrupt flags of interrupts specified by Mask.
 * @param peripheralBase Peripheral base address.
 * @param Mask Mask of interrupt clear requests. Use constants from group
 *        "Status flags constants (for GetStatusInterruptFlags1,
 *        ClearStatusInterruptFlags1 macros).".
 */
#define CAN_PDD_ClearStatusInterruptFlags1(peripheralBase, Mask) ( \
    CAN_ESR1_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       CAN_ESR1_REG(peripheralBase)) & ( \
       (uint32_t)(~(uint32_t)(( \
        CAN_ESR1_WAKINT_MASK) | (( \
        CAN_ESR1_ERRINT_MASK) | (( \
        CAN_ESR1_BOFFINT_MASK) | (( \
        CAN_ESR1_RWRNINT_MASK) | ( \
        CAN_ESR1_TWRNINT_MASK))))))))) | ( \
      (uint32_t)(Mask))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableMessageBufferInterruptMask1
   ---------------------------------------------------------------------------- */

/**
 * Enables message buffer[0..31] interrupt requests defined by mask parameter.
 * @param peripheralBase Peripheral base address.
 * @param Mask Message buffer interrupt mask value[0..0xFFFFFFFF].
 */
#define CAN_PDD_EnableMessageBufferInterruptMask1(peripheralBase, Mask) ( \
    CAN_IMASK1_REG(peripheralBase) |= \
     (uint32_t)(Mask) \
  )

/* ----------------------------------------------------------------------------
   -- DisableMessageBufferInterruptMask1
   ---------------------------------------------------------------------------- */

/**
 * Disables message buffer interrupt requests defined by mask parameter.
 * @param peripheralBase Peripheral base address.
 * @param Mask Message buffer interrupt mask value[0..0xFFFFFFFF].
 */
#define CAN_PDD_DisableMessageBufferInterruptMask1(peripheralBase, Mask) ( \
    CAN_IMASK1_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)(Mask)) \
  )

/* ----------------------------------------------------------------------------
   -- EnableMessageBufferInterruptMask2
   ---------------------------------------------------------------------------- */

/**
 * Enables message buffer[32..63] interrupt requests defined by mask parameter.
 * @param peripheralBase Peripheral base address.
 * @param Mask Message buffer interrupt mask value[0..0xFFFFFFFF].
 */
#define CAN_PDD_EnableMessageBufferInterruptMask2(peripheralBase, Mask) ( \
    CAN_IMASK2_REG(peripheralBase) |= \
     (uint32_t)(Mask) \
  )

/* ----------------------------------------------------------------------------
   -- DisableMessageBufferInterruptMask2
   ---------------------------------------------------------------------------- */

/**
 * Disables message buffer interrupt requests defined by mask parameter.
 * @param peripheralBase Peripheral base address.
 * @param Mask Message buffer interrupt mask value[0..0xFFFFFFFF].
 */
#define CAN_PDD_DisableMessageBufferInterruptMask2(peripheralBase, Mask) ( \
    CAN_IMASK2_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)(Mask)) \
  )

/* ----------------------------------------------------------------------------
   -- GetMessageBufferInterruptFlag1
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of Message Buffer Interrupt flag register 1.
 * @param peripheralBase Peripheral base address.
 */
#define CAN_PDD_GetMessageBufferInterruptFlag1(peripheralBase) ( \
    CAN_IFLAG1_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- ClearMessageBufferInterruptFlagMask1
   ---------------------------------------------------------------------------- */

/**
 * Clear Message Buffer Interrupt Flag defined by mask parameter.
 * @param peripheralBase Peripheral base address.
 * @param Mask Mask of interrupt clear requests.
 */
#define CAN_PDD_ClearMessageBufferInterruptFlagMask1(peripheralBase, Mask) ( \
    CAN_IFLAG1_REG(peripheralBase) = \
     (uint32_t)(Mask) \
  )

/* ----------------------------------------------------------------------------
   -- GetMessageBufferInterruptFlag2
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of Message Buffer Interrupt flag register 2.
 * @param peripheralBase Peripheral base address.
 */
#define CAN_PDD_GetMessageBufferInterruptFlag2(peripheralBase) ( \
    CAN_IFLAG2_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- ClearMessageBufferInterruptFlagMask2
   ---------------------------------------------------------------------------- */

/**
 * Clear Message Buffer Interrupt Flag defined by mask parameter.
 * @param peripheralBase Peripheral base address.
 * @param Mask Mask of interrupt clear requests.
 */
#define CAN_PDD_ClearMessageBufferInterruptFlagMask2(peripheralBase, Mask) ( \
    CAN_IFLAG2_REG(peripheralBase) = \
     (uint32_t)(Mask) \
  )

/* ----------------------------------------------------------------------------
   -- EnableWriteAccessToMemory
   ---------------------------------------------------------------------------- */

/**
 * Enables or disables Write Access To Memory In Freeze Mode.
 * @param peripheralBase Peripheral base address.
 * @param State Parameter specifying if Write Access To Memory In Freeze Mode
 *        will be enabled or disabled.
 */
#define CAN_PDD_EnableWriteAccessToMemory(peripheralBase, State) ( \
    CAN_CTRL2_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       CAN_CTRL2_REG(peripheralBase)) & (( \
       (uint32_t)(~(uint32_t)CAN_CTRL2_WRMFRZ_MASK)) & ( \
       (uint32_t)(~(uint32_t)0x80000000U))))) | ( \
      (uint32_t)((uint32_t)(State) << CAN_CTRL2_WRMFRZ_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- SetNumberRxFIFOFilter
   ---------------------------------------------------------------------------- */

/**
 * Sets the value of Number Rx FIFO filter.
 * @param peripheralBase Peripheral base address.
 * @param Value Number of Rx FIFO filter[0..3].
 */
#define CAN_PDD_SetNumberRxFIFOFilter(peripheralBase, Value) ( \
    CAN_CTRL2_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       CAN_CTRL2_REG(peripheralBase)) & (( \
       (uint32_t)(~(uint32_t)CAN_CTRL2_RFFN_MASK)) & ( \
       (uint32_t)(~(uint32_t)0x80000000U))))) | ( \
      (uint32_t)((uint32_t)(Value) << CAN_CTRL2_RFFN_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- SetTxArbitrationStartDelay
   ---------------------------------------------------------------------------- */

/**
 * Sets the value of Tx Arbitration Start Delay.
 * @param peripheralBase Peripheral base address.
 * @param Value Value[0..31] of Tx Arbitration Start Delay.
 */
#define CAN_PDD_SetTxArbitrationStartDelay(peripheralBase, Value) ( \
    CAN_CTRL2_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       CAN_CTRL2_REG(peripheralBase)) & (( \
       (uint32_t)(~(uint32_t)CAN_CTRL2_TASD_MASK)) & ( \
       (uint32_t)(~(uint32_t)0x80000000U))))) | ( \
      (uint32_t)((uint32_t)(Value) << CAN_CTRL2_TASD_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- SetReceptionPriority
   ---------------------------------------------------------------------------- */

/**
 * Sets mailboxes reception priority.
 * @param peripheralBase Peripheral base address.
 * @param Priority Parameter specifying mailboxes reception priority.
 */
#define CAN_PDD_SetReceptionPriority(peripheralBase, Priority) ( \
    CAN_CTRL2_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       CAN_CTRL2_REG(peripheralBase)) & (( \
       (uint32_t)(~(uint32_t)CAN_CTRL2_MRP_MASK)) & ( \
       (uint32_t)(~(uint32_t)0x80000000U))))) | ( \
      (uint32_t)(Priority))) \
  )

/* ----------------------------------------------------------------------------
   -- SetRemoteRequestPriority
   ---------------------------------------------------------------------------- */

/**
 * Sets remote request priority.
 * @param peripheralBase Peripheral base address.
 * @param Priority Parameter specifying remote request priority.
 */
#define CAN_PDD_SetRemoteRequestPriority(peripheralBase, Priority) ( \
    CAN_CTRL2_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       CAN_CTRL2_REG(peripheralBase)) & (( \
       (uint32_t)(~(uint32_t)CAN_CTRL2_RRS_MASK)) & ( \
       (uint32_t)(~(uint32_t)0x80000000U))))) | ( \
      (uint32_t)(Priority))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableRTRComparison
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables the comparison of both Rx Mailbox filter's IDE and RTR bit
 * with their corresponding bitswithin the incoming frame.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state of Rx mailbox filter's.
 */
#define CAN_PDD_EnableRTRComparison(peripheralBase, State) ( \
    CAN_CTRL2_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       CAN_CTRL2_REG(peripheralBase)) & (( \
       (uint32_t)(~(uint32_t)CAN_CTRL2_EACEN_MASK)) & ( \
       (uint32_t)(~(uint32_t)0x80000000U))))) | ( \
      (uint32_t)((uint32_t)(State) << CAN_CTRL2_EACEN_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- GetErrorStatusRegister2
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of Error Status Register 2.
 * @param peripheralBase Peripheral base address.
 */
#define CAN_PDD_GetErrorStatusRegister2(peripheralBase) ( \
    CAN_ESR2_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- GetCRCRegister
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the CRC register.
 * @param peripheralBase Peripheral base address.
 */
#define CAN_PDD_GetCRCRegister(peripheralBase) ( \
    CAN_CRCR_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- SetGlobalRxFIFOMask
   ---------------------------------------------------------------------------- */

/**
 * Sets Global Rx FIFO Mask.
 * @param peripheralBase Peripheral base address.
 * @param Mask Global Rx FIFO mask value.
 */
#define CAN_PDD_SetGlobalRxFIFOMask(peripheralBase, Mask) ( \
    CAN_RXFGMASK_REG(peripheralBase) = \
     (uint32_t)(Mask) \
  )

/* ----------------------------------------------------------------------------
   -- GetRxFIFOInfoRegister
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the Rx FIFO Information Register.
 * @param peripheralBase Peripheral base address.
 */
#define CAN_PDD_GetRxFIFOInfoRegister(peripheralBase) ( \
    CAN_RXFIR_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- SetInvidualAcceptanceMask
   ---------------------------------------------------------------------------- */

/**
 * Sets value of invidual acceptance mask defined by Index parameter.
 * @param peripheralBase Peripheral base address.
 * @param Index Message buffer index.
 * @param AccMask Acceptance mask value.
 */
#define CAN_PDD_SetInvidualAcceptanceMask(peripheralBase, Index, AccMask) ( \
    CAN_RXIMR_REG(peripheralBase,(Index)) = \
     (uint32_t)(AccMask) \
  )

/* ----------------------------------------------------------------------------
   -- GetInvidualAcceptanceMask
   ---------------------------------------------------------------------------- */

/**
 * Returns the value Invidual Acceptance Mask Register.
 * @param peripheralBase Peripheral base address.
 * @param Index Message buffer index.
 */
#define CAN_PDD_GetInvidualAcceptanceMask(peripheralBase, Index) ( \
    CAN_RXIMR_REG(peripheralBase,(Index)) \
  )

/* ----------------------------------------------------------------------------
   -- SetMessageBufferCode
   ---------------------------------------------------------------------------- */

/**
 * Sets the message buffer code.
 * @param peripheralBase Peripheral base address.
 * @param Index Message buffer index.
 * @param Value Message buffer code value[0..15].
 */
#define CAN_PDD_SetMessageBufferCode(peripheralBase, Index, Value) ( \
    CAN_CS_REG(peripheralBase,(Index)) = \
     (uint32_t)(( \
      (uint32_t)(CAN_CS_REG(peripheralBase,(Index)) & (uint32_t)(~(uint32_t)CAN_CS_CODE_MASK))) | ( \
      (uint32_t)((uint32_t)(Value) << CAN_CS_CODE_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- GetMessageBufferCode
   ---------------------------------------------------------------------------- */

/**
 * Returns the value of message buffer code.
 * @param peripheralBase Peripheral base address.
 * @param Index Message buffer index.
 */
#define CAN_PDD_GetMessageBufferCode(peripheralBase, Index) ( \
    (uint8_t)(( \
     (uint32_t)(CAN_CS_REG(peripheralBase,(Index)) & CAN_CS_CODE_MASK)) >> ( \
     CAN_CS_CODE_SHIFT)) \
  )

/* ----------------------------------------------------------------------------
   -- SetMessageBufferDataLength
   ---------------------------------------------------------------------------- */

/**
 * Sets the message buffer data length.
 * @param peripheralBase Peripheral base address.
 * @param Index Message buffer index.
 * @param Value Message buffer code value[0..8].
 */
#define CAN_PDD_SetMessageBufferDataLength(peripheralBase, Index, Value) ( \
    CAN_CS_REG(peripheralBase,(Index)) = \
     (uint32_t)(( \
      (uint32_t)(CAN_CS_REG(peripheralBase,(Index)) & (uint32_t)(~(uint32_t)CAN_CS_DLC_MASK))) | ( \
      (uint32_t)((uint32_t)(Value) << CAN_CS_DLC_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- GetMessageBufferDataLength
   ---------------------------------------------------------------------------- */

/**
 * Returns the value of message buffer data length.
 * @param peripheralBase Peripheral base address.
 * @param Index Message buffer index.
 */
#define CAN_PDD_GetMessageBufferDataLength(peripheralBase, Index) ( \
    (uint8_t)(( \
     (uint32_t)(CAN_CS_REG(peripheralBase,(Index)) & CAN_CS_DLC_MASK)) >> ( \
     CAN_CS_DLC_SHIFT)) \
  )

/* ----------------------------------------------------------------------------
   -- SetMessageBufferTimeStamp
   ---------------------------------------------------------------------------- */

/**
 * Sets the message buffer message buffer TimeStamp.
 * @param peripheralBase Peripheral base address.
 * @param Index Message buffer index.
 * @param Value Message buffer code value[0..8].
 */
#define CAN_PDD_SetMessageBufferTimeStamp(peripheralBase, Index, Value) ( \
    CAN_CS_REG(peripheralBase,(Index)) = \
     (uint32_t)(( \
      (uint32_t)(( \
       CAN_CS_REG(peripheralBase,(Index))) & ( \
       (uint32_t)(~(uint32_t)CAN_CS_TIME_STAMP_MASK)))) | ( \
      (uint32_t)(Value))) \
  )

/* ----------------------------------------------------------------------------
   -- GetMessageBufferTimeStamp
   ---------------------------------------------------------------------------- */

/**
 * Returns the value of message buffer TimeStamp.
 * @param peripheralBase Peripheral base address.
 * @param Index Message buffer index.
 */
#define CAN_PDD_GetMessageBufferTimeStamp(peripheralBase, Index) ( \
    (uint16_t)(CAN_CS_REG(peripheralBase,(Index)) & CAN_CS_TIME_STAMP_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- EnableMessageBufferRTR
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables RTR of the message buffer.
 * @param peripheralBase Peripheral base address.
 * @param Index Message buffer index.
 * @param State Requested state of Remote Transmission Request bit.
 */
#define CAN_PDD_EnableMessageBufferRTR(peripheralBase, Index, State) ( \
    CAN_CS_REG(peripheralBase,(Index)) = \
     (uint32_t)(( \
      (uint32_t)(CAN_CS_REG(peripheralBase,(Index)) & (uint32_t)(~(uint32_t)CAN_CS_RTR_MASK))) | ( \
      (uint32_t)((uint32_t)(State) << CAN_CS_RTR_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- GetMessageBufferRTR
   ---------------------------------------------------------------------------- */

/**
 * Returns the value of RTR bit.
 * @param peripheralBase Peripheral base address.
 * @param Index Message buffer index.
 */
#define CAN_PDD_GetMessageBufferRTR(peripheralBase, Index) ( \
    (uint8_t)(( \
     (uint32_t)(CAN_CS_REG(peripheralBase,(Index)) & CAN_CS_RTR_MASK)) >> ( \
     CAN_CS_RTR_SHIFT)) \
  )

/* ----------------------------------------------------------------------------
   -- EnableMessageBufferSRR
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables SRR of the message buffer.
 * @param peripheralBase Peripheral base address.
 * @param Index Message buffer index.
 * @param State Requested state of Substitute Remote Request bit.
 */
#define CAN_PDD_EnableMessageBufferSRR(peripheralBase, Index, State) ( \
    CAN_CS_REG(peripheralBase,(Index)) = \
     (uint32_t)(( \
      (uint32_t)(CAN_CS_REG(peripheralBase,(Index)) & (uint32_t)(~(uint32_t)CAN_CS_SRR_MASK))) | ( \
      (uint32_t)((uint32_t)(State) << CAN_CS_SRR_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- GetMessageBufferSRR
   ---------------------------------------------------------------------------- */

/**
 * Returns the value of SRR bit.
 * @param peripheralBase Peripheral base address.
 * @param Index Message buffer index.
 */
#define CAN_PDD_GetMessageBufferSRR(peripheralBase, Index) ( \
    (uint8_t)(( \
     (uint32_t)(CAN_CS_REG(peripheralBase,(Index)) & CAN_CS_SRR_MASK)) >> ( \
     CAN_CS_SRR_SHIFT)) \
  )

/* ----------------------------------------------------------------------------
   -- EnableMessageBufferIDExt
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables extended ID of the message buffer.
 * @param peripheralBase Peripheral base address.
 * @param Index Message buffer index.
 * @param State Requested frame format.
 */
#define CAN_PDD_EnableMessageBufferIDExt(peripheralBase, Index, State) ( \
    CAN_CS_REG(peripheralBase,(Index)) = \
     (uint32_t)(( \
      (uint32_t)(CAN_CS_REG(peripheralBase,(Index)) & (uint32_t)(~(uint32_t)CAN_CS_IDE_MASK))) | ( \
      (uint32_t)((uint32_t)(State) << CAN_CS_IDE_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- GetMessageBufferIDExt
   ---------------------------------------------------------------------------- */

/**
 * Returns the value of ID extended bit.
 * @param peripheralBase Peripheral base address.
 * @param Index Message buffer index.
 */
#define CAN_PDD_GetMessageBufferIDExt(peripheralBase, Index) ( \
    (( \
      (uint8_t)(( \
       (uint32_t)(CAN_CS_REG(peripheralBase,(Index)) & CAN_CS_IDE_MASK)) >> ( \
       CAN_CS_IDE_SHIFT))) == ( \
      0U)) ? ( \
      PDD_DISABLE) : ( \
      PDD_ENABLE) \
  )

/* ----------------------------------------------------------------------------
   -- SetMessageBufferID
   ---------------------------------------------------------------------------- */

/**
 * Sets the value of message buffer ID.
 * @param peripheralBase Peripheral base address.
 * @param Index Message buffer index.
 * @param TypeID Requested ID format.
 * @param Value ID value.
 */
#define CAN_PDD_SetMessageBufferID(peripheralBase, Index, TypeID, Value) ( \
    ((TypeID) == CAN_PDD_BUFFER_ID_STD) ? ( \
      CAN_ID_REG(peripheralBase,(Index)) = \
       (uint32_t)(( \
        (uint32_t)(CAN_ID_REG(peripheralBase,(Index)) & (uint32_t)(~(uint32_t)CAN_ID_STD_MASK))) | ( \
        (uint32_t)((uint32_t)(Value) << CAN_ID_STD_SHIFT)))) : ( \
      CAN_ID_REG(peripheralBase,(Index)) = \
       (uint32_t)(( \
        (uint32_t)(( \
         CAN_ID_REG(peripheralBase,(Index))) & ( \
         (uint32_t)(~(uint32_t)(CAN_ID_STD_MASK | CAN_ID_EXT_MASK))))) | ( \
        (uint32_t)(Value)))) \
  )

/* ----------------------------------------------------------------------------
   -- GetMessageBufferID
   ---------------------------------------------------------------------------- */

/**
 * Returns the value ID of message buffer.
 * @param peripheralBase Peripheral base address.
 * @param Index Message buffer index.
 * @param TypeID Requested ID format.
 */
#define CAN_PDD_GetMessageBufferID(peripheralBase, Index, TypeID) ( \
    ((TypeID) == CAN_PDD_BUFFER_ID_STD) ? ( \
      (uint32_t)(( \
       (uint32_t)(CAN_ID_REG(peripheralBase,(Index)) & CAN_ID_STD_MASK)) >> ( \
       CAN_ID_STD_SHIFT))) : ( \
      (uint32_t)(( \
       CAN_ID_REG(peripheralBase,(Index))) & ( \
       (uint32_t)(CAN_ID_STD_MASK | CAN_ID_EXT_MASK)))) \
  )

/* ----------------------------------------------------------------------------
   -- SetMessageBufferWORD0
   ---------------------------------------------------------------------------- */

/**
 * Sets the message buffer message buffer data WORD0.
 * @param peripheralBase Peripheral base address.
 * @param Index Message buffer index.
 * @param Value Message buffer data value[0..0xFFFFFFFF].
 */
#define CAN_PDD_SetMessageBufferWORD0(peripheralBase, Index, Value) ( \
    CAN_WORD0_REG(peripheralBase,(Index)) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- GetMessageBufferWORD0
   ---------------------------------------------------------------------------- */

/**
 * Returns the value of message buffer data WORD0.
 * @param peripheralBase Peripheral base address.
 * @param Index Message buffer index.
 */
#define CAN_PDD_GetMessageBufferWORD0(peripheralBase, Index) ( \
    CAN_WORD0_REG(peripheralBase,(Index)) \
  )

/* ----------------------------------------------------------------------------
   -- SetMessageBufferWORD1
   ---------------------------------------------------------------------------- */

/**
 * Sets the message buffer message buffer data WORD1.
 * @param peripheralBase Peripheral base address.
 * @param Index Message buffer index.
 * @param Value Message buffer data value[0..0xFFFFFFFF].
 */
#define CAN_PDD_SetMessageBufferWORD1(peripheralBase, Index, Value) ( \
    CAN_WORD1_REG(peripheralBase,(Index)) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- GetMessageBufferWORD1
   ---------------------------------------------------------------------------- */

/**
 * Returns the value of message buffer data WORD1.
 * @param peripheralBase Peripheral base address.
 * @param Index Message buffer index.
 */
#define CAN_PDD_GetMessageBufferWORD1(peripheralBase, Index) ( \
    CAN_WORD1_REG(peripheralBase,(Index)) \
  )

/* ----------------------------------------------------------------------------
   -- SetMessageBufferData
   ---------------------------------------------------------------------------- */

/**
 * Sets the data field in the message buffer denominated by Index.
 * @param peripheralBase Peripheral base address.
 * @param Index Message buffer index.
 * @param ByteIndex Data byte index.
 * @param Value Data value.
 */
#define CAN_PDD_SetMessageBufferData(peripheralBase, Index, ByteIndex, Value) ( \
    ((uint8_t)((uint8_t)(ByteIndex) & 0xFCU) == 0U) ? ( \
      CAN_WORD0_REG(peripheralBase,(Index)) = \
       (uint32_t)(( \
        (uint32_t)(( \
         CAN_WORD0_REG(peripheralBase,(Index))) & ( \
         (uint32_t)(~(uint32_t)(( \
          (uint32_t)0xFFU) << ( \
          24U - (uint8_t)((uint8_t)((uint8_t)(ByteIndex) & 0x3U) << 3U))))))) | ( \
        (uint32_t)(( \
         (uint32_t)(Value)) << ( \
         24U - (uint8_t)((uint8_t)((uint8_t)(ByteIndex) & 0x3U) << 3U)))))) : ( \
      CAN_WORD1_REG(peripheralBase,(Index)) = \
       (uint32_t)(( \
        (uint32_t)(( \
         CAN_WORD1_REG(peripheralBase,(Index))) & ( \
         (uint32_t)(~(uint32_t)(( \
          (uint32_t)0xFFU) << ( \
          24U - (uint8_t)((uint8_t)((uint8_t)(ByteIndex) & 0x3U) << 3U))))))) | ( \
        (uint32_t)(( \
         (uint32_t)(Value)) << ( \
         24U - (uint8_t)((uint8_t)((uint8_t)(ByteIndex) & 0x3U) << 3U)))))) \
  )

/* ----------------------------------------------------------------------------
   -- GetMessageBufferData
   ---------------------------------------------------------------------------- */

/**
 * Gets the data field in the message buffer denominated by Index.
 * @param peripheralBase Peripheral base address.
 * @param Index Message buffer index.
 * @param ByteIndex Data byte index.
 */
#define CAN_PDD_GetMessageBufferData(peripheralBase, Index, ByteIndex) ( \
    ((uint8_t)((uint8_t)(ByteIndex) & 0xFCU) == 0U) ? ( \
      (uint8_t)(( \
       CAN_WORD0_REG(peripheralBase,(Index))) >> ( \
       24U - (uint8_t)((uint8_t)((uint8_t)(ByteIndex) & 0x3U) << 3U)))) : ( \
      (uint8_t)(( \
       CAN_WORD1_REG(peripheralBase,(Index))) >> ( \
       24U - (uint8_t)((uint8_t)((uint8_t)(ByteIndex) & 0x3U) << 3U)))) \
  )

/* ----------------------------------------------------------------------------
   -- SetMessageBufferLocalPrio
   ---------------------------------------------------------------------------- */

/**
 *  Sets the Local Priority Field within the message ID buffer denominated by
 * Index.
 * @param peripheralBase Peripheral base address.
 * @param Index Message buffer index.
 * @param Value Local priority value[0..7].
 */
#define CAN_PDD_SetMessageBufferLocalPrio(peripheralBase, Index, Value) ( \
    CAN_ID_REG(peripheralBase,(Index)) = \
     (uint32_t)(( \
      (uint32_t)(CAN_ID_REG(peripheralBase,(Index)) & (uint32_t)(~(uint32_t)CAN_ID_PRIO_MASK))) | ( \
      (uint32_t)((uint32_t)(Value) << CAN_ID_PRIO_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- GetMessageBufferLocalPrio
   ---------------------------------------------------------------------------- */

/**
 * Returns the value of Local priority.
 * @param peripheralBase Peripheral base address.
 * @param Index Message buffer index.
 */
#define CAN_PDD_GetMessageBufferLocalPrio(peripheralBase, Index) ( \
    (uint8_t)(( \
     (uint32_t)(CAN_ID_REG(peripheralBase,(Index)) & CAN_ID_PRIO_MASK)) >> ( \
     CAN_ID_PRIO_SHIFT)) \
  )

/* ----------------------------------------------------------------------------
   -- SetFIFOFilter
   ---------------------------------------------------------------------------- */

/**
 * Sets the filters for FIFO table, this table is located on unavailable MB
 * memory space.
 * @param peripheralBase Peripheral base address.
 * @param Index Message buffer index.
 * @param CS Value of CS register.
 * @param ID Value of ID register.
 * @param WORD0 Value of WORD0 register.
 * @param WORD1 Value of WORD1 register.
 */
#define CAN_PDD_SetFIFOFilter(peripheralBase, Index, CS, ID, WORD0, WORD1) ( \
    (CAN_CS_REG(peripheralBase,(Index)) = \
     (uint32_t)(CS)), \
    ((CAN_ID_REG(peripheralBase,(Index)) = \
     (uint32_t)(ID)), \
    ((CAN_WORD0_REG(peripheralBase,(Index)) = \
     (uint32_t)(WORD0)), \
    (CAN_WORD1_REG(peripheralBase,(Index)) = \
     (uint32_t)(WORD1)))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableDozeMode
   ---------------------------------------------------------------------------- */

/**
 * Enables or disables doze mode.
 * @param peripheralBase Peripheral base address.
 * @param State Parameter specifying if doze mode will be enabled or disabled.
 */
#define CAN_PDD_EnableDozeMode(peripheralBase, State) ( \
    CAN_MCR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(CAN_MCR_REG(peripheralBase) & (uint32_t)(~(uint32_t)CAN_MCR_DOZE_MASK))) | ( \
      (uint32_t)((uint32_t)(State) << CAN_MCR_DOZE_SHIFT))) \
  )
#endif  /* #if defined(CAN_PDD_H_) */

/* CAN_PDD.h, eof. */
