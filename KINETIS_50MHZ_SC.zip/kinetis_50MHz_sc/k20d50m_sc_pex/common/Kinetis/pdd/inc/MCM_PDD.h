/*
  PDD layer implementation for peripheral type MCM
  (C) 2010 Freescale, Inc. All rights reserved.

  This file is static and it is generated from API-Factory
*/

#if !defined(MCM_PDD_H_)
#define MCM_PDD_H_

/* ----------------------------------------------------------------------------
   -- Test if supported MCU is active
   ---------------------------------------------------------------------------- */

#if !defined(MCU_ACTIVE)
  // No MCU is active
  #error MCM PDD library: No derivative is active. Place proper #include with PDD memory map before including PDD library.
#elif \
      !defined(MCU_MKL04Z4) /* MCM */ && \
      !defined(MCU_MKL05Z4) /* MCM */ && \
      !defined(MCU_MKL14Z4) /* MCM */ && \
      !defined(MCU_MKL15Z4) /* MCM */ && \
      !defined(MCU_MKL24Z4) /* MCM */ && \
      !defined(MCU_MKL25Z4) /* MCM */
  // Unsupported MCU is active
  #error MCM PDD library: Unsupported derivative is active.
#endif

#include "PDD_Types.h"

/* ----------------------------------------------------------------------------
   -- Method symbol definitions
   ---------------------------------------------------------------------------- */

/* Crossbar master arbitration type */
#define MCM_PDD_FIXED_PRIORITY 0U                /**< Fixed-priority arbitration for the crossbar masters */
#define MCM_PDD_ROUND_ROBIN 0x200U               /**< Round-robin arbitration for the crossbar masters */


/* ----------------------------------------------------------------------------
   -- DisableStallingFlashController
   ---------------------------------------------------------------------------- */

/**
 * Disable stalling flash controller.
 * @param peripheralBase Peripheral base address.
 */
#define MCM_PDD_DisableStallingFlashController(peripheralBase) ( \
    MCM_PLACR_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)MCM_PLACR_ESFC_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- EnableStallingFlashController
   ---------------------------------------------------------------------------- */

/**
 * Enable stalling flash controller.
 * @param peripheralBase Peripheral base address.
 */
#define MCM_PDD_EnableStallingFlashController(peripheralBase) ( \
    MCM_PLACR_REG(peripheralBase) |= \
     MCM_PLACR_ESFC_MASK \
  )

/* ----------------------------------------------------------------------------
   -- DisableFlashControllerSpeculation
   ---------------------------------------------------------------------------- */

/**
 * Disable flash controller speculation.
 * @param peripheralBase Peripheral base address.
 */
#define MCM_PDD_DisableFlashControllerSpeculation(peripheralBase) ( \
    MCM_PLACR_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)MCM_PLACR_DFCS_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- EnableFlashControllerSpeculation
   ---------------------------------------------------------------------------- */

/**
 * Enable flash controller speculation.
 * @param peripheralBase Peripheral base address.
 */
#define MCM_PDD_EnableFlashControllerSpeculation(peripheralBase) ( \
    MCM_PLACR_REG(peripheralBase) |= \
     MCM_PLACR_DFCS_MASK \
  )

/* ----------------------------------------------------------------------------
   -- DisableFlashDataSpeculation
   ---------------------------------------------------------------------------- */

/**
 * Disable flash data speculation.
 * @param peripheralBase Peripheral base address.
 */
#define MCM_PDD_DisableFlashDataSpeculation(peripheralBase) ( \
    MCM_PLACR_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)MCM_PLACR_EFDS_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- EnableFlashDataSpeculation
   ---------------------------------------------------------------------------- */

/**
 * Enable flash data speculation.
 * @param peripheralBase Peripheral base address.
 */
#define MCM_PDD_EnableFlashDataSpeculation(peripheralBase) ( \
    MCM_PLACR_REG(peripheralBase) |= \
     MCM_PLACR_EFDS_MASK \
  )

/* ----------------------------------------------------------------------------
   -- EnableFlashControllerCache
   ---------------------------------------------------------------------------- */

/**
 * Enable flash controllerCache.
 * @param peripheralBase Peripheral base address.
 */
#define MCM_PDD_EnableFlashControllerCache(peripheralBase) ( \
    MCM_PLACR_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)MCM_PLACR_DFCC_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- DisableFlashControllerCache
   ---------------------------------------------------------------------------- */

/**
 * Disable flash controllerCache.
 * @param peripheralBase Peripheral base address.
 */
#define MCM_PDD_DisableFlashControllerCache(peripheralBase) ( \
    MCM_PLACR_REG(peripheralBase) |= \
     MCM_PLACR_DFCC_MASK \
  )

/* ----------------------------------------------------------------------------
   -- EnableFlashControllerInstructionCaching
   ---------------------------------------------------------------------------- */

/**
 * Enable flash controller instruction caching.
 * @param peripheralBase Peripheral base address.
 */
#define MCM_PDD_EnableFlashControllerInstructionCaching(peripheralBase) ( \
    MCM_PLACR_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)MCM_PLACR_DFCIC_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- DisableFlashControllerInstructionCaching
   ---------------------------------------------------------------------------- */

/**
 * Disable flash controller instruction caching.
 * @param peripheralBase Peripheral base address.
 */
#define MCM_PDD_DisableFlashControllerInstructionCaching(peripheralBase) ( \
    MCM_PLACR_REG(peripheralBase) |= \
     MCM_PLACR_DFCIC_MASK \
  )

/* ----------------------------------------------------------------------------
   -- EnableFlashControllerDataCaching
   ---------------------------------------------------------------------------- */

/**
 * Enable flash controller data caching.
 * @param peripheralBase Peripheral base address.
 */
#define MCM_PDD_EnableFlashControllerDataCaching(peripheralBase) ( \
    MCM_PLACR_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)MCM_PLACR_DFCDA_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- DisableFlashControllerDataCaching
   ---------------------------------------------------------------------------- */

/**
 * Disable flash controller data caching.
 * @param peripheralBase Peripheral base address.
 */
#define MCM_PDD_DisableFlashControllerDataCaching(peripheralBase) ( \
    MCM_PLACR_REG(peripheralBase) |= \
     MCM_PLACR_DFCDA_MASK \
  )

/* ----------------------------------------------------------------------------
   -- InvalidateFlashCache
   ---------------------------------------------------------------------------- */

/**
 * Invalidates flash cache.
 * @param peripheralBase Peripheral base address.
 */
#define MCM_PDD_InvalidateFlashCache(peripheralBase) ( \
    MCM_PLACR_REG(peripheralBase) |= \
     MCM_PLACR_CFCC_MASK \
  )

/* ----------------------------------------------------------------------------
   -- SetCrossbarMastersArbitrationType
   ---------------------------------------------------------------------------- */

/**
 * Selects arbitration type for crossbar masters.
 * @param peripheralBase Peripheral base address.
 * @param State Crossbar masters arbitration type.
 */
#define MCM_PDD_SetCrossbarMastersArbitrationType(peripheralBase, State) ( \
    MCM_PLACR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(MCM_PLACR_REG(peripheralBase) & (uint32_t)(~(uint32_t)MCM_PLACR_ARB_MASK))) | ( \
      (uint32_t)(State))) \
  )
#endif  /* #if defined(MCM_PDD_H_) */

/* MCM_PDD.h, eof. */
