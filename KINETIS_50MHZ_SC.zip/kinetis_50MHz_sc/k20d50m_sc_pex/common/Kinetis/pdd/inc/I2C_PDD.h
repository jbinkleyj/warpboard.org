/*
  PDD layer implementation for peripheral type I2C
  (C) 2010 Freescale, Inc. All rights reserved.

  This file is static and it is generated from API-Factory
*/

#if !defined(I2C_PDD_H_)
#define I2C_PDD_H_

/* ----------------------------------------------------------------------------
   -- Test if supported MCU is active
   ---------------------------------------------------------------------------- */

#if !defined(MCU_ACTIVE)
  // No MCU is active
  #error I2C PDD library: No derivative is active. Place proper #include with PDD memory map before including PDD library.
#elif \
      !defined(MCU_MK10D10) /* I2C0, I2C1 */ && \
      !defined(MCU_MK10D5) /* I2C0 */ && \
      !defined(MCU_MK10D7) /* I2C0, I2C1 */ && \
      !defined(MCU_MK10F12) /* I2C0, I2C1 */ && \
      !defined(MCU_MK10DZ10) /* I2C0, I2C1 */ && \
      !defined(MCU_MK11D5) /* I2C0, I2C1 */ && \
      !defined(MCU_MK12D5) /* I2C0, I2C1 */ && \
      !defined(MCU_MK20D10) /* I2C0, I2C1 */ && \
      !defined(MCU_MK20D5) /* I2C0 */ && \
      !defined(MCU_MK20D7) /* I2C0, I2C1 */ && \
      !defined(MCU_MK20F12) /* I2C0, I2C1 */ && \
      !defined(MCU_MK20DZ10) /* I2C0, I2C1 */ && \
      !defined(MCU_MK21D5) /* I2C0, I2C1 */ && \
      !defined(MCU_MK22D5) /* I2C0, I2C1 */ && \
      !defined(MCU_MK30D10) /* I2C0, I2C1 */ && \
      !defined(MCU_MK30D7) /* I2C0, I2C1 */ && \
      !defined(MCU_MK30DZ10) /* I2C0, I2C1 */ && \
      !defined(MCU_MK40D10) /* I2C0, I2C1 */ && \
      !defined(MCU_MK40D7) /* I2C0, I2C1 */ && \
      !defined(MCU_MK40DZ10) /* I2C0, I2C1 */ && \
      !defined(MCU_MK40X256VMD100) /* I2C0, I2C1 */ && \
      !defined(MCU_MK50D10) /* I2C0, I2C1 */ && \
      !defined(MCU_MK50D7) /* I2C0, I2C1 */ && \
      !defined(MCU_MK50DZ10) /* I2C0, I2C1 */ && \
      !defined(MCU_MK51D10) /* I2C0, I2C1 */ && \
      !defined(MCU_MK51D7) /* I2C0, I2C1 */ && \
      !defined(MCU_MK51DZ10) /* I2C0, I2C1 */ && \
      !defined(MCU_MK52D10) /* I2C0, I2C1 */ && \
      !defined(MCU_MK52DZ10) /* I2C0, I2C1 */ && \
      !defined(MCU_MK53D10) /* I2C0, I2C1 */ && \
      !defined(MCU_MK53DZ10) /* I2C0, I2C1 */ && \
      !defined(MCU_MK60D10) /* I2C0, I2C1 */ && \
      !defined(MCU_MK60F12) /* I2C0, I2C1 */ && \
      !defined(MCU_MK60F15) /* I2C0, I2C1 */ && \
      !defined(MCU_MK60DZ10) /* I2C0, I2C1 */ && \
      !defined(MCU_MK60N512VMD100) /* I2C0, I2C1 */ && \
      !defined(MCU_MK61F12) /* I2C0, I2C1 */ && \
      !defined(MCU_MK61F15) /* I2C0, I2C1 */ && \
      !defined(MCU_MK70F12) /* I2C0, I2C1 */ && \
      !defined(MCU_MK70F15) /* I2C0, I2C1 */ && \
      !defined(MCU_MKL04Z4) /* I2C0 */ && \
      !defined(MCU_MKL05Z4) /* I2C0 */ && \
      !defined(MCU_MKL14Z4) /* I2C0, I2C1 */ && \
      !defined(MCU_MKL15Z4) /* I2C0, I2C1 */ && \
      !defined(MCU_MKL24Z4) /* I2C0, I2C1 */ && \
      !defined(MCU_MKL25Z4) /* I2C0, I2C1 */ && \
      !defined(MCU_PCK20L4) /* I2C0 */
  // Unsupported MCU is active
  #error I2C PDD library: Unsupported derivative is active.
#endif

#include "PDD_Types.h"

/* ----------------------------------------------------------------------------
   -- Method symbol definitions
   ---------------------------------------------------------------------------- */

/* Status flags constants (for ReadStatusReg, GetInterruptFlags,
   ClearInterruptFlags macros). */
#define I2C_PDD_RX_ACKNOWLEDGE I2C_S_RXAK_MASK   /**< Receive acknowledge. */
#define I2C_PDD_INTERRUPT_FLAG I2C_S_IICIF_MASK  /**< Interrupt flag. */
#define I2C_PDD_SLAVE_TRANSMIT I2C_S_SRW_MASK    /**< Slave read/write request. */
#define I2C_PDD_RANGE_ADDRESS_MATCH I2C_S_RAM_MASK /**< Range address match. */
#define I2C_PDD_ARBIT_LOST I2C_S_ARBL_MASK       /**< Arbitration lost. */
#define I2C_PDD_BUS_IS_BUSY I2C_S_BUSY_MASK      /**< Bus busy - set when a START signal is detected. */
#define I2C_PDD_ADDRESSED_AS_SLAVE I2C_S_IAAS_MASK /**< Addressed as a slave. */
#define I2C_PDD_TX_COMPLETE I2C_S_TCF_MASK       /**< Transfer complete flag. */

/* SCL timeout flags constants (for GetSCLTimeoutInterruptFlags,
   ClearSCLTimeoutInterruptFlags macros). */
#define I2C_PDD_SCL_LOW_TIMEOUT I2C_SMB_SLTF_MASK /**< SCL low timeout flag. */
#define I2C_PDD_SCL_HI_AND_SDA_HI_TIMEOUT I2C_SMB_SHTF1_MASK /**< SCL high timeout flag - sets when SCL and SDA are held high more than clock × LoValue / 512. */
#define I2C_PDD_SCL_HI_AND_SDA_LOW_TIMEOUT I2C_SMB_SHTF2_MASK /**< SCL high timeout flag - sets when SCL is held high and SDA is held low more than clock × LoValue/512. */

/* Status flags constants. */
#define I2C_PDD_BUS_STOP_FLAG I2C_FLT_STOPF_MASK /**< Stop detected on I2C bus */

/* Frequency multiplier constants (for SetFrequencyMultiplier macro). */
#define I2C_PDD_FREQUENCY_MUL_1 0U               /**< Multiplier factor = 1 */
#define I2C_PDD_FREQUENCY_MUL_2 0x1U             /**< Multiplier factor = 2 */
#define I2C_PDD_FREQUENCY_MUL_4 0x2U             /**< Multiplier factor = 4 */

/* Master mode constants (for MasterMode, GetMasterMode macros). */
#define I2C_PDD_MASTER_MODE 0x20U                /**< Master mode. */
#define I2C_PDD_SLAVE_MODE 0U                    /**< Slave mode. */

/* Transmit mode constants (for SetTransmitMode, GetTransmitMode macros). */
#define I2C_PDD_TX_DIRECTION 0x10U               /**< SDA pin set as output. */
#define I2C_PDD_RX_DIRECTION 0U                  /**< SDA pin set as input. */

/* BUS status constants (for GetBusStatus macro). */
#define I2C_PDD_BUS_IDLE 0U                      /**< Bus is idle. */
#define I2C_PDD_BUS_BUSY 0x20U                   /**< Bus is busy. */

/* Fast SMBus Acknowledge constants (for GetFastSmBusAcknowledge macro). */
#define I2C_PDD_ACK_FOLLOWING_RX_DATA 0U         /**< ACK or NACK is sent on the following receiving data byte. */
#define I2C_PDD_ACK_AFTER_RX_DATA 0x80U          /**< ACK or NACK is sent after receiving a data byte. */

/* Clock source constants (for SetSCLTimeoutBusClockSource macro). */
#define I2C_PDD_BUS_CLOCK 0x10U                  /**< Bus clock frequency */
#define I2C_PDD_BUS_CLOCK_DIV64 0U               /**< Bus clock / 64 frequency */


/* ----------------------------------------------------------------------------
   -- SetSlaveAddress7bits
   ---------------------------------------------------------------------------- */

/**
 * Writes to the address register and set address length to 7 bits.
 * @param peripheralBase Peripheral base address.
 * @param AddrValue Slave address value[0..127].
 */
#define I2C_PDD_SetSlaveAddress7bits(peripheralBase, AddrValue) ( \
    (I2C_A1_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(I2C_A1_REG(peripheralBase) & (uint8_t)(~(uint8_t)I2C_A1_AD_MASK))) | ( \
      (uint8_t)((uint8_t)(AddrValue) << I2C_A1_AD_SHIFT)))), \
    (I2C_C2_REG(peripheralBase) &= \
     (uint8_t)(~(uint8_t)I2C_C2_ADEXT_MASK)) \
  )

/* ----------------------------------------------------------------------------
   -- SetSlaveAddress10bits
   ---------------------------------------------------------------------------- */

/**
 * Writes to the address register and set address length to 10 bits.
 * @param peripheralBase Peripheral base address.
 * @param AddrValue Slave address value[0..1023].
 */
#define I2C_PDD_SetSlaveAddress10bits(peripheralBase, AddrValue) ( \
    (I2C_A1_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(I2C_A1_REG(peripheralBase) & (uint8_t)(~(uint8_t)I2C_A1_AD_MASK))) | ( \
      (uint8_t)((uint8_t)((uint16_t)(AddrValue) & 0x7FU) << I2C_A1_AD_SHIFT)))), \
    (I2C_C2_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(I2C_C2_REG(peripheralBase) & (uint8_t)(~(uint8_t)I2C_C2_AD_MASK))) | (( \
      (uint8_t)((uint16_t)(AddrValue) >> 7U)) | ( \
      I2C_C2_ADEXT_MASK)))) \
  )

/* ----------------------------------------------------------------------------
   -- SetFrequencyDivider
   ---------------------------------------------------------------------------- */

/**
 * Sets the prescaler to configure the I2C clock for the bit-rate selection.
 * @param peripheralBase Peripheral base address.
 * @param FreqDividerValue Frequency divider value[0..63].
 */
#define I2C_PDD_SetFrequencyDivider(peripheralBase, FreqDividerValue) ( \
    I2C_F_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(I2C_F_REG(peripheralBase) & (uint8_t)(~(uint8_t)I2C_F_ICR_MASK))) | ( \
      (uint8_t)(FreqDividerValue))) \
  )

/* ----------------------------------------------------------------------------
   -- SetFrequencyMultiplier
   ---------------------------------------------------------------------------- */

/**
 * Sets the factor, what is used along with frequency divider to generate the
 * I2C baud rate.
 * @param peripheralBase Peripheral base address.
 * @param FreqMultiplierValue Frequency multiplier value[0..2].
 */
#define I2C_PDD_SetFrequencyMultiplier(peripheralBase, FreqMultiplierValue) ( \
    I2C_F_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(I2C_F_REG(peripheralBase) & (uint8_t)(~(uint8_t)I2C_F_MULT_MASK))) | ( \
      (uint8_t)((uint8_t)(FreqMultiplierValue) << I2C_F_MULT_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableDevice
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables I2C device.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state of device.
 */
#define I2C_PDD_EnableDevice(peripheralBase, State) ( \
    I2C_C1_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(I2C_C1_REG(peripheralBase) & (uint8_t)(~(uint8_t)I2C_C1_IICEN_MASK))) | ( \
      (uint8_t)((uint8_t)(State) << I2C_C1_IICEN_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables the I2C interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define I2C_PDD_EnableInterrupt(peripheralBase) ( \
    I2C_C1_REG(peripheralBase) |= \
     I2C_C1_IICIE_MASK \
  )

/* ----------------------------------------------------------------------------
   -- DisableInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables the I2C interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define I2C_PDD_DisableInterrupt(peripheralBase) ( \
    I2C_C1_REG(peripheralBase) &= \
     (uint8_t)(~(uint8_t)I2C_C1_IICIE_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- SetMasterMode
   ---------------------------------------------------------------------------- */

/**
 * Puts the I2C to the master or slave mode.
 * @param peripheralBase Peripheral base address.
 * @param MasterMode I2C mode value. The user should use one from the enumerated
 *        values.
 */
#define I2C_PDD_SetMasterMode(peripheralBase, MasterMode) ( \
    I2C_C1_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(I2C_C1_REG(peripheralBase) & (uint8_t)(~(uint8_t)I2C_C1_MST_MASK))) | ( \
      (uint8_t)(MasterMode))) \
  )

/* ----------------------------------------------------------------------------
   -- GetMasterMode
   ---------------------------------------------------------------------------- */

/**
 * Returns the current operating mode.
 * @param peripheralBase Peripheral base address.
 */
#define I2C_PDD_GetMasterMode(peripheralBase) ( \
    (uint8_t)(I2C_C1_REG(peripheralBase) & I2C_C1_MST_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- SetTransmitMode
   ---------------------------------------------------------------------------- */

/**
 * Sets data pin to the output or input direction.
 * @param peripheralBase Peripheral base address.
 * @param TransmitMode Direction I2C pins. The user should use one from the
 *        enumerated values.
 */
#define I2C_PDD_SetTransmitMode(peripheralBase, TransmitMode) ( \
    I2C_C1_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(I2C_C1_REG(peripheralBase) & (uint8_t)(~(uint8_t)I2C_C1_TX_MASK))) | ( \
      (uint8_t)(TransmitMode))) \
  )

/* ----------------------------------------------------------------------------
   -- GetTransmitMode
   ---------------------------------------------------------------------------- */

/**
 * Returns the current direction mode.
 * @param peripheralBase Peripheral base address.
 */
#define I2C_PDD_GetTransmitMode(peripheralBase) ( \
    (uint8_t)(I2C_C1_REG(peripheralBase) & I2C_C1_TX_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- EnableTransmitAcknowledge
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables an acknowledge signal to be sent to the bus at the ninth
 * clock bit after receiving one byte of data.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state of acknowledge signal.
 */
#define I2C_PDD_EnableTransmitAcknowledge(peripheralBase, State) ( \
    ((State) == PDD_ENABLE) ? ( \
      I2C_C1_REG(peripheralBase) &= \
       (uint8_t)(~(uint8_t)I2C_C1_TXAK_MASK)) : ( \
      I2C_C1_REG(peripheralBase) |= \
       (uint8_t)((uint8_t)0x1U << I2C_C1_TXAK_SHIFT)) \
  )

/* ----------------------------------------------------------------------------
   -- RepeatStart
   ---------------------------------------------------------------------------- */

/**
 * Generates a repeated START condition.
 * @param peripheralBase Peripheral base address.
 */
#define I2C_PDD_RepeatStart(peripheralBase) ( \
    I2C_C1_REG(peripheralBase) |= \
     I2C_C1_RSTA_MASK \
  )

/* ----------------------------------------------------------------------------
   -- EnableWakeUp
   ---------------------------------------------------------------------------- */

/**
 * Enables or disables the wakeup function in stop3 mode.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state of wakeup function.
 */
#define I2C_PDD_EnableWakeUp(peripheralBase, State) ( \
    I2C_C1_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(I2C_C1_REG(peripheralBase) & (uint8_t)(~(uint8_t)I2C_C1_WUEN_MASK))) | ( \
      (uint8_t)((uint8_t)(State) << I2C_C1_WUEN_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableDmaRequest
   ---------------------------------------------------------------------------- */

/**
 * Enables or disables the DMA transfer.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state of DMA function.
 */
#define I2C_PDD_EnableDmaRequest(peripheralBase, State) ( \
    I2C_C1_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(I2C_C1_REG(peripheralBase) & (uint8_t)(~(uint8_t)I2C_C1_DMAEN_MASK))) | ( \
      (uint8_t)(State))) \
  )

/* ----------------------------------------------------------------------------
   -- ReadStatusReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the value of the status register.
 * @param peripheralBase Peripheral base address.
 * @return Use constants from group "Status flags constants (for ReadStatusReg,
 *         GetInterruptFlags, ClearInterruptFlags macros)." for processing return
 *         value.
 */
#define I2C_PDD_ReadStatusReg(peripheralBase) ( \
    I2C_S_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- GetBusStatus
   ---------------------------------------------------------------------------- */

/**
 * Returns status of the BUS.
 * @param peripheralBase Peripheral base address.
 */
#define I2C_PDD_GetBusStatus(peripheralBase) ( \
    (uint8_t)(I2C_S_REG(peripheralBase) & I2C_S_BUSY_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetInterruptFlags
   ---------------------------------------------------------------------------- */

/**
 * Returns a value that represents a mask of active (pending) interrupts.
 * @param peripheralBase Peripheral base address.
 * @return Use constants from group "Status flags constants (for ReadStatusReg,
 *         GetInterruptFlags, ClearInterruptFlags macros)." for processing return
 *         value.
 */
#define I2C_PDD_GetInterruptFlags(peripheralBase) ( \
    (uint8_t)(( \
     I2C_S_REG(peripheralBase)) & ( \
     (uint8_t)(( \
      I2C_S_TCF_MASK) | (( \
      I2C_S_IICIF_MASK) | (( \
      I2C_S_RAM_MASK) | (( \
      I2C_S_ARBL_MASK) | ( \
      I2C_S_IAAS_MASK))))))) \
  )

/* ----------------------------------------------------------------------------
   -- ClearInterruptFlags
   ---------------------------------------------------------------------------- */

/**
 * Clears interrupt flags of interrupts specified by Mask.
 * @param peripheralBase Peripheral base address.
 * @param Mask Mask of interrupt clear requests. Use constants from group
 *        "Status flags constants (for ReadStatusReg, GetInterruptFlags,
 *        ClearInterruptFlags macros).".
 */
#define I2C_PDD_ClearInterruptFlags(peripheralBase, Mask) ( \
    I2C_S_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(( \
       I2C_S_REG(peripheralBase)) & (( \
       (uint8_t)(~(uint8_t)I2C_S_IICIF_MASK)) & ( \
       (uint8_t)(~(uint8_t)I2C_S_ARBL_MASK))))) | ( \
      (uint8_t)(Mask))) \
  )

/* ----------------------------------------------------------------------------
   -- ReadDataReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the data register.
 * @param peripheralBase Peripheral base address.
 */
#define I2C_PDD_ReadDataReg(peripheralBase) ( \
    I2C_D_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteDataReg
   ---------------------------------------------------------------------------- */

/**
 * Writes data to the data register.
 * @param peripheralBase Peripheral base address.
 * @param Data Data value.
 */
#define I2C_PDD_WriteDataReg(peripheralBase, Data) ( \
    I2C_D_REG(peripheralBase) = \
     (uint8_t)(Data) \
  )

/* ----------------------------------------------------------------------------
   -- EnableGeneralCallAddress
   ---------------------------------------------------------------------------- */

/**
 * Enables or disables general call address.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state of general call address function.
 */
#define I2C_PDD_EnableGeneralCallAddress(peripheralBase, State) ( \
    I2C_C2_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(I2C_C2_REG(peripheralBase) & (uint8_t)(~(uint8_t)I2C_C2_GCAEN_MASK))) | ( \
      (uint8_t)((uint8_t)(State) << I2C_C2_GCAEN_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- SetPadsNormalDriveMode
   ---------------------------------------------------------------------------- */

/**
 * Sets control the drive capability of the I2C pads to normal drive mode.
 * @param peripheralBase Peripheral base address.
 */
#define I2C_PDD_SetPadsNormalDriveMode(peripheralBase) ( \
    I2C_C2_REG(peripheralBase) &= \
     (uint8_t)(~(uint8_t)I2C_C2_HDRS_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- SetPadsHighDriveMode
   ---------------------------------------------------------------------------- */

/**
 * Sets control the drive capability of the I2C pads to high drive mode.
 * @param peripheralBase Peripheral base address.
 */
#define I2C_PDD_SetPadsHighDriveMode(peripheralBase) ( \
    I2C_C2_REG(peripheralBase) |= \
     I2C_C2_HDRS_MASK \
  )

/* ----------------------------------------------------------------------------
   -- EnableRangeAddressMatch
   ---------------------------------------------------------------------------- */

/**
 * Enables or disables range address matching.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state of range address matching function.
 */
#define I2C_PDD_EnableRangeAddressMatch(peripheralBase, State) ( \
    I2C_C2_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(I2C_C2_REG(peripheralBase) & (uint8_t)(~(uint8_t)I2C_C2_RMEN_MASK))) | ( \
      (uint8_t)((uint8_t)(State) << I2C_C2_RMEN_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- SetInputGlitchFilter
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MKL04Z4)) || (defined(MCU_MKL05Z4)) || (defined(MCU_MKL14Z4)) || (defined(MCU_MKL15Z4)) || (defined(MCU_MKL24Z4)) || (defined(MCU_MKL25Z4)))
/**
 * Sets the programming controls for the width of glitch (in terms of bus clock
 * cycles) the filter must absorb.
 * @param peripheralBase Peripheral base address.
 * @param FilterFactorValue Input glitch filter value[0..31].
 */
  #define I2C_PDD_SetInputGlitchFilter(peripheralBase, FilterFactorValue) ( \
      I2C_FLT_REG(peripheralBase) = \
       (uint8_t)(( \
        (uint8_t)(( \
         I2C_FLT_REG(peripheralBase)) & (( \
         (uint8_t)(~(uint8_t)I2C_FLT_FLT_MASK)) & ( \
         (uint8_t)(~(uint8_t)I2C_FLT_STOPF_MASK))))) | ( \
        (uint8_t)(FilterFactorValue))) \
    )
#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_PCK20L4)) */
/**
 * Sets the programming controls for the width of glitch (in terms of bus clock
 * cycles) the filter must absorb.
 * @param peripheralBase Peripheral base address.
 * @param FilterFactorValue Input glitch filter value[0..31].
 */
  #define I2C_PDD_SetInputGlitchFilter(peripheralBase, FilterFactorValue) ( \
      I2C_FLT_REG(peripheralBase) = \
       (uint8_t)(( \
        (uint8_t)(I2C_FLT_REG(peripheralBase) & (uint8_t)(~(uint8_t)I2C_FLT_FLT_MASK))) | ( \
        (uint8_t)(FilterFactorValue))) \
    )
#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_PCK20L4)) */

/* ----------------------------------------------------------------------------
   -- SetRangeAddress
   ---------------------------------------------------------------------------- */

/**
 * Sets the range slave address.
 * @param peripheralBase Peripheral base address.
 * @param RangeAddressValue Range Address value[0..127].
 */
#define I2C_PDD_SetRangeAddress(peripheralBase, RangeAddressValue) ( \
    I2C_RA_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(I2C_RA_REG(peripheralBase) & (uint8_t)(~(uint8_t)I2C_RA_RAD_MASK))) | ( \
      (uint8_t)((uint8_t)(RangeAddressValue) << I2C_RA_RAD_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableFastSmBusNackAck
   ---------------------------------------------------------------------------- */

/**
 * Enables or disables fast SMBus NACK/ACK.
 * @param peripheralBase Peripheral base address.
 * @param State Parameter specifying if SMBus alert response will be enabled or
 *        disabled.
 */
#define I2C_PDD_EnableFastSmBusNackAck(peripheralBase, State) ( \
    I2C_SMB_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(( \
       I2C_SMB_REG(peripheralBase)) & (( \
       (uint8_t)(~(uint8_t)I2C_SMB_FACK_MASK)) & (( \
       (uint8_t)(~(uint8_t)I2C_SMB_SHTF2_MASK)) & ( \
       (uint8_t)(~(uint8_t)I2C_SMB_SLTF_MASK)))))) | ( \
      (uint8_t)((uint8_t)(State) << I2C_SMB_FACK_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- GetFastSmBusAcknowledge
   ---------------------------------------------------------------------------- */

/**
 * Fast NACK/ACK enable bit.
 * @param peripheralBase Peripheral base address.
 */
#define I2C_PDD_GetFastSmBusAcknowledge(peripheralBase) ( \
    (uint8_t)(I2C_SMB_REG(peripheralBase) & I2C_SMB_FACK_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- EnableSmBusAlertResponseAddress
   ---------------------------------------------------------------------------- */

/**
 * Enables or disables SMBus alert response address.
 * @param peripheralBase Peripheral base address.
 * @param State Parameter specifying if SMBus alert response will be enabled or
 *        disabled.
 */
#define I2C_PDD_EnableSmBusAlertResponseAddress(peripheralBase, State) ( \
    I2C_SMB_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(( \
       I2C_SMB_REG(peripheralBase)) & (( \
       (uint8_t)(~(uint8_t)I2C_SMB_ALERTEN_MASK)) & (( \
       (uint8_t)(~(uint8_t)I2C_SMB_SHTF2_MASK)) & ( \
       (uint8_t)(~(uint8_t)I2C_SMB_SLTF_MASK)))))) | ( \
      (uint8_t)((uint8_t)(State) << I2C_SMB_ALERTEN_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableSecondI2CAddress
   ---------------------------------------------------------------------------- */

/**
 * Enables or disables SMBus device default address.
 * @param peripheralBase Peripheral base address.
 * @param State Parameter specifying if SMBus device default address will be
 *        enabled or disabled.
 */
#define I2C_PDD_EnableSecondI2CAddress(peripheralBase, State) ( \
    I2C_SMB_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(( \
       I2C_SMB_REG(peripheralBase)) & (( \
       (uint8_t)(~(uint8_t)I2C_SMB_SIICAEN_MASK)) & (( \
       (uint8_t)(~(uint8_t)I2C_SMB_SHTF2_MASK)) & ( \
       (uint8_t)(~(uint8_t)I2C_SMB_SLTF_MASK)))))) | ( \
      (uint8_t)((uint8_t)(State) << I2C_SMB_SIICAEN_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- SetSCLTimeoutBusClockSource
   ---------------------------------------------------------------------------- */

/**
 * Sets clock source of the timeout counter to Bus clock or Bus clock/64
 * frequency.
 * @param peripheralBase Peripheral base address.
 * @param ClockSource SCL timeout BUS clock source value. The user should use
 *        one from the enumerated values.
 */
#define I2C_PDD_SetSCLTimeoutBusClockSource(peripheralBase, ClockSource) ( \
    I2C_SMB_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(( \
       I2C_SMB_REG(peripheralBase)) & (( \
       (uint8_t)(~(uint8_t)I2C_SMB_TCKSEL_MASK)) & (( \
       (uint8_t)(~(uint8_t)I2C_SMB_SHTF2_MASK)) & ( \
       (uint8_t)(~(uint8_t)I2C_SMB_SLTF_MASK)))))) | ( \
      (uint8_t)(ClockSource))) \
  )

/* ----------------------------------------------------------------------------
   -- GetSCLTimeoutInterruptFlags
   ---------------------------------------------------------------------------- */

/**
 * Returns a value that represents a mask of active (pending) interrupts.
 * @param peripheralBase Peripheral base address.
 * @return Use constants from group "SCL timeout flags constants (for
 *         GetSCLTimeoutInterruptFlags, ClearSCLTimeoutInterruptFlags macros)." for
 *         processing return value.
 */
#define I2C_PDD_GetSCLTimeoutInterruptFlags(peripheralBase) ( \
    (uint8_t)(( \
     I2C_SMB_REG(peripheralBase)) & ( \
     (uint8_t)(I2C_SMB_SLTF_MASK | (I2C_SMB_SHTF1_MASK | I2C_SMB_SHTF2_MASK)))) \
  )

/* ----------------------------------------------------------------------------
   -- ClearSCLTimeoutInterruptFlags
   ---------------------------------------------------------------------------- */

/**
 * Clears interrupt flags of interrupts specified by Mask.
 * @param peripheralBase Peripheral base address.
 * @param Mask Mask of interrupt clear requests. Use constants from group "SCL
 *        timeout flags constants (for GetSCLTimeoutInterruptFlags,
 *        ClearSCLTimeoutInterruptFlags macros).".
 */
#define I2C_PDD_ClearSCLTimeoutInterruptFlags(peripheralBase, Mask) ( \
    I2C_SMB_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(( \
       I2C_SMB_REG(peripheralBase)) & ( \
       (uint8_t)(~(uint8_t)(I2C_SMB_SLTF_MASK | I2C_SMB_SHTF2_MASK))))) | ( \
      (uint8_t)(Mask))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableSCLTimeoutInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables SCL high and SDA low timeout interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define I2C_PDD_EnableSCLTimeoutInterrupt(peripheralBase) ( \
    I2C_SMB_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(I2C_SMB_REG(peripheralBase) | I2C_SMB_SHTF2IE_MASK)) & (( \
      (uint8_t)(~(uint8_t)I2C_SMB_SHTF2_MASK)) & ( \
      (uint8_t)(~(uint8_t)I2C_SMB_SLTF_MASK)))) \
  )

/* ----------------------------------------------------------------------------
   -- DisableSCLTimeoutInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables SCL high and SDA low timeout interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define I2C_PDD_DisableSCLTimeoutInterrupt(peripheralBase) ( \
    I2C_SMB_REG(peripheralBase) &= \
     (uint8_t)(( \
      (uint8_t)(~(uint8_t)I2C_SMB_SHTF2IE_MASK)) & (( \
      (uint8_t)(~(uint8_t)I2C_SMB_SHTF2_MASK)) & ( \
      (uint8_t)(~(uint8_t)I2C_SMB_SLTF_MASK)))) \
  )

/* ----------------------------------------------------------------------------
   -- SetSMBusSlaveAddress
   ---------------------------------------------------------------------------- */

/**
 * Sets SMBus address to the address register.
 * @param peripheralBase Peripheral base address.
 * @param SMBusSlaveAddrValue SMBus slave address value[0..127].
 */
#define I2C_PDD_SetSMBusSlaveAddress(peripheralBase, SMBusSlaveAddrValue) ( \
    I2C_A2_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(I2C_A2_REG(peripheralBase) & (uint8_t)(~(uint8_t)I2C_A2_SAD_MASK))) | ( \
      (uint8_t)((uint8_t)(SMBusSlaveAddrValue) << I2C_A2_SAD_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- SetSCLLowTimeout
   ---------------------------------------------------------------------------- */

/**
 * Sets SCL low timeout value that determines the timeout period of SCL low.
 * @param peripheralBase Peripheral base address.
 * @param SCLLowTimeoutValue SCL low timeout value[0..65535].
 */
#define I2C_PDD_SetSCLLowTimeout(peripheralBase, SCLLowTimeoutValue) ( \
    (I2C_SLTL_REG(peripheralBase) = \
     (uint8_t)(SCLLowTimeoutValue)), \
    (I2C_SLTH_REG(peripheralBase) = \
     (uint8_t)((uint16_t)(SCLLowTimeoutValue) >> 8U)) \
  )

/* ----------------------------------------------------------------------------
   -- EnableStopHoldOffMode
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables stop mode holdoff.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state of stop mode holdoff.
 */
#define I2C_PDD_EnableStopHoldOffMode(peripheralBase, State) ( \
    I2C_FLT_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(( \
       I2C_FLT_REG(peripheralBase)) & (( \
       (uint8_t)(~(uint8_t)I2C_FLT_SHEN_MASK)) & ( \
       (uint8_t)(~(uint8_t)I2C_FLT_STOPF_MASK))))) | ( \
      (uint8_t)((uint8_t)(State) << I2C_FLT_SHEN_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- ReadBusStatusFlags
   ---------------------------------------------------------------------------- */

/**
 * Returns the value of the bus status flags.
 * @param peripheralBase Peripheral base address.
 * @return Use constants from group "Status flags constants." for processing
 *         return value.
 */
#define I2C_PDD_ReadBusStatusFlags(peripheralBase) ( \
    I2C_FLT_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- ClearBusStatusInterruptFlags
   ---------------------------------------------------------------------------- */

/**
 * Clears bus status interrupt flags of interrupts specified by Mask.
 * @param peripheralBase Peripheral base address.
 * @param Mask Mask of interrupt clear requests. Use constants from group
 *        "Status flags constants.".
 */
#define I2C_PDD_ClearBusStatusInterruptFlags(peripheralBase, Mask) ( \
    I2C_FLT_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(I2C_FLT_REG(peripheralBase) & (uint8_t)(~(uint8_t)I2C_FLT_STOPF_MASK))) | ( \
      (uint8_t)(Mask))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableBusStopOrStartInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables the bus stop or start interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define I2C_PDD_EnableBusStopOrStartInterrupt(peripheralBase) ( \
    I2C_FLT_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(I2C_FLT_REG(peripheralBase) | I2C_FLT_STOPIE_MASK)) & ( \
      (uint8_t)(~(uint8_t)I2C_FLT_STOPF_MASK))) \
  )

/* ----------------------------------------------------------------------------
   -- DisableBusStopOrStartInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables the bus stop or start interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define I2C_PDD_DisableBusStopOrStartInterrupt(peripheralBase) ( \
    I2C_FLT_REG(peripheralBase) &= \
     (uint8_t)(( \
      (uint8_t)(~(uint8_t)I2C_FLT_STOPIE_MASK)) & ( \
      (uint8_t)(~(uint8_t)I2C_FLT_STOPF_MASK))) \
  )
#endif  /* #if defined(I2C_PDD_H_) */

/* I2C_PDD.h, eof. */
