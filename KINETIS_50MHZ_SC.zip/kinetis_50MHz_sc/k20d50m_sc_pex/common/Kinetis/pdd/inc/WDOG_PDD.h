/*
  PDD layer implementation for peripheral type WDOG
  (C) 2010 Freescale, Inc. All rights reserved.

  This file is static and it is generated from API-Factory
*/

#if !defined(WDOG_PDD_H_)
#define WDOG_PDD_H_

/* ----------------------------------------------------------------------------
   -- Test if supported MCU is active
   ---------------------------------------------------------------------------- */

#if !defined(MCU_ACTIVE)
  // No MCU is active
  #error WDOG PDD library: No derivative is active. Place proper #include with PDD memory map before including PDD library.
#elif \
      !defined(MCU_MK10D10) /* WDOG */ && \
      !defined(MCU_MK10D5) /* WDOG */ && \
      !defined(MCU_MK10D7) /* WDOG */ && \
      !defined(MCU_MK10F12) /* WDOG */ && \
      !defined(MCU_MK10DZ10) /* WDOG */ && \
      !defined(MCU_MK11D5) /* WDOG */ && \
      !defined(MCU_MK12D5) /* WDOG */ && \
      !defined(MCU_MK20D10) /* WDOG */ && \
      !defined(MCU_MK20D5) /* WDOG */ && \
      !defined(MCU_MK20D7) /* WDOG */ && \
      !defined(MCU_MK20F12) /* WDOG */ && \
      !defined(MCU_MK20DZ10) /* WDOG */ && \
      !defined(MCU_MK21D5) /* WDOG */ && \
      !defined(MCU_MK22D5) /* WDOG */ && \
      !defined(MCU_MK30D10) /* WDOG */ && \
      !defined(MCU_MK30D7) /* WDOG */ && \
      !defined(MCU_MK30DZ10) /* WDOG */ && \
      !defined(MCU_MK40D10) /* WDOG */ && \
      !defined(MCU_MK40D7) /* WDOG */ && \
      !defined(MCU_MK40DZ10) /* WDOG */ && \
      !defined(MCU_MK40X256VMD100) /* WDOG */ && \
      !defined(MCU_MK50D10) /* WDOG */ && \
      !defined(MCU_MK50D7) /* WDOG */ && \
      !defined(MCU_MK50DZ10) /* WDOG */ && \
      !defined(MCU_MK51D10) /* WDOG */ && \
      !defined(MCU_MK51D7) /* WDOG */ && \
      !defined(MCU_MK51DZ10) /* WDOG */ && \
      !defined(MCU_MK52D10) /* WDOG */ && \
      !defined(MCU_MK52DZ10) /* WDOG */ && \
      !defined(MCU_MK53D10) /* WDOG */ && \
      !defined(MCU_MK53DZ10) /* WDOG */ && \
      !defined(MCU_MK60D10) /* WDOG */ && \
      !defined(MCU_MK60F12) /* WDOG */ && \
      !defined(MCU_MK60F15) /* WDOG */ && \
      !defined(MCU_MK60DZ10) /* WDOG */ && \
      !defined(MCU_MK60N512VMD100) /* WDOG */ && \
      !defined(MCU_MK61F12) /* WDOG */ && \
      !defined(MCU_MK61F15) /* WDOG */ && \
      !defined(MCU_MK70F12) /* WDOG */ && \
      !defined(MCU_MK70F15) /* WDOG */ && \
      !defined(MCU_PCK20L4) /* WDOG */
  // Unsupported MCU is active
  #error WDOG PDD library: Unsupported derivative is active.
#endif

#include "PDD_Types.h"

/* ----------------------------------------------------------------------------
   -- Method symbol definitions
   ---------------------------------------------------------------------------- */

/* Windowing mode constants */
#define WDOG_PDD_WINDOWING_DISABLED 0U           /**< Disabled */
#define WDOG_PDD_WINDOWING_ENABLED WDOG_STCTRLH_WINEN_MASK /**< Enabled */

/* Clock source constants. */
#define WDOG_PDD_SOURCE_DEDICATED 0U             /**< Dedicated */
#define WDOG_PDD_SOURCE_ALTERNATE WDOG_STCTRLH_CLKSRC_MASK /**< Alternate */

/* Refresh constants */
#define WDOG_PDD_KEY_1 0xA602U                   /**< First key */
#define WDOG_PDD_KEY_2 0xB480U                   /**< Second key */

/* Unlock constants */
#define WDOG_PDD_UNLOCK_1 0xC520U                /**< First key */
#define WDOG_PDD_UNLOCK_2 0xD928U                /**< Second key */

/* Prescaler constants */
#define WDOG_PDD_DIVIDE_1 0U                     /**< 1 */
#define WDOG_PDD_DIVIDE_2 0x1U                   /**< 2 */
#define WDOG_PDD_DIVIDE_3 0x2U                   /**< 3 */
#define WDOG_PDD_DIVIDE_4 0x3U                   /**< 4 */
#define WDOG_PDD_DIVIDE_5 0x4U                   /**< 5 */
#define WDOG_PDD_DIVIDE_6 0x5U                   /**< 6 */
#define WDOG_PDD_DIVIDE_7 0x6U                   /**< 7 */
#define WDOG_PDD_DIVIDE_8 0x7U                   /**< 8 */


/* ----------------------------------------------------------------------------
   -- GetAllowUpdateStatus
   ---------------------------------------------------------------------------- */

/**
 * Returns non-zero if watchdog registers can be unlocked. .
 * @param peripheralBase Peripheral base address.
 */
#define WDOG_PDD_GetAllowUpdateStatus(peripheralBase) ( \
    (uint16_t)(WDOG_STCTRLH_REG(peripheralBase) & WDOG_STCTRLH_ALLOWUPDATE_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- DisableUpdate
   ---------------------------------------------------------------------------- */

/**
 * No further updates allowed to WDOG write once registers.
 * @param peripheralBase Peripheral base address.
 */
#define WDOG_PDD_DisableUpdate(peripheralBase) ( \
    WDOG_STCTRLH_REG(peripheralBase) &= \
     (uint16_t)(~(uint16_t)WDOG_STCTRLH_ALLOWUPDATE_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- SetWindowingMode
   ---------------------------------------------------------------------------- */

/**
 * Configures the windowing mode operation.
 * @param peripheralBase Peripheral base address.
 * @param Mode New value of the mode.
 */
#define WDOG_PDD_SetWindowingMode(peripheralBase, Mode) ( \
    WDOG_STCTRLH_REG(peripheralBase) = \
     (uint16_t)(( \
      (uint16_t)(( \
       WDOG_STCTRLH_REG(peripheralBase)) & ( \
       (uint16_t)(~(uint16_t)WDOG_STCTRLH_WINEN_MASK)))) | ( \
      (uint16_t)(Mode))) \
  )

/* ----------------------------------------------------------------------------
   -- GetInterruptMask
   ---------------------------------------------------------------------------- */

/**
 * Returns interrupt mask.
 * @param peripheralBase Peripheral base address.
 */
#define WDOG_PDD_GetInterruptMask(peripheralBase) ( \
    (uint16_t)(WDOG_STCTRLH_REG(peripheralBase) & WDOG_STCTRLH_IRQRSTEN_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- EnableInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables the WDOG interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define WDOG_PDD_EnableInterrupt(peripheralBase) ( \
    WDOG_STCTRLH_REG(peripheralBase) |= \
     WDOG_STCTRLH_IRQRSTEN_MASK \
  )

/* ----------------------------------------------------------------------------
   -- DisableInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables the WDOG interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define WDOG_PDD_DisableInterrupt(peripheralBase) ( \
    WDOG_STCTRLH_REG(peripheralBase) &= \
     (uint16_t)(~(uint16_t)WDOG_STCTRLH_IRQRSTEN_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- SelectClockSource
   ---------------------------------------------------------------------------- */

/**
 * Selects clock source.
 * @param peripheralBase Peripheral base address.
 * @param Source New value of the source.
 */
#define WDOG_PDD_SelectClockSource(peripheralBase, Source) ( \
    WDOG_STCTRLH_REG(peripheralBase) = \
     (uint16_t)(( \
      (uint16_t)(( \
       WDOG_STCTRLH_REG(peripheralBase)) & ( \
       (uint16_t)(~(uint16_t)WDOG_STCTRLH_CLKSRC_MASK)))) | ( \
      (uint16_t)(Source))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableDevice
   ---------------------------------------------------------------------------- */

/**
 * Enables the WDOG device.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state of WDOG device.
 */
#define WDOG_PDD_EnableDevice(peripheralBase, State) ( \
    WDOG_STCTRLH_REG(peripheralBase) = \
     (uint16_t)(( \
      (uint16_t)(( \
       WDOG_STCTRLH_REG(peripheralBase)) & ( \
       (uint16_t)(~(uint16_t)WDOG_STCTRLH_WDOGEN_MASK)))) | ( \
      (uint16_t)(State))) \
  )

/* ----------------------------------------------------------------------------
   -- GetEnableDeviceStatus
   ---------------------------------------------------------------------------- */

/**
 * Returns current state of WDOG device.
 * @param peripheralBase Peripheral base address.
 */
#define WDOG_PDD_GetEnableDeviceStatus(peripheralBase) ( \
    (uint16_t)(WDOG_STCTRLH_REG(peripheralBase) & WDOG_STCTRLH_WDOGEN_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- WriteControlHighReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the watchdog status and control register high.
 * @param peripheralBase Peripheral base address.
 * @param Value New content of the watchdog status and control register high.
 */
#define WDOG_PDD_WriteControlHighReg(peripheralBase, Value) ( \
    WDOG_STCTRLH_REG(peripheralBase) = \
     (uint16_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadControlHighReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the watchdog status and control register high.
 * @param peripheralBase Peripheral base address.
 */
#define WDOG_PDD_ReadControlHighReg(peripheralBase) ( \
    WDOG_STCTRLH_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- GetInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Returns interrupt flag bit.
 * @param peripheralBase Peripheral base address.
 */
#define WDOG_PDD_GetInterruptFlag(peripheralBase) ( \
    (uint16_t)(WDOG_STCTRLL_REG(peripheralBase) & WDOG_STCTRLL_INTFLG_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- ClearInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Clears interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define WDOG_PDD_ClearInterruptFlag(peripheralBase) ( \
    WDOG_STCTRLL_REG(peripheralBase) = \
     (uint16_t)(WDOG_STCTRLL_INTFLG_MASK | 0x1U) \
  )

/* ----------------------------------------------------------------------------
   -- WriteTimeOutHighReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the watchdog time-out value register high.
 * @param peripheralBase Peripheral base address.
 * @param Value New content of the watchdog time-out value register high.
 */
#define WDOG_PDD_WriteTimeOutHighReg(peripheralBase, Value) ( \
    WDOG_TOVALH_REG(peripheralBase) = \
     (uint16_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- WriteTimeOutLowReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the watchdog time-out value register low.
 * @param peripheralBase Peripheral base address.
 * @param Value New content of the watchdog time-out value register low.
 */
#define WDOG_PDD_WriteTimeOutLowReg(peripheralBase, Value) ( \
    WDOG_TOVALL_REG(peripheralBase) = \
     (uint16_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- WriteWindowHighReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the watchdog window register high.
 * @param peripheralBase Peripheral base address.
 * @param Value New content of the watchdog window register high.
 */
#define WDOG_PDD_WriteWindowHighReg(peripheralBase, Value) ( \
    WDOG_WINH_REG(peripheralBase) = \
     (uint16_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- WriteWindowLowReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the watchdog window register low.
 * @param peripheralBase Peripheral base address.
 * @param Value New content of the watchdog window register low.
 */
#define WDOG_PDD_WriteWindowLowReg(peripheralBase, Value) ( \
    WDOG_WINL_REG(peripheralBase) = \
     (uint16_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- WriteRefreshReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the watchdog refresh register.
 * @param peripheralBase Peripheral base address.
 * @param Value Service constant.
 */
#define WDOG_PDD_WriteRefreshReg(peripheralBase, Value) ( \
    WDOG_REFRESH_REG(peripheralBase) = \
     (uint16_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- WriteUnlockReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the watchdog unlock register.
 * @param peripheralBase Peripheral base address.
 * @param Value Unlock constant.
 */
#define WDOG_PDD_WriteUnlockReg(peripheralBase, Value) ( \
    WDOG_UNLOCK_REG(peripheralBase) = \
     (uint16_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- SetPrescaler
   ---------------------------------------------------------------------------- */

/**
 * Sets prescale value.
 * @param peripheralBase Peripheral base address.
 * @param Prescaler New value of the prescaler.
 */
#define WDOG_PDD_SetPrescaler(peripheralBase, Prescaler) ( \
    WDOG_PRESC_REG(peripheralBase) = \
     (uint16_t)((uint16_t)(Prescaler) << WDOG_PRESC_PRESCVAL_SHIFT) \
  )
#endif  /* #if defined(WDOG_PDD_H_) */

/* WDOG_PDD.h, eof. */
