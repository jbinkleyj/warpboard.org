/*
  PDD layer implementation for peripheral type I2S
  (C) 2010 Freescale, Inc. All rights reserved.

  This file is static and it is generated from API-Factory
*/

#if !defined(SAI_PDD_H_)
#define SAI_PDD_H_

/* ----------------------------------------------------------------------------
   -- Test if supported MCU is active
   ---------------------------------------------------------------------------- */

#if !defined(MCU_ACTIVE)
  // No MCU is active
  #error I2S PDD library: No derivative is active. Place proper #include with PDD memory map before including PDD library.
#elif \
      !defined(MCU_MK10D10) /* I2S0 */ && \
      !defined(MCU_MK10D5) /* I2S0 */ && \
      !defined(MCU_MK10D7) /* I2S0 */ && \
      !defined(MCU_MK10F12) /* I2S0, I2S1 */ && \
      !defined(MCU_MK11D5) /* I2S0 */ && \
      !defined(MCU_MK12D5) /* I2S0 */ && \
      !defined(MCU_MK20D10) /* I2S0 */ && \
      !defined(MCU_MK20D5) /* I2S0 */ && \
      !defined(MCU_MK20D7) /* I2S0 */ && \
      !defined(MCU_MK20F12) /* I2S0, I2S1 */ && \
      !defined(MCU_MK21D5) /* I2S0 */ && \
      !defined(MCU_MK22D5) /* I2S0 */ && \
      !defined(MCU_MK30D10) /* I2S0 */ && \
      !defined(MCU_MK30D7) /* I2S0 */ && \
      !defined(MCU_MK40D10) /* I2S0 */ && \
      !defined(MCU_MK40D7) /* I2S0 */ && \
      !defined(MCU_MK50D10) /* I2S0 */ && \
      !defined(MCU_MK50D7) /* I2S0 */ && \
      !defined(MCU_MK51D10) /* I2S0 */ && \
      !defined(MCU_MK51D7) /* I2S0 */ && \
      !defined(MCU_MK52D10) /* I2S0 */ && \
      !defined(MCU_MK53D10) /* I2S0 */ && \
      !defined(MCU_MK60D10) /* I2S0 */ && \
      !defined(MCU_MK60F12) /* I2S0, I2S1 */ && \
      !defined(MCU_MK60F15) /* I2S0, I2S1 */ && \
      !defined(MCU_MK61F12) /* I2S0, I2S1 */ && \
      !defined(MCU_MK61F15) /* I2S0, I2S1 */ && \
      !defined(MCU_MK70F12) /* I2S0, I2S1 */ && \
      !defined(MCU_MK70F15) /* I2S0, I2S1 */ && \
      !defined(MCU_PCK20L4) /* I2S0 */
  // Unsupported MCU is active
  #error I2S PDD library: Unsupported derivative is active.
#endif

#include "PDD_Types.h"

/* ----------------------------------------------------------------------------
   -- Method symbol definitions
   ---------------------------------------------------------------------------- */

/* Transmitter/receiver status flags constants. */
#define I2S_PDD_WORD_START_FLAG I2S_TCSR_WSF_MASK /**< Word start flag. */
#define I2S_PDD_SYNC_ERROR_FLAG I2S_TCSR_SEF_MASK /**< Sync error flag. */
#define I2S_PDD_FIFO_ERROR_FLAG I2S_TCSR_FEF_MASK /**< FIFO error flag. */
#define I2S_PDD_FIFO_WARNING_FLAG I2S_TCSR_FWF_MASK /**< FIFO warning flag. */
#define I2S_PDD_FIFO_REQUEST_FLAG I2S_TCSR_FRF_MASK /**< FIFO request flag. */
#define I2S_PDD_ALL_INT_FLAG 0x1C0000U           /**< All interrupt flags. */

/* Transmitter/receiver interrupt enable/disable constants (for
   EnableTxInterrupt, DisableTxInterrupt, EnableRxInterrupt and DisableRxInterrupt macros). */
#define I2S_PDD_WORD_START_INT I2S_TCSR_WSIE_MASK /**< Word start interrupt mask. */
#define I2S_PDD_SYNC_ERROR_INT I2S_TCSR_SEIE_MASK /**< Sync error interrupt mask. */
#define I2S_PDD_FIFO_ERROR_INT I2S_TCSR_FEIE_MASK /**< FIFO error interrupt mask. */
#define I2S_PDD_FIFO_WARNING_INT I2S_TCSR_FWIE_MASK /**< FIFO warning interrupt mask. */
#define I2S_PDD_FIFO_REQUEST_INT I2S_TCSR_FRIE_MASK /**< FIFO request interrupt mask. */

/* Transmitter watermark constants (for SetTxFifoWatermark macro). */
#define I2S_PDD_TX_WATERMARK_VALUE_0 0U          /**< Transmitter FIFO watermark 0 */
#define I2S_PDD_TX_WATERMARK_VALUE_1 0x1U        /**< Transmitter FIFO watermark 1 */
#define I2S_PDD_TX_WATERMARK_VALUE_2 0x2U        /**< Transmitter FIFO watermark 2 */
#define I2S_PDD_TX_WATERMARK_VALUE_3 0x3U        /**< Transmitter FIFO watermark 3 */
#define I2S_PDD_TX_WATERMARK_VALUE_4 0x4U        /**< Transmitter FIFO watermark 4 */
#define I2S_PDD_TX_WATERMARK_VALUE_5 0x5U        /**< Transmitter FIFO watermark 5 */
#define I2S_PDD_TX_WATERMARK_VALUE_6 0x6U        /**< Transmitter FIFO watermark 6 */
#define I2S_PDD_TX_WATERMARK_VALUE_7 0x7U        /**< Transmitter FIFO watermark 7 */

/* Clocking transmitter mode constants (for SetTxSynchronousMode macro). */
#define I2S_PDD_TX_ASYNCHRONOUS_MODE 0U          /**< Asynchronous mode. */
#define I2S_PDD_TX_SYNC_WITH_RECEIVER 0x1U       /**< Synchronous with receiver. */
#define I2S_PDD_TX_SYNC_WITH_ANOTHER_TRANSMITTER 0x2U /**< Synchronous with another SAI transmitter. */
#define I2S_PDD_TX_SYNC_WITH_ANOTHER_RECEIVER 0x3U /**< Synchronous with another SAI receiver. */

/* Clocking transmitter mode constants (for SetTxBitClockSource,
   SetRxBitClockSource macro). */
#define I2S_PDD_BUS_CLOCK_SOURCE  0U             /**< Bus clock selected. */
#define I2S_PDD_MASTER_CLOCK_1_SOURCE 0x1U       /**< Mclk output 1 source */
#define I2S_PDD_MASTER_CLOCK_2_SOURCE 0x2U       /**< Mclk output 2 source */

/* Transmitter or receiver word flag configuration constants. */
#define I2S_PDD_WORD_FLAG_1 0U                   /**< Word flag is set on 1st word. */
#define I2S_PDD_WORD_FLAG_2 0x1U                 /**< Word flag is set on 2nd word. */
#define I2S_PDD_WORD_FLAG_3 0x2U                 /**< Word flag is set on 3rd word. */
#define I2S_PDD_WORD_FLAG_4 0x3U                 /**< Word flag is set on 4th word. */
#define I2S_PDD_WORD_FLAG_5 0x4U                 /**< Word flag is set on 5th word. */
#define I2S_PDD_WORD_FLAG_6 0x5U                 /**< Word flag is set on 6th word. */
#define I2S_PDD_WORD_FLAG_7 0x6U                 /**< Word flag is set on 7th word. */
#define I2S_PDD_WORD_FLAG_8 0x7U                 /**< Word flag is set on 8th word. */
#define I2S_PDD_WORD_FLAG_9 0x8U                 /**< Word flag is set on 9th word. */
#define I2S_PDD_WORD_FLAG_10 0x9U                /**< Word flag is set on 10th word. */
#define I2S_PDD_WORD_FLAG_11 0xAU                /**< Word flag is set on 11th word. */
#define I2S_PDD_WORD_FLAG_12 0xBU                /**< Word flag is set on 12th word. */
#define I2S_PDD_WORD_FLAG_13 0xCU                /**< Word flag is set on 13th word. */
#define I2S_PDD_WORD_FLAG_14 0xDU                /**< Word flag is set on 14th word. */
#define I2S_PDD_WORD_FLAG_15 0xEU                /**< Word flag is set on 15th word. */
#define I2S_PDD_WORD_FLAG_16 0xFU                /**< Word flag is set on 16th word. */

/* Transmitter or receiver frame size constants. */
#define I2S_PDD_FRAME_SIZE_1 0U                  /**< 1 word per frame. */
#define I2S_PDD_FRAME_SIZE_2 0x1U                /**< 2 words per frame. */
#define I2S_PDD_FRAME_SIZE_3 0x2U                /**< 3 words per frame. */
#define I2S_PDD_FRAME_SIZE_4 0x3U                /**< 4 words per frame. */
#define I2S_PDD_FRAME_SIZE_5 0x4U                /**< 5 words per frame. */
#define I2S_PDD_FRAME_SIZE_6 0x5U                /**< 6 words per frame. */
#define I2S_PDD_FRAME_SIZE_7 0x6U                /**< 7 words per frame. */
#define I2S_PDD_FRAME_SIZE_8 0x7U                /**< 8 words per frame. */
#define I2S_PDD_FRAME_SIZE_9 0x8U                /**< 9 words per frame. */
#define I2S_PDD_FRAME_SIZE_10 0x9U               /**< 10 words per frame. */
#define I2S_PDD_FRAME_SIZE_11 0xAU               /**< 11 words per frame. */
#define I2S_PDD_FRAME_SIZE_12 0xBU               /**< 12 words per frame. */
#define I2S_PDD_FRAME_SIZE_13 0xCU               /**< 13 words per frame. */
#define I2S_PDD_FRAME_SIZE_14 0xDU               /**< 14 words per frame. */
#define I2S_PDD_FRAME_SIZE_15 0xEU               /**< 15 words per frame. */
#define I2S_PDD_FRAME_SIZE_16 0xFU               /**< 16 words per frame. */

/* Transmitter or receiver sync width constants. */
#define I2S_PDD_SYNC_WIDTH_1 0U                  /**< 1 bit clock. */
#define I2S_PDD_SYNC_WIDTH_2 0x1U                /**< 2 bits clock. */
#define I2S_PDD_SYNC_WIDTH_3 0x2U                /**< 3 bits clock. */
#define I2S_PDD_SYNC_WIDTH_4 0x3U                /**< 4 bits clock. */
#define I2S_PDD_SYNC_WIDTH_5 0x4U                /**< 5 bits clock. */
#define I2S_PDD_SYNC_WIDTH_6 0x5U                /**< 6 bits clock. */
#define I2S_PDD_SYNC_WIDTH_7 0x6U                /**< 7 bits clock. */
#define I2S_PDD_SYNC_WIDTH_8 0x7U                /**< 8 bits clock. */
#define I2S_PDD_SYNC_WIDTH_9 0x8U                /**< 9 bits clock. */
#define I2S_PDD_SYNC_WIDTH_10 0x9U               /**< 10 bits clock. */
#define I2S_PDD_SYNC_WIDTH_11 0xAU               /**< 11 bits clock. */
#define I2S_PDD_SYNC_WIDTH_12 0xBU               /**< 12 bits clock. */
#define I2S_PDD_SYNC_WIDTH_13 0xCU               /**< 13 bits clock. */
#define I2S_PDD_SYNC_WIDTH_14 0xDU               /**< 14 bits clock. */
#define I2S_PDD_SYNC_WIDTH_15 0xEU               /**< 15 bits clock. */
#define I2S_PDD_SYNC_WIDTH_16 0xFU               /**< 16 bits clock. */
#define I2S_PDD_SYNC_WIDTH_17 0x10U              /**< 17 bits clock. */
#define I2S_PDD_SYNC_WIDTH_18 0x11U              /**< 18 bits clock. */
#define I2S_PDD_SYNC_WIDTH_19 0x12U              /**< 19 bits clock. */
#define I2S_PDD_SYNC_WIDTH_20 0x13U              /**< 20 bits clock. */
#define I2S_PDD_SYNC_WIDTH_21 0x14U              /**< 21 bits clock. */
#define I2S_PDD_SYNC_WIDTH_22 0x15U              /**< 22 bits clock. */
#define I2S_PDD_SYNC_WIDTH_23 0x16U              /**< 23 bits clock. */
#define I2S_PDD_SYNC_WIDTH_24 0x17U              /**< 24 bits clock. */
#define I2S_PDD_SYNC_WIDTH_25 0x18U              /**< 25 bits clock. */
#define I2S_PDD_SYNC_WIDTH_26 0x19U              /**< 26 bits clock. */
#define I2S_PDD_SYNC_WIDTH_27 0x1AU              /**< 27 bits clock. */
#define I2S_PDD_SYNC_WIDTH_28 0x1BU              /**< 28 bits clock. */
#define I2S_PDD_SYNC_WIDTH_29 0x1CU              /**< 29 bits clock. */
#define I2S_PDD_SYNC_WIDTH_30 0x1DU              /**< 30 bits clock. */
#define I2S_PDD_SYNC_WIDTH_31 0x1EU              /**< 31 bits clock. */
#define I2S_PDD_SYNC_WIDTH_32 0x1FU              /**< 32 bits clock. */

/* Transmitter or receiver word width (in bits) constants. */
#define I2S_PDD_WORD_WIDTH_1 0U                  /**< 1 bit. */
#define I2S_PDD_WORD_WIDTH_2 0x1U                /**< 2 bits. */
#define I2S_PDD_WORD_WIDTH_3 0x2U                /**< 3 bits. */
#define I2S_PDD_WORD_WIDTH_4 0x3U                /**< 4 bits. */
#define I2S_PDD_WORD_WIDTH_5 0x4U                /**< 5 bits. */
#define I2S_PDD_WORD_WIDTH_6 0x5U                /**< 6 bits. */
#define I2S_PDD_WORD_WIDTH_7 0x6U                /**< 7 bits. */
#define I2S_PDD_WORD_WIDTH_8 0x7U                /**< 8 bits. */
#define I2S_PDD_WORD_WIDTH_9 0x8U                /**< 9 bits. */
#define I2S_PDD_WORD_WIDTH_10 0x9U               /**< 10 bits. */
#define I2S_PDD_WORD_WIDTH_11 0xAU               /**< 11 bits. */
#define I2S_PDD_WORD_WIDTH_12 0xBU               /**< 12 bits. */
#define I2S_PDD_WORD_WIDTH_13 0xCU               /**< 13 bits. */
#define I2S_PDD_WORD_WIDTH_14 0xDU               /**< 14 bits. */
#define I2S_PDD_WORD_WIDTH_15 0xEU               /**< 15 bits. */
#define I2S_PDD_WORD_WIDTH_16 0xFU               /**< 16 bits. */
#define I2S_PDD_WORD_WIDTH_17 0x10U              /**< 17 bits. */
#define I2S_PDD_WORD_WIDTH_18 0x11U              /**< 18 bits. */
#define I2S_PDD_WORD_WIDTH_19 0x12U              /**< 19 bits. */
#define I2S_PDD_WORD_WIDTH_20 0x13U              /**< 20 bits. */
#define I2S_PDD_WORD_WIDTH_21 0x14U              /**< 21 bits. */
#define I2S_PDD_WORD_WIDTH_22 0x15U              /**< 22 bits. */
#define I2S_PDD_WORD_WIDTH_23 0x16U              /**< 23 bits. */
#define I2S_PDD_WORD_WIDTH_24 0x17U              /**< 24 bits. */
#define I2S_PDD_WORD_WIDTH_25 0x18U              /**< 25 bits. */
#define I2S_PDD_WORD_WIDTH_26 0x19U              /**< 26 bits. */
#define I2S_PDD_WORD_WIDTH_27 0x1AU              /**< 27 bits. */
#define I2S_PDD_WORD_WIDTH_28 0x1BU              /**< 28 bits. */
#define I2S_PDD_WORD_WIDTH_29 0x1CU              /**< 29 bits. */
#define I2S_PDD_WORD_WIDTH_30 0x1DU              /**< 30 bits. */
#define I2S_PDD_WORD_WIDTH_31 0x1EU              /**< 31 bits. */
#define I2S_PDD_WORD_WIDTH_32 0x1FU              /**< 32 bits. */

/* Receiver watermark constants (for SetRxFifoWatermark macro). */
#define I2S_PDD_RX_WATERMARK_VALUE_1 0U          /**< Receiver FIFO watermark 1 */
#define I2S_PDD_RX_WATERMARK_VALUE_2 0x1U        /**< Receiver FIFO watermark 2 */
#define I2S_PDD_RX_WATERMARK_VALUE_3 0x2U        /**< Receiver FIFO watermark 3 */
#define I2S_PDD_RX_WATERMARK_VALUE_4 0x3U        /**< Receiver FIFO watermark 4 */
#define I2S_PDD_RX_WATERMARK_VALUE_5 0x4U        /**< Receiver FIFO watermark 5 */
#define I2S_PDD_RX_WATERMARK_VALUE_6 0x5U        /**< Receiver FIFO watermark 6 */
#define I2S_PDD_RX_WATERMARK_VALUE_7 0x6U        /**< Receiver FIFO watermark 7 */
#define I2S_PDD_RX_WATERMARK_VALUE_8 0x7U        /**< Receiver FIFO watermark 8 */

/* Clocking transmitter mode constants (for SetRxSynchronousMode macro). */
#define I2S_PDD_RX_ASYNCHRONOUS_MODE 0U          /**< Asynchronous mode. */
#define I2S_PDD_RX_SYNC_WITH_TRANSMITTER 0x1U    /**< Synchronous with receiver. */
#define I2S_PDD_RX_SYNC_WITH_ANOTHER_RECEIVER 0x2U /**< Synchronous with another SAI transmitter. */
#define I2S_PDD_RX_SYNC_WITH_ANOTHER_TRANSMITTER 0x3U /**< Synchronous with another SAI transmitter. */

/* Divider update status flag constant (for GetDividerUpdateFlag macro). */
#define I2S_PDD_MCLK_DIVIDER_RATIO_UPDATED I2S_MCR_DUF_MASK /**< MCLK Divider ratio is updating on-the-fly. */

/* Transmitter internal logic bit clock input constants (for SetTxBitClockInput
   macros). */
#define I2S_PDD_INTERNAL_BIT_CLOCK 0U            /**< No effect. */
#define I2S_PDD_EXTERNAL_BIT_CLOCK 0x10000000U   /**< Internal logic is clocked as if bit clock was externally generated. */

/* Transmitter bit clock polarity constants (for SetTxBitClockPolarity,
   SetRxBitClockPolarity macros). */
#define I2S_PDD_BIT_CLOCK_ACTIVE_HIGH 0U         /**< Bit Clock is active high (drive outputs on rising edge and sample inputs on falling edge). */
#define I2S_PDD_BIT_CLOCK_ACTIVE_LOW 0x2000000U  /**< Bit Clock is active low (drive outputs on falling edge and sample inputs on rising edge). */

/* Bit clock direction constants (for SetTxBitClockDirection,
   SetRxBitClockDirection macros). */
#define I2S_PDD_BIT_CLOCK_OUTPUT 0x1000000U      /**< Bit clock is generated internally (master mode). */
#define I2S_PDD_BIT_CLOCK_INPUT 0U               /**< Bit clock is generated externally (slave mode). */

/* Data channel mask constant constants (for EnableRx/TxDataChannels,
   DisableRx/TxDataChannels macros). */
#define I2S_PDD_DATA_CHANNEL_0 0x1U              /**< Data channel 0 mask */
#define I2S_PDD_DATA_CHANNEL_1 0x2U              /**< Data channel 1 mask */

/* Bit shift order constants (for SetTxShiftDirection, SetRxShiftDirection
   macros). */
#define I2S_PDD_MSB_FIRST 0U                     /**< MBS is transmitted/received first. */
#define I2S_PDD_LSB_FIRST 0x10U                  /**< LBS is transmitted/received first. */

/* Frame sync position in stream constants (for SetTxFrameSyncEarly,
   SetRxFrameSyncEarly macros). */
#define I2S_PDD_FIRST_BIT_OF_DATA 0U             /**< Asserts with the first bit of the frame. */
#define I2S_PDD_ONE_BIT_BEFORE_DATA 0x8U         /**< Asserts one bit before the first bit of the frame. */

/* Frame sync active polarity constants (for SetTxFrameSyncPolarity,
   SetRxFrameSyncPolarity macros). */
#define I2S_PDD_FRAME_SYNC_ACTIVE_HIGH 0U        /**< Active high. */
#define I2S_PDD_FRAME_SYNC_ACTIVE_LOW 0x2U       /**< Active low. */

/* Frame sync PIN direction constants (for SetTxFrameSyncDirection,
   SetRxFrameSyncDirection macros). */
#define I2S_PDD_FRAME_SYNC_OUTPUT 0x1U           /**< Generated internally (master mode). */
#define I2S_PDD_FRAME_SYNC_INPUT 0U              /**< Generated externally (slave mode). */

/* Receiver internal logic bit clock input constants (for SetRxBitClockInput
   macros). */
#define I2S_PDD_INTERNAL_BIT_CLOCK 0U            /**< No effect. */
#define I2S_PDD_EXTERNAL_BIT_CLOCK 0x10000000U   /**< Internal logic is clocked as if bit clock was externally generated. */

#if ((defined(MCU_MK10F12)) || (defined(MCU_MK20F12)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)))
/* Mclk clock input constants (for SetMclkClockSource macro). */
  #define I2S_PDD_SYSTEM_CLK 0U                    /**< System Clock. */
  #define I2S_PDD_ER_OSC0 0x1000000U               /**< ER OSC0 */
  #define I2S_PDD_ER_OSC1 0x2000000U               /**< ER OSC1 */
  #define I2S_PDD_PLL_CLK 0x3000000U               /**< MCG PLL out. */

#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK52D10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK60D10)) || (defined(MCU_PCK20L4)) */
/* Mclk clock input constants (for SetMclkClockSource macro). */
  #define I2S_PDD_SYSTEM_CLK 0U                    /**< System Clock. */
  #define I2S_PDD_ER_OSC0 0x1000000U               /**< ER OSC0 */
  #define I2S_PDD_PLL_CLK 0x3000000U               /**< MCG PLL out. */

#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK52D10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK60D10)) || (defined(MCU_PCK20L4)) */

/* ----------------------------------------------------------------------------
   -- EnableTxDevice
   ---------------------------------------------------------------------------- */

/**
 * Enables or disables the transmitter.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state of transmitter.
 */
#define I2S_PDD_EnableTxDevice(peripheralBase, State) ( \
    ((State) == PDD_ENABLE) ? ( \
      I2S_TCSR_REG(peripheralBase) = \
       (uint32_t)(( \
        (uint32_t)(I2S_TCSR_REG(peripheralBase) | I2S_TCSR_TE_MASK)) & (( \
        (uint32_t)(~(uint32_t)I2S_TCSR_FEF_MASK)) & (( \
        (uint32_t)(~(uint32_t)I2S_TCSR_SEF_MASK)) & ( \
        (uint32_t)(~(uint32_t)I2S_TCSR_WSF_MASK)))))) : ( \
      I2S_TCSR_REG(peripheralBase) &= \
       (uint32_t)(( \
        (uint32_t)(~(uint32_t)I2S_TCSR_TE_MASK)) & (( \
        (uint32_t)(~(uint32_t)I2S_TCSR_BCE_MASK)) & (( \
        (uint32_t)(~(uint32_t)I2S_TCSR_FEF_MASK)) & (( \
        (uint32_t)(~(uint32_t)I2S_TCSR_SEF_MASK)) & ( \
        (uint32_t)(~(uint32_t)I2S_TCSR_WSF_MASK))))))) \
  )

/* ----------------------------------------------------------------------------
   -- GetTxDeviceState
   ---------------------------------------------------------------------------- */

/**
 * Returns transmitter enable/disable status.
 * @param peripheralBase Peripheral base address.
 */
#define I2S_PDD_GetTxDeviceState(peripheralBase) ( \
    (( \
      (uint8_t)(( \
       (uint32_t)(I2S_TCSR_REG(peripheralBase) & I2S_TCSR_TE_MASK)) >> ( \
       I2S_TCSR_TE_SHIFT))) == ( \
      0x1U)) ? ( \
      PDD_ENABLE) : ( \
      PDD_DISABLE) \
  )

/* ----------------------------------------------------------------------------
   -- EnableTxInStopMode
   ---------------------------------------------------------------------------- */

/**
 * Enables or disables transmitter operation in stop mode.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state in stop mode.
 */
#define I2S_PDD_EnableTxInStopMode(peripheralBase, State) ( \
    I2S_TCSR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       I2S_TCSR_REG(peripheralBase)) & (( \
       (uint32_t)(~(uint32_t)I2S_TCSR_STOPE_MASK)) & (( \
       (uint32_t)(~(uint32_t)I2S_TCSR_FEF_MASK)) & (( \
       (uint32_t)(~(uint32_t)I2S_TCSR_SEF_MASK)) & ( \
       (uint32_t)(~(uint32_t)I2S_TCSR_WSF_MASK))))))) | ( \
      (uint32_t)((uint32_t)(State) << I2S_TCSR_STOPE_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableTxInDebugMode
   ---------------------------------------------------------------------------- */

/**
 * Enables or disables transmitter operation in debug mode.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state in debug mode.
 */
#define I2S_PDD_EnableTxInDebugMode(peripheralBase, State) ( \
    I2S_TCSR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       I2S_TCSR_REG(peripheralBase)) & (( \
       (uint32_t)(~(uint32_t)I2S_TCSR_DBGE_MASK)) & (( \
       (uint32_t)(~(uint32_t)I2S_TCSR_FEF_MASK)) & (( \
       (uint32_t)(~(uint32_t)I2S_TCSR_SEF_MASK)) & ( \
       (uint32_t)(~(uint32_t)I2S_TCSR_WSF_MASK))))))) | ( \
      (uint32_t)((uint32_t)(State) << I2S_TCSR_DBGE_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableTxBitClock
   ---------------------------------------------------------------------------- */

/**
 * Enables or disables the transmit bit clock, separately from the transmit
 * enable.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state of Tx bit clock.
 */
#define I2S_PDD_EnableTxBitClock(peripheralBase, State) ( \
    I2S_TCSR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       I2S_TCSR_REG(peripheralBase)) & (( \
       (uint32_t)(~(uint32_t)I2S_TCSR_BCE_MASK)) & (( \
       (uint32_t)(~(uint32_t)I2S_TCSR_FEF_MASK)) & (( \
       (uint32_t)(~(uint32_t)I2S_TCSR_SEF_MASK)) & ( \
       (uint32_t)(~(uint32_t)I2S_TCSR_WSF_MASK))))))) | ( \
      (uint32_t)((uint32_t)(State) << I2S_TCSR_BCE_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- GetTxBitClockState
   ---------------------------------------------------------------------------- */

/**
 * Returns transmitter bit clock enable/disable status.
 * @param peripheralBase Peripheral base address.
 */
#define I2S_PDD_GetTxBitClockState(peripheralBase) ( \
    (( \
      (uint8_t)(( \
       (uint32_t)(I2S_TCSR_REG(peripheralBase) & I2S_TCSR_BCE_MASK)) >> ( \
       I2S_TCSR_BCE_SHIFT))) == ( \
      0x1U)) ? ( \
      PDD_ENABLE) : ( \
      PDD_DISABLE) \
  )

/* ----------------------------------------------------------------------------
   -- TxFifoReset
   ---------------------------------------------------------------------------- */

/**
 * Resets the transmitter FIFO pointers.
 * @param peripheralBase Peripheral base address.
 */
#define I2S_PDD_TxFifoReset(peripheralBase) ( \
    I2S_TCSR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(I2S_TCSR_REG(peripheralBase) | I2S_TCSR_FR_MASK)) & (( \
      (uint32_t)(~(uint32_t)I2S_TCSR_FEF_MASK)) & (( \
      (uint32_t)(~(uint32_t)I2S_TCSR_SEF_MASK)) & ( \
      (uint32_t)(~(uint32_t)I2S_TCSR_WSF_MASK))))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableTxSoftwareReset
   ---------------------------------------------------------------------------- */

/**
 * Resets the internal transmitter logic including the FIFO pointers.
 * @param peripheralBase Peripheral base address.
 * @param State Requested transmitter reset state.
 */
#define I2S_PDD_EnableTxSoftwareReset(peripheralBase, State) ( \
    I2S_TCSR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       I2S_TCSR_REG(peripheralBase)) & (( \
       (uint32_t)(~(uint32_t)I2S_TCSR_SR_MASK)) & (( \
       (uint32_t)(~(uint32_t)I2S_TCSR_FEF_MASK)) & (( \
       (uint32_t)(~(uint32_t)I2S_TCSR_SEF_MASK)) & ( \
       (uint32_t)(~(uint32_t)I2S_TCSR_WSF_MASK))))))) | ( \
      (uint32_t)((uint32_t)(State) << I2S_TCSR_SR_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- GetTxInterruptFlags
   ---------------------------------------------------------------------------- */

/**
 * Returns the value of the status flags.
 * @param peripheralBase Peripheral base address.
 * @return Use constants from group "Transmitter/receiver status flags
 *         constants." for processing return value.
 */
#define I2S_PDD_GetTxInterruptFlags(peripheralBase) ( \
    (uint32_t)(( \
     I2S_TCSR_REG(peripheralBase)) & ( \
     (uint32_t)(( \
      I2S_TCSR_WSF_MASK) | (( \
      I2S_TCSR_SEF_MASK) | (( \
      I2S_TCSR_FEF_MASK) | (( \
      I2S_TCSR_FWF_MASK) | ( \
      I2S_TCSR_FRF_MASK))))))) \
  )

/* ----------------------------------------------------------------------------
   -- ClearTxInterruptFlags
   ---------------------------------------------------------------------------- */

/**
 * Clears transmitter interrupt flags of interrupts specified by Mask.
 * @param peripheralBase Peripheral base address.
 * @param Mask Mask of interrupt clear requests. Use constants from group
 *        "Transmitter/receiver status flags constants.".
 */
#define I2S_PDD_ClearTxInterruptFlags(peripheralBase, Mask) ( \
    I2S_TCSR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       I2S_TCSR_REG(peripheralBase)) & ( \
       (uint32_t)(~(uint32_t)(I2S_TCSR_WSF_MASK | (I2S_TCSR_SEF_MASK | I2S_TCSR_FEF_MASK)))))) | ( \
      (uint32_t)(Mask))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableTxInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables transmitter interrupt requests defined by mask parameter.
 * @param peripheralBase Peripheral base address.
 * @param Mask Mask of interrupt requests. Use constants from group
 *        "Transmitter/receiver interrupt enable/disable constants (for EnableTxInterrupt,
 *        DisableTxInterrupt, EnableRxInterrupt and DisableRxInterrupt macros).".
 */
#define I2S_PDD_EnableTxInterrupt(peripheralBase, Mask) ( \
    I2S_TCSR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       I2S_TCSR_REG(peripheralBase)) & ( \
       (uint32_t)(~(uint32_t)(I2S_TCSR_WSF_MASK | (I2S_TCSR_SEF_MASK | I2S_TCSR_FEF_MASK)))))) | ( \
      (uint32_t)(Mask))) \
  )

/* ----------------------------------------------------------------------------
   -- DisableTxInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables transmitter interrupt requests defined by mask parameter.
 * @param peripheralBase Peripheral base address.
 * @param Mask Mask of interrupt requests. Use constants from group
 *        "Transmitter/receiver interrupt enable/disable constants (for EnableTxInterrupt,
 *        DisableTxInterrupt, EnableRxInterrupt and DisableRxInterrupt macros).".
 */
#define I2S_PDD_DisableTxInterrupt(peripheralBase, Mask) ( \
    I2S_TCSR_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)(Mask)) \
  )

/* ----------------------------------------------------------------------------
   -- EnableTxFifoWarningDma
   ---------------------------------------------------------------------------- */

/**
 * Enables or disables the transmitter FIFO warning DMA.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state of FIFO warning DMA.
 */
#define I2S_PDD_EnableTxFifoWarningDma(peripheralBase, State) ( \
    I2S_TCSR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       I2S_TCSR_REG(peripheralBase)) & (( \
       (uint32_t)(~(uint32_t)I2S_TCSR_FWDE_MASK)) & (( \
       (uint32_t)(~(uint32_t)I2S_TCSR_FEF_MASK)) & (( \
       (uint32_t)(~(uint32_t)I2S_TCSR_SEF_MASK)) & ( \
       (uint32_t)(~(uint32_t)I2S_TCSR_WSF_MASK))))))) | ( \
      (uint32_t)((uint32_t)(State) << I2S_TCSR_FWDE_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableTxFifoRequestDma
   ---------------------------------------------------------------------------- */

/**
 * Enables or disables the transmitter FIFO request DMA.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state of FIFO request DMA.
 */
#define I2S_PDD_EnableTxFifoRequestDma(peripheralBase, State) ( \
    I2S_TCSR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       I2S_TCSR_REG(peripheralBase)) & (( \
       (uint32_t)(~(uint32_t)I2S_TCSR_FRDE_MASK)) & (( \
       (uint32_t)(~(uint32_t)I2S_TCSR_FEF_MASK)) & (( \
       (uint32_t)(~(uint32_t)I2S_TCSR_SEF_MASK)) & ( \
       (uint32_t)(~(uint32_t)I2S_TCSR_WSF_MASK))))))) | ( \
      (uint32_t)(State))) \
  )

/* ----------------------------------------------------------------------------
   -- SetTxFifoWatermark
   ---------------------------------------------------------------------------- */

/**
 * Sets the transmitter FIFO watermark.
 * @param peripheralBase Peripheral base address.
 * @param Value Transmitter FIFO watermark. Use constants from group
 *        "Transmitter watermark constants (for SetTxFifoWatermark macro).".
 */
#define I2S_PDD_SetTxFifoWatermark(peripheralBase, Value) ( \
    I2S_TCR1_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(I2S_TCR1_REG(peripheralBase) & (uint32_t)(~(uint32_t)I2S_TCR1_TFW_MASK))) | ( \
      (uint32_t)(Value))) \
  )

/* ----------------------------------------------------------------------------
   -- SetTxSynchronousMode
   ---------------------------------------------------------------------------- */

/**
 * Sets transmitter asynchronous or synchronous modes of operation.
 * @param peripheralBase Peripheral base address.
 * @param Mode Transmit synchronous mode value. Use constants from group
 *        "Clocking transmitter mode constants (for SetTxSynchronousMode macro).".
 */
#define I2S_PDD_SetTxSynchronousMode(peripheralBase, Mode) ( \
    I2S_TCR2_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(I2S_TCR2_REG(peripheralBase) & (uint32_t)(~(uint32_t)I2S_TCR2_SYNC_MASK))) | ( \
      (uint32_t)((uint32_t)(Mode) << I2S_TCR2_SYNC_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableTxBitClockSwap
   ---------------------------------------------------------------------------- */

/**
 * Enables or disables the transmitter swap bit clock source.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state of swap bit clock source.
 */
#define I2S_PDD_EnableTxBitClockSwap(peripheralBase, State) ( \
    I2S_TCR2_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(I2S_TCR2_REG(peripheralBase) & (uint32_t)(~(uint32_t)I2S_TCR2_BCS_MASK))) | ( \
      (uint32_t)((uint32_t)(State) << I2S_TCR2_BCS_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- SetTxBitClockInput
   ---------------------------------------------------------------------------- */

/**
 * Sets transmitter internal logic bit clock input.
 * @param peripheralBase Peripheral base address.
 * @param Source Transmitter internal logic bit clock input value. The user
 *        should use one from the enumerated values.
 */
#define I2S_PDD_SetTxBitClockInput(peripheralBase, Source) ( \
    I2S_TCR2_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(I2S_TCR2_REG(peripheralBase) & (uint32_t)(~(uint32_t)I2S_TCR2_BCI_MASK))) | ( \
      (uint32_t)(Source))) \
  )

/* ----------------------------------------------------------------------------
   -- SetTxBitClockSource
   ---------------------------------------------------------------------------- */

/**
 * Sets transmitter bit clock source.
 * @param peripheralBase Peripheral base address.
 * @param ClkSource Transmit bit clock source value. Use constants from group
 *        "Clocking transmitter mode constants (for SetTxBitClockSource,
 *        SetRxBitClockSource macro).".
 */
#define I2S_PDD_SetTxBitClockSource(peripheralBase, ClkSource) ( \
    I2S_TCR2_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(I2S_TCR2_REG(peripheralBase) & (uint32_t)(~(uint32_t)I2S_TCR2_MSEL_MASK))) | ( \
      (uint32_t)((uint32_t)(ClkSource) << I2S_TCR2_MSEL_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- SetTxBitClockPolarity
   ---------------------------------------------------------------------------- */

/**
 * Sets transmitter bit clock polarity.
 * @param peripheralBase Peripheral base address.
 * @param Polarity Transmitter bit clock polarity value. The user should use one
 *        from the enumerated values.
 */
#define I2S_PDD_SetTxBitClockPolarity(peripheralBase, Polarity) ( \
    I2S_TCR2_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(I2S_TCR2_REG(peripheralBase) & (uint32_t)(~(uint32_t)I2S_TCR2_BCP_MASK))) | ( \
      (uint32_t)(Polarity))) \
  )

/* ----------------------------------------------------------------------------
   -- SetTxBitClockDirection
   ---------------------------------------------------------------------------- */

/**
 * Sets the transmitter bit clock PIN direction.
 * @param peripheralBase Peripheral base address.
 * @param Direction Transmitter bit clock direction value. The user should use
 *        one from the enumerated values.
 */
#define I2S_PDD_SetTxBitClockDirection(peripheralBase, Direction) ( \
    I2S_TCR2_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(I2S_TCR2_REG(peripheralBase) & (uint32_t)(~(uint32_t)I2S_TCR2_BCD_MASK))) | ( \
      (uint32_t)(Direction))) \
  )

/* ----------------------------------------------------------------------------
   -- SetTxBitClockDivider
   ---------------------------------------------------------------------------- */

/**
 * Sets the transmitter bit clock divider value.
 * @param peripheralBase Peripheral base address.
 * @param Value Bit clock divider value[0..255].
 */
#define I2S_PDD_SetTxBitClockDivider(peripheralBase, Value) ( \
    I2S_TCR2_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(I2S_TCR2_REG(peripheralBase) & (uint32_t)(~(uint32_t)I2S_TCR2_DIV_MASK))) | ( \
      (uint32_t)(Value))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableTxDataChannelMask
   ---------------------------------------------------------------------------- */

/**
 * Enables the transmitter data channel defined by mask parameter.
 * @param peripheralBase Peripheral base address.
 * @param Mask Transmitter data channel mask value.
 */
#define I2S_PDD_EnableTxDataChannelMask(peripheralBase, Mask) ( \
    I2S_TCR3_REG(peripheralBase) |= \
     (uint32_t)((uint32_t)(Mask) << I2S_TCR3_TCE_SHIFT) \
  )

/* ----------------------------------------------------------------------------
   -- DisableTxDataChannelMask
   ---------------------------------------------------------------------------- */

/**
 * Disables the transmitter data channel defined by mask parameter.
 * @param peripheralBase Peripheral base address.
 * @param Mask Transmitter data channel mask value.
 */
#define I2S_PDD_DisableTxDataChannelMask(peripheralBase, Mask) ( \
    I2S_TCR3_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)((uint32_t)(Mask) << I2S_TCR3_TCE_SHIFT)) \
  )

/* ----------------------------------------------------------------------------
   -- SetTxFifoWordFlag
   ---------------------------------------------------------------------------- */

/**
 * Configures which word the start of word flag is set.
 * @param peripheralBase Peripheral base address.
 * @param Value Word flag configuration. Use constants from group "Transmitter
 *        or receiver word flag configuration constants.".
 */
#define I2S_PDD_SetTxFifoWordFlag(peripheralBase, Value) ( \
    I2S_TCR3_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(I2S_TCR3_REG(peripheralBase) & (uint32_t)(~(uint32_t)I2S_TCR3_WDFL_MASK))) | ( \
      (uint32_t)(Value))) \
  )

/* ----------------------------------------------------------------------------
   -- SetTxFrameSize
   ---------------------------------------------------------------------------- */

/**
 * Configures the number of words in each frame.
 * @param peripheralBase Peripheral base address.
 * @param Value Frame size. Use constants from group "Transmitter or receiver
 *        frame size constants.".
 */
#define I2S_PDD_SetTxFrameSize(peripheralBase, Value) ( \
    I2S_TCR4_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(I2S_TCR4_REG(peripheralBase) & (uint32_t)(~(uint32_t)I2S_TCR4_FRSZ_MASK))) | ( \
      (uint32_t)((uint32_t)(Value) << I2S_TCR4_FRSZ_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- SetTxSyncWidth
   ---------------------------------------------------------------------------- */

/**
 * Configures the length of the frame sync in number of bit clocks.
 * @param peripheralBase Peripheral base address.
 * @param Value Sync width. Use constants from group "Transmitter or receiver
 *        sync width constants.".
 */
#define I2S_PDD_SetTxSyncWidth(peripheralBase, Value) ( \
    I2S_TCR4_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(I2S_TCR4_REG(peripheralBase) & (uint32_t)(~(uint32_t)I2S_TCR4_SYWD_MASK))) | ( \
      (uint32_t)((uint32_t)(Value) << I2S_TCR4_SYWD_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- SetTxShiftDirection
   ---------------------------------------------------------------------------- */

/**
 * Specifies whether the LSB or the MSB is transmitted first.
 * @param peripheralBase Peripheral base address.
 * @param Direction Bit shift order value. The user should use one from the
 *        enumerated values.
 */
#define I2S_PDD_SetTxShiftDirection(peripheralBase, Direction) ( \
    I2S_TCR4_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(I2S_TCR4_REG(peripheralBase) & (uint32_t)(~(uint32_t)I2S_TCR4_MF_MASK))) | ( \
      (uint32_t)(Direction))) \
  )

/* ----------------------------------------------------------------------------
   -- SetTxFrameSyncEarly
   ---------------------------------------------------------------------------- */

/**
 * Sets frame sync position in stream.
 * @param peripheralBase Peripheral base address.
 * @param SyncEarly Frame sync position in stream value. The user should use one
 *        from the enumerated values.
 */
#define I2S_PDD_SetTxFrameSyncEarly(peripheralBase, SyncEarly) ( \
    I2S_TCR4_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(I2S_TCR4_REG(peripheralBase) & (uint32_t)(~(uint32_t)I2S_TCR4_FSE_MASK))) | ( \
      (uint32_t)(SyncEarly))) \
  )

/* ----------------------------------------------------------------------------
   -- SetTxFrameSyncPolarity
   ---------------------------------------------------------------------------- */

/**
 * Sets frame sync active polarity.
 * @param peripheralBase Peripheral base address.
 * @param Polarity Active frame sync polarity value. The user should use one
 *        from the enumerated values.
 */
#define I2S_PDD_SetTxFrameSyncPolarity(peripheralBase, Polarity) ( \
    I2S_TCR4_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(I2S_TCR4_REG(peripheralBase) & (uint32_t)(~(uint32_t)I2S_TCR4_FSP_MASK))) | ( \
      (uint32_t)(Polarity))) \
  )

/* ----------------------------------------------------------------------------
   -- SetTxFrameSyncDirection
   ---------------------------------------------------------------------------- */

/**
 * Sets frame sync PIN direction.
 * @param peripheralBase Peripheral base address.
 * @param Direction Frame sync PIN direction value. The user should use one from
 *        the enumerated values.
 */
#define I2S_PDD_SetTxFrameSyncDirection(peripheralBase, Direction) ( \
    I2S_TCR4_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(I2S_TCR4_REG(peripheralBase) & (uint32_t)(~(uint32_t)I2S_TCR4_FSD_MASK))) | ( \
      (uint32_t)(Direction))) \
  )

/* ----------------------------------------------------------------------------
   -- SetTxWordNWidth
   ---------------------------------------------------------------------------- */

/**
 * Configures the number of bits in each word, for each word except the first in
 * the frame.
 * @param peripheralBase Peripheral base address.
 * @param Value Word N width. Use constants from group "Transmitter or receiver
 *        sync width constants.".
 */
#define I2S_PDD_SetTxWordNWidth(peripheralBase, Value) ( \
    I2S_TCR5_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(I2S_TCR5_REG(peripheralBase) & (uint32_t)(~(uint32_t)I2S_TCR5_WNW_MASK))) | ( \
      (uint32_t)((uint32_t)(Value) << I2S_TCR5_WNW_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- SetTxWord0Width
   ---------------------------------------------------------------------------- */

/**
 * Configures the number of bits in the first word in each frame.
 * @param peripheralBase Peripheral base address.
 * @param Value Word 0 width. Use constants from group "Transmitter or receiver
 *        sync width constants.".
 */
#define I2S_PDD_SetTxWord0Width(peripheralBase, Value) ( \
    I2S_TCR5_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(I2S_TCR5_REG(peripheralBase) & (uint32_t)(~(uint32_t)I2S_TCR5_W0W_MASK))) | ( \
      (uint32_t)((uint32_t)(Value) << I2S_TCR5_W0W_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- SetTxFirstBitShifted
   ---------------------------------------------------------------------------- */

/**
 * Configures the bit index for the first bit transmitted for each word in the
 * frame.
 * @param peripheralBase Peripheral base address.
 * @param Value First bit shifted index [0..31].
 */
#define I2S_PDD_SetTxFirstBitShifted(peripheralBase, Value) ( \
    I2S_TCR5_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(I2S_TCR5_REG(peripheralBase) & (uint32_t)(~(uint32_t)I2S_TCR5_FBT_MASK))) | ( \
      (uint32_t)((uint32_t)(Value) << I2S_TCR5_FBT_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- WriteTxDataChannelReg
   ---------------------------------------------------------------------------- */

/**
 * Writes data to the data channel register defined by Index parameter.
 * @param peripheralBase Peripheral base address.
 * @param Index Data channel index.
 * @param Data Value stored to the data channel register.
 */
#define I2S_PDD_WriteTxDataChannelReg(peripheralBase, Index, Data) ( \
    I2S_TDR_REG(peripheralBase,(Index)) = \
     (uint32_t)(Data) \
  )

/* ----------------------------------------------------------------------------
   -- GetTxDataChannelRegAddress
   ---------------------------------------------------------------------------- */

/**
 * Returns the address of the data channel register defined by Index parameter.
 * @param peripheralBase Peripheral base address.
 * @param Index Data channel index.
 */
#define I2S_PDD_GetTxDataChannelRegAddress(peripheralBase, Index) ( \
    (uint32_t)&I2S_TDR_REG(peripheralBase,(Index)) \
  )

/* ----------------------------------------------------------------------------
   -- GetTxChannelWriteFifoPointer
   ---------------------------------------------------------------------------- */

/**
 * Returns the FIFO write pointer for transmit data channel defined by Index
 * parameter.
 * @param peripheralBase Peripheral base address.
 * @param Index Data channel index.
 */
#define I2S_PDD_GetTxChannelWriteFifoPointer(peripheralBase, Index) ( \
    (uint8_t)(( \
     (uint32_t)(I2S_TFR_REG(peripheralBase,(Index)) & I2S_TFR_WFP_MASK)) >> ( \
     I2S_TFR_WFP_SHIFT)) \
  )

/* ----------------------------------------------------------------------------
   -- GetTxChannelReadFifoPointer
   ---------------------------------------------------------------------------- */

/**
 * Returns the FIFO read pointer for transmit data channel defined by Index
 * parameter.
 * @param peripheralBase Peripheral base address.
 * @param Index Data channel index.
 */
#define I2S_PDD_GetTxChannelReadFifoPointer(peripheralBase, Index) ( \
    (uint8_t)(I2S_TFR_REG(peripheralBase,(Index)) & I2S_TFR_RFP_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- WriteTxTimeSlotMaskReg
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)))
/**
 * Transmit word mask.
 * @param peripheralBase Peripheral base address.
 * @param Mask Value stored to the transmit time slot register.
 */
  #define I2S_PDD_WriteTxTimeSlotMaskReg(peripheralBase, Mask) ( \
      I2S_TMR_REG(peripheralBase) = \
       (uint32_t)(( \
        (uint32_t)(I2S_TMR_REG(peripheralBase) & (uint32_t)(~(uint32_t)I2S_TMR_TWM_MASK))) | ( \
        (uint32_t)(Mask))) \
    )
#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10F12)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20F12)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK52D10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_PCK20L4)) */
/**
 * Transmit word mask.
 * @param peripheralBase Peripheral base address.
 * @param Mask Value stored to the transmit time slot register.
 */
  #define I2S_PDD_WriteTxTimeSlotMaskReg(peripheralBase, Mask) ( \
      I2S_TMR_REG(peripheralBase) = \
       (uint32_t)(Mask) \
    )
#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10F12)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20F12)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK52D10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_PCK20L4)) */

/* ----------------------------------------------------------------------------
   -- EnableRxDevice
   ---------------------------------------------------------------------------- */

/**
 * Enables or disables the receiver.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state of receiver.
 */
#define I2S_PDD_EnableRxDevice(peripheralBase, State) ( \
    ((State) == PDD_ENABLE) ? ( \
      I2S_RCSR_REG(peripheralBase) = \
       (uint32_t)(( \
        (uint32_t)(I2S_RCSR_REG(peripheralBase) | I2S_RCSR_RE_MASK)) & (( \
        (uint32_t)(~(uint32_t)I2S_RCSR_FEF_MASK)) & (( \
        (uint32_t)(~(uint32_t)I2S_RCSR_SEF_MASK)) & ( \
        (uint32_t)(~(uint32_t)I2S_RCSR_WSF_MASK)))))) : ( \
      I2S_RCSR_REG(peripheralBase) &= \
       (uint32_t)(( \
        (uint32_t)(~(uint32_t)I2S_RCSR_RE_MASK)) & (( \
        (uint32_t)(~(uint32_t)I2S_RCSR_BCE_MASK)) & (( \
        (uint32_t)(~(uint32_t)I2S_RCSR_FEF_MASK)) & (( \
        (uint32_t)(~(uint32_t)I2S_RCSR_SEF_MASK)) & ( \
        (uint32_t)(~(uint32_t)I2S_RCSR_WSF_MASK))))))) \
  )

/* ----------------------------------------------------------------------------
   -- GetRxDeviceState
   ---------------------------------------------------------------------------- */

/**
 * Returns receiver enable/disable status.
 * @param peripheralBase Peripheral base address.
 */
#define I2S_PDD_GetRxDeviceState(peripheralBase) ( \
    (( \
      (uint8_t)(( \
       (uint32_t)(I2S_RCSR_REG(peripheralBase) & I2S_RCSR_RE_MASK)) >> ( \
       I2S_RCSR_RE_SHIFT))) == ( \
      0x1U)) ? ( \
      PDD_ENABLE) : ( \
      PDD_DISABLE) \
  )

/* ----------------------------------------------------------------------------
   -- GetRxBitClockState
   ---------------------------------------------------------------------------- */

/**
 * Returns receiver bit clock enable/disable status.
 * @param peripheralBase Peripheral base address.
 */
#define I2S_PDD_GetRxBitClockState(peripheralBase) ( \
    (( \
      (uint8_t)(( \
       (uint32_t)(I2S_RCSR_REG(peripheralBase) & I2S_RCSR_BCE_MASK)) >> ( \
       I2S_RCSR_BCE_SHIFT))) == ( \
      0x1U)) ? ( \
      PDD_ENABLE) : ( \
      PDD_DISABLE) \
  )

/* ----------------------------------------------------------------------------
   -- EnableRxInStopMode
   ---------------------------------------------------------------------------- */

/**
 * Enables or disables receiver operation in stop mode.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state in stop mode.
 */
#define I2S_PDD_EnableRxInStopMode(peripheralBase, State) ( \
    I2S_RCSR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       I2S_RCSR_REG(peripheralBase)) & (( \
       (uint32_t)(~(uint32_t)I2S_RCSR_STOPE_MASK)) & (( \
       (uint32_t)(~(uint32_t)I2S_RCSR_FEF_MASK)) & (( \
       (uint32_t)(~(uint32_t)I2S_RCSR_SEF_MASK)) & ( \
       (uint32_t)(~(uint32_t)I2S_RCSR_WSF_MASK))))))) | ( \
      (uint32_t)((uint32_t)(State) << I2S_RCSR_STOPE_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableRxInDebugMode
   ---------------------------------------------------------------------------- */

/**
 * Enables or disables receiver operation in debug mode.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state in debug mode.
 */
#define I2S_PDD_EnableRxInDebugMode(peripheralBase, State) ( \
    I2S_RCSR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       I2S_RCSR_REG(peripheralBase)) & (( \
       (uint32_t)(~(uint32_t)I2S_RCSR_DBGE_MASK)) & (( \
       (uint32_t)(~(uint32_t)I2S_RCSR_FEF_MASK)) & (( \
       (uint32_t)(~(uint32_t)I2S_RCSR_SEF_MASK)) & ( \
       (uint32_t)(~(uint32_t)I2S_RCSR_WSF_MASK))))))) | ( \
      (uint32_t)((uint32_t)(State) << I2S_RCSR_DBGE_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableRxBitClock
   ---------------------------------------------------------------------------- */

/**
 * Enables or disables the receive bit clock, separately from the receive enable.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state of Rx bit clock.
 */
#define I2S_PDD_EnableRxBitClock(peripheralBase, State) ( \
    I2S_RCSR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       I2S_RCSR_REG(peripheralBase)) & (( \
       (uint32_t)(~(uint32_t)I2S_RCSR_BCE_MASK)) & (( \
       (uint32_t)(~(uint32_t)I2S_RCSR_FEF_MASK)) & (( \
       (uint32_t)(~(uint32_t)I2S_RCSR_SEF_MASK)) & ( \
       (uint32_t)(~(uint32_t)I2S_RCSR_WSF_MASK))))))) | ( \
      (uint32_t)((uint32_t)(State) << I2S_RCSR_BCE_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- RxFifoReset
   ---------------------------------------------------------------------------- */

/**
 * Resets the receiver FIFO pointers.
 * @param peripheralBase Peripheral base address.
 */
#define I2S_PDD_RxFifoReset(peripheralBase) ( \
    I2S_RCSR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(I2S_RCSR_REG(peripheralBase) | I2S_RCSR_FR_MASK)) & (( \
      (uint32_t)(~(uint32_t)I2S_RCSR_FEF_MASK)) & (( \
      (uint32_t)(~(uint32_t)I2S_RCSR_SEF_MASK)) & ( \
      (uint32_t)(~(uint32_t)I2S_RCSR_WSF_MASK))))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableRxSoftwareReset
   ---------------------------------------------------------------------------- */

/**
 * Resets the internal receiver logic including the FIFO pointers.
 * @param peripheralBase Peripheral base address.
 * @param State Requested receiver reset state.
 */
#define I2S_PDD_EnableRxSoftwareReset(peripheralBase, State) ( \
    I2S_RCSR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       I2S_RCSR_REG(peripheralBase)) & (( \
       (uint32_t)(~(uint32_t)I2S_RCSR_SR_MASK)) & (( \
       (uint32_t)(~(uint32_t)I2S_RCSR_FEF_MASK)) & (( \
       (uint32_t)(~(uint32_t)I2S_RCSR_SEF_MASK)) & ( \
       (uint32_t)(~(uint32_t)I2S_RCSR_WSF_MASK))))))) | ( \
      (uint32_t)((uint32_t)(State) << I2S_RCSR_SR_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- GetRxInterruptFlags
   ---------------------------------------------------------------------------- */

/**
 * Returns the value of the status flags.
 * @param peripheralBase Peripheral base address.
 * @return Use constants from group "Transmitter/receiver status flags
 *         constants." for processing return value.
 */
#define I2S_PDD_GetRxInterruptFlags(peripheralBase) ( \
    (uint32_t)(( \
     I2S_RCSR_REG(peripheralBase)) & ( \
     (uint32_t)(( \
      I2S_RCSR_WSF_MASK) | (( \
      I2S_RCSR_SEF_MASK) | (( \
      I2S_RCSR_FEF_MASK) | (( \
      I2S_RCSR_FWF_MASK) | ( \
      I2S_RCSR_FRF_MASK))))))) \
  )

/* ----------------------------------------------------------------------------
   -- ClearRxInterruptFlags
   ---------------------------------------------------------------------------- */

/**
 * Clears receiver interrupt flags of interrupts specified by Mask.
 * @param peripheralBase Peripheral base address.
 * @param Mask Mask of interrupt clear requests. Use constants from group
 *        "Transmitter/receiver status flags constants.".
 */
#define I2S_PDD_ClearRxInterruptFlags(peripheralBase, Mask) ( \
    I2S_RCSR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       I2S_RCSR_REG(peripheralBase)) & ( \
       (uint32_t)(~(uint32_t)(I2S_RCSR_WSF_MASK | (I2S_RCSR_SEF_MASK | I2S_RCSR_FEF_MASK)))))) | ( \
      (uint32_t)(Mask))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableRxInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables receiver interrupt requests defined by mask parameter.
 * @param peripheralBase Peripheral base address.
 * @param Mask Mask of interrupt requests. Use constants from group
 *        "Transmitter/receiver interrupt enable/disable constants (for EnableTxInterrupt,
 *        DisableTxInterrupt, EnableRxInterrupt and DisableRxInterrupt macros).".
 */
#define I2S_PDD_EnableRxInterrupt(peripheralBase, Mask) ( \
    I2S_RCSR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       I2S_RCSR_REG(peripheralBase)) & ( \
       (uint32_t)(~(uint32_t)(I2S_RCSR_WSF_MASK | (I2S_RCSR_SEF_MASK | I2S_RCSR_FEF_MASK)))))) | ( \
      (uint32_t)(Mask))) \
  )

/* ----------------------------------------------------------------------------
   -- DisableRxInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables receiver interrupt requests defined by mask parameter.
 * @param peripheralBase Peripheral base address.
 * @param Mask Mask of interrupt requests. Use constants from group
 *        "Transmitter/receiver interrupt enable/disable constants (for EnableTxInterrupt,
 *        DisableTxInterrupt, EnableRxInterrupt and DisableRxInterrupt macros).".
 */
#define I2S_PDD_DisableRxInterrupt(peripheralBase, Mask) ( \
    I2S_RCSR_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)(Mask)) \
  )

/* ----------------------------------------------------------------------------
   -- EnableRxFifoWarningDma
   ---------------------------------------------------------------------------- */

/**
 * Enables or disables the receiver FIFO warning DMA.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state of FIFO warning DMA.
 */
#define I2S_PDD_EnableRxFifoWarningDma(peripheralBase, State) ( \
    I2S_RCSR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       I2S_RCSR_REG(peripheralBase)) & (( \
       (uint32_t)(~(uint32_t)I2S_RCSR_FWDE_MASK)) & (( \
       (uint32_t)(~(uint32_t)I2S_RCSR_FEF_MASK)) & (( \
       (uint32_t)(~(uint32_t)I2S_RCSR_SEF_MASK)) & ( \
       (uint32_t)(~(uint32_t)I2S_RCSR_WSF_MASK))))))) | ( \
      (uint32_t)((uint32_t)(State) << I2S_RCSR_FWDE_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableRxFifoRequestDma
   ---------------------------------------------------------------------------- */

/**
 * Enables or disables the receiver FIFO request DMA.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state of FIFO request DMA.
 */
#define I2S_PDD_EnableRxFifoRequestDma(peripheralBase, State) ( \
    I2S_RCSR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       I2S_RCSR_REG(peripheralBase)) & (( \
       (uint32_t)(~(uint32_t)I2S_RCSR_FRDE_MASK)) & (( \
       (uint32_t)(~(uint32_t)I2S_RCSR_FEF_MASK)) & (( \
       (uint32_t)(~(uint32_t)I2S_RCSR_SEF_MASK)) & ( \
       (uint32_t)(~(uint32_t)I2S_RCSR_WSF_MASK))))))) | ( \
      (uint32_t)(State))) \
  )

/* ----------------------------------------------------------------------------
   -- SetRxFifoWatermark
   ---------------------------------------------------------------------------- */

/**
 * Sets the receiver FIFO watermark.
 * @param peripheralBase Peripheral base address.
 * @param Value Receiver FIFO watermark. Use constants from group "Receiver
 *        watermark constants (for SetRxFifoWatermark macro).".
 */
#define I2S_PDD_SetRxFifoWatermark(peripheralBase, Value) ( \
    I2S_RCR1_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(I2S_RCR1_REG(peripheralBase) & (uint32_t)(~(uint32_t)I2S_RCR1_RFW_MASK))) | ( \
      (uint32_t)(Value))) \
  )

/* ----------------------------------------------------------------------------
   -- SetRxSynchronousMode
   ---------------------------------------------------------------------------- */

/**
 * Sets receiver asynchronous or synchronous modes of operation.
 * @param peripheralBase Peripheral base address.
 * @param Mode Receive synchronous mode value. Use constants from group
 *        "Clocking transmitter mode constants (for SetRxSynchronousMode macro).".
 */
#define I2S_PDD_SetRxSynchronousMode(peripheralBase, Mode) ( \
    I2S_RCR2_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(I2S_RCR2_REG(peripheralBase) & (uint32_t)(~(uint32_t)I2S_RCR2_SYNC_MASK))) | ( \
      (uint32_t)((uint32_t)(Mode) << I2S_RCR2_SYNC_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableRxBitClockSwap
   ---------------------------------------------------------------------------- */

/**
 * Enables or disables the receiver swap bit clock source.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state of swap bit clock source.
 */
#define I2S_PDD_EnableRxBitClockSwap(peripheralBase, State) ( \
    I2S_RCR2_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(I2S_RCR2_REG(peripheralBase) & (uint32_t)(~(uint32_t)I2S_RCR2_BCS_MASK))) | ( \
      (uint32_t)((uint32_t)(State) << I2S_RCR2_BCS_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- SetRxBitClockInput
   ---------------------------------------------------------------------------- */

/**
 * Sets receiver internal logic bit clock input.
 * @param peripheralBase Peripheral base address.
 * @param Source Receiver internal logic bit clock input value. The user should
 *        use one from the enumerated values.
 */
#define I2S_PDD_SetRxBitClockInput(peripheralBase, Source) ( \
    I2S_RCR2_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(I2S_RCR2_REG(peripheralBase) & (uint32_t)(~(uint32_t)I2S_RCR2_BCI_MASK))) | ( \
      (uint32_t)(Source))) \
  )

/* ----------------------------------------------------------------------------
   -- SetRxBitClockSource
   ---------------------------------------------------------------------------- */

/**
 * Sets receiver bit clock source.
 * @param peripheralBase Peripheral base address.
 * @param ClkSource Receive bit clock source value. Use constants from group
 *        "Clocking transmitter mode constants (for SetTxBitClockSource,
 *        SetRxBitClockSource macro).".
 */
#define I2S_PDD_SetRxBitClockSource(peripheralBase, ClkSource) ( \
    I2S_RCR2_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(I2S_RCR2_REG(peripheralBase) & (uint32_t)(~(uint32_t)I2S_RCR2_MSEL_MASK))) | ( \
      (uint32_t)((uint32_t)(ClkSource) << I2S_RCR2_MSEL_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- SetRxBitClockPolarity
   ---------------------------------------------------------------------------- */

/**
 * Sets receiver bit clock polarity.
 * @param peripheralBase Peripheral base address.
 * @param Polarity Receiver bit clock polarity value. The user should use one
 *        from the enumerated values.
 */
#define I2S_PDD_SetRxBitClockPolarity(peripheralBase, Polarity) ( \
    I2S_RCR2_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(I2S_RCR2_REG(peripheralBase) & (uint32_t)(~(uint32_t)I2S_RCR2_BCP_MASK))) | ( \
      (uint32_t)(Polarity))) \
  )

/* ----------------------------------------------------------------------------
   -- SetRxBitClockDirection
   ---------------------------------------------------------------------------- */

/**
 * Sets the receiver bit clock PIN direction.
 * @param peripheralBase Peripheral base address.
 * @param Direction Receiver bit clock direction value. The user should use one
 *        from the enumerated values.
 */
#define I2S_PDD_SetRxBitClockDirection(peripheralBase, Direction) ( \
    I2S_RCR2_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(I2S_RCR2_REG(peripheralBase) & (uint32_t)(~(uint32_t)I2S_RCR2_BCD_MASK))) | ( \
      (uint32_t)(Direction))) \
  )

/* ----------------------------------------------------------------------------
   -- SetRxBitClockDivider
   ---------------------------------------------------------------------------- */

/**
 * Sets the receiver bit clock divider value.
 * @param peripheralBase Peripheral base address.
 * @param Value Bit clock divider value[0..255].
 */
#define I2S_PDD_SetRxBitClockDivider(peripheralBase, Value) ( \
    I2S_RCR2_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(I2S_RCR2_REG(peripheralBase) & (uint32_t)(~(uint32_t)I2S_RCR2_DIV_MASK))) | ( \
      (uint32_t)(Value))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableRxDataChannelMask
   ---------------------------------------------------------------------------- */

/**
 * Enables the receiver data channel defined by mask parameter.
 * @param peripheralBase Peripheral base address.
 * @param Mask Receiver data channel mask value.
 */
#define I2S_PDD_EnableRxDataChannelMask(peripheralBase, Mask) ( \
    I2S_RCR3_REG(peripheralBase) |= \
     (uint32_t)((uint32_t)(Mask) << I2S_RCR3_RCE_SHIFT) \
  )

/* ----------------------------------------------------------------------------
   -- DisableRxDataChannelMask
   ---------------------------------------------------------------------------- */

/**
 * Disables the receiver data channel defined by mask parameter.
 * @param peripheralBase Peripheral base address.
 * @param Mask Receiver data channel mask value.
 */
#define I2S_PDD_DisableRxDataChannelMask(peripheralBase, Mask) ( \
    I2S_RCR3_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)((uint32_t)(Mask) << I2S_RCR3_RCE_SHIFT)) \
  )

/* ----------------------------------------------------------------------------
   -- SetRxFifoWordFlag
   ---------------------------------------------------------------------------- */

/**
 * Configures which word the start of word flag is set.
 * @param peripheralBase Peripheral base address.
 * @param Value Word flag configuration. Use constants from group "Transmitter
 *        or receiver word flag configuration constants.".
 */
#define I2S_PDD_SetRxFifoWordFlag(peripheralBase, Value) ( \
    I2S_RCR3_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(I2S_RCR3_REG(peripheralBase) & (uint32_t)(~(uint32_t)I2S_RCR3_WDFL_MASK))) | ( \
      (uint32_t)(Value))) \
  )

/* ----------------------------------------------------------------------------
   -- SetRxFrameSize
   ---------------------------------------------------------------------------- */

/**
 * Configures the number of words in each frame.
 * @param peripheralBase Peripheral base address.
 * @param Value Frame size. Use constants from group "Transmitter or receiver
 *        frame size constants.".
 */
#define I2S_PDD_SetRxFrameSize(peripheralBase, Value) ( \
    I2S_RCR4_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(I2S_RCR4_REG(peripheralBase) & (uint32_t)(~(uint32_t)I2S_RCR4_FRSZ_MASK))) | ( \
      (uint32_t)((uint32_t)(Value) << I2S_RCR4_FRSZ_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- SetRxSyncWidth
   ---------------------------------------------------------------------------- */

/**
 * Configures the length of the frame sync in number of bit clocks.
 * @param peripheralBase Peripheral base address.
 * @param Value Sync width. Use constants from group "Transmitter or receiver
 *        sync width constants.".
 */
#define I2S_PDD_SetRxSyncWidth(peripheralBase, Value) ( \
    I2S_RCR4_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(I2S_RCR4_REG(peripheralBase) & (uint32_t)(~(uint32_t)I2S_RCR4_SYWD_MASK))) | ( \
      (uint32_t)((uint32_t)(Value) << I2S_RCR4_SYWD_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- SetRxShiftDirection
   ---------------------------------------------------------------------------- */

/**
 * Specifies whether the LSB or the MSB is received first.
 * @param peripheralBase Peripheral base address.
 * @param Direction Bit shift order value. The user should use one from the
 *        enumerated values.
 */
#define I2S_PDD_SetRxShiftDirection(peripheralBase, Direction) ( \
    I2S_RCR4_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(I2S_RCR4_REG(peripheralBase) & (uint32_t)(~(uint32_t)I2S_RCR4_MF_MASK))) | ( \
      (uint32_t)(Direction))) \
  )

/* ----------------------------------------------------------------------------
   -- SetRxFrameSyncEarly
   ---------------------------------------------------------------------------- */

/**
 * Sets frame sync position in stream.
 * @param peripheralBase Peripheral base address.
 * @param SyncEarly Frame sync position in stream value. The user should use one
 *        from the enumerated values.
 */
#define I2S_PDD_SetRxFrameSyncEarly(peripheralBase, SyncEarly) ( \
    I2S_RCR4_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(I2S_RCR4_REG(peripheralBase) & (uint32_t)(~(uint32_t)I2S_RCR4_FSE_MASK))) | ( \
      (uint32_t)(SyncEarly))) \
  )

/* ----------------------------------------------------------------------------
   -- SetRxFrameSyncPolarity
   ---------------------------------------------------------------------------- */

/**
 * Sets frame sync active polarity.
 * @param peripheralBase Peripheral base address.
 * @param Polarity Active frame sync polarity value. The user should use one
 *        from the enumerated values.
 */
#define I2S_PDD_SetRxFrameSyncPolarity(peripheralBase, Polarity) ( \
    I2S_RCR4_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(I2S_RCR4_REG(peripheralBase) & (uint32_t)(~(uint32_t)I2S_RCR4_FSP_MASK))) | ( \
      (uint32_t)(Polarity))) \
  )

/* ----------------------------------------------------------------------------
   -- SetRxFrameSyncDirection
   ---------------------------------------------------------------------------- */

/**
 * Sets frame sync PIN direction.
 * @param peripheralBase Peripheral base address.
 * @param Direction Frame sync PIN direction value. The user should use one from
 *        the enumerated values.
 */
#define I2S_PDD_SetRxFrameSyncDirection(peripheralBase, Direction) ( \
    I2S_RCR4_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(I2S_RCR4_REG(peripheralBase) & (uint32_t)(~(uint32_t)I2S_RCR4_FSD_MASK))) | ( \
      (uint32_t)(Direction))) \
  )

/* ----------------------------------------------------------------------------
   -- SetRxWordNWidth
   ---------------------------------------------------------------------------- */

/**
 * Configures the number of bits in each word, for each word except the first in
 * the frame.
 * @param peripheralBase Peripheral base address.
 * @param Value Word N width. Use constants from group "Transmitter or receiver
 *        sync width constants.".
 */
#define I2S_PDD_SetRxWordNWidth(peripheralBase, Value) ( \
    I2S_RCR5_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(I2S_RCR5_REG(peripheralBase) & (uint32_t)(~(uint32_t)I2S_RCR5_WNW_MASK))) | ( \
      (uint32_t)((uint32_t)(Value) << I2S_RCR5_WNW_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- SetRxWord0Width
   ---------------------------------------------------------------------------- */

/**
 * Configures the number of bits in the first word in each frame.
 * @param peripheralBase Peripheral base address.
 * @param Value Word 0 width. Use constants from group "Transmitter or receiver
 *        sync width constants.".
 */
#define I2S_PDD_SetRxWord0Width(peripheralBase, Value) ( \
    I2S_RCR5_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(I2S_RCR5_REG(peripheralBase) & (uint32_t)(~(uint32_t)I2S_RCR5_W0W_MASK))) | ( \
      (uint32_t)((uint32_t)(Value) << I2S_RCR5_W0W_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- SetRxFirstBitShifted
   ---------------------------------------------------------------------------- */

/**
 * Configures the bit index for the first bit received for each word in the
 * frame.
 * @param peripheralBase Peripheral base address.
 * @param Value First bit shifted index [0..31].
 */
#define I2S_PDD_SetRxFirstBitShifted(peripheralBase, Value) ( \
    I2S_RCR5_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(I2S_RCR5_REG(peripheralBase) & (uint32_t)(~(uint32_t)I2S_RCR5_FBT_MASK))) | ( \
      (uint32_t)((uint32_t)(Value) << I2S_RCR5_FBT_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- ReadRxDataChannelReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the data channel register defined by Index parameter.
 * @param peripheralBase Peripheral base address.
 * @param Index Data channel index.
 */
#define I2S_PDD_ReadRxDataChannelReg(peripheralBase, Index) ( \
    I2S_RDR_REG(peripheralBase,(Index)) \
  )

/* ----------------------------------------------------------------------------
   -- GetRxDataChannelRegAddress
   ---------------------------------------------------------------------------- */

/**
 * Returns the address of the data channel register defined by Index parameter.
 * @param peripheralBase Peripheral base address.
 * @param Index Data channel index.
 */
#define I2S_PDD_GetRxDataChannelRegAddress(peripheralBase, Index) ( \
    (uint32_t)&I2S_RDR_REG(peripheralBase,(Index)) \
  )

/* ----------------------------------------------------------------------------
   -- GetRxChannelWriteFifoPointer
   ---------------------------------------------------------------------------- */

/**
 * Returns the FIFO write pointer for receive data channel defined by Index
 * parameter.
 * @param peripheralBase Peripheral base address.
 * @param Index Data channel index.
 */
#define I2S_PDD_GetRxChannelWriteFifoPointer(peripheralBase, Index) ( \
    (uint8_t)(( \
     (uint32_t)(I2S_RFR_REG(peripheralBase,(Index)) & I2S_RFR_WFP_MASK)) >> ( \
     I2S_RFR_WFP_SHIFT)) \
  )

/* ----------------------------------------------------------------------------
   -- GetRxChannelReadFifoPointer
   ---------------------------------------------------------------------------- */

/**
 * Returns the FIFO read pointer for receive data channel defined by Index
 * parameter.
 * @param peripheralBase Peripheral base address.
 * @param Index Data channel index.
 */
#define I2S_PDD_GetRxChannelReadFifoPointer(peripheralBase, Index) ( \
    (uint8_t)(I2S_RFR_REG(peripheralBase,(Index)) & I2S_RFR_RFP_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- WriteRxTimeSlotMaskReg
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)))
/**
 * Receive word mask.
 * @param peripheralBase Peripheral base address.
 * @param Mask Value stored to the receive time slot register.
 */
  #define I2S_PDD_WriteRxTimeSlotMaskReg(peripheralBase, Mask) ( \
      I2S_RMR_REG(peripheralBase) = \
       (uint32_t)(( \
        (uint32_t)(I2S_RMR_REG(peripheralBase) & (uint32_t)(~(uint32_t)I2S_RMR_RWM_MASK))) | ( \
        (uint32_t)(Mask))) \
    )
#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10F12)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20F12)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK52D10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_PCK20L4)) */
/**
 * Receive word mask.
 * @param peripheralBase Peripheral base address.
 * @param Mask Value stored to the receive time slot register.
 */
  #define I2S_PDD_WriteRxTimeSlotMaskReg(peripheralBase, Mask) ( \
      I2S_RMR_REG(peripheralBase) = \
       (uint32_t)(Mask) \
    )
#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10F12)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20F12)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK52D10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_PCK20L4)) */

/* ----------------------------------------------------------------------------
   -- GetDividerUpdateFlag
   ---------------------------------------------------------------------------- */

/**
 * Returns divider update status flag.
 * @param peripheralBase Peripheral base address.
 * @return Use constants from group "Divider update status flag constant (for
 *         GetDividerUpdateFlag macro)." for processing return value.
 */
#define I2S_PDD_GetDividerUpdateFlag(peripheralBase) ( \
    I2S_MCR_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- EnableMclkDivider
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables the MCLK divider and configures the SAI_MCLK pin as an
 * output.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state of master clock divider.
 */
#define I2S_PDD_EnableMclkDivider(peripheralBase, State) ( \
    I2S_MCR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(I2S_MCR_REG(peripheralBase) & (uint32_t)(~(uint32_t)I2S_MCR_MOE_MASK))) | ( \
      (uint32_t)((uint32_t)(State) << I2S_MCR_MOE_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- GetMclkDividerState
   ---------------------------------------------------------------------------- */

/**
 * Returns Mclk divider enable/disable status.
 * @param peripheralBase Peripheral base address.
 */
#define I2S_PDD_GetMclkDividerState(peripheralBase) ( \
    (( \
      (uint8_t)(( \
       (uint32_t)(I2S_MCR_REG(peripheralBase) & I2S_MCR_MOE_MASK)) >> ( \
       I2S_MCR_MOE_SHIFT))) == ( \
      0x1U)) ? ( \
      PDD_ENABLE) : ( \
      PDD_DISABLE) \
  )

/* ----------------------------------------------------------------------------
   -- SetMclkClockSource
   ---------------------------------------------------------------------------- */

/**
 * Selects the clock input to the MCLK Divider.
 * @param peripheralBase Peripheral base address.
 * @param Source Clock source value. The user should use one from the enumerated
 *        values.
 */
#define I2S_PDD_SetMclkClockSource(peripheralBase, Source) ( \
    I2S_MCR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(I2S_MCR_REG(peripheralBase) & (uint32_t)(~(uint32_t)I2S_MCR_MICS_MASK))) | ( \
      (uint32_t)(Source))) \
  )

/* ----------------------------------------------------------------------------
   -- SetMclkFraction
   ---------------------------------------------------------------------------- */

/**
 * Sets the Mclk fraction factor.
 * @param peripheralBase Peripheral base address.
 * @param Value Fraction value[0..255].
 */
#define I2S_PDD_SetMclkFraction(peripheralBase, Value) ( \
    I2S_MDR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(I2S_MDR_REG(peripheralBase) & (uint32_t)(~(uint32_t)I2S_MDR_FRACT_MASK))) | ( \
      (uint32_t)((uint32_t)(Value) << I2S_MDR_FRACT_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- SetMclkDivider
   ---------------------------------------------------------------------------- */

/**
 * Sets the Mclk divider factor.
 * @param peripheralBase Peripheral base address.
 * @param Value Divider value[0..4095].
 */
#define I2S_PDD_SetMclkDivider(peripheralBase, Value) ( \
    I2S_MDR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(I2S_MDR_REG(peripheralBase) & (uint32_t)(~(uint32_t)I2S_MDR_DIVIDE_MASK))) | ( \
      (uint32_t)(Value))) \
  )

/* ----------------------------------------------------------------------------
   -- WriteMclkDivideRatioReg
   ---------------------------------------------------------------------------- */

/**
 * Writes data to the Mclk divide ratio register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value stored to the Mclk divide ration register.
 */
#define I2S_PDD_WriteMclkDivideRatioReg(peripheralBase, Value) ( \
    I2S_MDR_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- EnableTxDataChannel
   ---------------------------------------------------------------------------- */

/**
 * Enables or disables the transmitter data channel.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state of transmitter data channel.
 */
#define I2S_PDD_EnableTxDataChannel(peripheralBase, State) ( \
    I2S_TCR3_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(I2S_TCR3_REG(peripheralBase) & (uint32_t)(~(uint32_t)I2S_TCR3_TCE_MASK))) | ( \
      (uint32_t)((uint32_t)(State) << I2S_TCR3_TCE_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- WriteTxDataReg
   ---------------------------------------------------------------------------- */

/**
 * Writes data to the data register.
 * @param peripheralBase Peripheral base address.
 * @param Data Value stored to the data register.
 */
#define I2S_PDD_WriteTxDataReg(peripheralBase, Data) ( \
    I2S_TDR_REG(peripheralBase,0U) = \
     (uint32_t)(Data) \
  )

/* ----------------------------------------------------------------------------
   -- GetTxDataRegAddress
   ---------------------------------------------------------------------------- */

/**
 * Returns the address of the data channel register.
 * @param peripheralBase Peripheral base address.
 */
#define I2S_PDD_GetTxDataRegAddress(peripheralBase) ( \
    (uint32_t)&I2S_TDR_REG(peripheralBase,0U) \
  )

/* ----------------------------------------------------------------------------
   -- GetTxWriteFifoPointer
   ---------------------------------------------------------------------------- */

/**
 * Returns the FIFO write pointer for transmit data channel.
 * @param peripheralBase Peripheral base address.
 */
#define I2S_PDD_GetTxWriteFifoPointer(peripheralBase) ( \
    (uint8_t)(( \
     (uint32_t)(I2S_TFR_REG(peripheralBase,0U) & I2S_TFR_WFP_MASK)) >> ( \
     I2S_TFR_WFP_SHIFT)) \
  )

/* ----------------------------------------------------------------------------
   -- GetTxReadFifoPointer
   ---------------------------------------------------------------------------- */

/**
 * Returns the FIFO read pointer for transmit data channel.
 * @param peripheralBase Peripheral base address.
 */
#define I2S_PDD_GetTxReadFifoPointer(peripheralBase) ( \
    (uint8_t)(I2S_TFR_REG(peripheralBase,0U) & I2S_TFR_RFP_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- EnableRxDataChannel
   ---------------------------------------------------------------------------- */

/**
 * Enables or disables the receiver data channel.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state of receiver data channel.
 */
#define I2S_PDD_EnableRxDataChannel(peripheralBase, State) ( \
    I2S_RCR3_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(I2S_RCR3_REG(peripheralBase) & (uint32_t)(~(uint32_t)I2S_RCR3_RCE_MASK))) | ( \
      (uint32_t)((uint32_t)(State) << I2S_RCR3_RCE_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- ReadRxDataReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the data register.
 * @param peripheralBase Peripheral base address.
 */
#define I2S_PDD_ReadRxDataReg(peripheralBase) ( \
    I2S_RDR_REG(peripheralBase,0U) \
  )

/* ----------------------------------------------------------------------------
   -- GetRxDataRegAddress
   ---------------------------------------------------------------------------- */

/**
 * Returns the address of the data channel register.
 * @param peripheralBase Peripheral base address.
 */
#define I2S_PDD_GetRxDataRegAddress(peripheralBase) ( \
    (uint32_t)&I2S_RDR_REG(peripheralBase,0U) \
  )

/* ----------------------------------------------------------------------------
   -- GetRxWriteFifoPointer
   ---------------------------------------------------------------------------- */

/**
 * Returns the FIFO write pointer for receive data channel.
 * @param peripheralBase Peripheral base address.
 */
#define I2S_PDD_GetRxWriteFifoPointer(peripheralBase) ( \
    (uint8_t)(( \
     (uint32_t)(I2S_RFR_REG(peripheralBase,0U) & I2S_RFR_WFP_MASK)) >> ( \
     I2S_RFR_WFP_SHIFT)) \
  )

/* ----------------------------------------------------------------------------
   -- GetRxReadFifoPointer
   ---------------------------------------------------------------------------- */

/**
 * Returns the FIFO read pointer for receive data channel.
 * @param peripheralBase Peripheral base address.
 */
#define I2S_PDD_GetRxReadFifoPointer(peripheralBase) ( \
    (uint8_t)(I2S_RFR_REG(peripheralBase,0U) & I2S_RFR_RFP_MASK) \
  )
#endif  /* #if defined(SAI_PDD_H_) */

/* SAI_PDD.h, eof. */
