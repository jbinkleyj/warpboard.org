/*
  PDD layer implementation for peripheral type ENET
  (C) 2010 Freescale, Inc. All rights reserved.

  This file is static and it is generated from API-Factory
*/

#if !defined(ENET_PDD_H_)
#define ENET_PDD_H_

/* ----------------------------------------------------------------------------
   -- Test if supported MCU is active
   ---------------------------------------------------------------------------- */

#if !defined(MCU_ACTIVE)
  // No MCU is active
  #error ENET PDD library: No derivative is active. Place proper #include with PDD memory map before including PDD library.
#elif \
      !defined(MCU_MK52D10) /* ENET */ && \
      !defined(MCU_MK52DZ10) /* ENET */ && \
      !defined(MCU_MK53D10) /* ENET */ && \
      !defined(MCU_MK53DZ10) /* ENET */ && \
      !defined(MCU_MK60D10) /* ENET */ && \
      !defined(MCU_MK60F12) /* ENET */ && \
      !defined(MCU_MK60F15) /* ENET */ && \
      !defined(MCU_MK60DZ10) /* ENET */ && \
      !defined(MCU_MK60N512VMD100) /* ENET */ && \
      !defined(MCU_MK61F12) /* ENET */ && \
      !defined(MCU_MK61F15) /* ENET */ && \
      !defined(MCU_MK70F12) /* ENET */ && \
      !defined(MCU_MK70F15) /* ENET */
  // Unsupported MCU is active
  #error ENET PDD library: Unsupported derivative is active.
#endif

#include "PDD_Types.h"

/* ----------------------------------------------------------------------------
   -- Method symbol definitions
   ---------------------------------------------------------------------------- */

/* Interrupt masks */
#define ENET_PDD_BABBLING_RX_ERROR_INT ENET_EIR_BABR_MASK /**< Babbling receive error interrupt. */
#define ENET_PDD_BABBLING_TX_ERROR_INT ENET_EIR_BABT_MASK /**< Babbling transmit error interrupt. */
#define ENET_PDD_GRACEFUL_STOP_COMPLETE_INT ENET_EIR_GRA_MASK /**< Graceful stop complete interrupt. */
#define ENET_PDD_TX_FRAME_INT ENET_EIR_TXF_MASK  /**< Transmit frame interrupt. */
#define ENET_PDD_TX_BUFFER_INT ENET_EIR_TXB_MASK /**< Transmit buffer interrupt. */
#define ENET_PDD_RX_FRAME_INT ENET_EIR_RXF_MASK  /**< Receive frame interrupt. */
#define ENET_PDD_RX_BUFFER_INT ENET_EIR_RXB_MASK /**< Receive buffer interrupt. */
#define ENET_PDD_MII_INT ENET_EIR_MII_MASK       /**< MII interrupt. */
#define ENET_PDD_ETHERNET_BUS_ERROR_INT ENET_EIR_EBERR_MASK /**< Ethernet bus error interrupt. */
#define ENET_PDD_LATE_COLLISION_INT ENET_EIR_LC_MASK /**< Late collision interrupt. */
#define ENET_PDD_COLLISION_RETRY_LIMIT_INT ENET_EIR_RL_MASK /**< Collision retry limit interrupt. */
#define ENET_PDD_TX_FIFO_UNDERRUN_INT ENET_EIR_UN_MASK /**< Transmit FIFO underrun interrupt. */
#define ENET_PDD_PAYLOAD_RX_ERROR_INT ENET_EIR_PLR_MASK /**< Payload receive error interrupt. */
#define ENET_PDD_WAKEUP_INT ENET_EIR_WAKEUP_MASK /**< Node wake-up request indication interrupt. */
#define ENET_PDD_TX_TIMESTAMP_AVAIL_INT ENET_EIR_TS_AVAIL_MASK /**< Transmit timestamp available interrupt. */
#define ENET_PDD_TIMER_PERIOD_INT ENET_EIR_TS_TIMER_MASK /**< Timestamp timer interrupt. */

/* Filter modes */
#define ENET_PDD_NONE 0U                         /**< No filtering. */
#define ENET_PDD_UNICAST_AND_MULTICAST_FILTER ENET_RCR_PROM_MASK /**< Unicast and multicast address filtering. */
#define ENET_PDD_BROADCAST_REJECT ENET_RCR_BC_REJ_MASK /**< Broadcast frames rejection. */

/* Message Information Block counter indices */
#define ENET_PDD_RMON_T_DROP 0U                  /**< Count of frames not counted correctly. */
#define ENET_PDD_RMON_T_PACKETS 0x1U             /**< RMON Tx packet count. */
#define ENET_PDD_RMON_T_BC_PKT 0x2U              /**< RMON Tx Broadcast Packets. */
#define ENET_PDD_RMON_T_MC_PKT 0x3U              /**< RMON Tx Multicast Packets. */
#define ENET_PDD_RMON_T_CRC_ALIGN 0x4U           /**< RMON Tx Packets w CRC/Align error. */
#define ENET_PDD_RMON_T_UNDERSIZE 0x5U           /**< RMON Tx Packets < 64 bytes, good crc. */
#define ENET_PDD_RMON_T_OVERSIZE 0x6U            /**< RMON Tx Packets > MAX_FL bytes, good crc. */
#define ENET_PDD_RMON_T_FRAG 0x7U                /**< RMON Tx Packets < 64 bytes, bad crc. */
#define ENET_PDD_RMON_T_JAB 0x8U                 /**< RMON Tx Packets > MAX_FL bytes, bad crc. */
#define ENET_PDD_RMON_T_COL 0x9U                 /**< RMON Tx collision count. */
#define ENET_PDD_RMON_T_P64 0xAU                 /**< RMON Tx 64 byte packets. */
#define ENET_PDD_RMON_T_P65TO127 0xBU            /**< RMON Tx 65 to 127 byte packets. */
#define ENET_PDD_RMON_T_P128TO255 0xCU           /**< RMON Tx 128 to 255 byte packets. */
#define ENET_PDD_RMON_T_P256TO511 0xDU           /**< RMON Tx 256 to 511 byte packets. */
#define ENET_PDD_RMON_T_P512TO1023 0xEU          /**< RMON Tx 512 to 1023 byte packets. */
#define ENET_PDD_RMON_T_P1024TO2047 0xFU         /**< RMON Tx 1024 to 2047 byte packets. */
#define ENET_PDD_RMON_T_P_GTE2048 0x10U          /**< RMON Tx packets w > 2048 bytes. */
#define ENET_PDD_RMON_T_OCTETS 0x11U             /**< RMON Tx Octets. */
#define ENET_PDD_IEEE_T_DROP 0x12U               /**< Count of frames not counted correctly. */
#define ENET_PDD_IEEE_T_FRAME_OK 0x13U           /**< Frames Transmitted OK. */
#define ENET_PDD_IEEE_T_1COL 0x14U               /**< Frames Transmitted with Single Collision. */
#define ENET_PDD_IEEE_T_MCOL 0x15U               /**< Frames Transmitted with Multiple Collisions. */
#define ENET_PDD_IEEE_T_DEF 0x16U                /**< Frames Transmitted after Deferral Delay. */
#define ENET_PDD_IEEE_T_LCOL 0x17U               /**< Frames Transmitted with Late Collision. */
#define ENET_PDD_IEEE_T_EXCOL 0x18U              /**< Frames Transmitted with Excessive Collisions. */
#define ENET_PDD_IEEE_T_MACERR 0x19U             /**< Frames Transmitted with Tx FIFO Underrun. */
#define ENET_PDD_IEEE_T_CSERR 0x1AU              /**< Frames Transmitted with Carrier Sense Error. */
#define ENET_PDD_IEEE_T_SQE 0x1BU                /**< Frames Transmitted with SQE Error. */
#define ENET_PDD_IEEE_T_FDXFC 0x1CU              /**< Flow Control Pause frames transmitted. */
#define ENET_PDD_IEEE_T_OCTETS_OK 0x1DU          /**< Octet count for Frames Transmitted w/o Error. */
#define ENET_PDD_RMON_R_DROP 0x20U               /**< Count of frames not counted correctly. */
#define ENET_PDD_RMON_R_PACKETS 0x21U            /**< RMON Rx packet count. */
#define ENET_PDD_RMON_R_BC_PKT 0x22U             /**< RMON Rx Broadcast Packets. */
#define ENET_PDD_RMON_R_MC_PKT 0x23U             /**< RMON Rx Multicast Packets. */
#define ENET_PDD_RMON_R_CRC_ALIGN 0x24U          /**< RMON Rx Packets w CRC/Align error. */
#define ENET_PDD_RMON_R_UNDERSIZE 0x25U          /**< RMON Rx Packets < 64 bytes, good crc. */
#define ENET_PDD_RMON_R_OVERSIZE 0x26U           /**< RMON Rx Packets > MAX_FL bytes, good crc. */
#define ENET_PDD_RMON_R_FRAG 0x27U               /**< RMON Rx Packets < 64 bytes, bad crc. */
#define ENET_PDD_RMON_R_JAB 0x28U                /**< RMON Rx Packets > MAX_FL bytes, bad crc. */
#define ENET_PDD_RMON_R_RESVD_0 0x29U            /**< Reserved. */
#define ENET_PDD_RMON_R_P64 0x2AU                /**< RMON Rx 64 byte packets. */
#define ENET_PDD_RMON_R_P65TO127 0x2BU           /**< RMON Rx 65 to 127 byte packets. */
#define ENET_PDD_RMON_R_P128TO255 0x2CU          /**< RMON Rx 128 to 255 byte packets. */
#define ENET_PDD_RMON_R_P256TO511 0x2DU          /**< RMON Rx 256 to 511 byte packets. */
#define ENET_PDD_RMON_R_P512TO1023 0x2EU         /**< RMON Rx 512 to 1023 byte packets. */
#define ENET_PDD_RMON_R_P1024TO2047 0x2FU        /**< RMON Rx 1024 to 2047 byte packets. */
#define ENET_PDD_RMON_R_P_GTE2048 0x30U          /**< RMON Rx packets w > 2048 bytes. */
#define ENET_PDD_RMON_R_OCTETS 0x31U             /**< RMON Rx Octets. */
#define ENET_PDD_IEEE_R_DROP 0x32U               /**< Count of frames not counted correctly. */
#define ENET_PDD_IEEE_R_FRAME_OK 0x33U           /**< Frames Received OK. */
#define ENET_PDD_IEEE_R_CRC 0x34U                /**< Frames Received with CRC Error. */
#define ENET_PDD_IEEE_R_ALIGN 0x35U              /**< Frames Received with Alignment Error. */
#define ENET_PDD_IEEE_R_MACERR 0x36U             /**< Receive Fifo Overflow count. */
#define ENET_PDD_IEEE_R_FDXFC 0x37U              /**< Flow Control Pause frames received. */
#define ENET_PDD_IEEE_R_OCTETS_OK 0x38U          /**< Octet count for Frames Rcvd w/o Error  */

/* Control frame types */
#define ENET_PDD_PAUSE ENET_RCR_PAUFWD_MASK      /**< Pause frame. */
#define ENET_PDD_NON_PAUSE ENET_RCR_CFEN_MASK    /**< Control frame other than pause frame. */

/* Received frame processing types */
#define ENET_PDD_CRC_REMOVE ENET_RCR_CRCFWD_MASK /**< Frame CRC removal. */
#define ENET_PDD_PADDING_REMOVE ENET_RCR_PADEN_MASK /**< Frame header padding removal. */

/* Transmit frame processing types */
#define ENET_PDD_CRC_INSERT ENET_TCR_CRCFWD_MASK /**< Frame CRC insertion. */

/* Protocol checksum accelerators */
#define ENET_PDD_INSERT_ON_TX 0x1U               /**< Insert on transmission. */
#define ENET_PDD_DROP_ON_RX 0x2U                 /**< Drop on reception. */

/* FIFO shift types */
#define ENET_PDD_TX_ONLY 0x1U                    /**< On transmission only. */
#define ENET_PDD_RX_ONLY 0x2U                    /**< On reception only. */
#define ENET_PDD_TX_AND_RX 0x3U                  /**< On transmission and reception. */

/* Timer status flags */
#define ENET_PDD_TIMER_CHANNEL_0 ENET_TGSR_TF0_MASK /**< Timer channel 0. */
#define ENET_PDD_TIMER_CHANNEL_1 ENET_TGSR_TF1_MASK /**< Timer channel 1. */
#define ENET_PDD_TIMER_CHANNEL_2 ENET_TGSR_TF2_MASK /**< Timer channel 2. */
#define ENET_PDD_TIMER_CHANNEL_3 ENET_TGSR_TF3_MASK /**< Timer channel 3. */

/* Timer clock sources */
#define ENET_PDD_CORE_SYSTEM_CLOCK 0U            /**< Core/system clock. */
#define ENET_PDD_PLL_FLL_CLOCK 0x1U              /**< PLL or FLL clock. */
#define ENET_PDD_EXTAL_CLOCK 0x2U                /**< Extal clock. */
#define ENET_PDD_EXTERNAL_CLOCK 0x3U             /**< External clock. */

/* MII management frame operation code */
#define ENET_PDD_MII_WRITE 0x10000000U           /**< Write MII register. */
#define ENET_PDD_MII_READ 0x20000000U            /**< Read MII register. */

/* Duplex modes */
#define ENET_PDD_FULL_DUPLEX 0x4U                /**< Full duplex. */
#define ENET_PDD_HALF_DUPLEX 0U                  /**< Half duplex. */

/* Power saving modes */
#define ENET_PDD_SLEEP 0U                        /**< Sleep mode. */
#define ENET_PDD_STOP 0x1U                       /**< Stop mode. */
#define ENET_PDD_RUN 0x2U                        /**< Run mode. */

/* MII modes */
#define ENET_PDD_MII 0U                          /**< MII mode. */
#define ENET_PDD_RMII_10MBIT 0x1U                /**< 10MBit RMII mode. */
#define ENET_PDD_RMII_100MBIT 0x2U               /**< 100MBit RMII mode. */

/* MAC address sources */
#define ENET_PDD_KEEP 0U                         /**< Keep frame MAC address. */
#define ENET_PDD_AUTO 0x1U                       /**< Auto-complete frame MAC address. */
#define ENET_PDD_AUTO_SUPPL0 0x2U                /**< Auto-complete supplemental MAC address 0. */
#define ENET_PDD_AUTO_SUPPL1 0x3U                /**< Auto-complete supplemental MAC address 1. */
#define ENET_PDD_AUTO_SUPPL2 0x4U                /**< Auto-complete supplemental MAC address 2. */
#define ENET_PDD_AUTO_SUPPL3 0x5U                /**< Auto-complete supplemental MAC address 3. */

/* Timer modes */
#define ENET_PDD_DISABLED 0U                     /**< Disabled. */
#define ENET_PDD_INPUT_CAPTURE_RISING_EDGE 0x4U  /**< Input capture on rising edge. */
#define ENET_PDD_INPUT_CAPTURE_FALLING_EDGE 0x8U /**< Input capture on falling edge. */
#define ENET_PDD_INPUT_CAPTURE_BOTH_EDGES 0xCU   /**< Input capture on both edges. */
#define ENET_PDD_OUTPUT_COMPARE_SOFTWARE_ONLY 0x10U /**< Output compare - software only. */
#define ENET_PDD_OUTPUT_COMPARE_TOGGLE_ON_COMPARE 0x14U /**< Output compare - toggle on compare. */
#define ENET_PDD_OUTPUT_COMPARE_CLEAR_ON_COMPARE 0x18U /**< Output compare - clear on compare. */
#define ENET_PDD_OUTPUT_COMPARE_SET_ON_COMPARE 0x1CU /**< Output compare - set on compare. */
#define ENET_PDD_OUTPUT_COMPARE_CLEAR_ON_COMPARE_SET_ON_OVERFLOW 0x28U /**< Output compare - clear on compare, set on overflow. */
#define ENET_PDD_OUTPUT_COMPARE_SET_ON_COMPARE_CLEAR_ON_OVERFLOW 0x24U /**< Output compare - set on compare, clear on overflow. */
#define ENET_PDD_OUTPUT_COMPARE_PULSE_LOW 0x38U  /**< Output compare - pulse low. */
#define ENET_PDD_OUTPUT_COMPARE_PULSE_HIGH 0x3CU /**< Output compare - pulse high. */


/* ----------------------------------------------------------------------------
   -- EnableDevice
   ---------------------------------------------------------------------------- */

/**
 * Enables the device, transmission and reception are possible.
 * @param peripheralBase Peripheral base address.
 */
#define ENET_PDD_EnableDevice(peripheralBase) ( \
    ENET_ECR_REG(peripheralBase) |= \
     ENET_ECR_ETHEREN_MASK \
  )

/* ----------------------------------------------------------------------------
   -- DisableDevice
   ---------------------------------------------------------------------------- */

/**
 * Immediately stops receiving and transmission stops after a bad CRC is
 * appended to any currently transmitted frame. The buffer descriptors for an aborted
 * transmit frame are not updated. The DMA, buffer descriptor, and FIFO control
 * logic are reset including the buffer descriptor and FIFO pointers.
 * @param peripheralBase Peripheral base address.
 */
#define ENET_PDD_DisableDevice(peripheralBase) ( \
    ENET_ECR_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)ENET_ECR_ETHEREN_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- ResetDevice
   ---------------------------------------------------------------------------- */

/**
 * Performs a hardware reset of the device and waits for its completion. All
 * registers take their reset values. Also, any transmission/reception currently in
 * progress is abruptly aborted.
 * @param peripheralBase Peripheral base address.
 */
#define ENET_PDD_ResetDevice(peripheralBase) ( \
    ENET_ECR_REG(peripheralBase) |= \
     ENET_ECR_RESET_MASK \
  )

/* ----------------------------------------------------------------------------
   -- IsResetFinished
   ---------------------------------------------------------------------------- */

/**
 * Indicates whether the reset has finished.
 * @param peripheralBase Peripheral base address.
 */
#define ENET_PDD_IsResetFinished(peripheralBase) ( \
    (uint32_t)(( \
     (uint32_t)(ENET_ECR_REG(peripheralBase) & ENET_ECR_RESET_MASK)) ^ ( \
     ENET_ECR_RESET_MASK)) \
  )

/* ----------------------------------------------------------------------------
   -- EnableTransmission
   ---------------------------------------------------------------------------- */

/**
 * Starts processing the transmit buffer descriptors ring.
 * @param peripheralBase Peripheral base address.
 */
#define ENET_PDD_EnableTransmission(peripheralBase) ( \
    ENET_TDAR_REG(peripheralBase) |= \
     ENET_TDAR_TDAR_MASK \
  )

/* ----------------------------------------------------------------------------
   -- EnableReception
   ---------------------------------------------------------------------------- */

/**
 * Starts processing the receive buffer descriptors ring.
 * @param peripheralBase Peripheral base address.
 */
#define ENET_PDD_EnableReception(peripheralBase) ( \
    ENET_RDAR_REG(peripheralBase) |= \
     ENET_RDAR_RDAR_MASK \
  )

/* ----------------------------------------------------------------------------
   -- EnableInterrupts
   ---------------------------------------------------------------------------- */

/**
 * Enables interrupts specified by the mask.
 * @param peripheralBase Peripheral base address.
 * @param Mask Interrupt mask. Possible values (OR mask from):
 *        ENET_PDD_BABBLING_RX_ERROR_INT, ENET_PDD_BABBLING_TX_ERROR_INT,
 *        ENET_PDD_GRACEFUL_STOP_COMPLETE_INT, ENET_PDD_TX_FRAME_INT, ENET_PDD_TX_BUFFER_INT,
 *        ENET_PDD_RX_FRAME_INT, ENET_PDD_RX_BUFFER_INT, ENET_PDD_MII_INT,
 *        ENET_PDD_ETHERNET_BUS_ERROR_INT, ENET_PDD_LATE_COLLISION_INT,
 *        ENET_PDD_COLLISION_RETRY_LIMIT_INT, ENET_PDD_TX_FIFO_UNDERRUN_INT, ENET_PDD_PAYLOAD_RX_ERROR_INT,
 *        ENET_PDD_WAKEUP_INT, ENET_PDD_TX_TIMESTAMP_AVAIL_INT,
 *        ENET_PDD_TIMER_PERIOD_INT.
 */
#define ENET_PDD_EnableInterrupts(peripheralBase, Mask) ( \
    ENET_EIMR_REG(peripheralBase) |= \
     (uint32_t)(Mask) \
  )

/* ----------------------------------------------------------------------------
   -- DisableInterrupts
   ---------------------------------------------------------------------------- */

/**
 * Disables interrupts specified by the mask.
 * @param peripheralBase Peripheral base address.
 * @param Mask Interrupt mask. Possible values (OR mask from):
 *        ENET_PDD_BABBLING_RX_ERROR_INT, ENET_PDD_BABBLING_TX_ERROR_INT,
 *        ENET_PDD_GRACEFUL_STOP_COMPLETE_INT, ENET_PDD_TX_FRAME_INT, ENET_PDD_TX_BUFFER_INT,
 *        ENET_PDD_RX_FRAME_INT, ENET_PDD_RX_BUFFER_INT, ENET_PDD_MII_INT,
 *        ENET_PDD_ETHERNET_BUS_ERROR_INT, ENET_PDD_LATE_COLLISION_INT,
 *        ENET_PDD_COLLISION_RETRY_LIMIT_INT, ENET_PDD_TX_FIFO_UNDERRUN_INT, ENET_PDD_PAYLOAD_RX_ERROR_INT,
 *        ENET_PDD_WAKEUP_INT, ENET_PDD_TX_TIMESTAMP_AVAIL_INT,
 *        ENET_PDD_TIMER_PERIOD_INT.
 */
#define ENET_PDD_DisableInterrupts(peripheralBase, Mask) ( \
    ENET_EIMR_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)(Mask)) \
  )

/* ----------------------------------------------------------------------------
   -- GetInterruptFlags
   ---------------------------------------------------------------------------- */

/**
 * Returns the interrupt flags. The return value can be masked with predefined
 * macros.
 * @param peripheralBase Peripheral base address.
 */
#define ENET_PDD_GetInterruptFlags(peripheralBase) ( \
    ENET_EIR_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- ClearInterruptFlags
   ---------------------------------------------------------------------------- */

/**
 * Clears the specified interrupt flags.
 * @param peripheralBase Peripheral base address.
 * @param Mask Interrupt mask. Possible values (OR mask from):
 *        ENET_PDD_BABBLING_RX_ERROR_INT, ENET_PDD_BABBLING_TX_ERROR_INT,
 *        ENET_PDD_GRACEFUL_STOP_COMPLETE_INT, ENET_PDD_TX_FRAME_INT, ENET_PDD_TX_BUFFER_INT,
 *        ENET_PDD_RX_FRAME_INT, ENET_PDD_RX_BUFFER_INT, ENET_PDD_MII_INT,
 *        ENET_PDD_ETHERNET_BUS_ERROR_INT, ENET_PDD_LATE_COLLISION_INT,
 *        ENET_PDD_COLLISION_RETRY_LIMIT_INT, ENET_PDD_TX_FIFO_UNDERRUN_INT, ENET_PDD_PAYLOAD_RX_ERROR_INT,
 *        ENET_PDD_WAKEUP_INT, ENET_PDD_TX_TIMESTAMP_AVAIL_INT,
 *        ENET_PDD_TIMER_PERIOD_INT.
 */
#define ENET_PDD_ClearInterruptFlags(peripheralBase, Mask) ( \
    ENET_EIR_REG(peripheralBase) = \
     (uint32_t)(Mask) \
  )

/* ----------------------------------------------------------------------------
   -- SendMIIFrame
   ---------------------------------------------------------------------------- */

/**
 * Performs the specified operation on the MII Management Interface.
 * @param peripheralBase Peripheral base address.
 * @param OpCode Operation code. Possible values (one of): ENET_PDD_MII_READ,
 *        ENET_PDD_MII_WRITE.
 * @param PhyAddr PHY device address. Possible values: 0-31.
 * @param RegAddr Register address within the specified PHY device. Possible
 *        values: 0-31.
 * @param Data MII management frame data written to the PHY register.
 */
#define ENET_PDD_SendMIIFrame(peripheralBase, OpCode, PhyAddr, RegAddr, Data) ( \
    ENET_MMFR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)((uint32_t)0x1U << ENET_MMFR_ST_SHIFT)) | (( \
      (uint32_t)(OpCode)) | (( \
      (uint32_t)((uint32_t)(PhyAddr) << ENET_MMFR_PA_SHIFT)) | (( \
      (uint32_t)((uint32_t)(RegAddr) << ENET_MMFR_RA_SHIFT)) | (( \
      (uint32_t)((uint32_t)0x2U << ENET_MMFR_TA_SHIFT)) | ( \
      (uint32_t)(Data))))))) \
  )

/* ----------------------------------------------------------------------------
   -- RecvMIIFrame
   ---------------------------------------------------------------------------- */

/**
 * Reads the received MII management frame data.
 * @param peripheralBase Peripheral base address.
 * @param Data MII management frame data read from the PHY register.
 */
#define ENET_PDD_RecvMIIFrame(peripheralBase, Data) ( \
    (Data) = (uint16_t)(ENET_MMFR_REG(peripheralBase) & ENET_MMFR_DATA_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- SetMIIHoldtime
   ---------------------------------------------------------------------------- */

/**
 * Sets the MII holdtime on the MDIO output.
 * @param peripheralBase Peripheral base address.
 * @param Holdtime MII holdtime in bus cycle count. Should be at least 10ns.
 *        Possible values: 1-8.
 */
#define ENET_PDD_SetMIIHoldtime(peripheralBase, Holdtime) ( \
    ENET_MSCR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(ENET_MSCR_REG(peripheralBase) & (uint32_t)(~(uint32_t)ENET_MSCR_HOLDTIME_MASK))) | ( \
      (uint32_t)((uint32_t)(Holdtime) << ENET_MSCR_HOLDTIME_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableMIIPreamble
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables the MII preamble to be prepended to the MII management frame.
 * @param peripheralBase Peripheral base address.
 * @param Enable Enable flag. Possible values: PDD_ENABLE, PDD_DISABLE.
 */
#define ENET_PDD_EnableMIIPreamble(peripheralBase, Enable) ( \
    ((uint32_t)(Enable) == 0U) ? ( \
      ENET_MSCR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)ENET_MSCR_DIS_PRE_MASK)) : ( \
      ENET_MSCR_REG(peripheralBase) |= \
       ENET_MSCR_DIS_PRE_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- SetMIISpeed
   ---------------------------------------------------------------------------- */

/**
 * Sets the MII clock speed.
 * @param peripheralBase Peripheral base address.
 * @param Speed MII speed. Relative to the bus clock frequency. Possible values:
 *        0 - turns off the MII management interface, 1-64 - management
 *        interface clock will be set to bus_clock/((value + 1) x 2).
 */
#define ENET_PDD_SetMIISpeed(peripheralBase, Speed) ( \
    ENET_MSCR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       ENET_MSCR_REG(peripheralBase)) & ( \
       (uint32_t)(~(uint32_t)ENET_MSCR_MII_SPEED_MASK)))) | ( \
      (uint32_t)((uint32_t)(Speed) << ENET_MSCR_MII_SPEED_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableFilters
   ---------------------------------------------------------------------------- */

/**
 * Enables selected ethernet address filters. Disables not selected ones.
 * @param peripheralBase Peripheral base address.
 * @param Mask Filter mask. Possible values (OR mask from):
 *        ENET_PDD_UNICAST_AND_MULTICAST_FILTER - enables unicast and multicast address filtering
 *        based on MAC address and address hash tables, ENET_PDD_BROADCAST_REJECT -
 *        enables broadcast frame rejecting.
 */
#define ENET_PDD_EnableFilters(peripheralBase, Mask) ( \
    ENET_RCR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       ENET_RCR_REG(peripheralBase)) & ( \
       (uint32_t)(~(uint32_t)(ENET_RCR_PROM_MASK | ENET_RCR_BC_REJ_MASK))))) | ( \
      (uint32_t)((uint32_t)(Mask) ^ ENET_RCR_PROM_MASK))) \
  )

/* ----------------------------------------------------------------------------
   -- SetDuplexMode
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables transmitting while receiving and vice-versa in the ethernet
 * MAC.
 * @param peripheralBase Peripheral base address.
 * @param Mode Duplex mode to be set. Possible values (one of):
 *        ENET_PDD_FULL_DUPLEX, ENET_PDD_HALF_DUPLEX.
 */
#define ENET_PDD_SetDuplexMode(peripheralBase, Mode) ( \
    (ENET_TCR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(ENET_TCR_REG(peripheralBase) & (uint32_t)(~(uint32_t)ENET_TCR_FDEN_MASK))) | ( \
      (uint32_t)(Mode)))), \
    ( \
     ((Mode) == ENET_PDD_FULL_DUPLEX) ? ( \
      ENET_RCR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)ENET_RCR_DRT_MASK)) : ( \
      ENET_RCR_REG(peripheralBase) |= \
       (uint32_t)((uint32_t)0x1U << ENET_RCR_DRT_SHIFT)) \
    ) \
  )

/* ----------------------------------------------------------------------------
   -- SendPauseFrame
   ---------------------------------------------------------------------------- */

/**
 * Transmits a MAC control PAUSE frame after the current transmission is
 * completed, then resumes the transmission of data frames. This method is only
 * available if flow control is enabled.
 * @param peripheralBase Peripheral base address.
 */
#define ENET_PDD_SendPauseFrame(peripheralBase) ( \
    ENET_TCR_REG(peripheralBase) |= \
     ENET_TCR_TFC_PAUSE_MASK \
  )

/* ----------------------------------------------------------------------------
   -- SetPauseDuration
   ---------------------------------------------------------------------------- */

/**
 * Sets the duration of the PAUSE frame. The PAUSE frame will contain this
 * value. This method is only available if flow control is enabled.
 * @param peripheralBase Peripheral base address.
 * @param Duration Duration of the PAUSE frame.
 */
#define ENET_PDD_SetPauseDuration(peripheralBase, Duration) ( \
    ENET_OPD_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(ENET_OPD_REG(peripheralBase) & (uint32_t)(~(uint32_t)ENET_OPD_PAUSE_DUR_MASK))) | ( \
      (uint32_t)(Duration))) \
  )

/* ----------------------------------------------------------------------------
   -- SetMACAddress
   ---------------------------------------------------------------------------- */

/**
 * Changes the MAC address of the ethernet device.
 * @param peripheralBase Peripheral base address.
 * @param Address MAC address.
 */
#define ENET_PDD_SetMACAddress(peripheralBase, Address) ( \
    (ENET_PALR_REG(peripheralBase) = \
     (uint32_t)(( \
      (Address)[3]) | (( \
      (uint32_t)((uint32_t)((Address)[2]) << 8U)) | (( \
      (uint32_t)((uint32_t)((Address)[1]) << 16U)) | ( \
      (uint32_t)((uint32_t)((Address)[0]) << 24U)))))), \
    (ENET_PAUR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)((uint32_t)((Address)[5]) << 16U)) | ( \
      (uint32_t)((uint32_t)((Address)[4]) << 24U)))) \
  )

/* ----------------------------------------------------------------------------
   -- GetMACAddress
   ---------------------------------------------------------------------------- */

/**
 * Returns the current MAC address of the ethernet device.
 * @param peripheralBase Peripheral base address.
 * @param Address Variable, where the current MAC address of the device will be
 *        stored.
 */
#define ENET_PDD_GetMACAddress(peripheralBase, Address) ( \
    (Address)[0] = (uint8_t)((uint32_t)((uint32_t)ENET_PALR_REG(peripheralBase) >> 24) & 0xFFU), \
    ((Address)[1] = (uint8_t)((uint32_t)((uint32_t)ENET_PALR_REG(peripheralBase) >> 16) & 0xFFU), \
    ((Address)[2] = (uint8_t)((uint32_t)((uint32_t)ENET_PALR_REG(peripheralBase) >>  8) & 0xFFU), \
    ((Address)[3] = (uint8_t)((uint32_t)ENET_PALR_REG(peripheralBase) & 0xFFU), \
    ((Address)[4] = (uint8_t)((uint32_t)((uint32_t)ENET_PAUR_REG(peripheralBase) >> 24) & 0xFFU), \
    (Address)[5] = (uint8_t)((uint32_t)((uint32_t)ENET_PAUR_REG(peripheralBase) >> 16) & 0xFFU))))) \
  )

/* ----------------------------------------------------------------------------
   -- SetUnicastAddrHashTableBit
   ---------------------------------------------------------------------------- */

/**
 * Raises the specified bit in the unicast (individual) address hash table.
 * @param peripheralBase Peripheral base address.
 * @param Index Unicast hash table bit index. Possible values: 0-63.
 */
#define ENET_PDD_SetUnicastAddrHashTableBit(peripheralBase, Index) ( \
    ((uint8_t)((uint8_t)(Index) & 0x20U) == 0U) ? ( \
      ENET_IALR_REG(peripheralBase) |= \
       (uint32_t)((uint32_t)0x1U << (uint8_t)(Index))) : ( \
      ENET_IAUR_REG(peripheralBase) |= \
       (uint32_t)((uint32_t)0x1U << (uint8_t)((uint8_t)(Index) & 0x1FU))) \
  )

/* ----------------------------------------------------------------------------
   -- ClearUnicastAddrHashTable
   ---------------------------------------------------------------------------- */

/**
 * Clears all bits in the unicast (individual) address hash table.
 * @param peripheralBase Peripheral base address.
 */
#define ENET_PDD_ClearUnicastAddrHashTable(peripheralBase) ( \
    (ENET_IALR_REG(peripheralBase) = \
     0U), \
    (ENET_IAUR_REG(peripheralBase) = \
     0U) \
  )

/* ----------------------------------------------------------------------------
   -- SetMulticastAddrHashTableBit
   ---------------------------------------------------------------------------- */

/**
 * Raises the specified bit in the multicast (group) address hash table.
 * @param peripheralBase Peripheral base address.
 * @param Index Multicast hash table bit index. Possible values: 0-63.
 */
#define ENET_PDD_SetMulticastAddrHashTableBit(peripheralBase, Index) ( \
    ((uint8_t)((uint8_t)(Index) & 0x20U) == 0U) ? ( \
      ENET_GALR_REG(peripheralBase) |= \
       (uint32_t)((uint32_t)0x1U << (uint8_t)(Index))) : ( \
      ENET_GAUR_REG(peripheralBase) |= \
       (uint32_t)((uint32_t)0x1U << (uint8_t)((uint8_t)(Index) & 0x1FU))) \
  )

/* ----------------------------------------------------------------------------
   -- ClearMulticastAddrHashTable
   ---------------------------------------------------------------------------- */

/**
 * Clears all bits in the multicast (group) address hash table.
 * @param peripheralBase Peripheral base address.
 */
#define ENET_PDD_ClearMulticastAddrHashTable(peripheralBase) ( \
    (ENET_GALR_REG(peripheralBase) = \
     0U), \
    (ENET_GAUR_REG(peripheralBase) = \
     0U) \
  )

/* ----------------------------------------------------------------------------
   -- SetTxRingStartAddr
   ---------------------------------------------------------------------------- */

/**
 * Sets the start address of the transmit buffer descriptor ring.
 * @param peripheralBase Peripheral base address.
 * @param Address Pointer to the start of the transmit buffer descriptor ring.
 */
#define ENET_PDD_SetTxRingStartAddr(peripheralBase, Address) ( \
    ENET_TDSR_REG(peripheralBase) = \
     (uint32_t)(Address) \
  )

/* ----------------------------------------------------------------------------
   -- SetRxRingStartAddr
   ---------------------------------------------------------------------------- */

/**
 * Sets the start address of the receive buffer descriptor ring.
 * @param peripheralBase Peripheral base address.
 * @param Address Pointer to the start of the receive buffer descriptor ring.
 */
#define ENET_PDD_SetRxRingStartAddr(peripheralBase, Address) ( \
    ENET_RDSR_REG(peripheralBase) = \
     (uint32_t)(Address) \
  )

/* ----------------------------------------------------------------------------
   -- EnableEnhancedBufferDesc
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables enhanced buffer descriptors containing additional
 * information (e.g. timestamps).
 * @param peripheralBase Peripheral base address.
 * @param Enable Enable flag. Possible values: PDD_ENABLE, PDD_DISABLE.
 */
#define ENET_PDD_EnableEnhancedBufferDesc(peripheralBase, Enable) ( \
    ((uint32_t)(Enable) == 0U) ? ( \
      ENET_ECR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)ENET_ECR_EN1588_MASK)) : ( \
      ENET_ECR_REG(peripheralBase) |= \
       ENET_ECR_EN1588_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- EnableDebug
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables MAC freeze mode when the processor is in debug mode.
 * @param peripheralBase Peripheral base address.
 * @param Enable Enable flag. Possible values: PDD_ENABLE, PDD_DISABLE.
 */
#define ENET_PDD_EnableDebug(peripheralBase, Enable) ( \
    ((uint32_t)(Enable) == 0U) ? ( \
      ENET_ECR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)ENET_ECR_DBGEN_MASK)) : ( \
      ENET_ECR_REG(peripheralBase) |= \
       ENET_ECR_DBGEN_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- SetPowerSavingMode
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables power saving mode with optional magic packet detection.
 * @param peripheralBase Peripheral base address.
 * @param Mode Power saving mode. Possible values (one of): ENET_PDD_SLEEP,
 *        ENET_PDD_STOP, ENET_PDD_RUN.
 * @param WakeUp Wake-up mode. Possible values (one of): PDD_ENABLED,
 *        PDD_DISABLE.
 */
#define ENET_PDD_SetPowerSavingMode(peripheralBase, Mode, WakeUp) ( \
    ( \
     ((uint32_t)(WakeUp) == 0U) ? ( \
      ENET_ECR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)ENET_ECR_MAGICEN_MASK)) : ( \
      ENET_ECR_REG(peripheralBase) |= \
       ENET_ECR_MAGICEN_MASK) \
    ), \
    (( \
     ((Mode) == ENET_PDD_SLEEP) ? ( \
      ENET_ECR_REG(peripheralBase) |= \
       (uint32_t)((uint32_t)0x1U << ENET_ECR_SLEEP_SHIFT)) : (((Mode) == ENET_PDD_STOP) ? ( \
      ENET_ECR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)ENET_ECR_SLEEP_MASK)) : ( \
      ENET_ECR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)ENET_ECR_SLEEP_MASK)) \
    )), \
    ( \
     ((Mode) == ENET_PDD_SLEEP) ? ( \
      ENET_ECR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)ENET_ECR_STOPEN_MASK)) : (((Mode) == ENET_PDD_STOP) ? ( \
      ENET_ECR_REG(peripheralBase) |= \
       (uint32_t)((uint32_t)0x1U << ENET_ECR_STOPEN_SHIFT)) : ( \
      ENET_ECR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)ENET_ECR_STOPEN_MASK)) \
    ))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableMIBCounters
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables MIB counters.
 * @param peripheralBase Peripheral base address.
 * @param Enable Enable flag. Possible values: PDD_ENABLE, PDD_DISABLE.
 */
#define ENET_PDD_EnableMIBCounters(peripheralBase, Enable) ( \
    ((uint32_t)(Enable) == 0U) ? ( \
      ENET_MIBC_REG(peripheralBase) |= \
       ENET_MIBC_MIB_DIS_MASK) : ( \
      ENET_MIBC_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)ENET_MIBC_MIB_DIS_MASK)) \
  )

/* ----------------------------------------------------------------------------
   -- ClearMIBCounters
   ---------------------------------------------------------------------------- */

/**
 * Clears MIB counters.
 * @param peripheralBase Peripheral base address.
 */
#define ENET_PDD_ClearMIBCounters(peripheralBase) ( \
    (ENET_MIBC_REG(peripheralBase) |= \
     ENET_MIBC_MIB_CLEAR_MASK), \
    (ENET_MIBC_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)ENET_MIBC_MIB_CLEAR_MASK)) \
  )

/* ----------------------------------------------------------------------------
   -- IsMIBIdle
   ---------------------------------------------------------------------------- */

/**
 * Indicates whether the MIB is in the idle state.
 * @param peripheralBase Peripheral base address.
 */
#define ENET_PDD_IsMIBIdle(peripheralBase) ( \
    (uint32_t)(ENET_MIBC_REG(peripheralBase) & ENET_MIBC_MIB_IDLE_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetMIBCounter
   ---------------------------------------------------------------------------- */

/**
 * Returns the specified MIB counter value.
 * @param peripheralBase Peripheral base address.
 * @param Counter MIB counter. Possible values (one of): ENET_PDD_RMON_T_DROP,
 *        ENET_PDD_RMON_T_PACKETS, ENET_PDD_RMON_T_BC_PKT, ENET_PDD_RMON_T_MC_PKT,
 *        ENET_PDD_RMON_T_CRC_ALIGN, ENET_PDD_RMON_T_UNDERSIZE,
 *        ENET_PDD_RMON_T_OVERSIZE, ENET_PDD_RMON_T_FRAG, ENET_PDD_RMON_T_JAB,
 *        ENET_PDD_RMON_T_COL, ENET_PDD_RMON_T_P64, ENET_PDD_RMON_T_P65TO127,
 *        ENET_PDD_RMON_T_P128TO255, ENET_PDD_RMON_T_P256TO511, ENET_PDD_RMON_T_P512TO1023,
 *        ENET_PDD_RMON_T_P1024TO2047, ENET_PDD_RMON_T_P_GTE2048, ENET_PDD_RMON_T_OCTETS,
 *        ENET_PDD_IEEE_T_DROP, ENET_PDD_IEEE_T_FRAME_OK, ENET_PDD_IEEE_T_1COL,
 *        ENET_PDD_IEEE_T_MCOL, ENET_PDD_IEEE_T_DEF, ENET_PDD_IEEE_T_LCOL,
 *        ENET_PDD_IEEE_T_EXCOL, ENET_PDD_IEEE_T_MACERR, ENET_PDD_IEEE_T_CSERR,
 *        ENET_PDD_IEEE_T_SQE, ENET_PDD_IEEE_T_FDXFC, ENET_PDD_IEEE_T_OCTETS_OK,
 *        ENET_PDD_RMON_R_DROP, ENET_PDD_RMON_R_PACKETS, ENET_PDD_RMON_R_BC_PKT,
 *        ENET_PDD_RMON_R_MC_PKT, ENET_PDD_RMON_R_CRC_ALIGN, ENET_PDD_RMON_R_UNDERSIZE,
 *        ENET_PDD_RMON_R_OVERSIZE, ENET_PDD_RMON_R_FRAG, ENET_PDD_RMON_R_JAB,
 *        ENET_PDD_RMON_R_RESVD_0, ENET_PDD_RMON_R_P64, ENET_PDD_RMON_R_P65TO127,
 *        ENET_PDD_RMON_R_P128TO255, ENET_PDD_RMON_R_P256TO511,
 *        ENET_PDD_RMON_R_P512TO1023, ENET_PDD_RMON_R_P1024TO2047, ENET_PDD_RMON_R_P_GTE2048,
 *        ENET_PDD_RMON_R_OCTETS, ENET_PDD_IEEE_R_DROP, ENET_PDD_IEEE_R_FRAME_OK,
 *        ENET_PDD_IEEE_R_CRC, ENET_PDD_IEEE_R_ALIGN, ENET_PDD_IEEE_R_MACERR,
 *        ENET_PDD_IEEE_R_FDXFC, ENET_PDD_IEEE_R_OCTETS_OK.
 */
#define ENET_PDD_GetMIBCounter(peripheralBase, Counter) ( \
    *(volatile uint32_t*)((uint32_t)(&ENET_RMON_T_DROP_REG(peripheralBase)) + ((uint32_t)(Counter) * 4U)) \
  )

/* ----------------------------------------------------------------------------
   -- IsGracefulRxStop
   ---------------------------------------------------------------------------- */

/**
 * Indicates whether receive has gracefully stopped.
 * @param peripheralBase Peripheral base address.
 */
#define ENET_PDD_IsGracefulRxStop(peripheralBase) ( \
    (uint32_t)(ENET_RCR_REG(peripheralBase) & ENET_RCR_GRS_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- EnableRxPayloadLengthCheck
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables received frame payload length check with frame length/type
 * field.
 * @param peripheralBase Peripheral base address.
 * @param Enable Enable flag. Possible values: PDD_ENABLE, PDD_DISABLE.
 */
#define ENET_PDD_EnableRxPayloadLengthCheck(peripheralBase, Enable) ( \
    ((uint32_t)(Enable) == 0U) ? ( \
      ENET_RCR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)ENET_RCR_NLC_MASK)) : ( \
      ENET_RCR_REG(peripheralBase) |= \
       ENET_RCR_NLC_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- SetMaxFrameLength
   ---------------------------------------------------------------------------- */

/**
 * Sets the maximum frame length.
 * @param peripheralBase Peripheral base address.
 * @param Length Maximum frame length. Possible values: 0-16384.
 */
#define ENET_PDD_SetMaxFrameLength(peripheralBase, Length) ( \
    ENET_RCR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(ENET_RCR_REG(peripheralBase) & (uint32_t)(~(uint32_t)ENET_RCR_MAX_FL_MASK))) | ( \
      (uint32_t)((uint32_t)(Length) << ENET_RCR_MAX_FL_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableControlFrames
   ---------------------------------------------------------------------------- */

/**
 * Enables selected ethernet control frames of specified types. Disables not
 * selected ones.
 * @param peripheralBase Peripheral base address.
 * @param Mask Control frame type mask. Possible values (OR mask from):
 *        ENET_PDD_PAUSE - enables PAUSE frames, ENET_PDD_NON_PAUSE - enables control
 *        frames other than PAUSE frames.
 */
#define ENET_PDD_EnableControlFrames(peripheralBase, Mask) ( \
    ENET_RCR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       ENET_RCR_REG(peripheralBase)) & ( \
       (uint32_t)(~(uint32_t)(ENET_RCR_CFEN_MASK | ENET_RCR_PAUFWD_MASK))))) | ( \
      (uint32_t)((uint32_t)(Mask) ^ ENET_RCR_CFEN_MASK))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableRxFrameProcessing
   ---------------------------------------------------------------------------- */

/**
 * Enables selected types of received frame processing. Disables not selected
 * ones.
 * @param peripheralBase Peripheral base address.
 * @param Mask Processing type mask. Possible values (OR mask from):
 *        ENET_PDD_CRC_REMOVE - removes CRC, ENET_PDD_PADDING_REMOVE - removes frame
 *        padding,.
 */
#define ENET_PDD_EnableRxFrameProcessing(peripheralBase, Mask) ( \
    ENET_RCR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       ENET_RCR_REG(peripheralBase)) & ( \
       (uint32_t)(~(uint32_t)(ENET_RCR_CRCFWD_MASK | ENET_RCR_PADEN_MASK))))) | ( \
      (uint32_t)(Mask))) \
  )

/* ----------------------------------------------------------------------------
   -- SetMIIMode
   ---------------------------------------------------------------------------- */

/**
 * Sets MII mode.
 * @param peripheralBase Peripheral base address.
 * @param Mode MII mode. Possible values (one of): ENET_PDD_MII - MII mode,
 *        ENET_PDD_RMII_10MBIT - RMII mode with speed set to 10 MBit,
 *        ENET_PDD_RMII_100MBIT - RMII mode with speed set to 100MBit, ENET_PDD_SGMII - serial
 *        gigabit MII mode, ENET_PDD_RGMII - reduced gigabit MII mode, PDD_DISABLE
 *        - MII/RMII mode disabled.
 */
#define ENET_PDD_SetMIIMode(peripheralBase, Mode) ( \
    ((Mode) == ENET_PDD_MII) ? ( \
      ENET_RCR_REG(peripheralBase) = \
       (uint32_t)(( \
        (uint32_t)(( \
         ENET_RCR_REG(peripheralBase)) | ( \
         (uint32_t)((uint32_t)0x1U << ENET_RCR_MII_MODE_SHIFT)))) & (( \
        (uint32_t)(~(uint32_t)ENET_RCR_RMII_MODE_MASK)) & ( \
        (uint32_t)(~(uint32_t)ENET_RCR_RMII_10T_MASK))))) : (((Mode) == ENET_PDD_RMII_10MBIT) ? ( \
      ENET_RCR_REG(peripheralBase) |= \
       (uint32_t)(( \
        (uint32_t)((uint32_t)0x1U << ENET_RCR_MII_MODE_SHIFT)) | (( \
        (uint32_t)((uint32_t)0x1U << ENET_RCR_RMII_MODE_SHIFT)) | ( \
        (uint32_t)((uint32_t)0x1U << ENET_RCR_RMII_10T_SHIFT))))) : ( \
      ENET_RCR_REG(peripheralBase) = \
       (uint32_t)(( \
        (uint32_t)(( \
         ENET_RCR_REG(peripheralBase)) | (( \
         (uint32_t)((uint32_t)0x1U << ENET_RCR_MII_MODE_SHIFT)) | ( \
         (uint32_t)((uint32_t)0x1U << ENET_RCR_RMII_MODE_SHIFT))))) & ( \
        (uint32_t)(~(uint32_t)ENET_RCR_RMII_10T_MASK)))) \
    ) \
  )

/* ----------------------------------------------------------------------------
   -- EnableFlowControl
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables automatic flow control. If enabled, the receiver detects
 * pause frames and stops the transmitter for a given duration.
 * @param peripheralBase Peripheral base address.
 * @param Enable Enable flag. Possible values: PDD_ENABLE, PDD_DISABLE.
 */
#define ENET_PDD_EnableFlowControl(peripheralBase, Enable) ( \
    ((uint32_t)(Enable) == 0U) ? ( \
      ENET_RCR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)ENET_RCR_FCE_MASK)) : ( \
      ENET_RCR_REG(peripheralBase) |= \
       ENET_RCR_FCE_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- EnableInternalLoopback
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables internal loopback mode.
 * @param peripheralBase Peripheral base address.
 * @param Enable Enable flag. Possible values: PDD_ENABLE, PDD_DISABLE.
 */
#define ENET_PDD_EnableInternalLoopback(peripheralBase, Enable) ( \
    ((uint32_t)(Enable) == 0U) ? ( \
      ENET_RCR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)ENET_RCR_LOOP_MASK)) : ( \
      ENET_RCR_REG(peripheralBase) |= \
       ENET_RCR_LOOP_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- EnableTxFrameProcessing
   ---------------------------------------------------------------------------- */

/**
 * Enables selected type of transmitted frames processing. Disables not selected
 * ones.
 * @param peripheralBase Peripheral base address.
 * @param Mask Processing type. Possible values (one of): ENET_PDD_CRC_INSERT -
 *        inserts CRC.
 */
#define ENET_PDD_EnableTxFrameProcessing(peripheralBase, Mask) ( \
    ENET_TCR_REG(peripheralBase) = \
     (uint32_t)((uint32_t)(Mask) ^ ENET_TCR_CRCFWD_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- SelectMACAddress
   ---------------------------------------------------------------------------- */

/**
 * Specifies which MAC address is used as frame source MAC address.
 * @param peripheralBase Peripheral base address.
 * @param Selection Source MAC address selection. Possible values (one of):
 *        ENET_PDD_KEEP - keeps the source MAC address contained in the frame,
 *        ENET_PDD_AUTO - automatically updates the source MAC address,
 *        ENET_PDD_AUTO_SUPPL0-ENET_PDD_AUTO_SUPPL3 - automatically updates the source MAC
 *        address from the specified supplemental MAC address.
 */
#define ENET_PDD_SelectMACAddress(peripheralBase, Selection) ( \
    ((Selection) == ENET_PDD_KEEP) ? ( \
      ENET_TCR_REG(peripheralBase) &= \
       (uint32_t)(( \
        (uint32_t)(~(uint32_t)ENET_TCR_ADDINS_MASK)) & ( \
        (uint32_t)(~(uint32_t)ENET_TCR_ADDSEL_MASK)))) : (((Selection) == ENET_PDD_AUTO) ? ( \
      ENET_TCR_REG(peripheralBase) = \
       (uint32_t)(( \
        (uint32_t)(( \
         ENET_TCR_REG(peripheralBase)) | ( \
         (uint32_t)((uint32_t)0x1U << ENET_TCR_ADDINS_SHIFT)))) & ( \
        (uint32_t)(~(uint32_t)ENET_TCR_ADDSEL_MASK)))) : (((Selection) == ENET_PDD_AUTO_SUPPL0) ? ( \
      ENET_TCR_REG(peripheralBase) = \
       (uint32_t)(( \
        (uint32_t)(( \
         (uint32_t)(( \
          ENET_TCR_REG(peripheralBase)) | ( \
          (uint32_t)((uint32_t)0x1U << ENET_TCR_ADDINS_SHIFT)))) & ( \
         (uint32_t)(~(uint32_t)ENET_TCR_ADDSEL_MASK)))) | ( \
        (uint32_t)((uint32_t)0x4U << ENET_TCR_ADDSEL_SHIFT)))) : (((Selection) == ENET_PDD_AUTO_SUPPL1) ? ( \
      ENET_TCR_REG(peripheralBase) = \
       (uint32_t)(( \
        (uint32_t)(( \
         (uint32_t)(( \
          ENET_TCR_REG(peripheralBase)) | ( \
          (uint32_t)((uint32_t)0x1U << ENET_TCR_ADDINS_SHIFT)))) & ( \
         (uint32_t)(~(uint32_t)ENET_TCR_ADDSEL_MASK)))) | ( \
        (uint32_t)((uint32_t)0x5U << ENET_TCR_ADDSEL_SHIFT)))) : (((Selection) == ENET_PDD_AUTO_SUPPL2) ? ( \
      ENET_TCR_REG(peripheralBase) = \
       (uint32_t)(( \
        (uint32_t)(( \
         (uint32_t)(( \
          ENET_TCR_REG(peripheralBase)) | ( \
          (uint32_t)((uint32_t)0x1U << ENET_TCR_ADDINS_SHIFT)))) & ( \
         (uint32_t)(~(uint32_t)ENET_TCR_ADDSEL_MASK)))) | ( \
        (uint32_t)((uint32_t)0x6U << ENET_TCR_ADDSEL_SHIFT)))) : ( \
      ENET_TCR_REG(peripheralBase) |= \
       (uint32_t)(( \
        (uint32_t)((uint32_t)0x1U << ENET_TCR_ADDINS_SHIFT)) | ( \
        (uint32_t)((uint32_t)0x7U << ENET_TCR_ADDSEL_SHIFT)))) \
    )))) \
  )

/* ----------------------------------------------------------------------------
   -- IsTransmissionPaused
   ---------------------------------------------------------------------------- */

/**
 * Indicates whether the transmitter is paused by a pause frame.
 * @param peripheralBase Peripheral base address.
 */
#define ENET_PDD_IsTransmissionPaused(peripheralBase) ( \
    (uint32_t)(ENET_TCR_REG(peripheralBase) & ENET_TCR_TFC_PAUSE_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- StartGracefulTxStop
   ---------------------------------------------------------------------------- */

/**
 * Initiates a graceful transmit stop.
 * @param peripheralBase Peripheral base address.
 */
#define ENET_PDD_StartGracefulTxStop(peripheralBase) ( \
    ENET_TCR_REG(peripheralBase) |= \
     ENET_TCR_GTS_MASK \
  )

/* ----------------------------------------------------------------------------
   -- FinishGracefulTxStop
   ---------------------------------------------------------------------------- */

/**
 * Finishes a graceful transmit stop and enables transmission.
 * @param peripheralBase Peripheral base address.
 */
#define ENET_PDD_FinishGracefulTxStop(peripheralBase) ( \
    ENET_TCR_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)ENET_TCR_GTS_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- IsGracefulTxStop
   ---------------------------------------------------------------------------- */

/**
 * Indicates whether transmission is gracefully stopped.
 * @param peripheralBase Peripheral base address.
 */
#define ENET_PDD_IsGracefulTxStop(peripheralBase) ( \
    (uint32_t)(ENET_TCR_REG(peripheralBase) & ENET_TCR_GTS_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- SetTxFIFOWatermark
   ---------------------------------------------------------------------------- */

/**
 * Sets the number of bytes written to transmit FIFO before transmission of a
 * frame begins.
 * @param peripheralBase Peripheral base address.
 * @param Watermark Transmit FIFO watermark. Possible values: 0 - enables store
 *        and forward, 1-63 - transmission starts after (value x 64) bytes are
 *        written to transmit FIFO.
 */
#define ENET_PDD_SetTxFIFOWatermark(peripheralBase, Watermark) ( \
    ((uint8_t)(Watermark) == 0U) ? ( \
      (ENET_TFWR_REG(peripheralBase) |= \
       ENET_TFWR_STRFWD_MASK), \
      (ENET_TFWR_REG(peripheralBase) = \
       (uint32_t)(( \
        (uint32_t)(ENET_TFWR_REG(peripheralBase) & (uint32_t)(~(uint32_t)ENET_TFWR_TFWR_MASK))) | ( \
        (uint32_t)(Watermark))))) : ( \
      (ENET_TFWR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)ENET_TFWR_STRFWD_MASK)), \
      (ENET_TFWR_REG(peripheralBase) = \
       (uint32_t)(( \
        (uint32_t)(ENET_TFWR_REG(peripheralBase) & (uint32_t)(~(uint32_t)ENET_TFWR_TFWR_MASK))) | ( \
        (uint32_t)(Watermark))))) \
  )

/* ----------------------------------------------------------------------------
   -- SetRxBufferSize
   ---------------------------------------------------------------------------- */

/**
 * Sets the size of receive buffers.
 * @param peripheralBase Peripheral base address.
 * @param Size Receive buffer size aligned to 16 bytes.
 */
#define ENET_PDD_SetRxBufferSize(peripheralBase, Size) ( \
    ENET_MRBR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       ENET_MRBR_REG(peripheralBase)) & ( \
       (uint32_t)(~(uint32_t)ENET_MRBR_R_BUF_SIZE_MASK)))) | ( \
      (uint32_t)((uint32_t)(Size) << ENET_MRBR_R_BUF_SIZE_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- SetRxFIFOSectionFullThreshold
   ---------------------------------------------------------------------------- */

/**
 * Sets the receive FIFO section full threshold.
 * @param peripheralBase Peripheral base address.
 * @param Value Value, in 64-bit words, of the receive FIFO section full
 *        threshold.
 */
#define ENET_PDD_SetRxFIFOSectionFullThreshold(peripheralBase, Value) ( \
    ENET_RSFL_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       ENET_RSFL_REG(peripheralBase)) & ( \
       (uint32_t)(~(uint32_t)ENET_RSFL_RX_SECTION_FULL_MASK)))) | ( \
      (uint32_t)(Value))) \
  )

/* ----------------------------------------------------------------------------
   -- SetRxFIFOSectionEmptyThreshold
   ---------------------------------------------------------------------------- */

/**
 * Sets the receive FIFO section empty threshold.
 * @param peripheralBase Peripheral base address.
 * @param Value Value, in 64-bit words, of the receive FIFO section empty
 *        threshold.
 */
#define ENET_PDD_SetRxFIFOSectionEmptyThreshold(peripheralBase, Value) ( \
    ENET_RSEM_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       ENET_RSEM_REG(peripheralBase)) & ( \
       (uint32_t)(~(uint32_t)ENET_RSEM_RX_SECTION_EMPTY_MASK)))) | ( \
      (uint32_t)(Value))) \
  )

/* ----------------------------------------------------------------------------
   -- SetRxFIFOAlmostEmptyThreshold
   ---------------------------------------------------------------------------- */

/**
 * Sets the receive FIFO almost full threshold.
 * @param peripheralBase Peripheral base address.
 * @param Value Value, in 64-bit words, of the receive FIFO almost empty
 *        threshold.
 */
#define ENET_PDD_SetRxFIFOAlmostEmptyThreshold(peripheralBase, Value) ( \
    ENET_RAEM_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       ENET_RAEM_REG(peripheralBase)) & ( \
       (uint32_t)(~(uint32_t)ENET_RAEM_RX_ALMOST_EMPTY_MASK)))) | ( \
      (uint32_t)(Value))) \
  )

/* ----------------------------------------------------------------------------
   -- SetRxFIFOAlmostFullThreshold
   ---------------------------------------------------------------------------- */

/**
 * Sets the receive FIFO almost full threshold.
 * @param peripheralBase Peripheral base address.
 * @param Value Value, in 64-bit words, of the receive FIFO almost full
 *        threshold.
 */
#define ENET_PDD_SetRxFIFOAlmostFullThreshold(peripheralBase, Value) ( \
    ENET_RAFL_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       ENET_RAFL_REG(peripheralBase)) & ( \
       (uint32_t)(~(uint32_t)ENET_RAFL_RX_ALMOST_FULL_MASK)))) | ( \
      (uint32_t)(Value))) \
  )

/* ----------------------------------------------------------------------------
   -- SetTxFIFOSectionEmptyThreshold
   ---------------------------------------------------------------------------- */

/**
 * Sets the transmit FIFO section empty threshold.
 * @param peripheralBase Peripheral base address.
 * @param Value Value, in 64-bit words, of the transmit FIFO section empty
 *        threshold.
 */
#define ENET_PDD_SetTxFIFOSectionEmptyThreshold(peripheralBase, Value) ( \
    ENET_TSEM_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       ENET_TSEM_REG(peripheralBase)) & ( \
       (uint32_t)(~(uint32_t)ENET_TSEM_TX_SECTION_EMPTY_MASK)))) | ( \
      (uint32_t)(Value))) \
  )

/* ----------------------------------------------------------------------------
   -- SetTxFIFOAlmostEmptyThreshold
   ---------------------------------------------------------------------------- */

/**
 * Sets the transmit FIFO almost empty threshold.
 * @param peripheralBase Peripheral base address.
 * @param Value Value, in 64-bit words, of the transmit FIFO almost empty
 *        threshold.
 */
#define ENET_PDD_SetTxFIFOAlmostEmptyThreshold(peripheralBase, Value) ( \
    ENET_TAEM_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       ENET_TAEM_REG(peripheralBase)) & ( \
       (uint32_t)(~(uint32_t)ENET_TAEM_TX_ALMOST_EMPTY_MASK)))) | ( \
      (uint32_t)(Value))) \
  )

/* ----------------------------------------------------------------------------
   -- SetTxFIFOAlmostFullThreshold
   ---------------------------------------------------------------------------- */

/**
 * Sets the transmit FIFO almost full threshold.
 * @param peripheralBase Peripheral base address.
 * @param Value Value, in 64-bit words, of the transmit FIFO almost full
 *        threshold.
 */
#define ENET_PDD_SetTxFIFOAlmostFullThreshold(peripheralBase, Value) ( \
    ENET_TAFL_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       ENET_TAFL_REG(peripheralBase)) & ( \
       (uint32_t)(~(uint32_t)ENET_TAFL_TX_ALMOST_FULL_MASK)))) | ( \
      (uint32_t)(Value))) \
  )

/* ----------------------------------------------------------------------------
   -- SetTxInterPacketGap
   ---------------------------------------------------------------------------- */

/**
 * Sets the transmit inter-packet gap.
 * @param peripheralBase Peripheral base address.
 * @param ByteCount Transmit inter-packet gap in bytes. Possible values: 0-7 -
 *        value is set to 8, 8-27 - the specified value is set, 28-32 - value is
 *        set to 27.
 */
#define ENET_PDD_SetTxInterPacketGap(peripheralBase, ByteCount) ( \
    ENET_TIPG_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(ENET_TIPG_REG(peripheralBase) & (uint32_t)(~(uint32_t)ENET_TIPG_IPG_MASK))) | ( \
      (uint32_t)(ByteCount))) \
  )

/* ----------------------------------------------------------------------------
   -- SetFrameTruncLength
   ---------------------------------------------------------------------------- */

/**
 * Sets the frame truncation length.
 * @param peripheralBase Peripheral base address.
 * @param Length Frame truncation length. Possible values: 0-16384.
 */
#define ENET_PDD_SetFrameTruncLength(peripheralBase, Length) ( \
    ENET_FTRL_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(ENET_FTRL_REG(peripheralBase) & (uint32_t)(~(uint32_t)ENET_FTRL_TRUNC_FL_MASK))) | ( \
      (uint32_t)(Length))) \
  )

/* ----------------------------------------------------------------------------
   -- SetProtocolChecksumAccelerators
   ---------------------------------------------------------------------------- */

/**
 * Sets accelerators for known protocols based on protocol cheksums.
 * @param peripheralBase Peripheral base address.
 * @param Mask Protocol checksum accelerators mask. Possible values (OR mask
 *        from): ENET_PDD_INSERT_ON_TX - insert protocol checksum into transmitted
 *        frames, ENET_PDD_CHECK_ON_RX - check protocol checksum of received
 *        frames, ENET_PDD_DROP_ON_RX - drop received frames with protocol checksum
 *        error.
 */
#define ENET_PDD_SetProtocolChecksumAccelerators(peripheralBase, Mask) ( \
    ( \
     ((uint32_t)((uint32_t)(Mask) & 0x1U) == 0x1U) ? ( \
      ENET_TACC_REG(peripheralBase) |= \
       ENET_TACC_PROCHK_MASK) : ( \
      ENET_TACC_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)ENET_TACC_PROCHK_MASK)) \
    ), \
    ( \
     ((uint32_t)((uint32_t)(Mask) & 0x2U) == 0x2U) ? ( \
      ENET_RACC_REG(peripheralBase) |= \
       ENET_RACC_PRODIS_MASK) : ( \
      ENET_RACC_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)ENET_RACC_PRODIS_MASK)) \
    ) \
  )

/* ----------------------------------------------------------------------------
   -- SetIPHeaderChecksumAccelerators
   ---------------------------------------------------------------------------- */

/**
 * Sets accelerators for IP header checksum processing.
 * @param peripheralBase Peripheral base address.
 * @param Mask IP header checksum accelerators mask. Possible values (OR mask
 *        from): ENET_PDD_INSERT_ON_TX - insert IP header checksum into transmitted
 *        frames, ENET_PDD_CHECK_ON_RX - check IP header checksum of received
 *        frames, ENET_PDD_DROP_ON_RX - drop received frames with IP header
 *        checksum error.
 */
#define ENET_PDD_SetIPHeaderChecksumAccelerators(peripheralBase, Mask) ( \
    ( \
     ((uint32_t)((uint32_t)(Mask) & 0x1U) == 0x1U) ? ( \
      ENET_TACC_REG(peripheralBase) |= \
       ENET_TACC_IPCHK_MASK) : ( \
      ENET_TACC_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)ENET_TACC_IPCHK_MASK)) \
    ), \
    ( \
     ((uint32_t)((uint32_t)(Mask) & 0x2U) == 0x2U) ? ( \
      ENET_RACC_REG(peripheralBase) |= \
       ENET_RACC_IPDIS_MASK) : ( \
      ENET_RACC_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)ENET_RACC_IPDIS_MASK)) \
    ) \
  )

/* ----------------------------------------------------------------------------
   -- SetFIFO16BitShift
   ---------------------------------------------------------------------------- */

/**
 * Enables frame header shifting for transmitted/received frames.
 * @param peripheralBase Peripheral base address.
 * @param Type Type of frames for which to enable frame header shifting.
 *        Possible values: TX_ONLY, RX_ONLY, TX_AND_RX.
 */
#define ENET_PDD_SetFIFO16BitShift(peripheralBase, Type) ( \
    ( \
     ((uint32_t)((uint32_t)(Type) & 0x1U) == 0x1U) ? ( \
      ENET_TACC_REG(peripheralBase) |= \
       ENET_TACC_SHIFT16_MASK) : ( \
      ENET_TACC_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)ENET_TACC_SHIFT16_MASK)) \
    ), \
    ( \
     ((uint32_t)((uint32_t)(Type) & 0x2U) == 0x2U) ? ( \
      ENET_RACC_REG(peripheralBase) |= \
       ENET_RACC_SHIFT16_MASK) : ( \
      ENET_RACC_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)ENET_RACC_SHIFT16_MASK)) \
    ) \
  )

/* ----------------------------------------------------------------------------
   -- EnableMACErrorDrops
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables frames with MAC error to be dropped by the receiver.
 * @param peripheralBase Peripheral base address.
 * @param Enable Enable flag. Possible values: PDD_ENABLE, PDD_DISABLE.
 */
#define ENET_PDD_EnableMACErrorDrops(peripheralBase, Enable) ( \
    ((uint32_t)(Enable) == 0U) ? ( \
      ENET_RACC_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)ENET_RACC_LINEDIS_MASK)) : ( \
      ENET_RACC_REG(peripheralBase) |= \
       ENET_RACC_LINEDIS_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- EnablePaddingRemoval
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables padding removal for short IP frames.
 * @param peripheralBase Peripheral base address.
 * @param Enable Enable flag. Possible values: PDD_ENABLE, PDD_DISABLE.
 */
#define ENET_PDD_EnablePaddingRemoval(peripheralBase, Enable) ( \
    ((uint32_t)(Enable) == 0U) ? ( \
      ENET_RACC_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)ENET_RACC_PADREM_MASK)) : ( \
      ENET_RACC_REG(peripheralBase) |= \
       ENET_RACC_PADREM_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- TIMER_EnableDevice
   ---------------------------------------------------------------------------- */

/**
 * Enables the timer.
 * @param peripheralBase Peripheral base address.
 */
#define ENET_PDD_TIMER_EnableDevice(peripheralBase) ( \
    ENET_ATCR_REG(peripheralBase) |= \
     ENET_ATCR_EN_MASK \
  )

/* ----------------------------------------------------------------------------
   -- TIMER_DisableDevice
   ---------------------------------------------------------------------------- */

/**
 * Disables the timer.
 * @param peripheralBase Peripheral base address.
 */
#define ENET_PDD_TIMER_DisableDevice(peripheralBase) ( \
    ENET_ATCR_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)ENET_ATCR_EN_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- TIMER_EnableSlaveMode
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables timer slave mode.
 * @param peripheralBase Peripheral base address.
 * @param Enable Enable flag. Possible values: PDD_ENABLE, PDD_DISABLE.
 */
#define ENET_PDD_TIMER_EnableSlaveMode(peripheralBase, Enable) ( \
    ((uint32_t)(Enable) == 0U) ? ( \
      ENET_ATCR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)ENET_ATCR_SLAVE_MASK)) : ( \
      ENET_ATCR_REG(peripheralBase) |= \
       ENET_ATCR_SLAVE_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- TIMER_CaptureTimer
   ---------------------------------------------------------------------------- */

/**
 * Captures the current time.
 * @param peripheralBase Peripheral base address.
 */
#define ENET_PDD_TIMER_CaptureTimer(peripheralBase) ( \
    ENET_ATCR_REG(peripheralBase) |= \
     ENET_ATCR_CAPTURE_MASK \
  )

/* ----------------------------------------------------------------------------
   -- TIMER_ResetTimer
   ---------------------------------------------------------------------------- */

/**
 * Resets the timer to zero.
 * @param peripheralBase Peripheral base address.
 */
#define ENET_PDD_TIMER_ResetTimer(peripheralBase) ( \
    ENET_ATCR_REG(peripheralBase) |= \
     ENET_ATCR_RESTART_MASK \
  )

/* ----------------------------------------------------------------------------
   -- TIMER_EnableOutputAssertOnPeriod
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables MAC output assertion on periodical event.
 * @param peripheralBase Peripheral base address.
 * @param Enable Enable flag. Possible values: PDD_ENABLE, PDD_DISABLE.
 */
#define ENET_PDD_TIMER_EnableOutputAssertOnPeriod(peripheralBase, Enable) ( \
    ((uint32_t)(Enable) == 0U) ? ( \
      ENET_ATCR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)ENET_ATCR_PINPER_MASK)) : ( \
      ENET_ATCR_REG(peripheralBase) |= \
       ENET_ATCR_PINPER_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- TIMER_EnablePeriodEvent
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables periodical event.
 * @param peripheralBase Peripheral base address.
 * @param Enable Enable flag. Possible values: PDD_ENABLE, PDD_DISABLE.
 */
#define ENET_PDD_TIMER_EnablePeriodEvent(peripheralBase, Enable) ( \
    ((uint32_t)(Enable) == 0U) ? ( \
      ENET_ATCR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)ENET_ATCR_PEREN_MASK)) : ( \
      ENET_ATCR_REG(peripheralBase) |= \
       ENET_ATCR_PEREN_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- TIMER_EnableResetOnOffsetEvent
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables reset on offset event.
 * @param peripheralBase Peripheral base address.
 * @param Enable Enable flag. Possible values: PDD_ENABLE, PDD_DISABLE.
 */
#define ENET_PDD_TIMER_EnableResetOnOffsetEvent(peripheralBase, Enable) ( \
    ((uint32_t)(Enable) == 0U) ? ( \
      ENET_ATCR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)ENET_ATCR_OFFRST_MASK)) : ( \
      ENET_ATCR_REG(peripheralBase) |= \
       ENET_ATCR_OFFRST_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- TIMER_EnableOffsetEvent
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables offset event.
 * @param peripheralBase Peripheral base address.
 * @param Enable Enable flag. Possible values: PDD_ENABLE, PDD_DISABLE.
 */
#define ENET_PDD_TIMER_EnableOffsetEvent(peripheralBase, Enable) ( \
    ((uint32_t)(Enable) == 0U) ? ( \
      ENET_ATCR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)ENET_ATCR_OFFEN_MASK)) : ( \
      ENET_ATCR_REG(peripheralBase) |= \
       ENET_ATCR_OFFEN_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- TIMER_SetTimer
   ---------------------------------------------------------------------------- */

/**
 * Sets the timer.
 * @param peripheralBase Peripheral base address.
 * @param Value Timer value.
 */
#define ENET_PDD_TIMER_SetTimer(peripheralBase, Value) ( \
    ENET_ATVR_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- TIMER_GetTimer
   ---------------------------------------------------------------------------- */

/**
 * Returns the last captured timer value.
 * @param peripheralBase Peripheral base address.
 */
#define ENET_PDD_TIMER_GetTimer(peripheralBase) ( \
    ENET_ATVR_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- TIMER_SetOffset
   ---------------------------------------------------------------------------- */

/**
 * Sets the timer offset.
 * @param peripheralBase Peripheral base address.
 * @param Offset Timer offset value.
 */
#define ENET_PDD_TIMER_SetOffset(peripheralBase, Offset) ( \
    ENET_ATOFF_REG(peripheralBase) = \
     (uint32_t)(Offset) \
  )

/* ----------------------------------------------------------------------------
   -- TIMER_SetPeriod
   ---------------------------------------------------------------------------- */

/**
 * Sets the timer period.
 * @param peripheralBase Peripheral base address.
 * @param Period Timer period value.
 */
#define ENET_PDD_TIMER_SetPeriod(peripheralBase, Period) ( \
    ENET_ATPER_REG(peripheralBase) = \
     (uint32_t)(Period) \
  )

/* ----------------------------------------------------------------------------
   -- TIMER_SetCorrectionCounter
   ---------------------------------------------------------------------------- */

/**
 * Sets the timer correction counter value.
 * @param peripheralBase Peripheral base address.
 * @param Counter Correction counter value.
 */
#define ENET_PDD_TIMER_SetCorrectionCounter(peripheralBase, Counter) ( \
    ENET_ATCOR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(ENET_ATCOR_REG(peripheralBase) & (uint32_t)(~(uint32_t)ENET_ATCOR_COR_MASK))) | ( \
      (uint32_t)(Counter))) \
  )

/* ----------------------------------------------------------------------------
   -- TIMER_SetCorrectionIncrement
   ---------------------------------------------------------------------------- */

/**
 * Sets the timer correction increment value.
 * @param peripheralBase Peripheral base address.
 * @param Increment Correction increment value.
 */
#define ENET_PDD_TIMER_SetCorrectionIncrement(peripheralBase, Increment) ( \
    ENET_ATINC_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       ENET_ATINC_REG(peripheralBase)) & ( \
       (uint32_t)(~(uint32_t)ENET_ATINC_INC_CORR_MASK)))) | ( \
      (uint32_t)((uint32_t)(Increment) << ENET_ATINC_INC_CORR_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- TIMER_SetIncrement
   ---------------------------------------------------------------------------- */

/**
 * Sets the timer increment value.
 * @param peripheralBase Peripheral base address.
 * @param Increment Timer increment value.
 */
#define ENET_PDD_TIMER_SetIncrement(peripheralBase, Increment) ( \
    ENET_ATINC_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(ENET_ATINC_REG(peripheralBase) & (uint32_t)(~(uint32_t)ENET_ATINC_INC_MASK))) | ( \
      (uint32_t)(Increment))) \
  )

/* ----------------------------------------------------------------------------
   -- TIMER_GetTimestamp
   ---------------------------------------------------------------------------- */

/**
 * Returns timestamp of the last frame transmitted with TimeStamp flag set.
 * @param peripheralBase Peripheral base address.
 */
#define ENET_PDD_TIMER_GetTimestamp(peripheralBase) ( \
    ENET_ATSTMP_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- TIMER_GetStatusFlags
   ---------------------------------------------------------------------------- */

/**
 * Returns the timer status flags. The return value can be masked with
 * predefined macros: TIMER_CHANNEL_0-3.
 * @param peripheralBase Peripheral base address.
 */
#define ENET_PDD_TIMER_GetStatusFlags(peripheralBase) ( \
    ENET_TGSR_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- TIMER_ClearStatusFlags
   ---------------------------------------------------------------------------- */

/**
 * Clears the specified timer status flags.
 * @param peripheralBase Peripheral base address.
 * @param Mask Status flag mask. Possible values (OR mask from):
 *        TIMER_CHANNEL_0-3.
 */
#define ENET_PDD_TIMER_ClearStatusFlags(peripheralBase, Mask) ( \
    ENET_TGSR_REG(peripheralBase) = \
     (uint32_t)(Mask) \
  )

/* ----------------------------------------------------------------------------
   -- TIMER_EnableInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables interrupts for a specified channel.
 * @param peripheralBase Peripheral base address.
 * @param Channel Channel index. Possible values: 0-3.
 */
#define ENET_PDD_TIMER_EnableInterrupt(peripheralBase, Channel) ( \
    ENET_TCSR_REG(peripheralBase,(Channel)) = \
     (uint32_t)(( \
      (uint32_t)(ENET_TCSR_REG(peripheralBase,(Channel)) | ENET_TCSR_TIE_MASK)) & ( \
      (uint32_t)(~(uint32_t)ENET_TCSR_TF_MASK))) \
  )

/* ----------------------------------------------------------------------------
   -- TIMER_DisableInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables interrupts for a specified channel.
 * @param peripheralBase Peripheral base address.
 * @param Channel Channel index. Possible values: 0-3.
 */
#define ENET_PDD_TIMER_DisableInterrupt(peripheralBase, Channel) ( \
    ENET_TCSR_REG(peripheralBase,(Channel)) &= \
     (uint32_t)(( \
      (uint32_t)(~(uint32_t)ENET_TCSR_TIE_MASK)) & ( \
      (uint32_t)(~(uint32_t)ENET_TCSR_TF_MASK))) \
  )

/* ----------------------------------------------------------------------------
   -- TIMER_SetMode
   ---------------------------------------------------------------------------- */

/**
 * Sets the timer mode.
 * @param peripheralBase Peripheral base address.
 * @param Channel Channel index. Possible values: 0-3.
 * @param Mode Timer mode. Possible values: DISABLED, INPUT_CAPTURE_RISING_EDGE,
 *        INPUT_CAPTURE_FALLING_EDGE, INPUT_CAPTURE_BOTH_EDGES,
 *        OUTPUT_COMPARE_SOFTWARE_ONLY, OUTPUT_COMPARE_TOGGLE_ON_COMPARE,
 *        OUTPUT_COMPARE_CLEAR_ON_COMPARE, OUTPUT_COMPARE_SET_ON_COMPARE,
 *        OUTPUT_COMPARE_CLEAR_ON_COMPARE_SET_ON_OVERFLOW, OUTPUT_COMPARE_SET_ON_COMPARE_CLEAR_ON_OVERFLOW,
 *        OUTPUT_COMPARE_PULSE_LOW, OUTPUT_COMPARE_PULSE_HIGH.
 */
#define ENET_PDD_TIMER_SetMode(peripheralBase, Channel, Mode) ( \
    ENET_TCSR_REG(peripheralBase,(Channel)) = \
     (uint32_t)(( \
      (uint32_t)(( \
       ENET_TCSR_REG(peripheralBase,(Channel))) & (( \
       (uint32_t)(~(uint32_t)ENET_TCSR_TMODE_MASK)) & ( \
       (uint32_t)(~(uint32_t)ENET_TCSR_TF_MASK))))) | ( \
      (uint32_t)(Mode))) \
  )

/* ----------------------------------------------------------------------------
   -- TIMER_EnableDMARequest
   ---------------------------------------------------------------------------- */

/**
 * Enables the DMA request for the specified channel.
 * @param peripheralBase Peripheral base address.
 * @param Channel Channel index. Possible values: 0-3.
 * @param Enable Enable flag. Possible values: PDD_ENABLE, PDD_DISABLE.
 */
#define ENET_PDD_TIMER_EnableDMARequest(peripheralBase, Channel, Enable) ( \
    ((uint32_t)(Enable) == 0U) ? ( \
      ENET_TCSR_REG(peripheralBase,(Channel)) &= \
       (uint32_t)(( \
        (uint32_t)(~(uint32_t)ENET_TCSR_TDRE_MASK)) & ( \
        (uint32_t)(~(uint32_t)ENET_TCSR_TF_MASK)))) : ( \
      ENET_TCSR_REG(peripheralBase,(Channel)) = \
       (uint32_t)(( \
        (uint32_t)(ENET_TCSR_REG(peripheralBase,(Channel)) | ENET_TCSR_TDRE_MASK)) & ( \
        (uint32_t)(~(uint32_t)ENET_TCSR_TF_MASK)))) \
  )

/* ----------------------------------------------------------------------------
   -- TIMER_GetCapture
   ---------------------------------------------------------------------------- */

/**
 * Returns the timer value captured when a rising edge occurred on input pin.
 * @param peripheralBase Peripheral base address.
 * @param Channel Channel index. Possible values: 0-3.
 */
#define ENET_PDD_TIMER_GetCapture(peripheralBase, Channel) ( \
    ENET_TCCR_REG(peripheralBase,(Channel)) \
  )

/* ----------------------------------------------------------------------------
   -- TIMER_SetCompare
   ---------------------------------------------------------------------------- */

/**
 * Sets the timer compare value. When timer reaches this value, output pin is
 * asserted.
 * @param peripheralBase Peripheral base address.
 * @param Channel Channel index. Possible values: 0-3.
 * @param Value Timer compare value.
 */
#define ENET_PDD_TIMER_SetCompare(peripheralBase, Channel, Value) ( \
    ENET_TCCR_REG(peripheralBase,(Channel)) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- TIMER_SetClockSource
   ---------------------------------------------------------------------------- */

/**
 * Selects the timer clock source (in the SIM module).
 * @param peripheralBase Peripheral base address.
 * @param Source Timer clock source. Possible values: CORE_SYSTEM_CLOCK,
 *        PLL_FLL_CLOCK, EXTAL_CLOCK, EXTERNAL_CLOCK. Use constants from group "Timer
 *        clock sources".
 */
#define ENET_PDD_TIMER_SetClockSource(peripheralBase, Source) ( \
    SIM_SOPT2_REG(SIM_BASE_PTR) = \
     (( \
      (uint32_t)(SIM_SOPT2_REG(SIM_BASE_PTR) & (uint32_t)(~(uint32_t)SIM_SOPT2_TIMESRC_MASK))) | ( \
      (uint32_t)((uint32_t)(Source) << SIM_SOPT2_TIMESRC_SHIFT))) \
  )
#endif  /* #if defined(ENET_PDD_H_) */

/* ENET_PDD.h, eof. */
