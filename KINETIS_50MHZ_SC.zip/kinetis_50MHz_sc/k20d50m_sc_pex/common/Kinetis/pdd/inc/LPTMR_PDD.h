/*
  PDD layer implementation for peripheral type LPTMR
  (C) 2010 Freescale, Inc. All rights reserved.

  This file is static and it is generated from API-Factory
*/

#if !defined(LPTMR_PDD_H_)
#define LPTMR_PDD_H_

/* ----------------------------------------------------------------------------
   -- Test if supported MCU is active
   ---------------------------------------------------------------------------- */

#if !defined(MCU_ACTIVE)
  // No MCU is active
  #error LPTMR PDD library: No derivative is active. Place proper #include with PDD memory map before including PDD library.
#elif \
      !defined(MCU_MK10D10) /* LPTMR0 */ && \
      !defined(MCU_MK10D5) /* LPTMR0 */ && \
      !defined(MCU_MK10D7) /* LPTMR0 */ && \
      !defined(MCU_MK10F12) /* LPTMR0 */ && \
      !defined(MCU_MK10DZ10) /* LPTMR0 */ && \
      !defined(MCU_MK11D5) /* LPTMR0 */ && \
      !defined(MCU_MK12D5) /* LPTMR0 */ && \
      !defined(MCU_MK20D10) /* LPTMR0 */ && \
      !defined(MCU_MK20D5) /* LPTMR0 */ && \
      !defined(MCU_MK20D7) /* LPTMR0 */ && \
      !defined(MCU_MK20F12) /* LPTMR0 */ && \
      !defined(MCU_MK20DZ10) /* LPTMR0 */ && \
      !defined(MCU_MK21D5) /* LPTMR0 */ && \
      !defined(MCU_MK22D5) /* LPTMR0 */ && \
      !defined(MCU_MK30D10) /* LPTMR0 */ && \
      !defined(MCU_MK30D7) /* LPTMR0 */ && \
      !defined(MCU_MK30DZ10) /* LPTMR0 */ && \
      !defined(MCU_MK40D10) /* LPTMR0 */ && \
      !defined(MCU_MK40D7) /* LPTMR0 */ && \
      !defined(MCU_MK40DZ10) /* LPTMR0 */ && \
      !defined(MCU_MK40X256VMD100) /* LPTMR0 */ && \
      !defined(MCU_MK50D10) /* LPTMR0 */ && \
      !defined(MCU_MK50D7) /* LPTMR0 */ && \
      !defined(MCU_MK50DZ10) /* LPTMR0 */ && \
      !defined(MCU_MK51D10) /* LPTMR0 */ && \
      !defined(MCU_MK51D7) /* LPTMR0 */ && \
      !defined(MCU_MK51DZ10) /* LPTMR0 */ && \
      !defined(MCU_MK52D10) /* LPTMR0 */ && \
      !defined(MCU_MK52DZ10) /* LPTMR0 */ && \
      !defined(MCU_MK53D10) /* LPTMR0 */ && \
      !defined(MCU_MK53DZ10) /* LPTMR0 */ && \
      !defined(MCU_MK60D10) /* LPTMR0 */ && \
      !defined(MCU_MK60F12) /* LPTMR0 */ && \
      !defined(MCU_MK60F15) /* LPTMR0 */ && \
      !defined(MCU_MK60DZ10) /* LPTMR0 */ && \
      !defined(MCU_MK60N512VMD100) /* LPTMR0 */ && \
      !defined(MCU_MK61F12) /* LPTMR0 */ && \
      !defined(MCU_MK61F15) /* LPTMR0 */ && \
      !defined(MCU_MK70F12) /* LPTMR0 */ && \
      !defined(MCU_MK70F15) /* LPTMR0 */ && \
      !defined(MCU_MKL04Z4) /* LPTMR0 */ && \
      !defined(MCU_MKL05Z4) /* LPTMR0 */ && \
      !defined(MCU_MKL14Z4) /* LPTMR0 */ && \
      !defined(MCU_MKL15Z4) /* LPTMR0 */ && \
      !defined(MCU_MKL24Z4) /* LPTMR0 */ && \
      !defined(MCU_MKL25Z4) /* LPTMR0 */ && \
      !defined(MCU_PCK20L4) /* LPTMR0 */
  // Unsupported MCU is active
  #error LPTMR PDD library: Unsupported derivative is active.
#endif

#include "PDD_Types.h"

/* ----------------------------------------------------------------------------
   -- Method symbol definitions
   ---------------------------------------------------------------------------- */

/* Enable freerun constants */
#define LPTMR_PDD_RESTART_ENABLED 0U             /**< Enabled */
#define LPTMR_PDD_RESTART_DISABLED LPTMR_CSR_TFC_MASK /**< Disabled */

/* Timer mode constants */
#define LPTMR_PDD_SOURCE_INTERNAL 0U             /**< Internal */
#define LPTMR_PDD_SOURCE_EXTERNAL LPTMR_CSR_TMS_MASK /**< External */

/* Prescaler/Filter constants */
#define LPTMR_PDD_PRESCALER_2 0U                 /**< 2 */
#define LPTMR_PDD_PRESCALER_4 0x1U               /**< 4 */
#define LPTMR_PDD_PRESCALER_8 0x2U               /**< 8 */
#define LPTMR_PDD_PRESCALER_16 0x3U              /**< 16 */
#define LPTMR_PDD_PRESCALER_32 0x4U              /**< 32 */
#define LPTMR_PDD_PRESCALER_64 0x5U              /**< 64 */
#define LPTMR_PDD_PRESCALER_128 0x6U             /**< 128 */
#define LPTMR_PDD_PRESCALER_256 0x7U             /**< 256 */
#define LPTMR_PDD_PRESCALER_512 0x8U             /**< 512 */
#define LPTMR_PDD_PRESCALER_1024 0x9U            /**< 1024 */
#define LPTMR_PDD_PRESCALER_2048 0xAU            /**< 2048 */
#define LPTMR_PDD_PRESCALER_4096 0xBU            /**< 4096 */
#define LPTMR_PDD_PRESCALER_8192 0xCU            /**< 8192 */
#define LPTMR_PDD_PRESCALER_16384 0xDU           /**< 16384 */
#define LPTMR_PDD_PRESCALER_32768 0xEU           /**< 32768 */
#define LPTMR_PDD_PRESCALER_65536 0xFU           /**< 65536 */
#define LPTMR_PDD_FILTER_2 0x1U                  /**< 2 */
#define LPTMR_PDD_FILTER_4 0x2U                  /**< 4 */
#define LPTMR_PDD_FILTER_8 0x3U                  /**< 8 */
#define LPTMR_PDD_FILTER_16 0x4U                 /**< 16 */
#define LPTMR_PDD_FILTER_32 0x5U                 /**< 32 */
#define LPTMR_PDD_FILTER_64 0x6U                 /**< 64 */
#define LPTMR_PDD_FILTER_128 0x7U                /**< 128 */
#define LPTMR_PDD_FILTER_256 0x8U                /**< 256 */
#define LPTMR_PDD_FILTER_512 0x9U                /**< 512 */
#define LPTMR_PDD_FILTER_1024 0xAU               /**< 1024 */
#define LPTMR_PDD_FILTER_2048 0xBU               /**< 2048 */
#define LPTMR_PDD_FILTER_4096 0xCU               /**< 4096 */
#define LPTMR_PDD_FILTER_8192 0xDU               /**< 8192 */
#define LPTMR_PDD_FILTER_16384 0xEU              /**< 16384 */
#define LPTMR_PDD_FILTER_32768 0xFU              /**< 32768 */

/* Divider constants */
#define LPTMR_PDD_DIVIDER_1 0x1U                 /**< 1 */
#define LPTMR_PDD_DIVIDER_2 0U                   /**< 2 */
#define LPTMR_PDD_DIVIDER_4 0x2U                 /**< 4 */
#define LPTMR_PDD_DIVIDER_8 0x4U                 /**< 8 */
#define LPTMR_PDD_DIVIDER_16 0x6U                /**< 16 */
#define LPTMR_PDD_DIVIDER_32 0x8U                /**< 32 */
#define LPTMR_PDD_DIVIDER_64 0xAU                /**< 64 */
#define LPTMR_PDD_DIVIDER_128 0xCU               /**< 128 */
#define LPTMR_PDD_DIVIDER_256 0xEU               /**< 256 */
#define LPTMR_PDD_DIVIDER_512 0x10U              /**< 512 */
#define LPTMR_PDD_DIVIDER_1024 0x12U             /**< 1024 */
#define LPTMR_PDD_DIVIDER_2048 0x14U             /**< 2048 */
#define LPTMR_PDD_DIVIDER_4096 0x16U             /**< 4096 */
#define LPTMR_PDD_DIVIDER_8192 0x18U             /**< 8192 */
#define LPTMR_PDD_DIVIDER_16384 0x1AU            /**< 16384 */
#define LPTMR_PDD_DIVIDER_32768 0x1CU            /**< 32768 */
#define LPTMR_PDD_DIVIDER_65536 0x1EU            /**< 65536 */

/* Timer Pin Select constants. */
#define LPTMR_PDD_HSCMP 0U                       /**< Alt 0 */
#define LPTMR_PDD_PIN_1 0x10U                    /**< Alt 1 */
#define LPTMR_PDD_PIN_2 0x20U                    /**< Alt 2 */
#define LPTMR_PDD_PIN_3 0x30U                    /**< Alt 3 */

/* Timer Pin Polarity constants. */
#define LPTMR_PDD_POLARITY_RISING 0U             /**< Rising */
#define LPTMR_PDD_POLARITY_FALLING 0x8U          /**< Falling */

/* Prescaler bypass constants. */
#define LPTMR_PDD_BYPASS_DISABLED 0U             /**< Disabled */
#define LPTMR_PDD_BYPASS_ENABLED 0x4U            /**< Enabled */

/* Clock source constants. */
#define LPTMR_PDD_SOURCE_INTREF 0U               /**< Internal reference clock */
#define LPTMR_PDD_SOURCE_LPO1KHZ 0x1U            /**< Low power oscillator clock */
#define LPTMR_PDD_SOURCE_EXT32KHZ 0x2U           /**< External 32 kHz clock */
#define LPTMR_PDD_SOURCE_EXTREF 0x3U             /**< External reference clock */


/* ----------------------------------------------------------------------------
   -- GetInterruptMask
   ---------------------------------------------------------------------------- */

/**
 * Returns interrupt mask.
 * @param peripheralBase Peripheral base address.
 */
#define LPTMR_PDD_GetInterruptMask(peripheralBase) ( \
    (uint32_t)(LPTMR_CSR_REG(peripheralBase) & LPTMR_CSR_TIE_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Returns interrupt flag bit.
 * @param peripheralBase Peripheral base address.
 */
#define LPTMR_PDD_GetInterruptFlag(peripheralBase) ( \
    (uint32_t)(LPTMR_CSR_REG(peripheralBase) & LPTMR_CSR_TCF_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- EnableInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables the LPT interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define LPTMR_PDD_EnableInterrupt(peripheralBase) ( \
    LPTMR_CSR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(LPTMR_CSR_REG(peripheralBase) | LPTMR_CSR_TIE_MASK)) & ( \
      (uint32_t)(~(uint32_t)LPTMR_CSR_TCF_MASK))) \
  )

/* ----------------------------------------------------------------------------
   -- DisableInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables the LPT interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define LPTMR_PDD_DisableInterrupt(peripheralBase) ( \
    LPTMR_CSR_REG(peripheralBase) &= \
     (uint32_t)(( \
      (uint32_t)(~(uint32_t)LPTMR_CSR_TIE_MASK)) & ( \
      (uint32_t)(~(uint32_t)LPTMR_CSR_TCF_MASK))) \
  )

/* ----------------------------------------------------------------------------
   -- ClearInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Clears LPT interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define LPTMR_PDD_ClearInterruptFlag(peripheralBase) ( \
    LPTMR_CSR_REG(peripheralBase) |= \
     LPTMR_CSR_TCF_MASK \
  )

/* ----------------------------------------------------------------------------
   -- SelectPin
   ---------------------------------------------------------------------------- */

/**
 * Sets Timer Pin Select bits.
 * @param peripheralBase Peripheral base address.
 * @param TPS_val New value of the TPS.
 */
#define LPTMR_PDD_SelectPin(peripheralBase, TPS_val) ( \
    LPTMR_CSR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       LPTMR_CSR_REG(peripheralBase)) & (( \
       (uint32_t)(~(uint32_t)LPTMR_CSR_TPS_MASK)) & ( \
       (uint32_t)(~(uint32_t)LPTMR_CSR_TCF_MASK))))) | ( \
      (uint32_t)(TPS_val))) \
  )

/* ----------------------------------------------------------------------------
   -- SetPinPolarity
   ---------------------------------------------------------------------------- */

/**
 * Configures the polarity of the input source.
 * @param peripheralBase Peripheral base address.
 * @param Edge New value of the polarity.
 */
#define LPTMR_PDD_SetPinPolarity(peripheralBase, Edge) ( \
    LPTMR_CSR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       LPTMR_CSR_REG(peripheralBase)) & (( \
       (uint32_t)(~(uint32_t)LPTMR_CSR_TPP_MASK)) & ( \
       (uint32_t)(~(uint32_t)LPTMR_CSR_TCF_MASK))))) | ( \
      (uint32_t)(Edge))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableFreerun
   ---------------------------------------------------------------------------- */

/**
 * Configures the freerun mode.
 * @param peripheralBase Peripheral base address.
 * @param Restart New value of the restart.
 */
#define LPTMR_PDD_EnableFreerun(peripheralBase, Restart) ( \
    LPTMR_CSR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       LPTMR_CSR_REG(peripheralBase)) & (( \
       (uint32_t)(~(uint32_t)LPTMR_CSR_TFC_MASK)) & ( \
       (uint32_t)(~(uint32_t)LPTMR_CSR_TCF_MASK))))) | ( \
      (uint32_t)(Restart))) \
  )

/* ----------------------------------------------------------------------------
   -- SetTimerMode
   ---------------------------------------------------------------------------- */

/**
 * Selects timer mode.
 * @param peripheralBase Peripheral base address.
 * @param Source New value of the source.
 */
#define LPTMR_PDD_SetTimerMode(peripheralBase, Source) ( \
    LPTMR_CSR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       LPTMR_CSR_REG(peripheralBase)) & (( \
       (uint32_t)(~(uint32_t)LPTMR_CSR_TMS_MASK)) & ( \
       (uint32_t)(~(uint32_t)LPTMR_CSR_TCF_MASK))))) | ( \
      (uint32_t)(Source))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableDevice
   ---------------------------------------------------------------------------- */

/**
 * Enables the LPT device.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state of LPT device.
 */
#define LPTMR_PDD_EnableDevice(peripheralBase, State) ( \
    LPTMR_CSR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       LPTMR_CSR_REG(peripheralBase)) & (( \
       (uint32_t)(~(uint32_t)LPTMR_CSR_TEN_MASK)) & ( \
       (uint32_t)(~(uint32_t)LPTMR_CSR_TCF_MASK))))) | ( \
      (uint32_t)(State))) \
  )

/* ----------------------------------------------------------------------------
   -- GetEnableDeviceStatus
   ---------------------------------------------------------------------------- */

/**
 * Returns current state of LPT device.
 * @param peripheralBase Peripheral base address.
 */
#define LPTMR_PDD_GetEnableDeviceStatus(peripheralBase) ( \
    (uint32_t)(LPTMR_CSR_REG(peripheralBase) & LPTMR_CSR_TEN_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- SetPrescaler
   ---------------------------------------------------------------------------- */

/**
 * Sets prescale value.
 * @param peripheralBase Peripheral base address.
 * @param Prescaler New value of the prescaler.
 */
#define LPTMR_PDD_SetPrescaler(peripheralBase, Prescaler) ( \
    LPTMR_PSR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(LPTMR_PSR_REG(peripheralBase) & (uint32_t)(~(uint32_t)LPTMR_PSR_PRESCALE_MASK))) | ( \
      (uint32_t)((uint32_t)(Prescaler) << LPTMR_PSR_PRESCALE_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- EnablePrescalerBypass
   ---------------------------------------------------------------------------- */

/**
 * Sets prescaler bypass.
 * @param peripheralBase Peripheral base address.
 * @param Bypass New value of the bypass.
 */
#define LPTMR_PDD_EnablePrescalerBypass(peripheralBase, Bypass) ( \
    LPTMR_PSR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(LPTMR_PSR_REG(peripheralBase) & (uint32_t)(~(uint32_t)LPTMR_PSR_PBYP_MASK))) | ( \
      (uint32_t)(Bypass))) \
  )

/* ----------------------------------------------------------------------------
   -- SetDivider
   ---------------------------------------------------------------------------- */

/**
 * Sets both prescale value and bypass value.
 * @param peripheralBase Peripheral base address.
 * @param Divider New value of the divider.
 */
#define LPTMR_PDD_SetDivider(peripheralBase, Divider) ( \
    LPTMR_PSR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       LPTMR_PSR_REG(peripheralBase)) & (( \
       (uint32_t)(~(uint32_t)LPTMR_PSR_PRESCALE_MASK)) & ( \
       (uint32_t)(~(uint32_t)LPTMR_PSR_PBYP_MASK))))) | (( \
      (uint32_t)((uint32_t)((uint32_t)(Divider) >> 1U) << LPTMR_PSR_PRESCALE_SHIFT)) | ( \
      (uint32_t)((uint32_t)((uint32_t)(Divider) & 0x1U) << LPTMR_PSR_PBYP_SHIFT)))) \
  )

/* ----------------------------------------------------------------------------
   -- SelectPrescalerSource
   ---------------------------------------------------------------------------- */

/**
 * Selects clock source.
 * @param peripheralBase Peripheral base address.
 * @param Source New value of the source.
 */
#define LPTMR_PDD_SelectPrescalerSource(peripheralBase, Source) ( \
    LPTMR_PSR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(LPTMR_PSR_REG(peripheralBase) & (uint32_t)(~(uint32_t)LPTMR_PSR_PCS_MASK))) | ( \
      (uint32_t)(Source))) \
  )

/* ----------------------------------------------------------------------------
   -- WriteCompareReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the compare register.
 * @param peripheralBase Peripheral base address.
 * @param Value New content of the compare register.
 */
#define LPTMR_PDD_WriteCompareReg(peripheralBase, Value) ( \
    LPTMR_CMR_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadCompareReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the compare register.
 * @param peripheralBase Peripheral base address.
 */
#define LPTMR_PDD_ReadCompareReg(peripheralBase) ( \
    LPTMR_CMR_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- ReadCounterReg
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MK10DZ10)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60N512VMD100)))
/**
 * Returns the content of the counter register.
 * @param peripheralBase Peripheral base address.
 */
  #define LPTMR_PDD_ReadCounterReg(peripheralBase) ( \
      LPTMR_CNR_REG(peripheralBase) \
    )
#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK52D10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_MKL04Z4)) || (defined(MCU_MKL05Z4)) || (defined(MCU_MKL14Z4)) || (defined(MCU_MKL15Z4)) || (defined(MCU_MKL24Z4)) || (defined(MCU_MKL25Z4)) || (defined(MCU_PCK20L4)) */
/**
 * Returns the content of the counter register.
 * @param peripheralBase Peripheral base address.
 */
  #define LPTMR_PDD_ReadCounterReg(peripheralBase) ( \
      (LPTMR_CNR_REG(peripheralBase) = \
       0U), \
      LPTMR_CNR_REG(peripheralBase) \
    )
#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK52D10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_MKL04Z4)) || (defined(MCU_MKL05Z4)) || (defined(MCU_MKL14Z4)) || (defined(MCU_MKL15Z4)) || (defined(MCU_MKL24Z4)) || (defined(MCU_MKL25Z4)) || (defined(MCU_PCK20L4)) */
#endif  /* #if defined(LPTMR_PDD_H_) */

/* LPTMR_PDD.h, eof. */
