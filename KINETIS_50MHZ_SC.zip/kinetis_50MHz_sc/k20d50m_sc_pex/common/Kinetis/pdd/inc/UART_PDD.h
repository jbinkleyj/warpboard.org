/*
  PDD layer implementation for peripheral type UART
  (C) 2010 Freescale, Inc. All rights reserved.

  This file is static and it is generated from API-Factory
*/

#if !defined(UART_PDD_H_)
#define UART_PDD_H_

/* ----------------------------------------------------------------------------
   -- Test if supported MCU is active
   ---------------------------------------------------------------------------- */

#if !defined(MCU_ACTIVE)
  // No MCU is active
  #error UART PDD library: No derivative is active. Place proper #include with PDD memory map before including PDD library.
#elif \
      !defined(MCU_MK10D10) /* UART0, UART1, UART2, UART3, UART4, UART5 */ && \
      !defined(MCU_MK10D5) /* UART0, UART1, UART2 */ && \
      !defined(MCU_MK10D7) /* UART0, UART1, UART2, UART3, UART4 */ && \
      !defined(MCU_MK10F12) /* UART0, UART1, UART2, UART3, UART4, UART5 */ && \
      !defined(MCU_MK10DZ10) /* UART0, UART1, UART2, UART3, UART4, UART5 */ && \
      !defined(MCU_MK11D5) /* UART0, UART1, UART2, UART3 */ && \
      !defined(MCU_MK12D5) /* UART0, UART1, UART2, UART3 */ && \
      !defined(MCU_MK20D10) /* UART0, UART1, UART2, UART3, UART4, UART5 */ && \
      !defined(MCU_MK20D5) /* UART0, UART1, UART2 */ && \
      !defined(MCU_MK20D7) /* UART0, UART1, UART2, UART3, UART4 */ && \
      !defined(MCU_MK20F12) /* UART0, UART1, UART2, UART3, UART4, UART5 */ && \
      !defined(MCU_MK20DZ10) /* UART0, UART1, UART2, UART3, UART4, UART5 */ && \
      !defined(MCU_MK21D5) /* UART0, UART1, UART2, UART3 */ && \
      !defined(MCU_MK22D5) /* UART0, UART1, UART2, UART3 */ && \
      !defined(MCU_MK30D10) /* UART0, UART1, UART2, UART3, UART4, UART5 */ && \
      !defined(MCU_MK30D7) /* UART0, UART1, UART2, UART3, UART4 */ && \
      !defined(MCU_MK30DZ10) /* UART0, UART1, UART2, UART3, UART4, UART5 */ && \
      !defined(MCU_MK40D10) /* UART0, UART1, UART2, UART3, UART4, UART5 */ && \
      !defined(MCU_MK40D7) /* UART0, UART1, UART2, UART3, UART4 */ && \
      !defined(MCU_MK40DZ10) /* UART0, UART1, UART2, UART3, UART4, UART5 */ && \
      !defined(MCU_MK40X256VMD100) /* UART0, UART1, UART2, UART3, UART4, UART5 */ && \
      !defined(MCU_MK50D10) /* UART0, UART1, UART2, UART3, UART4, UART5 */ && \
      !defined(MCU_MK50D7) /* UART0, UART1, UART2, UART3, UART4 */ && \
      !defined(MCU_MK50DZ10) /* UART0, UART1, UART2, UART3, UART4, UART5 */ && \
      !defined(MCU_MK51D10) /* UART0, UART1, UART2, UART3, UART4, UART5 */ && \
      !defined(MCU_MK51D7) /* UART0, UART1, UART2, UART3, UART4 */ && \
      !defined(MCU_MK51DZ10) /* UART0, UART1, UART2, UART3, UART4, UART5 */ && \
      !defined(MCU_MK52D10) /* UART0, UART1, UART2, UART3, UART4, UART5 */ && \
      !defined(MCU_MK52DZ10) /* UART0, UART1, UART2, UART3, UART4, UART5 */ && \
      !defined(MCU_MK53D10) /* UART0, UART1, UART2, UART3, UART4, UART5 */ && \
      !defined(MCU_MK53DZ10) /* UART0, UART1, UART2, UART3, UART4, UART5 */ && \
      !defined(MCU_MK60D10) /* UART0, UART1, UART2, UART3, UART4, UART5 */ && \
      !defined(MCU_MK60F12) /* UART0, UART1, UART2, UART3, UART4, UART5 */ && \
      !defined(MCU_MK60F15) /* UART0, UART1, UART2, UART3, UART4, UART5 */ && \
      !defined(MCU_MK60DZ10) /* UART0, UART1, UART2, UART3, UART4, UART5 */ && \
      !defined(MCU_MK60N512VMD100) /* UART0, UART1, UART2, UART3, UART4, UART5 */ && \
      !defined(MCU_MK61F12) /* UART0, UART1, UART2, UART3, UART4, UART5 */ && \
      !defined(MCU_MK61F15) /* UART0, UART1, UART2, UART3, UART4, UART5 */ && \
      !defined(MCU_MK70F12) /* UART0, UART1, UART2, UART3, UART4, UART5 */ && \
      !defined(MCU_MK70F15) /* UART0, UART1, UART2, UART3, UART4, UART5 */ && \
      !defined(MCU_MKL14Z4) /* UART1, UART2 */ && \
      !defined(MCU_MKL15Z4) /* UART1, UART2 */ && \
      !defined(MCU_MKL24Z4) /* UART1, UART2 */ && \
      !defined(MCU_MKL25Z4) /* UART1, UART2 */ && \
      !defined(MCU_PCK20L4) /* UART0, UART1, UART2 */
  // Unsupported MCU is active
  #error UART PDD library: Unsupported derivative is active.
#endif

#include "PDD_Types.h"

/* ----------------------------------------------------------------------------
   -- Method symbol definitions
   ---------------------------------------------------------------------------- */

/* Interrupt masks */
#define UART_PDD_INTERRUPT_TRANSMITTER UART_C2_TIE_MASK /**< Transmitter interrupt enable mask */
#define UART_PDD_INTERRUPT_TRANSMITTER_COMPLETE UART_C2_TCIE_MASK /**< Transmitter complete interrupt enable mask */
#define UART_PDD_INTERRUPT_RECEIVER UART_C2_RIE_MASK /**< Receiver interrupt enable mask */
#define UART_PDD_INTERRUPT_IDLE UART_C2_ILIE_MASK /**< Idle interrupt enable mask */
#define UART_PDD_INTERRUPT_PARITY_ERROR UART_C3_PEIE_MASK /**< Parity error interrupt enable mask */
#define UART_PDD_INTERRUPT_FRAMING_ERROR UART_C3_FEIE_MASK /**< Framing error interrupt enable mask */
#define UART_PDD_INTERRUPT_NOISE_ERROR UART_C3_NEIE_MASK /**< Noise error interrupt enable mask */
#define UART_PDD_INTERRUPT_OVERRUN_ERROR UART_C3_ORIE_MASK /**< Overrun error interrupt enable mask */

/* Fifo masks */
#define UART_PDD_TX_FIFO_ENABLE UART_PFIFO_TXFE_MASK /**< Transmitter FIFO enable mask */
#define UART_PDD_RX_FIFO_ENABLE UART_PFIFO_RXFE_MASK /**< Receiver FIFO enable mask */
#define UART_PDD_TX_FIFO_FLUSH UART_CFIFO_TXFLUSH_MASK /**< Transmitter FIFO flush command mask */
#define UART_PDD_RX_FIFO_FLUSH UART_CFIFO_RXFLUSH_MASK /**< Receiver FIFO flush command mask */

/* Parity types */
#define UART_PDD_PARITY_NONE 0U                  /**< No parity */
#define UART_PDD_PARITY_EVEN 0x2U                /**< Even parity */
#define UART_PDD_PARITY_ODD 0x3U                 /**< Even parity */

#if ((defined(MCU_MKL14Z4)) || (defined(MCU_MKL15Z4)) || (defined(MCU_MKL24Z4)) || (defined(MCU_MKL25Z4)))
/* Data width */
  #define UART_PDD_WIDTH_8 0U                      /**< 8-bit communication */
  #define UART_PDD_WIDTH_9 0x10U                   /**< 9-bit communication */

#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_PCK20L4)) */
/* Data width */
  #define UART_PDD_WIDTH_8 0U                      /**< 8-bit communication */
  #define UART_PDD_WIDTH_9 0x1U                    /**< 9-bit communication */
  #define UART_PDD_WIDTH_10 0x2U                   /**< 10-bit communication (10th bit can be used only as parity bit) */

#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_PCK20L4)) */
/* Loop mode */
#define UART_PDD_LOOP_MODE_NORMAL 0U             /**< Normal operation mode. No loopback selected. */
#define UART_PDD_LOOP_MODE_LOCAL_LOOP 0x80U      /**< Local loopback mode. */

/* Position of a parity bit */
#define UART_PDD_PARITY_BIT_POSITION_9 0U        /**< Parity bit is the 9-th bit in the serial transmission */
#define UART_PDD_PARITY_BIT_POSITION_10 0x20U    /**< Parity bit is the 10-th bit in the serial transmission */

/* Receiver power states. */
#define UART_PDD_POWER_NORMAL 0U                 /**< Normal operation. */
#define UART_PDD_POWER_STANDBY 0x2U              /**< Standby mode (waiting for a wakeup condition). */

/* Stop bit lengths */
#define UART_PDD_STOP_BIT_LEN_1 0U               /**< One stop bit. */
#define UART_PDD_STOP_BIT_LEN_2 0x20U            /**< Two stop bits. */


/* ----------------------------------------------------------------------------
   -- EnableTransmitter
   ---------------------------------------------------------------------------- */

/**
 * Enables UART transmitter.
 * @param peripheralBase Peripheral base address.
 * @param State Enables or disables transmitter.
 */
#define UART_PDD_EnableTransmitter(peripheralBase, State) ( \
    UART_C2_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(UART_C2_REG(peripheralBase) & (uint8_t)(~(uint8_t)UART_C2_TE_MASK))) | ( \
      (uint8_t)((uint8_t)(State) << UART_C2_TE_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableReceiver
   ---------------------------------------------------------------------------- */

/**
 * Enables UART receiver.
 * @param peripheralBase Peripheral base address.
 * @param State Enables or disables receiver.
 */
#define UART_PDD_EnableReceiver(peripheralBase, State) ( \
    UART_C2_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(UART_C2_REG(peripheralBase) & (uint8_t)(~(uint8_t)UART_C2_RE_MASK))) | ( \
      (uint8_t)((uint8_t)(State) << UART_C2_RE_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- ReadDataReg
   ---------------------------------------------------------------------------- */

/**
 * Reads data register.
 * @param peripheralBase Peripheral base address.
 */
#define UART_PDD_ReadDataReg(peripheralBase) ( \
    UART_D_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteDataReg
   ---------------------------------------------------------------------------- */

/**
 * Writes data specified by the Value parameter into data register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value to be written to the data register.
 */
#define UART_PDD_WriteDataReg(peripheralBase, Value) ( \
    UART_D_REG(peripheralBase) = \
     (uint8_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- PutChar8
   ---------------------------------------------------------------------------- */

/**
 * Puts 8-bits character into the transmit buffer.
 * @param peripheralBase Peripheral base address.
 * @param Char 8-bits character to be written to the data register.
 */
#define UART_PDD_PutChar8(peripheralBase, Char) ( \
    UART_D_REG(peripheralBase) = \
     (uint8_t)(Char) \
  )

/* ----------------------------------------------------------------------------
   -- PutChar9
   ---------------------------------------------------------------------------- */

/**
 * Puts 9-bits character into the transmit buffer.
 * @param peripheralBase Peripheral base address.
 * @param Char 9-bits character to be written to the data register.
 */
#define UART_PDD_PutChar9(peripheralBase, Char) ( \
    (UART_C3_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(UART_C3_REG(peripheralBase) & (uint8_t)(~(uint8_t)UART_C3_T8_MASK))) | ( \
      (uint8_t)((uint8_t)((uint16_t)(Char) >> 8U) << UART_C3_T8_SHIFT)))), \
    (UART_D_REG(peripheralBase) = \
     (uint8_t)(Char)) \
  )

/* ----------------------------------------------------------------------------
   -- GetChar8
   ---------------------------------------------------------------------------- */

/**
 * Returns a 8-bit character from the receive buffer.
 * @param peripheralBase Peripheral base address.
 */
#define UART_PDD_GetChar8(peripheralBase) ( \
    UART_D_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- GetChar9Bit
   ---------------------------------------------------------------------------- */

/**
 * Returns the 9th bit of the character from the receive buffer shifted to its
 * bit position (9th). Must be called prior to calling GetChar8 to read the whole
 * 9-bit character.
 * @param peripheralBase Peripheral base address.
 */
#define UART_PDD_GetChar9Bit(peripheralBase) ( \
    (uint16_t)(( \
     (uint16_t)((uint16_t)(UART_C3_REG(peripheralBase) & UART_C3_R8_MASK) >> UART_C3_R8_SHIFT)) << ( \
     8U)) \
  )

/* ----------------------------------------------------------------------------
   -- EnableInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables interrupts specified by the Mask parameter.
 * @param peripheralBase Peripheral base address.
 * @param Mask Interrupt mask.
 */
#define UART_PDD_EnableInterrupt(peripheralBase, Mask) ( \
    (UART_C2_REG(peripheralBase) |= \
     (uint8_t)((uint8_t)(Mask) & (uint8_t)(~(uint8_t)0xFU))), \
    (UART_C3_REG(peripheralBase) |= \
     (uint8_t)((uint8_t)(Mask) & 0xFU)) \
  )

/* ----------------------------------------------------------------------------
   -- DisableInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables interrupts specified by the Mask parameter.
 * @param peripheralBase Peripheral base address.
 * @param Mask Interrupt mask.
 */
#define UART_PDD_DisableInterrupt(peripheralBase, Mask) ( \
    (UART_C2_REG(peripheralBase) &= \
     (uint8_t)(~(uint8_t)((uint8_t)(Mask) & (uint8_t)(~(uint8_t)0xFU)))), \
    (UART_C3_REG(peripheralBase) &= \
     (uint8_t)(~(uint8_t)((uint8_t)(Mask) & 0xFU))) \
  )

/* ----------------------------------------------------------------------------
   -- GetTxCompleteInterruptMask
   ---------------------------------------------------------------------------- */

/**
 * Gets the status of the transmiter complete interrupt enable bit.
 * @param peripheralBase Peripheral base address.
 */
#define UART_PDD_GetTxCompleteInterruptMask(peripheralBase) ( \
    (uint8_t)(UART_C2_REG(peripheralBase) & UART_C2_TCIE_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetTxCompleteStatus
   ---------------------------------------------------------------------------- */

/**
 * Gets the status of the transmiter complete interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define UART_PDD_GetTxCompleteStatus(peripheralBase) ( \
    (uint8_t)(UART_S1_REG(peripheralBase) & UART_S1_TC_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- SetParity
   ---------------------------------------------------------------------------- */

/**
 * Sets a communication parity type.
 * @param peripheralBase Peripheral base address.
 * @param Parity Parity type.
 */
#define UART_PDD_SetParity(peripheralBase, Parity) ( \
    UART_C1_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(UART_C1_REG(peripheralBase) & (uint8_t)(~(uint8_t)0x3U))) | ( \
      (uint8_t)(Parity))) \
  )

/* ----------------------------------------------------------------------------
   -- SetDataWidth
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MKL14Z4)) || (defined(MCU_MKL15Z4)) || (defined(MCU_MKL24Z4)) || (defined(MCU_MKL25Z4)))
/**
 * Sets the communication width.
 * @param peripheralBase Peripheral base address.
 * @param Width Data width.
 */
  #define UART_PDD_SetDataWidth(peripheralBase, Width) ( \
      UART_C1_REG(peripheralBase) = \
       (uint8_t)(( \
        (uint8_t)(UART_C1_REG(peripheralBase) & (uint8_t)(~(uint8_t)UART_C1_M_MASK))) | ( \
        (uint8_t)(Width))) \
    )
#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_PCK20L4)) */
/**
 * Sets the communication width.
 * @param peripheralBase Peripheral base address.
 * @param Width Data width.
 */
  #define UART_PDD_SetDataWidth(peripheralBase, Width) ( \
      ( \
       ((Width) == UART_PDD_WIDTH_8) ? ( \
        UART_C1_REG(peripheralBase) &= \
         (uint8_t)(~(uint8_t)UART_C1_M_MASK)) : (((Width) == UART_PDD_WIDTH_9) ? ( \
        UART_C1_REG(peripheralBase) |= \
         (uint8_t)((uint8_t)0x1U << UART_C1_M_SHIFT)) : ( \
        UART_C1_REG(peripheralBase) |= \
         (uint8_t)((uint8_t)0x1U << UART_C1_M_SHIFT)) \
      )), \
      ( \
       ((Width) == UART_PDD_WIDTH_8) ? ( \
        UART_C4_REG(peripheralBase) &= \
         (uint8_t)(~(uint8_t)UART_C4_M10_MASK)) : (((Width) == UART_PDD_WIDTH_9) ? ( \
        UART_C4_REG(peripheralBase) &= \
         (uint8_t)(~(uint8_t)UART_C4_M10_MASK)) : ( \
        UART_C4_REG(peripheralBase) |= \
         (uint8_t)((uint8_t)0x1U << UART_C4_M10_SHIFT)) \
      )) \
    )
#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_PCK20L4)) */

/* ----------------------------------------------------------------------------
   -- SetLoopMode
   ---------------------------------------------------------------------------- */

/**
 * Selects the loop mode operation.
 * @param peripheralBase Peripheral base address.
 * @param LoopMode Loop mode.
 */
#define UART_PDD_SetLoopMode(peripheralBase, LoopMode) ( \
    UART_C1_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(UART_C1_REG(peripheralBase) & (uint8_t)(~(uint8_t)UART_C1_LOOPS_MASK))) | ( \
      (uint8_t)(LoopMode))) \
  )

/* ----------------------------------------------------------------------------
   -- ReadInterruptStatusReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the interrupt status register.
 * @param peripheralBase Peripheral base address.
 */
#define UART_PDD_ReadInterruptStatusReg(peripheralBase) ( \
    UART_S1_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- SetBaudRate
   ---------------------------------------------------------------------------- */

/**
 * Sets new baud rate value.
 * @param peripheralBase Peripheral base address.
 * @param BaudRate New baud rate value.
 */
#define UART_PDD_SetBaudRate(peripheralBase, BaudRate) ( \
    (UART_BDH_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(UART_BDH_REG(peripheralBase) & (uint8_t)(~(uint8_t)UART_BDH_SBR_MASK))) | ( \
      (uint8_t)((uint16_t)(BaudRate) >> 8U)))), \
    (UART_BDL_REG(peripheralBase) = \
     (uint8_t)(BaudRate)) \
  )

/* ----------------------------------------------------------------------------
   -- SetBaudRateFineAdjust
   ---------------------------------------------------------------------------- */

/**
 * Set new baud rate fine adjust value.
 * @param peripheralBase Peripheral base address.
 * @param FineAdjust New baud rate fine adjust value.
 */
#define UART_PDD_SetBaudRateFineAdjust(peripheralBase, FineAdjust) ( \
    UART_C4_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(UART_C4_REG(peripheralBase) & (uint8_t)(~(uint8_t)UART_C4_BRFA_MASK))) | ( \
      (uint8_t)(FineAdjust))) \
  )

/* ----------------------------------------------------------------------------
   -- SetBreak
   ---------------------------------------------------------------------------- */

/**
 * Set the break signal.
 * @param peripheralBase Peripheral base address.
 */
#define UART_PDD_SetBreak(peripheralBase) ( \
    UART_C2_REG(peripheralBase) |= \
     UART_C2_SBK_MASK \
  )

/* ----------------------------------------------------------------------------
   -- ClearBreak
   ---------------------------------------------------------------------------- */

/**
 * Clears the break signal.
 * @param peripheralBase Peripheral base address.
 */
#define UART_PDD_ClearBreak(peripheralBase) ( \
    UART_C2_REG(peripheralBase) &= \
     (uint8_t)(~(uint8_t)UART_C2_SBK_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetBreak
   ---------------------------------------------------------------------------- */

/**
 * Returns .
 * @param peripheralBase Peripheral base address.
 */
#define UART_PDD_GetBreak(peripheralBase) ( \
    (( \
      (uint8_t)(UART_S1_REG(peripheralBase) & (uint8_t)(UART_S1_FE_MASK | UART_S1_RDRF_MASK))) == ( \
      (uint8_t)(UART_S1_FE_MASK | UART_S1_RDRF_MASK))) ? ( \
      0x1U) : ( \
      0U) \
  )

/* ----------------------------------------------------------------------------
   -- SendBreak
   ---------------------------------------------------------------------------- */

/**
 * Send the break character.
 * @param peripheralBase Peripheral base address.
 */
#define UART_PDD_SendBreak(peripheralBase) ( \
    (UART_C2_REG(peripheralBase) |= \
     UART_C2_SBK_MASK), \
    (UART_C2_REG(peripheralBase) &= \
     (uint8_t)(~(uint8_t)UART_C2_SBK_MASK)) \
  )

/* ----------------------------------------------------------------------------
   -- SetPositionOfParityBit
   ---------------------------------------------------------------------------- */

/**
 * Sets the position of the parity bit.
 * @param peripheralBase Peripheral base address.
 * @param Position Position of a parity bit.
 */
#define UART_PDD_SetPositionOfParityBit(peripheralBase, Position) ( \
    UART_C4_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(UART_C4_REG(peripheralBase) & (uint8_t)(~(uint8_t)UART_C4_M10_MASK))) | ( \
      (uint8_t)(Position))) \
  )

/* ----------------------------------------------------------------------------
   -- SetReceiverPowerState
   ---------------------------------------------------------------------------- */

/**
 * Places the receiver in a standby state where it waits for automatic hardware
 * detection of a selected wakeup condition.
 * @param peripheralBase Peripheral base address.
 * @param State Receiver power state to be set.
 */
#define UART_PDD_SetReceiverPowerState(peripheralBase, State) ( \
    UART_C2_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(UART_C2_REG(peripheralBase) & (uint8_t)(~(uint8_t)UART_C2_RWU_MASK))) | ( \
      (uint8_t)(State))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableFifo
   ---------------------------------------------------------------------------- */

/**
 * Enables FIFO specified by the FifoMask parameter.
 * @param peripheralBase Peripheral base address.
 * @param FifoMask Specifies receive or transmit FIFO.
 */
#define UART_PDD_EnableFifo(peripheralBase, FifoMask) ( \
    UART_PFIFO_REG(peripheralBase) |= \
     (uint8_t)(FifoMask) \
  )

/* ----------------------------------------------------------------------------
   -- FlushFifo
   ---------------------------------------------------------------------------- */

/**
 * Flushes FIFO specified by the FifoMask parameter.
 * @param peripheralBase Peripheral base address.
 * @param FifoMask Specifies receive or transmit FIFO.
 */
#define UART_PDD_FlushFifo(peripheralBase, FifoMask) ( \
    UART_CFIFO_REG(peripheralBase) |= \
     (uint8_t)(FifoMask) \
  )

/* ----------------------------------------------------------------------------
   -- SetStopBitLength
   ---------------------------------------------------------------------------- */

/**
 * Sets the number of stop bits.
 * @param peripheralBase Peripheral base address.
 * @param Length Stop bit length.
 */
#define UART_PDD_SetStopBitLength(peripheralBase, Length) ( \
    UART_BDH_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(UART_BDH_REG(peripheralBase) & (uint8_t)(~(uint8_t)UART_BDH_SBNS_MASK))) | ( \
      (uint8_t)(Length))) \
  )
#endif  /* #if defined(UART_PDD_H_) */

/* UART_PDD.h, eof. */
