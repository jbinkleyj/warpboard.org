/*
  PDD layer implementation for peripheral type FTM
  (C) 2010 Freescale, Inc. All rights reserved.

  This file is static and it is generated from API-Factory
*/

#if !defined(FTM_PDD_H_)
#define FTM_PDD_H_

/* ----------------------------------------------------------------------------
   -- Test if supported MCU is active
   ---------------------------------------------------------------------------- */

#if !defined(MCU_ACTIVE)
  // No MCU is active
  #error FTM PDD library: No derivative is active. Place proper #include with PDD memory map before including PDD library.
#elif \
      !defined(MCU_MK10D10) /* FTM0, FTM1, FTM2 */ && \
      !defined(MCU_MK10D5) /* FTM0, FTM1 */ && \
      !defined(MCU_MK10D7) /* FTM0, FTM1, FTM2 */ && \
      !defined(MCU_MK10F12) /* FTM0, FTM1, FTM2, FTM3 */ && \
      !defined(MCU_MK10DZ10) /* FTM0, FTM1, FTM2 */ && \
      !defined(MCU_MK11D5) /* FTM0, FTM1, FTM2 */ && \
      !defined(MCU_MK12D5) /* FTM0, FTM1, FTM2 */ && \
      !defined(MCU_MK20D10) /* FTM0, FTM1, FTM2 */ && \
      !defined(MCU_MK20D5) /* FTM0, FTM1 */ && \
      !defined(MCU_MK20D7) /* FTM0, FTM1, FTM2 */ && \
      !defined(MCU_MK20F12) /* FTM0, FTM1, FTM2, FTM3 */ && \
      !defined(MCU_MK20DZ10) /* FTM0, FTM1, FTM2 */ && \
      !defined(MCU_MK21D5) /* FTM0, FTM1, FTM2 */ && \
      !defined(MCU_MK22D5) /* FTM0, FTM1, FTM2 */ && \
      !defined(MCU_MK30D10) /* FTM0, FTM1, FTM2 */ && \
      !defined(MCU_MK30D7) /* FTM0, FTM1, FTM2 */ && \
      !defined(MCU_MK30DZ10) /* FTM0, FTM1, FTM2 */ && \
      !defined(MCU_MK40D10) /* FTM0, FTM1, FTM2 */ && \
      !defined(MCU_MK40D7) /* FTM0, FTM1, FTM2 */ && \
      !defined(MCU_MK40DZ10) /* FTM0, FTM1, FTM2 */ && \
      !defined(MCU_MK40X256VMD100) /* FTM0, FTM1, FTM2 */ && \
      !defined(MCU_MK50D10) /* FTM0, FTM1, FTM2 */ && \
      !defined(MCU_MK50D7) /* FTM0, FTM1, FTM2 */ && \
      !defined(MCU_MK50DZ10) /* FTM0, FTM1, FTM2 */ && \
      !defined(MCU_MK51D10) /* FTM0, FTM1, FTM2 */ && \
      !defined(MCU_MK51D7) /* FTM0, FTM1, FTM2 */ && \
      !defined(MCU_MK51DZ10) /* FTM0, FTM1, FTM2 */ && \
      !defined(MCU_MK52D10) /* FTM0, FTM1, FTM2 */ && \
      !defined(MCU_MK52DZ10) /* FTM0, FTM1, FTM2 */ && \
      !defined(MCU_MK53D10) /* FTM0, FTM1, FTM2 */ && \
      !defined(MCU_MK53DZ10) /* FTM0, FTM1, FTM2 */ && \
      !defined(MCU_MK60D10) /* FTM0, FTM1, FTM2 */ && \
      !defined(MCU_MK60F12) /* FTM0, FTM1, FTM2, FTM3 */ && \
      !defined(MCU_MK60F15) /* FTM0, FTM1, FTM2, FTM3 */ && \
      !defined(MCU_MK60DZ10) /* FTM0, FTM1, FTM2 */ && \
      !defined(MCU_MK60N512VMD100) /* FTM0, FTM1, FTM2 */ && \
      !defined(MCU_MK61F12) /* FTM0, FTM1, FTM2, FTM3 */ && \
      !defined(MCU_MK61F15) /* FTM0, FTM1, FTM2, FTM3 */ && \
      !defined(MCU_MK70F12) /* FTM0, FTM1, FTM2, FTM3 */ && \
      !defined(MCU_MK70F15) /* FTM0, FTM1, FTM2, FTM3 */ && \
      !defined(MCU_PCK20L4) /* FTM0, FTM1 */
  // Unsupported MCU is active
  #error FTM PDD library: Unsupported derivative is active.
#endif

#include "PDD_Types.h"

/* ----------------------------------------------------------------------------
   -- Method symbol definitions
   ---------------------------------------------------------------------------- */

/* FTM channel constants */
#define FTM_PDD_CHANNEL_0 0U                     /**< 0 */
#define FTM_PDD_CHANNEL_1 0x1U                   /**< 1 */
#define FTM_PDD_CHANNEL_2 0x2U                   /**< 2 */
#define FTM_PDD_CHANNEL_3 0x3U                   /**< 3 */
#define FTM_PDD_CHANNEL_4 0x4U                   /**< 4 */
#define FTM_PDD_CHANNEL_5 0x5U                   /**< 5 */
#define FTM_PDD_CHANNEL_6 0x6U                   /**< 6 */
#define FTM_PDD_CHANNEL_7 0x7U                   /**< 7 */

/* Prescaler constants */
#define FTM_PDD_DIVIDE_1 0U                      /**< 1 */
#define FTM_PDD_DIVIDE_2 0x1U                    /**< 2 */
#define FTM_PDD_DIVIDE_4 0x2U                    /**< 4 */
#define FTM_PDD_DIVIDE_8 0x3U                    /**< 8 */
#define FTM_PDD_DIVIDE_16 0x4U                   /**< 16 */
#define FTM_PDD_DIVIDE_32 0x5U                   /**< 32 */
#define FTM_PDD_DIVIDE_64 0x6U                   /**< 64 */
#define FTM_PDD_DIVIDE_128 0x7U                  /**< 128 */

/* PWM aligned mode constants */
#define FTM_PDD_EDGE_ALIGNED 0U                  /**< Edge aligned */
#define FTM_PDD_CENTER_ALIGNED FTM_SC_CPWMS_MASK /**< Center aligned */

/* Interrupt flag masks for ClearChannelFlag */
#define FTM_PDD_FLAG_0 FTM_STATUS_CH0F_MASK      /**< 0 */
#define FTM_PDD_FLAG_1 FTM_STATUS_CH1F_MASK      /**< 1 */
#define FTM_PDD_FLAG_2 FTM_STATUS_CH2F_MASK      /**< 2 */
#define FTM_PDD_FLAG_3 FTM_STATUS_CH3F_MASK      /**< 3 */
#define FTM_PDD_FLAG_4 FTM_STATUS_CH4F_MASK      /**< 4 */
#define FTM_PDD_FLAG_5 FTM_STATUS_CH5F_MASK      /**< 5 */
#define FTM_PDD_FLAG_6 FTM_STATUS_CH6F_MASK      /**< 6 */
#define FTM_PDD_FLAG_7 FTM_STATUS_CH7F_MASK      /**< 7 */

/* Clock source constants. */
#define FTM_PDD_DISABLED 0U                      /**< Disabled */
#define FTM_PDD_SYSTEM 0x8U                      /**< System clock */
#define FTM_PDD_FIXED 0x10U                      /**< Fixed clock */
#define FTM_PDD_EXTERNAL 0x18U                   /**< External clock */

/* Edge and level constants. */
#define FTM_PDD_EDGE_NONE 0U                     /**< Disabled */
#define FTM_PDD_EDGE_RISING 0x4U                 /**< Rising */
#define FTM_PDD_EDGE_FALLING 0x8U                /**< Falling */
#define FTM_PDD_EDGE_BOTH 0xCU                   /**< Both */

/* Output action constants. */
#define FTM_PDD_OUTPUT_NONE 0U                   /**< Disconnect */
#define FTM_PDD_OUTPUT_TOGGLE 0x10U              /**< Toggle */
#define FTM_PDD_OUTPUT_CLEAR 0x20U               /**< Clear */
#define FTM_PDD_OUTPUT_SET 0x30U                 /**< Set */


/* ----------------------------------------------------------------------------
   -- SetPrescaler
   ---------------------------------------------------------------------------- */

/**
 * Sets prescale value.
 * @param peripheralBase Peripheral base address.
 * @param Prescaler New value of the prescaler.
 */
#define FTM_PDD_SetPrescaler(peripheralBase, Prescaler) ( \
    FTM_SC_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       FTM_SC_REG(peripheralBase)) & (( \
       (uint32_t)(~(uint32_t)FTM_SC_PS_MASK)) & ( \
       (uint32_t)(~(uint32_t)FTM_SC_TOF_MASK))))) | ( \
      (uint32_t)(Prescaler))) \
  )

/* ----------------------------------------------------------------------------
   -- SelectPrescalerSource
   ---------------------------------------------------------------------------- */

/**
 * Select clock source.
 * @param peripheralBase Peripheral base address.
 * @param Source New value of the source.
 */
#define FTM_PDD_SelectPrescalerSource(peripheralBase, Source) ( \
    FTM_SC_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       FTM_SC_REG(peripheralBase)) & (( \
       (uint32_t)(~(uint32_t)FTM_SC_CLKS_MASK)) & ( \
       (uint32_t)(~(uint32_t)FTM_SC_TOF_MASK))))) | ( \
      (uint32_t)(Source))) \
  )

/* ----------------------------------------------------------------------------
   -- GetEnableDeviceStatus
   ---------------------------------------------------------------------------- */

/**
 * Returns current state of FTM device.
 * @param peripheralBase Peripheral base address.
 */
#define FTM_PDD_GetEnableDeviceStatus(peripheralBase) ( \
    (uint32_t)(FTM_SC_REG(peripheralBase) & FTM_SC_CLKS_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- SelectPwmAlignMode
   ---------------------------------------------------------------------------- */

/**
 * Configures PWM aligned mode.
 * @param peripheralBase Peripheral base address.
 * @param Mode New value of the mode.
 */
#define FTM_PDD_SelectPwmAlignMode(peripheralBase, Mode) ( \
    FTM_SC_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       FTM_SC_REG(peripheralBase)) & (( \
       (uint32_t)(~(uint32_t)FTM_SC_CPWMS_MASK)) & ( \
       (uint32_t)(~(uint32_t)FTM_SC_TOF_MASK))))) | ( \
      (uint32_t)(Mode))) \
  )

/* ----------------------------------------------------------------------------
   -- GetOverflowInterruptMask
   ---------------------------------------------------------------------------- */

/**
 * Returns overflow interrupt mask.
 * @param peripheralBase Peripheral base address.
 */
#define FTM_PDD_GetOverflowInterruptMask(peripheralBase) ( \
    (uint32_t)(FTM_SC_REG(peripheralBase) & FTM_SC_TOIE_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- EnableOverflowInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables the FTM overflow interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define FTM_PDD_EnableOverflowInterrupt(peripheralBase) ( \
    FTM_SC_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(FTM_SC_REG(peripheralBase) | FTM_SC_TOIE_MASK)) & ( \
      (uint32_t)(~(uint32_t)FTM_SC_TOF_MASK))) \
  )

/* ----------------------------------------------------------------------------
   -- DisableOverflowInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables the FTM overflow interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define FTM_PDD_DisableOverflowInterrupt(peripheralBase) ( \
    FTM_SC_REG(peripheralBase) &= \
     (uint32_t)(( \
      (uint32_t)(~(uint32_t)FTM_SC_TOIE_MASK)) & ( \
      (uint32_t)(~(uint32_t)FTM_SC_TOF_MASK))) \
  )

/* ----------------------------------------------------------------------------
   -- GetOverflowInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Returns overflow interrupt flag bit.
 * @param peripheralBase Peripheral base address.
 */
#define FTM_PDD_GetOverflowInterruptFlag(peripheralBase) ( \
    (uint32_t)(FTM_SC_REG(peripheralBase) & FTM_SC_TOF_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- ClearOverflowInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Clears overflow interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define FTM_PDD_ClearOverflowInterruptFlag(peripheralBase) ( \
    FTM_SC_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)FTM_SC_TOF_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- ReadCounterReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the counter register.
 * @param peripheralBase Peripheral base address.
 */
#define FTM_PDD_ReadCounterReg(peripheralBase) ( \
    FTM_CNT_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- InitializeCounter
   ---------------------------------------------------------------------------- */

/**
 * Writes value 0 to the counter register.
 * @param peripheralBase Peripheral base address.
 */
#define FTM_PDD_InitializeCounter(peripheralBase) ( \
    FTM_CNT_REG(peripheralBase) = \
     0U \
  )

/* ----------------------------------------------------------------------------
   -- WriteModuloReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the modulo register.
 * @param peripheralBase Peripheral base address.
 * @param Value New content of the modulo register.
 */
#define FTM_PDD_WriteModuloReg(peripheralBase, Value) ( \
    FTM_MOD_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadModuloReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the modulo register.
 * @param peripheralBase Peripheral base address.
 */
#define FTM_PDD_ReadModuloReg(peripheralBase) ( \
    FTM_MOD_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- EnableChannelDma
   ---------------------------------------------------------------------------- */

/**
 * Enables the FTM channel DMA.
 * @param peripheralBase Peripheral base address.
 * @param ChannelIdx FTM channel index.
 */
#define FTM_PDD_EnableChannelDma(peripheralBase, ChannelIdx) ( \
    FTM_CnSC_REG(peripheralBase,(ChannelIdx)) = \
     (uint32_t)(( \
      (uint32_t)(FTM_CnSC_REG(peripheralBase,(ChannelIdx)) | FTM_CnSC_DMA_MASK)) & ( \
      (uint32_t)(~(uint32_t)FTM_CnSC_CHF_MASK))) \
  )

/* ----------------------------------------------------------------------------
   -- DisableChannelDma
   ---------------------------------------------------------------------------- */

/**
 * Disables the FTM channel DMA.
 * @param peripheralBase Peripheral base address.
 * @param ChannelIdx FTM channel index.
 */
#define FTM_PDD_DisableChannelDma(peripheralBase, ChannelIdx) ( \
    FTM_CnSC_REG(peripheralBase,(ChannelIdx)) &= \
     (uint32_t)(( \
      (uint32_t)(~(uint32_t)FTM_CnSC_DMA_MASK)) & ( \
      (uint32_t)(~(uint32_t)FTM_CnSC_CHF_MASK))) \
  )

/* ----------------------------------------------------------------------------
   -- SelectChannelEdgeLevel
   ---------------------------------------------------------------------------- */

/**
 * Selects the FTM channel edge and level.
 * @param peripheralBase Peripheral base address.
 * @param ChannelIdx FTM channel index.
 * @param ELSBA_val FTM channel ELSB:ELSA bits.
 */
#define FTM_PDD_SelectChannelEdgeLevel(peripheralBase, ChannelIdx, ELSBA_val) ( \
    FTM_CnSC_REG(peripheralBase,(ChannelIdx)) = \
     (uint32_t)(( \
      (uint32_t)(( \
       FTM_CnSC_REG(peripheralBase,(ChannelIdx))) & (( \
       (uint32_t)(~(uint32_t)((uint32_t)0x3U << 2U))) & ( \
       (uint32_t)(~(uint32_t)FTM_CnSC_CHF_MASK))))) | ( \
      (uint32_t)(ELSBA_val))) \
  )

/* ----------------------------------------------------------------------------
   -- SelectChannelMode
   ---------------------------------------------------------------------------- */

/**
 * Selects the FTM channel mode.
 * @param peripheralBase Peripheral base address.
 * @param ChannelIdx FTM channel index.
 * @param MSBA_val FTM channel MSB:MSA bits.
 */
#define FTM_PDD_SelectChannelMode(peripheralBase, ChannelIdx, MSBA_val) ( \
    FTM_CnSC_REG(peripheralBase,(ChannelIdx)) = \
     (uint32_t)(( \
      (uint32_t)(( \
       FTM_CnSC_REG(peripheralBase,(ChannelIdx))) & (( \
       (uint32_t)(~(uint32_t)((uint32_t)0x3U << 4U))) & ( \
       (uint32_t)(~(uint32_t)FTM_CnSC_CHF_MASK))))) | ( \
      (uint32_t)(MSBA_val))) \
  )

/* ----------------------------------------------------------------------------
   -- GetChannelInterruptMask
   ---------------------------------------------------------------------------- */

/**
 * Returns channel interrupt mask.
 * @param peripheralBase Peripheral base address.
 * @param ChannelIdx FTM channel index.
 */
#define FTM_PDD_GetChannelInterruptMask(peripheralBase, ChannelIdx) ( \
    (uint32_t)(FTM_CnSC_REG(peripheralBase,(ChannelIdx)) & FTM_CnSC_CHIE_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- EnableChannelInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables the FTM channel interrupt.
 * @param peripheralBase Peripheral base address.
 * @param ChannelIdx FTM channel index.
 */
#define FTM_PDD_EnableChannelInterrupt(peripheralBase, ChannelIdx) ( \
    FTM_CnSC_REG(peripheralBase,(ChannelIdx)) = \
     (uint32_t)(( \
      (uint32_t)(FTM_CnSC_REG(peripheralBase,(ChannelIdx)) | FTM_CnSC_CHIE_MASK)) & ( \
      (uint32_t)(~(uint32_t)FTM_CnSC_CHF_MASK))) \
  )

/* ----------------------------------------------------------------------------
   -- DisableChannelInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables the FTM channel interrupt.
 * @param peripheralBase Peripheral base address.
 * @param ChannelIdx FTM channel index.
 */
#define FTM_PDD_DisableChannelInterrupt(peripheralBase, ChannelIdx) ( \
    FTM_CnSC_REG(peripheralBase,(ChannelIdx)) &= \
     (uint32_t)(( \
      (uint32_t)(~(uint32_t)FTM_CnSC_CHIE_MASK)) & ( \
      (uint32_t)(~(uint32_t)FTM_CnSC_CHF_MASK))) \
  )

/* ----------------------------------------------------------------------------
   -- GetChannelInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Returns channel interrupt flag bit.
 * @param peripheralBase Peripheral base address.
 * @param ChannelIdx FTM channel index.
 */
#define FTM_PDD_GetChannelInterruptFlag(peripheralBase, ChannelIdx) ( \
    (uint32_t)(FTM_CnSC_REG(peripheralBase,(ChannelIdx)) & FTM_CnSC_CHF_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- ClearChannelInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Clears channel interrupt flag.
 * @param peripheralBase Peripheral base address.
 * @param ChannelIdx FTM channel index.
 */
#define FTM_PDD_ClearChannelInterruptFlag(peripheralBase, ChannelIdx) ( \
    FTM_CnSC_REG(peripheralBase,(ChannelIdx)) &= \
     (uint32_t)(~(uint32_t)FTM_CnSC_CHF_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- ReadChannelControlReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the channel status and control register.
 * @param peripheralBase Peripheral base address.
 * @param ChannelIdx FTM channel index.
 */
#define FTM_PDD_ReadChannelControlReg(peripheralBase, ChannelIdx) ( \
    FTM_CnSC_REG(peripheralBase,(ChannelIdx)) \
  )

/* ----------------------------------------------------------------------------
   -- WriteChannelControlReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the channel status and control register.
 * @param peripheralBase Peripheral base address.
 * @param ChannelIdx FTM channel index.
 * @param Value New content of the channel status and control register.
 */
#define FTM_PDD_WriteChannelControlReg(peripheralBase, ChannelIdx, Value) ( \
    FTM_CnSC_REG(peripheralBase,(ChannelIdx)) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadChannelValueReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the channel value register.
 * @param peripheralBase Peripheral base address.
 * @param ChannelIdx FTM channel index.
 */
#define FTM_PDD_ReadChannelValueReg(peripheralBase, ChannelIdx) ( \
    FTM_CnV_REG(peripheralBase,(ChannelIdx)) \
  )

/* ----------------------------------------------------------------------------
   -- WriteChannelValueReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the channel value register.
 * @param peripheralBase Peripheral base address.
 * @param ChannelIdx FTM channel index.
 * @param Value New content of the channel value register.
 */
#define FTM_PDD_WriteChannelValueReg(peripheralBase, ChannelIdx, Value) ( \
    FTM_CnV_REG(peripheralBase,(ChannelIdx)) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- WriteInitialValueReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the counter initial value register.
 * @param peripheralBase Peripheral base address.
 * @param Value New content of the counter initial value register.
 */
#define FTM_PDD_WriteInitialValueReg(peripheralBase, Value) ( \
    FTM_CNTIN_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadInitialValueReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the counter initial value register.
 * @param peripheralBase Peripheral base address.
 */
#define FTM_PDD_ReadInitialValueReg(peripheralBase) ( \
    FTM_CNTIN_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- GetChannelFlags
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the capture and compare status register.
 * @param peripheralBase Peripheral base address.
 */
#define FTM_PDD_GetChannelFlags(peripheralBase) ( \
    FTM_STATUS_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- ClearChannelFlags
   ---------------------------------------------------------------------------- */

/**
 * Clears channel interrupt flag.
 * @param peripheralBase Peripheral base address.
 * @param Mask Interrupt flag mask.
 */
#define FTM_PDD_ClearChannelFlags(peripheralBase, Mask) ( \
    FTM_STATUS_REG(peripheralBase) = \
     (uint32_t)((uint32_t)(~(uint32_t)(Mask)) & (uint32_t)0xFFU) \
  )

/* ----------------------------------------------------------------------------
   -- EnableFaultInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables the FTM fault interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define FTM_PDD_EnableFaultInterrupt(peripheralBase) ( \
    FTM_MODE_REG(peripheralBase) |= \
     FTM_MODE_FAULTIE_MASK \
  )

/* ----------------------------------------------------------------------------
   -- DisableFaultInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables the FTM fault interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define FTM_PDD_DisableFaultInterrupt(peripheralBase) ( \
    FTM_MODE_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)FTM_MODE_FAULTIE_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- WriteProtectionDisable
   ---------------------------------------------------------------------------- */

/**
 * Disables the write protection.
 * @param peripheralBase Peripheral base address.
 */
#define FTM_PDD_WriteProtectionDisable(peripheralBase) ( \
    FTM_MODE_REG(peripheralBase) |= \
     FTM_MODE_WPDIS_MASK \
  )

/* ----------------------------------------------------------------------------
   -- InitializeOutputs
   ---------------------------------------------------------------------------- */

/**
 * Initialize the channel outputs.
 * @param peripheralBase Peripheral base address.
 */
#define FTM_PDD_InitializeOutputs(peripheralBase) ( \
    FTM_MODE_REG(peripheralBase) |= \
     FTM_MODE_INIT_MASK \
  )

/* ----------------------------------------------------------------------------
   -- WriteFeaturesModeReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the feature mode selection register.
 * @param peripheralBase Peripheral base address.
 * @param Value New content of the feature mode selection register.
 */
#define FTM_PDD_WriteFeaturesModeReg(peripheralBase, Value) ( \
    FTM_MODE_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadFeaturesModeReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the features mode selection register.
 * @param peripheralBase Peripheral base address.
 */
#define FTM_PDD_ReadFeaturesModeReg(peripheralBase) ( \
    FTM_MODE_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteSynchronizationReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the synchronization register.
 * @param peripheralBase Peripheral base address.
 * @param Value New content of the synchronization register.
 */
#define FTM_PDD_WriteSynchronizationReg(peripheralBase, Value) ( \
    FTM_SYNC_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadSynchronizationReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the synchronization register.
 * @param peripheralBase Peripheral base address.
 */
#define FTM_PDD_ReadSynchronizationReg(peripheralBase) ( \
    FTM_SYNC_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteInitialOutputReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the initial state for channels output register.
 * @param peripheralBase Peripheral base address.
 * @param Value New content of the initial state for channel output register.
 */
#define FTM_PDD_WriteInitialOutputReg(peripheralBase, Value) ( \
    FTM_OUTINIT_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadInitialOutputReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the initial state for channels output register.
 * @param peripheralBase Peripheral base address.
 */
#define FTM_PDD_ReadInitialOutputReg(peripheralBase) ( \
    FTM_OUTINIT_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteOutputMaskReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the output mask register.
 * @param peripheralBase Peripheral base address.
 * @param Value New content of the output mask register.
 */
#define FTM_PDD_WriteOutputMaskReg(peripheralBase, Value) ( \
    FTM_OUTMASK_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadOutputMaskReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the output mask register.
 * @param peripheralBase Peripheral base address.
 */
#define FTM_PDD_ReadOutputMaskReg(peripheralBase) ( \
    FTM_OUTMASK_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteCombineReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the function for linked channels register.
 * @param peripheralBase Peripheral base address.
 * @param Value New content of the function for linked channels register.
 */
#define FTM_PDD_WriteCombineReg(peripheralBase, Value) ( \
    FTM_COMBINE_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadCombineReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the function for linked channels register.
 * @param peripheralBase Peripheral base address.
 */
#define FTM_PDD_ReadCombineReg(peripheralBase) ( \
    FTM_COMBINE_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteDeadtimeReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the deadtime insertion control register.
 * @param peripheralBase Peripheral base address.
 * @param Value New content of the deadtime insertion control register.
 */
#define FTM_PDD_WriteDeadtimeReg(peripheralBase, Value) ( \
    FTM_DEADTIME_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadDeadtimeReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the deadtime insertion control register.
 * @param peripheralBase Peripheral base address.
 */
#define FTM_PDD_ReadDeadtimeReg(peripheralBase) ( \
    FTM_DEADTIME_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteExternalTriggerReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the FTM external trigger register.
 * @param peripheralBase Peripheral base address.
 * @param Value New content of the FTM external trigger register.
 */
#define FTM_PDD_WriteExternalTriggerReg(peripheralBase, Value) ( \
    FTM_EXTTRIG_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadExternalTriggerReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the FTM external trigger register.
 * @param peripheralBase Peripheral base address.
 */
#define FTM_PDD_ReadExternalTriggerReg(peripheralBase) ( \
    FTM_EXTTRIG_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WritePolarityReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the channels polarity register.
 * @param peripheralBase Peripheral base address.
 * @param Value New content of the channels polarity register.
 */
#define FTM_PDD_WritePolarityReg(peripheralBase, Value) ( \
    FTM_POL_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadPolarityReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the channels polarity register.
 * @param peripheralBase Peripheral base address.
 */
#define FTM_PDD_ReadPolarityReg(peripheralBase) ( \
    FTM_POL_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- ReadFaultStatusReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the fault mode status register.
 * @param peripheralBase Peripheral base address.
 */
#define FTM_PDD_ReadFaultStatusReg(peripheralBase) ( \
    FTM_FMS_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteProtectionEnable
   ---------------------------------------------------------------------------- */

/**
 * Enables the write protection.
 * @param peripheralBase Peripheral base address.
 */
#define FTM_PDD_WriteProtectionEnable(peripheralBase) ( \
    FTM_FMS_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(FTM_FMS_REG(peripheralBase) | FTM_FMS_WPEN_MASK)) & (( \
      (uint32_t)(~(uint32_t)FTM_FMS_FAULTF0_MASK)) & (( \
      (uint32_t)(~(uint32_t)FTM_FMS_FAULTF1_MASK)) & (( \
      (uint32_t)(~(uint32_t)FTM_FMS_FAULTF2_MASK)) & (( \
      (uint32_t)(~(uint32_t)FTM_FMS_FAULTF3_MASK)) & ( \
      (uint32_t)(~(uint32_t)FTM_FMS_FAULTF_MASK))))))) \
  )

/* ----------------------------------------------------------------------------
   -- WriteInputCaptureFilterReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the input capture filter control register.
 * @param peripheralBase Peripheral base address.
 * @param Value New content of the input capture filter control register.
 */
#define FTM_PDD_WriteInputCaptureFilterReg(peripheralBase, Value) ( \
    FTM_FILTER_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadInputCaptureFilterReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the input capture filter control register.
 * @param peripheralBase Peripheral base address.
 */
#define FTM_PDD_ReadInputCaptureFilterReg(peripheralBase) ( \
    FTM_FILTER_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteFaultControlReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the fault control register.
 * @param peripheralBase Peripheral base address.
 * @param Value New content of the fault control register.
 */
#define FTM_PDD_WriteFaultControlReg(peripheralBase, Value) ( \
    FTM_FLTCTRL_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadFaultControlReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the fault control register.
 * @param peripheralBase Peripheral base address.
 */
#define FTM_PDD_ReadFaultControlReg(peripheralBase) ( \
    FTM_FLTCTRL_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteQuadratureDecoderReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the quadrature decoder control and status register.
 * @param peripheralBase Peripheral base address.
 * @param Value New content of the quadrature decoder control and status
 *        register.
 */
#define FTM_PDD_WriteQuadratureDecoderReg(peripheralBase, Value) ( \
    FTM_QDCTRL_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadQuadratureDecoderReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the quadrature decoder control and status register.
 * @param peripheralBase Peripheral base address.
 */
#define FTM_PDD_ReadQuadratureDecoderReg(peripheralBase) ( \
    FTM_QDCTRL_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteConfigurationReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the configuration register.
 * @param peripheralBase Peripheral base address.
 * @param Value New content of the configuration register.
 */
#define FTM_PDD_WriteConfigurationReg(peripheralBase, Value) ( \
    FTM_CONF_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadConfigurationReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the configuration register.
 * @param peripheralBase Peripheral base address.
 */
#define FTM_PDD_ReadConfigurationReg(peripheralBase) ( \
    FTM_CONF_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteFaultInputPolarityReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the FTM fault input polarity register.
 * @param peripheralBase Peripheral base address.
 * @param Value New content of the FTM fault input polarity register.
 */
#define FTM_PDD_WriteFaultInputPolarityReg(peripheralBase, Value) ( \
    FTM_FLTPOL_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadFaultInputPolarityReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the FTM fault input polarity register.
 * @param peripheralBase Peripheral base address.
 */
#define FTM_PDD_ReadFaultInputPolarityReg(peripheralBase) ( \
    FTM_FLTPOL_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteSynchronizationConfigReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the synchronization configuration register.
 * @param peripheralBase Peripheral base address.
 * @param Value New content of the synchronization configuration register.
 */
#define FTM_PDD_WriteSynchronizationConfigReg(peripheralBase, Value) ( \
    FTM_SYNCONF_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadSynchronizationConfigReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the synchronization configuration register.
 * @param peripheralBase Peripheral base address.
 */
#define FTM_PDD_ReadSynchronizationConfigReg(peripheralBase) ( \
    FTM_SYNCONF_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteInvertingReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the FTM inverting control register.
 * @param peripheralBase Peripheral base address.
 * @param Value New content of the FTM inverting control register.
 */
#define FTM_PDD_WriteInvertingReg(peripheralBase, Value) ( \
    FTM_INVCTRL_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadInvertingReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the FTM inverting control register.
 * @param peripheralBase Peripheral base address.
 */
#define FTM_PDD_ReadInvertingReg(peripheralBase) ( \
    FTM_INVCTRL_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteSoftwareOutputReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the FTM software output control register.
 * @param peripheralBase Peripheral base address.
 * @param Value New content of the FTM software output control register.
 */
#define FTM_PDD_WriteSoftwareOutputReg(peripheralBase, Value) ( \
    FTM_SWOCTRL_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadSoftwareOutputReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the FTM software output control register.
 * @param peripheralBase Peripheral base address.
 */
#define FTM_PDD_ReadSoftwareOutputReg(peripheralBase) ( \
    FTM_SWOCTRL_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WritePwmLoadReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the FTM PWM load register.
 * @param peripheralBase Peripheral base address.
 * @param Value New content of the FTM PWM load register.
 */
#define FTM_PDD_WritePwmLoadReg(peripheralBase, Value) ( \
    FTM_PWMLOAD_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadPwmLoadReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the FTM PWM load register.
 * @param peripheralBase Peripheral base address.
 */
#define FTM_PDD_ReadPwmLoadReg(peripheralBase) ( \
    FTM_PWMLOAD_REG(peripheralBase) \
  )
#endif  /* #if defined(FTM_PDD_H_) */

/* FTM_PDD.h, eof. */
