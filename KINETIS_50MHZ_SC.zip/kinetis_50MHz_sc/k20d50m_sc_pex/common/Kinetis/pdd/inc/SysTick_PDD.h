/*
  PDD layer implementation for peripheral type SysTick
  (C) 2010 Freescale, Inc. All rights reserved.

  This file is static and it is generated from API-Factory
*/

#if !defined(SysTick_PDD_H_)
#define SysTick_PDD_H_

/* ----------------------------------------------------------------------------
   -- Test if supported MCU is active
   ---------------------------------------------------------------------------- */

#if !defined(MCU_ACTIVE)
  // No MCU is active
  #error SysTick PDD library: No derivative is active. Place proper #include with PDD memory map before including PDD library.
#elif \
      !defined(MCU_MK10D10) /* SysTick */ && \
      !defined(MCU_MK10D5) /* SysTick */ && \
      !defined(MCU_MK10D7) /* SysTick */ && \
      !defined(MCU_MK10F12) /* SysTick */ && \
      !defined(MCU_MK10DZ10) /* SysTick */ && \
      !defined(MCU_MK11D5) /* SysTick */ && \
      !defined(MCU_MK12D5) /* SysTick */ && \
      !defined(MCU_MK20D10) /* SysTick */ && \
      !defined(MCU_MK20D5) /* SysTick */ && \
      !defined(MCU_MK20D7) /* SysTick */ && \
      !defined(MCU_MK20F12) /* SysTick */ && \
      !defined(MCU_MK20DZ10) /* SysTick */ && \
      !defined(MCU_MK21D5) /* SysTick */ && \
      !defined(MCU_MK22D5) /* SysTick */ && \
      !defined(MCU_MK30D10) /* SysTick */ && \
      !defined(MCU_MK30D7) /* SysTick */ && \
      !defined(MCU_MK30DZ10) /* SysTick */ && \
      !defined(MCU_MK40D10) /* SysTick */ && \
      !defined(MCU_MK40D7) /* SysTick */ && \
      !defined(MCU_MK40DZ10) /* SysTick */ && \
      !defined(MCU_MK40X256VMD100) /* SysTick */ && \
      !defined(MCU_MK50D10) /* SysTick */ && \
      !defined(MCU_MK50D7) /* SysTick */ && \
      !defined(MCU_MK50DZ10) /* SysTick */ && \
      !defined(MCU_MK51D10) /* SysTick */ && \
      !defined(MCU_MK51D7) /* SysTick */ && \
      !defined(MCU_MK51DZ10) /* SysTick */ && \
      !defined(MCU_MK52D10) /* SysTick */ && \
      !defined(MCU_MK52DZ10) /* SysTick */ && \
      !defined(MCU_MK53D10) /* SysTick */ && \
      !defined(MCU_MK53DZ10) /* SysTick */ && \
      !defined(MCU_MK60D10) /* SysTick */ && \
      !defined(MCU_MK60F12) /* SysTick */ && \
      !defined(MCU_MK60F15) /* SysTick */ && \
      !defined(MCU_MK60DZ10) /* SysTick */ && \
      !defined(MCU_MK60N512VMD100) /* SysTick */ && \
      !defined(MCU_MK61F12) /* SysTick */ && \
      !defined(MCU_MK61F15) /* SysTick */ && \
      !defined(MCU_MK70F12) /* SysTick */ && \
      !defined(MCU_MK70F15) /* SysTick */ && \
      !defined(MCU_MKL04Z4) /* SysTick */ && \
      !defined(MCU_MKL05Z4) /* SysTick */ && \
      !defined(MCU_MKL14Z4) /* SysTick */ && \
      !defined(MCU_MKL15Z4) /* SysTick */ && \
      !defined(MCU_MKL24Z4) /* SysTick */ && \
      !defined(MCU_MKL25Z4) /* SysTick */ && \
      !defined(MCU_PCK20L4) /* SysTick */
  // Unsupported MCU is active
  #error SysTick PDD library: Unsupported derivative is active.
#endif

#include "PDD_Types.h"

/* ----------------------------------------------------------------------------
   -- Method symbol definitions
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MKL04Z4)) || (defined(MCU_MKL05Z4)) || (defined(MCU_MKL14Z4)) || (defined(MCU_MKL15Z4)) || (defined(MCU_MKL24Z4)) || (defined(MCU_MKL25Z4)))
/* Clock source constants. */
  #define SysTick_PDD_CORE_CLOCK 0x1U              /**< 1 */
  #define SysTick_PDD_CORE_CLOCK_DIV16 0U          /**< 1 */

#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_PCK20L4)) */
/* Clock source constants. */
  #define SysTick_PDD_CORE_CLOCK 0x1U              /**< 1 */

#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_PCK20L4)) */

/* ----------------------------------------------------------------------------
   -- GetInterruptMask
   ---------------------------------------------------------------------------- */

/**
 * Returns interrupt mask.
 * @param peripheralBase Peripheral base address.
 */
#define SysTick_PDD_GetInterruptMask(peripheralBase) ( \
    (uint32_t)(SysTick_CSR_REG(peripheralBase) & SysTick_CSR_TICKINT_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Returns interrupt flag bit.
 * @param peripheralBase Peripheral base address.
 */
#define SysTick_PDD_GetInterruptFlag(peripheralBase) ( \
    (uint32_t)(SysTick_CSR_REG(peripheralBase) & SysTick_CSR_COUNTFLAG_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- EnableInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables the SysTick interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define SysTick_PDD_EnableInterrupt(peripheralBase) ( \
    SysTick_CSR_REG(peripheralBase) |= \
     SysTick_CSR_TICKINT_MASK \
  )

/* ----------------------------------------------------------------------------
   -- DisableInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables the SysTick interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define SysTick_PDD_DisableInterrupt(peripheralBase) ( \
    SysTick_CSR_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)SysTick_CSR_TICKINT_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- ClearInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Clears SysTick interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define SysTick_PDD_ClearInterruptFlag(peripheralBase) ( \
    SysTick_CSR_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)SysTick_CSR_COUNTFLAG_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- EnableDevice
   ---------------------------------------------------------------------------- */

/**
 * Enables the SysTick device.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state of SysTick device.
 */
#define SysTick_PDD_EnableDevice(peripheralBase, State) ( \
    SysTick_CSR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       SysTick_CSR_REG(peripheralBase)) & ( \
       (uint32_t)(~(uint32_t)SysTick_CSR_ENABLE_MASK)))) | ( \
      (uint32_t)(State))) \
  )

/* ----------------------------------------------------------------------------
   -- GetEnableDeviceStatus
   ---------------------------------------------------------------------------- */

/**
 * Returns current state of SysTick device.
 * @param peripheralBase Peripheral base address.
 */
#define SysTick_PDD_GetEnableDeviceStatus(peripheralBase) ( \
    (uint32_t)(SysTick_CSR_REG(peripheralBase) & SysTick_CSR_ENABLE_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- SetClkSource
   ---------------------------------------------------------------------------- */

/**
 * Sets clock source.
 * @param peripheralBase Peripheral base address.
 * @param ClkSource New value of the clock source.
 */
#define SysTick_PDD_SetClkSource(peripheralBase, ClkSource) ( \
    SysTick_CSR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       SysTick_CSR_REG(peripheralBase)) & ( \
       (uint32_t)(~(uint32_t)SysTick_CSR_CLKSOURCE_MASK)))) | ( \
      (uint32_t)((uint32_t)(ClkSource) << SysTick_CSR_CLKSOURCE_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- GetClkSource
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MKL04Z4)) || (defined(MCU_MKL05Z4)) || (defined(MCU_MKL14Z4)) || (defined(MCU_MKL15Z4)) || (defined(MCU_MKL24Z4)) || (defined(MCU_MKL25Z4)))
/**
 * Gets clock source.
 * @param peripheralBase Peripheral base address.
 */
  #define SysTick_PDD_GetClkSource(peripheralBase) ( \
      (uint8_t)(( \
       (uint32_t)(SysTick_CSR_REG(peripheralBase) & SysTick_CSR_CLKSOURCE_MASK)) >> ( \
       SysTick_CSR_CLKSOURCE_SHIFT)) \
    )
#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_PCK20L4)) */
/**
 * Gets clock source.
 * @param peripheralBase Peripheral base address.
 */
  #define SysTick_PDD_GetClkSource(peripheralBase) ( \
      0x1U \
    )
#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_PCK20L4)) */

/* ----------------------------------------------------------------------------
   -- WriteReloadValueReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the reload register.
 * @param peripheralBase Peripheral base address.
 * @param Value New content of the reload register.
 */
#define SysTick_PDD_WriteReloadValueReg(peripheralBase, Value) ( \
    SysTick_RVR_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadReloadValueReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the reload register.
 * @param peripheralBase Peripheral base address.
 */
#define SysTick_PDD_ReadReloadValueReg(peripheralBase) ( \
    SysTick_RVR_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- ReadCurrentValueReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the current value register.
 * @param peripheralBase Peripheral base address.
 */
#define SysTick_PDD_ReadCurrentValueReg(peripheralBase) ( \
    SysTick_CVR_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- ReadCalibrationReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the calibration register.
 * @param peripheralBase Peripheral base address.
 */
#define SysTick_PDD_ReadCalibrationReg(peripheralBase) ( \
    SysTick_CALIB_REG(peripheralBase) \
  )
#endif  /* #if defined(SysTick_PDD_H_) */

/* SysTick_PDD.h, eof. */
