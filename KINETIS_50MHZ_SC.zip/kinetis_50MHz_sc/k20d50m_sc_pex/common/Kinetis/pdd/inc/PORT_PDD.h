/*
  PDD layer implementation for peripheral type PORT
  (C) 2010 Freescale, Inc. All rights reserved.

  This file is static and it is generated from API-Factory
*/

#if !defined(PORT_PDD_H_)
#define PORT_PDD_H_

/* ----------------------------------------------------------------------------
   -- Test if supported MCU is active
   ---------------------------------------------------------------------------- */

#if !defined(MCU_ACTIVE)
  // No MCU is active
  #error PORT PDD library: No derivative is active. Place proper #include with PDD memory map before including PDD library.
#elif \
      !defined(MCU_MK10D10) /* PORTA, PORTB, PORTC, PORTD, PORTE */ && \
      !defined(MCU_MK10D5) /* PORTA, PORTB, PORTC, PORTD, PORTE */ && \
      !defined(MCU_MK10D7) /* PORTA, PORTB, PORTC, PORTD, PORTE */ && \
      !defined(MCU_MK10F12) /* PORTA, PORTB, PORTC, PORTD, PORTE, PORTF */ && \
      !defined(MCU_MK10DZ10) /* PORTA, PORTB, PORTC, PORTD, PORTE */ && \
      !defined(MCU_MK11D5) /* PORTA, PORTB, PORTC, PORTD, PORTE */ && \
      !defined(MCU_MK12D5) /* PORTA, PORTB, PORTC, PORTD, PORTE */ && \
      !defined(MCU_MK20D10) /* PORTA, PORTB, PORTC, PORTD, PORTE */ && \
      !defined(MCU_MK20D5) /* PORTA, PORTB, PORTC, PORTD, PORTE */ && \
      !defined(MCU_MK20D7) /* PORTA, PORTB, PORTC, PORTD, PORTE */ && \
      !defined(MCU_MK20F12) /* PORTA, PORTB, PORTC, PORTD, PORTE, PORTF */ && \
      !defined(MCU_MK20DZ10) /* PORTA, PORTB, PORTC, PORTD, PORTE */ && \
      !defined(MCU_MK21D5) /* PORTA, PORTB, PORTC, PORTD, PORTE */ && \
      !defined(MCU_MK22D5) /* PORTA, PORTB, PORTC, PORTD, PORTE */ && \
      !defined(MCU_MK30D10) /* PORTA, PORTB, PORTC, PORTD, PORTE */ && \
      !defined(MCU_MK30D7) /* PORTA, PORTB, PORTC, PORTD, PORTE */ && \
      !defined(MCU_MK30DZ10) /* PORTA, PORTB, PORTC, PORTD, PORTE */ && \
      !defined(MCU_MK40D10) /* PORTA, PORTB, PORTC, PORTD, PORTE */ && \
      !defined(MCU_MK40D7) /* PORTA, PORTB, PORTC, PORTD, PORTE */ && \
      !defined(MCU_MK40DZ10) /* PORTA, PORTB, PORTC, PORTD, PORTE */ && \
      !defined(MCU_MK40X256VMD100) /* PORTA, PORTB, PORTC, PORTD, PORTE */ && \
      !defined(MCU_MK50D10) /* PORTA, PORTB, PORTC, PORTD, PORTE */ && \
      !defined(MCU_MK50D7) /* PORTA, PORTB, PORTC, PORTD, PORTE */ && \
      !defined(MCU_MK50DZ10) /* PORTA, PORTB, PORTC, PORTD, PORTE */ && \
      !defined(MCU_MK51D10) /* PORTA, PORTB, PORTC, PORTD, PORTE */ && \
      !defined(MCU_MK51D7) /* PORTA, PORTB, PORTC, PORTD, PORTE */ && \
      !defined(MCU_MK51DZ10) /* PORTA, PORTB, PORTC, PORTD, PORTE */ && \
      !defined(MCU_MK52D10) /* PORTA, PORTB, PORTC, PORTD, PORTE */ && \
      !defined(MCU_MK52DZ10) /* PORTA, PORTB, PORTC, PORTD, PORTE */ && \
      !defined(MCU_MK53D10) /* PORTA, PORTB, PORTC, PORTD, PORTE */ && \
      !defined(MCU_MK53DZ10) /* PORTA, PORTB, PORTC, PORTD, PORTE */ && \
      !defined(MCU_MK60D10) /* PORTA, PORTB, PORTC, PORTD, PORTE */ && \
      !defined(MCU_MK60F12) /* PORTA, PORTB, PORTC, PORTD, PORTE, PORTF */ && \
      !defined(MCU_MK60F15) /* PORTA, PORTB, PORTC, PORTD, PORTE, PORTF */ && \
      !defined(MCU_MK60DZ10) /* PORTA, PORTB, PORTC, PORTD, PORTE */ && \
      !defined(MCU_MK60N512VMD100) /* PORTA, PORTB, PORTC, PORTD, PORTE */ && \
      !defined(MCU_MK61F12) /* PORTA, PORTB, PORTC, PORTD, PORTE, PORTF */ && \
      !defined(MCU_MK61F15) /* PORTA, PORTB, PORTC, PORTD, PORTE, PORTF */ && \
      !defined(MCU_MK70F12) /* PORTA, PORTB, PORTC, PORTD, PORTE, PORTF */ && \
      !defined(MCU_MK70F15) /* PORTA, PORTB, PORTC, PORTD, PORTE, PORTF */ && \
      !defined(MCU_MKL04Z4) /* PORTA, PORTB */ && \
      !defined(MCU_MKL05Z4) /* PORTA, PORTB */ && \
      !defined(MCU_MKL14Z4) /* PORTA, PORTB, PORTC, PORTD, PORTE */ && \
      !defined(MCU_MKL15Z4) /* PORTA, PORTB, PORTC, PORTD, PORTE */ && \
      !defined(MCU_MKL24Z4) /* PORTA, PORTB, PORTC, PORTD, PORTE */ && \
      !defined(MCU_MKL25Z4) /* PORTA, PORTB, PORTC, PORTD, PORTE */ && \
      !defined(MCU_PCK20L4) /* PORTA, PORTB, PORTC, PORTD, PORTE */
  // Unsupported MCU is active
  #error PORT PDD library: Unsupported derivative is active.
#endif

#include "PDD_Types.h"

/* ----------------------------------------------------------------------------
   -- Method symbol definitions
   ---------------------------------------------------------------------------- */

/* Pin masks */
#define PORT_PDD_PIN_0 0x1U                      /**< Pin 0 mask */
#define PORT_PDD_PIN_1 0x2U                      /**< Pin 1 mask */
#define PORT_PDD_PIN_2 0x4U                      /**< Pin 2 mask */
#define PORT_PDD_PIN_3 0x8U                      /**< Pin 3 mask */
#define PORT_PDD_PIN_4 0x10U                     /**< Pin 4 mask */
#define PORT_PDD_PIN_5 0x20U                     /**< Pin 5 mask */
#define PORT_PDD_PIN_6 0x40U                     /**< Pin 6 mask */
#define PORT_PDD_PIN_7 0x80U                     /**< Pin 7 mask */
#define PORT_PDD_PIN_8 0x100U                    /**< Pin 8 mask */
#define PORT_PDD_PIN_9 0x200U                    /**< Pin 9 mask */
#define PORT_PDD_PIN_10 0x400U                   /**< Pin 10 mask */
#define PORT_PDD_PIN_11 0x800U                   /**< Pin 11 mask */
#define PORT_PDD_PIN_12 0x1000U                  /**< Pin 12 mask */
#define PORT_PDD_PIN_13 0x2000U                  /**< Pin 13 mask */
#define PORT_PDD_PIN_14 0x4000U                  /**< Pin 14 mask */
#define PORT_PDD_PIN_15 0x8000U                  /**< Pin 15 mask */
#define PORT_PDD_PIN_16 0x10000U                 /**< Pin 16 mask */
#define PORT_PDD_PIN_17 0x20000U                 /**< Pin 17 mask */
#define PORT_PDD_PIN_18 0x40000U                 /**< Pin 18 mask */
#define PORT_PDD_PIN_19 0x80000U                 /**< Pin 19 mask */
#define PORT_PDD_PIN_20 0x100000U                /**< Pin 20 mask */
#define PORT_PDD_PIN_21 0x200000U                /**< Pin 21 mask */
#define PORT_PDD_PIN_22 0x400000U                /**< Pin 22 mask */
#define PORT_PDD_PIN_23 0x800000U                /**< Pin 23 mask */
#define PORT_PDD_PIN_24 0x1000000U               /**< Pin 24 mask */
#define PORT_PDD_PIN_25 0x2000000U               /**< Pin 25 mask */
#define PORT_PDD_PIN_26 0x4000000U               /**< Pin 26 mask */
#define PORT_PDD_PIN_27 0x8000000U               /**< Pin 27 mask */
#define PORT_PDD_PIN_28 0x10000000U              /**< Pin 28 mask */
#define PORT_PDD_PIN_29 0x20000000U              /**< Pin 29 mask */
#define PORT_PDD_PIN_30 0x40000000U              /**< Pin 30 mask */
#define PORT_PDD_PIN_31 0x80000000U              /**< Pin 31 mask */

/* Constants for pull type selection */
#define PORT_PDD_PULL_DOWN 0U                    /**< Pull down */
#define PORT_PDD_PULL_UP 0x1U                    /**< Pull up */

/* Constants for pull enabling/disabling */
#define PORT_PDD_PULL_DISABLE 0U                 /**< Pull resistor disabled */
#define PORT_PDD_PULL_ENABLE 0x2U                /**< Pull resistor enabled */

/* Constants for slew rate setting */
#define PORT_PDD_SLEW_RATE_FAST 0U               /**< Fast slew rate */
#define PORT_PDD_SLEW_RATE_SLOW 0x4U             /**< Slow slew rate */

/* Constants for slew rate setting */
#define PORT_PDD_PASSIVE_FILTER_DISABLE 0U       /**< Passive filter disabled */
#define PORT_PDD_PASSIVE_FILTER_ENABLE 0x10U     /**< Passive filter enabled */

/* Constants for open drain setting */
#define PORT_PDD_OPEN_DRAIN_DISABLE 0U           /**< Open drain disabled */
#define PORT_PDD_OPEN_DRAIN_ENABLE 0x20U         /**< Open drain enabled */

/* Constants for drive strength setting */
#define PORT_PDD_DRIVE_STRENGTH_LOW 0U           /**< Low drive strength */
#define PORT_PDD_DRIVE_STRENGTH_HIGH 0x40U       /**< High drive strength */

/* Constants for mux control setting */
#define PORT_PDD_MUX_CONTROL_DISABLE 0U          /**< Mux control disabled */
#define PORT_PDD_MUX_CONTROL_ALT1 0x100U         /**< Pin used with alternate 1 functionality */
#define PORT_PDD_MUX_CONTROL_ALT2 0x200U         /**< Pin used with alternate 2 functionality */
#define PORT_PDD_MUX_CONTROL_ALT3 0x300U         /**< Pin used with alternate 3 functionality */
#define PORT_PDD_MUX_CONTROL_ALT4 0x400U         /**< Pin used with alternate 4 functionality */
#define PORT_PDD_MUX_CONTROL_ALT5 0x500U         /**< Pin used with alternate 5 functionality */
#define PORT_PDD_MUX_CONTROL_ALT6 0x600U         /**< Pin used with alternate 6 functionality */
#define PORT_PDD_MUX_CONTROL_ALT7 0x700U         /**< Pin used with alternate 7 functionality */

/* Constants for pin lock setting */
#define PORT_PDD_PIN_CONTROL_UNLOCK 0U           /**< Pin control unlocked */
#define PORT_PDD_PIN_CONTROL_LOCK 0x8000U        /**< Pin control locked */

/* Constants for interrupt configuration setting */
#define PORT_PDD_INTERRUPT_DMA_DISABLED 0U       /**< Interrupt and DMA disabled */
#define PORT_PDD_DMA_ON_RISING 0x10000U          /**< DMA enabled on rising edge */
#define PORT_PDD_DMA_ON_FALLING 0x20000U         /**< DMA enabled on falling edge */
#define PORT_PDD_DMA_ON_RISING_FALLING 0x30000U  /**< DMA enabled on rising and falling edges */
#define PORT_PDD_INTERRUPT_ON_ZERO 0x80000U      /**< Interrupt enabled on low level */
#define PORT_PDD_INTERRUPT_ON_RISING 0x90000U    /**< Interrupt enabled on rising edge */
#define PORT_PDD_INTERRUPT_ON_FALLING 0xA0000U   /**< Interrupt enabled on falling edge */
#define PORT_PDD_INTERRUPT_ON_RISING_FALLING 0xB0000U /**< Interrupt enabled on rising and falling edges */
#define PORT_PDD_INTERRUPT_ON_ONE 0xC0000U       /**< Interrupt enabled on high level */

/* Constants for digital clock source setting */
#define PORT_PDD_BUS_CLOCK 0U                    /**< Bus clock as filter clock source */
#define PORT_PDD_LPO_CLOCK 0x1U                  /**< LPO clock as filter clock source */


/* ----------------------------------------------------------------------------
   -- GetPinPullSelect
   ---------------------------------------------------------------------------- */

/**
 * Gets which pull resistor is selected.
 * @param peripheralBase Peripheral base address.
 * @param PinIndex Pin index inside the port.
 */
#define PORT_PDD_GetPinPullSelect(peripheralBase, PinIndex) ( \
    (uint32_t)(PORT_PCR_REG(peripheralBase,(PinIndex)) & PORT_PCR_PS_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- SetPinPullSelect
   ---------------------------------------------------------------------------- */

/**
 * Sets pull type.
 * @param peripheralBase Peripheral base address.
 * @param PinIndex Pin index inside the port.
 * @param Type Pull type.
 */
#define PORT_PDD_SetPinPullSelect(peripheralBase, PinIndex, Type) ( \
    PORT_PCR_REG(peripheralBase,(PinIndex)) = \
     (uint32_t)(( \
      (uint32_t)(( \
       PORT_PCR_REG(peripheralBase,(PinIndex))) & (( \
       (uint32_t)(~(uint32_t)PORT_PCR_PS_MASK)) & ( \
       (uint32_t)(~(uint32_t)PORT_PCR_ISF_MASK))))) | ( \
      (uint32_t)(Type))) \
  )

/* ----------------------------------------------------------------------------
   -- GetPinPullEnable
   ---------------------------------------------------------------------------- */

/**
 * Gets whether pull resistor is enabled.
 * @param peripheralBase Peripheral base address.
 * @param PinIndex Pin index inside the port.
 */
#define PORT_PDD_GetPinPullEnable(peripheralBase, PinIndex) ( \
    (uint32_t)(PORT_PCR_REG(peripheralBase,(PinIndex)) & PORT_PCR_PE_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- SetPinPullEnable
   ---------------------------------------------------------------------------- */

/**
 * Sets pull type.
 * @param peripheralBase Peripheral base address.
 * @param PinIndex Pin index inside the port.
 * @param State Requested state of pull enable.
 */
#define PORT_PDD_SetPinPullEnable(peripheralBase, PinIndex, State) ( \
    PORT_PCR_REG(peripheralBase,(PinIndex)) = \
     (uint32_t)(( \
      (uint32_t)(( \
       PORT_PCR_REG(peripheralBase,(PinIndex))) & (( \
       (uint32_t)(~(uint32_t)PORT_PCR_PE_MASK)) & ( \
       (uint32_t)(~(uint32_t)PORT_PCR_ISF_MASK))))) | ( \
      (uint32_t)(State))) \
  )

/* ----------------------------------------------------------------------------
   -- GetPinSlewRate
   ---------------------------------------------------------------------------- */

/**
 * Gets how slew rate is set.
 * @param peripheralBase Peripheral base address.
 * @param PinIndex Pin index inside the port.
 */
#define PORT_PDD_GetPinSlewRate(peripheralBase, PinIndex) ( \
    (uint32_t)(PORT_PCR_REG(peripheralBase,(PinIndex)) & PORT_PCR_SRE_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- SetPinSlewRate
   ---------------------------------------------------------------------------- */

/**
 * Sets slew rate.
 * @param peripheralBase Peripheral base address.
 * @param PinIndex Pin index inside the port.
 * @param State Requested state of slew rate.
 */
#define PORT_PDD_SetPinSlewRate(peripheralBase, PinIndex, State) ( \
    PORT_PCR_REG(peripheralBase,(PinIndex)) = \
     (uint32_t)(( \
      (uint32_t)(( \
       PORT_PCR_REG(peripheralBase,(PinIndex))) & (( \
       (uint32_t)(~(uint32_t)PORT_PCR_SRE_MASK)) & ( \
       (uint32_t)(~(uint32_t)PORT_PCR_ISF_MASK))))) | ( \
      (uint32_t)(State))) \
  )

/* ----------------------------------------------------------------------------
   -- GetPinPassiveFilter
   ---------------------------------------------------------------------------- */

/**
 * Gets whether passive filter is enabled.
 * @param peripheralBase Peripheral base address.
 * @param PinIndex Pin index inside the port.
 */
#define PORT_PDD_GetPinPassiveFilter(peripheralBase, PinIndex) ( \
    (uint32_t)(PORT_PCR_REG(peripheralBase,(PinIndex)) & PORT_PCR_PFE_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- SetPinPassiveFilter
   ---------------------------------------------------------------------------- */

/**
 * Sets passive filter.
 * @param peripheralBase Peripheral base address.
 * @param PinIndex Pin index inside the port.
 * @param State Requested state of passive filter.
 */
#define PORT_PDD_SetPinPassiveFilter(peripheralBase, PinIndex, State) ( \
    PORT_PCR_REG(peripheralBase,(PinIndex)) = \
     (uint32_t)(( \
      (uint32_t)(( \
       PORT_PCR_REG(peripheralBase,(PinIndex))) & (( \
       (uint32_t)(~(uint32_t)PORT_PCR_PFE_MASK)) & ( \
       (uint32_t)(~(uint32_t)PORT_PCR_ISF_MASK))))) | ( \
      (uint32_t)(State))) \
  )

/* ----------------------------------------------------------------------------
   -- GetPinOpenDrain
   ---------------------------------------------------------------------------- */

/**
 * Gets whether open drain is enabled.
 * @param peripheralBase Peripheral base address.
 * @param PinIndex Pin index inside the port.
 */
#define PORT_PDD_GetPinOpenDrain(peripheralBase, PinIndex) ( \
    (uint32_t)(PORT_PCR_REG(peripheralBase,(PinIndex)) & PORT_PCR_ODE_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- SetPinOpenDrain
   ---------------------------------------------------------------------------- */

/**
 * Sets open drain.
 * @param peripheralBase Peripheral base address.
 * @param PinIndex Pin index inside the port.
 * @param State Requested state of open drain.
 */
#define PORT_PDD_SetPinOpenDrain(peripheralBase, PinIndex, State) ( \
    PORT_PCR_REG(peripheralBase,(PinIndex)) = \
     (uint32_t)(( \
      (uint32_t)(( \
       PORT_PCR_REG(peripheralBase,(PinIndex))) & (( \
       (uint32_t)(~(uint32_t)PORT_PCR_ODE_MASK)) & ( \
       (uint32_t)(~(uint32_t)PORT_PCR_ISF_MASK))))) | ( \
      (uint32_t)(State))) \
  )

/* ----------------------------------------------------------------------------
   -- GetPinDriverStrength
   ---------------------------------------------------------------------------- */

/**
 * Gets how drive strength is set.
 * @param peripheralBase Peripheral base address.
 * @param PinIndex Pin index inside the port.
 */
#define PORT_PDD_GetPinDriverStrength(peripheralBase, PinIndex) ( \
    (uint32_t)(PORT_PCR_REG(peripheralBase,(PinIndex)) & PORT_PCR_DSE_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- SetPinDriveStrength
   ---------------------------------------------------------------------------- */

/**
 * Sets drive strength.
 * @param peripheralBase Peripheral base address.
 * @param PinIndex Pin index inside the port.
 * @param State Requested state of drive strength.
 */
#define PORT_PDD_SetPinDriveStrength(peripheralBase, PinIndex, State) ( \
    PORT_PCR_REG(peripheralBase,(PinIndex)) = \
     (uint32_t)(( \
      (uint32_t)(( \
       PORT_PCR_REG(peripheralBase,(PinIndex))) & (( \
       (uint32_t)(~(uint32_t)PORT_PCR_DSE_MASK)) & ( \
       (uint32_t)(~(uint32_t)PORT_PCR_ISF_MASK))))) | ( \
      (uint32_t)(State))) \
  )

/* ----------------------------------------------------------------------------
   -- GetPinMuxControl
   ---------------------------------------------------------------------------- */

/**
 * Gets how mux control is set.
 * @param peripheralBase Peripheral base address.
 * @param PinIndex Pin index inside the port.
 */
#define PORT_PDD_GetPinMuxControl(peripheralBase, PinIndex) ( \
    (uint32_t)(PORT_PCR_REG(peripheralBase,(PinIndex)) & PORT_PCR_MUX_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- SetPinMuxControl
   ---------------------------------------------------------------------------- */

/**
 * Sets mux control.
 * @param peripheralBase Peripheral base address.
 * @param PinIndex Pin index inside the port.
 * @param State Requested state of Mux control.
 */
#define PORT_PDD_SetPinMuxControl(peripheralBase, PinIndex, State) ( \
    PORT_PCR_REG(peripheralBase,(PinIndex)) = \
     (uint32_t)(( \
      (uint32_t)(( \
       PORT_PCR_REG(peripheralBase,(PinIndex))) & (( \
       (uint32_t)(~(uint32_t)PORT_PCR_MUX_MASK)) & ( \
       (uint32_t)(~(uint32_t)PORT_PCR_ISF_MASK))))) | ( \
      (uint32_t)(State))) \
  )

/* ----------------------------------------------------------------------------
   -- GetPinControlLock
   ---------------------------------------------------------------------------- */

/**
 * Gets how pin lock is set.
 * @param peripheralBase Peripheral base address.
 * @param PinIndex Pin index inside the port.
 */
#define PORT_PDD_GetPinControlLock(peripheralBase, PinIndex) ( \
    (uint32_t)(PORT_PCR_REG(peripheralBase,(PinIndex)) & PORT_PCR_LK_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- LockPinControl
   ---------------------------------------------------------------------------- */

/**
 * Locks pin control such as settings of pull, slew rate, passive filter, open
 * drain, mux control and pin lock.
 * @param peripheralBase Peripheral base address.
 * @param PinIndex Pin index inside the port.
 * @param State Requested state of pin lock.
 */
#define PORT_PDD_LockPinControl(peripheralBase, PinIndex, State) ( \
    PORT_PCR_REG(peripheralBase,(PinIndex)) = \
     (uint32_t)(( \
      (uint32_t)(( \
       PORT_PCR_REG(peripheralBase,(PinIndex))) & (( \
       (uint32_t)(~(uint32_t)PORT_PCR_LK_MASK)) & ( \
       (uint32_t)(~(uint32_t)PORT_PCR_ISF_MASK))))) | ( \
      (uint32_t)(State))) \
  )

/* ----------------------------------------------------------------------------
   -- GetPinInterruptConfiguration
   ---------------------------------------------------------------------------- */

/**
 * Gets how interupt configuration is set.
 * @param peripheralBase Peripheral base address.
 * @param PinIndex Pin index inside the port.
 */
#define PORT_PDD_GetPinInterruptConfiguration(peripheralBase, PinIndex) ( \
    (uint32_t)(PORT_PCR_REG(peripheralBase,(PinIndex)) & PORT_PCR_IRQC_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- SetPinInterruptConfiguration
   ---------------------------------------------------------------------------- */

/**
 * Sets interrupt configuration.
 * @param peripheralBase Peripheral base address.
 * @param PinIndex Pin index inside the port.
 * @param State Requested state of interrupt configuration.
 */
#define PORT_PDD_SetPinInterruptConfiguration(peripheralBase, PinIndex, State) ( \
    PORT_PCR_REG(peripheralBase,(PinIndex)) = \
     (uint32_t)(( \
      (uint32_t)(( \
       PORT_PCR_REG(peripheralBase,(PinIndex))) & (( \
       (uint32_t)(~(uint32_t)PORT_PCR_IRQC_MASK)) & ( \
       (uint32_t)(~(uint32_t)PORT_PCR_ISF_MASK))))) | ( \
      (uint32_t)(State))) \
  )

/* ----------------------------------------------------------------------------
   -- GetPinInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Returns interrupt flags.
 * @param peripheralBase Peripheral base address.
 * @param PinIndex Pin index inside the port.
 */
#define PORT_PDD_GetPinInterruptFlag(peripheralBase, PinIndex) ( \
    (uint32_t)(PORT_PCR_REG(peripheralBase,(PinIndex)) & PORT_PCR_ISF_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetInterruptFlags
   ---------------------------------------------------------------------------- */

/**
 * Returns interrupt flags.
 * @param peripheralBase Peripheral base address.
 */
#define PORT_PDD_GetInterruptFlags(peripheralBase) ( \
    PORT_ISFR_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- ClearPinInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Clears interrupt flag.
 * @param peripheralBase Peripheral base address.
 * @param PinIndex Pin index inside the port.
 */
#define PORT_PDD_ClearPinInterruptFlag(peripheralBase, PinIndex) ( \
    PORT_PCR_REG(peripheralBase,(PinIndex)) |= \
     PORT_PCR_ISF_MASK \
  )

/* ----------------------------------------------------------------------------
   -- ClearInterruptFlags
   ---------------------------------------------------------------------------- */

/**
 * Clears interrupt flag bits defined by mask parameter.
 * @param peripheralBase Peripheral base address.
 * @param Mask Mask of pins to clearing theirs interrupt flags. Use constants
 *        from group "Pin masks".
 */
#define PORT_PDD_ClearInterruptFlags(peripheralBase, Mask) ( \
    PORT_ISFR_REG(peripheralBase) = \
     (uint32_t)(Mask) \
  )

/* ----------------------------------------------------------------------------
   -- SetGlobalPinControl
   ---------------------------------------------------------------------------- */

/**
 * Sets required pin control for required pins of whole port.
 * @param peripheralBase Peripheral base address.
 * @param Mask Mask of pins in port where the bit 0 corresponds with the pin
 *        which has index 0 within the port and the bit 31 corresponds with the pin
 *        which has index 31 within the port.
 * @param Value Settings of pull, slew rate, passive filter, open drain, mux
 *        control and pin lock .
 */
#define PORT_PDD_SetGlobalPinControl(peripheralBase, Mask, Value) ( \
    (PORT_GPCLR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)((uint32_t)((uint32_t)(Mask) & 0xFFFFU) << PORT_GPCLR_GPWE_SHIFT)) | ( \
      (uint32_t)(Value)))), \
    (PORT_GPCHR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)((uint32_t)(Mask) & (uint32_t)(~(uint32_t)0xFFFFU))) | ( \
      (uint32_t)(Value)))) \
  )

/* ----------------------------------------------------------------------------
   -- SetGlobalPinControlLow
   ---------------------------------------------------------------------------- */

/**
 * Sets required pin control for required pins from low part of port.
 * @param peripheralBase Peripheral base address.
 * @param Mask Mask of pins in port where the bit 0 corresponds with the pin
 *        which has index 0 within the port and the bit 15 corresponds with the pin
 *        which has index 15 within the port.
 * @param Value Settings of pull, slew rate, passive filter, open drain, mux
 *        control and pin lock .
 */
#define PORT_PDD_SetGlobalPinControlLow(peripheralBase, Mask, Value) ( \
    PORT_GPCLR_REG(peripheralBase) = \
     (uint32_t)((uint32_t)((uint32_t)(Mask) << PORT_GPCLR_GPWE_SHIFT) | (uint32_t)(Value)) \
  )

/* ----------------------------------------------------------------------------
   -- SetGlobalPinControlHigh
   ---------------------------------------------------------------------------- */

/**
 * Sets required pin control for required pins from high part of port.
 * @param peripheralBase Peripheral base address.
 * @param Mask Mask of pins in port where the bit 0 corresponds with the pin
 *        which has index 16 within the port and the bit 15 corresponds with the pin
 *        which has index 31 within the port.
 * @param Value Settings of pull, slew rate, passive filter, open drain, mux
 *        control and pin lock .
 */
#define PORT_PDD_SetGlobalPinControlHigh(peripheralBase, Mask, Value) ( \
    PORT_GPCHR_REG(peripheralBase) = \
     (uint32_t)((uint32_t)((uint32_t)(Mask) << PORT_GPCHR_GPWE_SHIFT) | (uint32_t)(Value)) \
  )

/* ----------------------------------------------------------------------------
   -- GetEnableDigitalFilterStatusMask
   ---------------------------------------------------------------------------- */

/**
 * Returns enable status of digital filter for whole port.
 * @param peripheralBase Peripheral base address.
 */
#define PORT_PDD_GetEnableDigitalFilterStatusMask(peripheralBase) ( \
    PORT_DFER_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- EnableDigitalFilters
   ---------------------------------------------------------------------------- */

/**
 * Enables digital filters.
 * @param peripheralBase Peripheral base address.
 * @param Mask Mask of pins. Use constants from group "Pin masks".
 */
#define PORT_PDD_EnableDigitalFilters(peripheralBase, Mask) ( \
    PORT_DFER_REG(peripheralBase) |= \
     (uint32_t)(Mask) \
  )

/* ----------------------------------------------------------------------------
   -- DisableDigitalFilters
   ---------------------------------------------------------------------------- */

/**
 * Disables digital filters.
 * @param peripheralBase Peripheral base address.
 * @param Mask Mask of pins. Use constants from group "Pin masks".
 */
#define PORT_PDD_DisableDigitalFilters(peripheralBase, Mask) ( \
    PORT_DFER_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)(Mask)) \
  )

/* ----------------------------------------------------------------------------
   -- GetFilterClockSource
   ---------------------------------------------------------------------------- */

/**
 * Gets how filter clock source is set.
 * @param peripheralBase Peripheral base address.
 */
#define PORT_PDD_GetFilterClockSource(peripheralBase) ( \
    (uint32_t)(PORT_DFCR_REG(peripheralBase) & PORT_DFCR_CS_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- SetFilterClockSource
   ---------------------------------------------------------------------------- */

/**
 * Sets filter clock source.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state of filter clock source.
 */
#define PORT_PDD_SetFilterClockSource(peripheralBase, State) ( \
    PORT_DFCR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(PORT_DFCR_REG(peripheralBase) & (uint32_t)(~(uint32_t)PORT_DFCR_CS_MASK))) | ( \
      (uint32_t)(State))) \
  )

/* ----------------------------------------------------------------------------
   -- GetFilterLength
   ---------------------------------------------------------------------------- */

/**
 * Returns filter length in clock cycles.
 * @param peripheralBase Peripheral base address.
 */
#define PORT_PDD_GetFilterLength(peripheralBase) ( \
    PORT_DFWR_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- SetFilterLength
   ---------------------------------------------------------------------------- */

/**
 * Sets filter length in clock cycles.
 * @param peripheralBase Peripheral base address.
 * @param Value Parameter specifying new value.
 */
#define PORT_PDD_SetFilterLength(peripheralBase, Value) ( \
    PORT_DFWR_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )
#endif  /* #if defined(PORT_PDD_H_) */

/* PORT_PDD.h, eof. */
