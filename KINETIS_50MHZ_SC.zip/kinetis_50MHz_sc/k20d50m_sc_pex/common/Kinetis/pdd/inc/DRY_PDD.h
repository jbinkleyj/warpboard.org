/*
  PDD layer implementation for peripheral type DRY
  (C) 2010 Freescale, Inc. All rights reserved.

  This file is static and it is generated from API-Factory
*/

#if !defined(DRY_PDD_H_)
#define DRY_PDD_H_

/* ----------------------------------------------------------------------------
   -- Test if supported MCU is active
   ---------------------------------------------------------------------------- */

#if !defined(MCU_ACTIVE)
  // No MCU is active
  #error DRY PDD library: No derivative is active. Place proper #include with PDD memory map before including PDD library.
#elif \
      !defined(MCU_MK11D5) /* DRY */ && \
      !defined(MCU_MK21D5) /* DRY */ && \
      !defined(MCU_MK61F12) /* DRY */ && \
      !defined(MCU_MK61F15) /* DRY */
  // Unsupported MCU is active
  #error DRY PDD library: Unsupported derivative is active.
#endif

#include "PDD_Types.h"

/* ----------------------------------------------------------------------------
   -- Method symbol definitions
   ---------------------------------------------------------------------------- */

/* Secure key work masks */
#define DRY_PDD_SECURE_KEY_WORD_0_MASK 0x1U      /**< Secure key word 0 mask. */
#define DRY_PDD_SECURE_KEY_WORD_1_MASK 0x2U      /**< Secure key word 1 mask. */
#define DRY_PDD_SECURE_KEY_WORD_2_MASK 0x4U      /**< Secure key word 2 mask. */
#define DRY_PDD_SECURE_KEY_WORD_3_MASK 0x8U      /**< Secure key word 3 mask. */
#define DRY_PDD_SECURE_KEY_WORD_4_MASK 0x10U     /**< Secure key word 4 mask. */
#define DRY_PDD_SECURE_KEY_WORD_5_MASK 0x20U     /**< Secure key word 5 mask. */
#define DRY_PDD_SECURE_KEY_WORD_6_MASK 0x40U     /**< Secure key word 6 mask. */
#define DRY_PDD_SECURE_KEY_WORD_7_MASK 0x80U     /**< Secure key word 7 mask. */

/* Tamper flag masks */
#define DRY_PDD_TAMPER_PIN_0_MASK 0x10000U       /**< Tamper pin 0 flag mask. */
#define DRY_PDD_TAMPER_PIN_1_MASK 0x20000U       /**< Tamper pin 1 flag mask. */
#define DRY_PDD_TAMPER_PIN_2_MASK 0x40000U       /**< Tamper pin 2 flag mask. */
#define DRY_PDD_TAMPER_PIN_3_MASK 0x80000U       /**< Tamper pin 3 flag mask. */
#define DRY_PDD_TAMPER_PIN_4_MASK 0x100000U      /**< Tamper pin 4 flag mask. */
#define DRY_PDD_TAMPER_PIN_5_MASK 0x200000U      /**< Tamper pin 5 flag mask. */
#define DRY_PDD_TAMPER_PIN_6_MASK 0x400000U      /**< Tamper pin 6 flag mask. */
#define DRY_PDD_TAMPER_PIN_7_MASK 0x800000U      /**< Tamper pin 7 flag mask. */
#define DRY_PDD_TEST_MODE_MASK 0x200U            /**< Test mode flag mask. */
#define DRY_PDD_FLASH_SECURITY_MASK 0x100U       /**< Flash security flag mask. */
#define DRY_PDD_SECURITY_TAMPER_MASK 0x80U       /**< Security tamper flag mask. */
#define DRY_PDD_TEMPERATURE_TAMPER_MASK 0x40U    /**< Temperature tamper flag mask. */
#define DRY_PDD_CLOCK_TAMPER_MASK 0x20U          /**< Clock tamper flag mask. */
#define DRY_PDD_VOLTAGE_TAMPER_MASK 0x10U        /**< Voltage tamper flag mask. */
#define DRY_PDD_MONOTONIC_OVERFLOW_MASK 0x8U     /**< Monotonic overflow flag mask. */
#define DRY_PDD_TIME_OVERFLOW_MASK 0x4U          /**< Time overflow flag mask. */
#define DRY_PDD_TAMPER_ACK_MASK 0x2U             /**< Tamper acknowledge flag mask. */
#define DRY_PDD_DRY_ICE_TAMPER_MASK 0x1U         /**< Tamper flag mask. */

/* Lock masks */
#define DRY_PDD_PIN_0_GLITCH_FILTER_LOCK_MASK 0x10000U /**< Pin 0 glitch filter lock mask. */
#define DRY_PDD_PIN_1_GLITCH_FILTER_LOCK_MASK 0x20000U /**< Pin 1 glitch filter lock mask. */
#define DRY_PDD_PIN_2_GLITCH_FILTER_LOCK_MASK 0x40000U /**< Pin 2 glitch filter lock mask. */
#define DRY_PDD_PIN_3_GLITCH_FILTER_LOCK_MASK 0x80000U /**< Pin 3 glitch filter lock mask. */
#define DRY_PDD_PIN_4_GLITCH_FILTER_LOCK_MASK 0x100000U /**< Pin 4 glitch filter lock mask. */
#define DRY_PDD_PIN_5_GLITCH_FILTER_LOCK_MASK 0x200000U /**< Pin 5 glitch filter lock mask. */
#define DRY_PDD_PIN_6_GLITCH_FILTER_LOCK_MASK 0x400000U /**< Pin 6 glitch filter lock mask. */
#define DRY_PDD_PIN_7_GLITCH_FILTER_LOCK_MASK 0x800000U /**< Pin 7 glitch filter lock mask. */
#define DRY_PDD_ACTIVE_TAMPER_1_LOCK_MASK 0x2000U /**< Active tamper register 1 lock mask. */
#define DRY_PDD_ACTIVE_TAMPER_0_LOCK_MASK 0x1000U /**< Active tamper register 0 lock mask. */
#define DRY_PDD_PIN_POLARITY_LOCK_MASK 0x800U    /**< Pin polarity register lock mask. */
#define DRY_PDD_PIN_DIRECTION_LOCK_MASK 0x400U   /**< Pin direction register lock mask. */
#define DRY_PDD_TAMPER_ENABLE_LOCK_MASK 0x200U   /**< Tamper enable register lock mask. */
#define DRY_PDD_TAMPER_SECONDS_LOCK_MASK 0x100U  /**< Tamper seconds register lock mask. */
#define DRY_PDD_INTERRUPT_ENABLE_LOCK_MASK 0x80U /**< Interrupt enable register lock mask. */
#define DRY_PDD_LOCK_LOCK_MASK 0x40U             /**< Lock register lock mask. */
#define DRY_PDD_STATUS_LOCK_MASK 0x20U           /**< Status register lock mask. */
#define DRY_PDD_CONTROL_LOCK_MASK 0x10U          /**< Control register lock mask. */
#define DRY_PDD_KEY_READ_LOCK_MASK 0x8U          /**< Secure key read register lock mask. */
#define DRY_PDD_KEY_WRITE_LOCK_MASK 0x4U         /**< Secure key write register lock mask. */
#define DRY_PDD_KEY_VALID_LOCK_MASK 0x2U         /**< Secure key valid register lock mask. */

/* Tamper pin values. */
#define DRY_PDD_LOGIC_ZERO 0U                    /**< Logic zero. */
#define DRY_PDD_LOGIC_ONE 0x1U                   /**< Logic one. */

/* Tamper pin directions. */
#define DRY_PDD_INPUT 0U                         /**< Pin is input. */
#define DRY_PDD_OUTPUT 0x1U                      /**< Pin is output and drives inverse of expected value. */

/* Tamper pin polarity. */
#define DRY_PDD_NOT_INVERTED 0U                  /**< Expected value is not inverted. */
#define DRY_PDD_INVERTED 0x1U                    /**< Expected value is inverted. */

/* Tamper pin expected values. */
#define DRY_PDD_LOGIC_ZERO_EXPECTED 0U           /**< Logic zero. */
#define DRY_PDD_ACTIVE_TAMPER_0_OUTPUT_EXPECTED 0x10000U /**< Active tamper 0 output. */
#define DRY_PDD_ACTIVE_TAMPER_1_OUTPUT_EXPECTED 0x20000U /**< Active tamper 1 output. */
#define DRY_PDD_ACTIVE_TAMPER_0_XOR_ACTIVE_TAMPER_1_OUTPUT_EXPECTED 0x30000U /**< Active tamper 0 output XORed with active tamper 1 output. */

/* Glitch filter prescaler clocks. */
#define DRY_PDD_512_HZ_CLOCK 0U                  /**< 512 Hz clock. */
#define DRY_PDD_32768_HZ_CLOCK 0x40U             /**< 32.768 kHz clock. */


/* ----------------------------------------------------------------------------
   -- InvalidateSecureKeyWords
   ---------------------------------------------------------------------------- */

/**
 * Invalidates and clears the secure key words specified by the mask parameter.
 * At the same time unlocks the read and write access to the corresponding secure
 * key words.
 * @param peripheralBase Peripheral base address.
 * @param Mask Secure key word mask. Possible values (OR mask from): see 'Secure
 *        key word masks'.
 */
#define DRY_PDD_InvalidateSecureKeyWords(peripheralBase, Mask) ( \
    DRY_SKVR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(DRY_SKVR_REG(peripheralBase) & (uint32_t)(~(uint32_t)DRY_SKVR_SKV_MASK))) | ( \
      (uint32_t)(Mask))) \
  )

/* ----------------------------------------------------------------------------
   -- GetValidSecureKeyWordsMask
   ---------------------------------------------------------------------------- */

/**
 * Returns the mask of valid secure key words. The mask can be tested against
 * predefined masks. See 'Secure key word masks'.
 * @param peripheralBase Peripheral base address.
 */
#define DRY_PDD_GetValidSecureKeyWordsMask(peripheralBase) ( \
    (uint8_t)(DRY_SKVR_REG(peripheralBase) & DRY_SKVR_SKV_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- LockSecureKeyWriteTillVBATReset
   ---------------------------------------------------------------------------- */

/**
 * Locks the secure key words specified by the mask parameter for write until
 * VBAT reset or software reset.
 * @param peripheralBase Peripheral base address.
 * @param Mask Secure key word mask. Possible values (OR mask from): see 'Secure
 *        key word masks'.
 */
#define DRY_PDD_LockSecureKeyWriteTillVBATReset(peripheralBase, Mask) ( \
    DRY_SKWLR_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)(Mask)) \
  )

/* ----------------------------------------------------------------------------
   -- LockSecureKeyReadTillVBATReset
   ---------------------------------------------------------------------------- */

/**
 * Locks the secure key words specified by the mask parameter for read until
 * VBAT reset or software reset.
 * @param peripheralBase Peripheral base address.
 * @param Mask Secure key word mask. Possible values (OR mask from): see 'Secure
 *        key word masks'.
 */
#define DRY_PDD_LockSecureKeyReadTillVBATReset(peripheralBase, Mask) ( \
    DRY_SKRLR_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)(Mask)) \
  )

/* ----------------------------------------------------------------------------
   -- SetPrescalerInitValue
   ---------------------------------------------------------------------------- */

/**
 * Configures the initial value of the prescaler. Can be used only if the
 * peripheral is disabled.
 * @param peripheralBase Peripheral base address.
 * @param Value Initial value of the prescaler. Possible values: from 0 to 32767.
 */
#define DRY_PDD_SetPrescalerInitValue(peripheralBase, Value) ( \
    DRY_CR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(DRY_CR_REG(peripheralBase) & (uint32_t)(~(uint32_t)DRY_CR_DPR_MASK))) | ( \
      (uint32_t)((uint32_t)(Value) << DRY_CR_DPR_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- GetPrescalerValue
   ---------------------------------------------------------------------------- */

/**
 * Returns the current value of the prescaler in the range from 0 to 32767. The
 * inverse of bit 7 is the 512 Hz prescaler clock output that is used to clock
 * the glitch filters. The inverse of bit 15 is the 1 Hz prescaler clock output
 * that is used to clock the active tamper shift registers.
 * @param peripheralBase Peripheral base address.
 */
#define DRY_PDD_GetPrescalerValue(peripheralBase) ( \
    (uint16_t)((uint32_t)(DRY_CR_REG(peripheralBase) & DRY_CR_DPR_MASK) >> DRY_CR_DPR_SHIFT) \
  )

/* ----------------------------------------------------------------------------
   -- EnableTamperFastSlewRate
   ---------------------------------------------------------------------------- */

/**
 * Enables fast slew rate on tamper pins.
 * @param peripheralBase Peripheral base address.
 * @param Enable Enable flag. Possible values: PDD_ENABLE, PDD_DISABLE.
 */
#define DRY_PDD_EnableTamperFastSlewRate(peripheralBase, Enable) ( \
    ((uint32_t)(Enable) == 0U) ? ( \
      DRY_CR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)DRY_CR_TSRE_MASK)) : ( \
      DRY_CR_REG(peripheralBase) |= \
       DRY_CR_TSRE_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- EnableTamperHighDriveStrength
   ---------------------------------------------------------------------------- */

/**
 * Enables high drive strength on tamper pins.
 * @param peripheralBase Peripheral base address.
 * @param Enable Enable flag. Possible values: PDD_ENABLE, PDD_DISABLE.
 */
#define DRY_PDD_EnableTamperHighDriveStrength(peripheralBase, Enable) ( \
    ((uint32_t)(Enable) == 0U) ? ( \
      DRY_CR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)DRY_CR_TDSE_MASK)) : ( \
      DRY_CR_REG(peripheralBase) |= \
       DRY_CR_TDSE_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- EnableTamperPassiveFilter
   ---------------------------------------------------------------------------- */

/**
 * Enables passive input filters on tamper pins.
 * @param peripheralBase Peripheral base address.
 * @param Enable Enable flag. Possible values: PDD_ENABLE, PDD_DISABLE.
 */
#define DRY_PDD_EnableTamperPassiveFilter(peripheralBase, Enable) ( \
    ((uint32_t)(Enable) == 0U) ? ( \
      DRY_CR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)DRY_CR_TPFE_MASK)) : ( \
      DRY_CR_REG(peripheralBase) |= \
       DRY_CR_TPFE_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- EnableTamperHysteresis
   ---------------------------------------------------------------------------- */

/**
 * Enables hysteresis on tamper pins.
 * @param peripheralBase Peripheral base address.
 * @param Enable Enable flag. Possible values: PDD_ENABLE, PDD_DISABLE.
 */
#define DRY_PDD_EnableTamperHysteresis(peripheralBase, Enable) ( \
    ((uint32_t)(Enable) == 0x1U) ? ( \
      DRY_CR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)DRY_CR_TPFE_MASK)) : ( \
      DRY_CR_REG(peripheralBase) |= \
       DRY_CR_TPFE_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- EnableUpdateMode
   ---------------------------------------------------------------------------- */

/**
 * Enables the update mode in which status flags can be written unless the
 * status register is locked, ignoring the tamper flag.
 * @param peripheralBase Peripheral base address.
 * @param Enable Enable flag. Possible values: PDD_ENABLE, PDD_DISABLE.
 */
#define DRY_PDD_EnableUpdateMode(peripheralBase, Enable) ( \
    ((uint32_t)(Enable) == 0x1U) ? ( \
      DRY_CR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)DRY_CR_UM_MASK)) : ( \
      DRY_CR_REG(peripheralBase) |= \
       DRY_CR_UM_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- EnableTamperSystemReset
   ---------------------------------------------------------------------------- */

/**
 * Enables the chip reset generation when the tamper flag is set and the tamper
 * acknowledge flag is clear.
 * @param peripheralBase Peripheral base address.
 * @param Enable Enable flag. Possible values: PDD_ENABLE, PDD_DISABLE.
 */
#define DRY_PDD_EnableTamperSystemReset(peripheralBase, Enable) ( \
    ((uint32_t)(Enable) == 0U) ? ( \
      DRY_CR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)DRY_CR_TFSR_MASK)) : ( \
      DRY_CR_REG(peripheralBase) |= \
       DRY_CR_TFSR_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- EnableDevice
   ---------------------------------------------------------------------------- */

/**
 * Enables the device clock. Must be enabled before enabling a glitch filter or
 * active tamper and should only be disabled after disabling all glitch filters
 * and active tampers.
 * @param peripheralBase Peripheral base address.
 * @param Enable Enable flag. Possible values: PDD_ENABLE, PDD_DISABLE.
 */
#define DRY_PDD_EnableDevice(peripheralBase, Enable) ( \
    ((uint32_t)(Enable) == 0U) ? ( \
      DRY_CR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)DRY_CR_DEN_MASK)) : ( \
      DRY_CR_REG(peripheralBase) |= \
       DRY_CR_DEN_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- ResetDevice
   ---------------------------------------------------------------------------- */

/**
 * Resets all the registers except the control register.
 * @param peripheralBase Peripheral base address.
 */
#define DRY_PDD_ResetDevice(peripheralBase) ( \
    DRY_CR_REG(peripheralBase) |= \
     DRY_CR_SWR_MASK \
  )

/* ----------------------------------------------------------------------------
   -- GetTamperFlags
   ---------------------------------------------------------------------------- */

/**
 * Returns the mask of set tamper flags. The mask can be tested against
 * predefined masks. See 'Tamper flag masks'.
 * @param peripheralBase Peripheral base address.
 */
#define DRY_PDD_GetTamperFlags(peripheralBase) ( \
    (uint32_t)(( \
     DRY_SR_REG(peripheralBase)) & ( \
     (uint32_t)(( \
      DRY_SR_TPF_MASK) | (( \
      DRY_SR_TMF_MASK) | (( \
      DRY_SR_FSF_MASK) | (( \
      DRY_SR_STF_MASK) | (( \
      DRY_SR_TTF_MASK) | (( \
      DRY_SR_CTF_MASK) | (( \
      DRY_SR_VTF_MASK) | (( \
      DRY_SR_MOF_MASK) | (( \
      DRY_SR_TOF_MASK) | (( \
      DRY_SR_TAF_MASK) | ( \
      DRY_SR_DTF_MASK))))))))))))) \
  )

/* ----------------------------------------------------------------------------
   -- ClearTamperFlags
   ---------------------------------------------------------------------------- */

/**
 * Clears the tamper flags specified by the mask parameter. A tamper pin flag
 * should be cleared after the tamper pin equals its expected value and the glitch
 * filter output has updated.
 * @param peripheralBase Peripheral base address.
 * @param Mask Tamper flags mask. Possible values (OR mask from): see 'Tamper
 *        flag masks'.
 */
#define DRY_PDD_ClearTamperFlags(peripheralBase, Mask) ( \
    DRY_SR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       DRY_SR_REG(peripheralBase)) & ( \
       (uint32_t)(~(uint32_t)(( \
        DRY_SR_TPF_MASK) | (( \
        DRY_SR_TMF_MASK) | (( \
        DRY_SR_FSF_MASK) | (( \
        DRY_SR_STF_MASK) | (( \
        DRY_SR_TTF_MASK) | (( \
        DRY_SR_CTF_MASK) | (( \
        DRY_SR_VTF_MASK) | (( \
        DRY_SR_MOF_MASK) | (( \
        DRY_SR_TOF_MASK) | (( \
        DRY_SR_TAF_MASK) | ( \
        DRY_SR_DTF_MASK))))))))))))))) | ( \
      (uint32_t)(Mask))) \
  )

/* ----------------------------------------------------------------------------
   -- LockWriteTillVBATReset
   ---------------------------------------------------------------------------- */

/**
 * Locks the registers specified by the mask parameter for write until VBAT
 * reset.
 * @param peripheralBase Peripheral base address.
 * @param Mask Lock mask. Possible values (OR mask from): see 'Lock masks'.
 */
#define DRY_PDD_LockWriteTillVBATReset(peripheralBase, Mask) ( \
    DRY_LR_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)(Mask)) \
  )

/* ----------------------------------------------------------------------------
   -- EnableInterrupts
   ---------------------------------------------------------------------------- */

/**
 * Enables the interrupts specified by the mask parameter.
 * @param peripheralBase Peripheral base address.
 * @param Mask Interrupt mask. Possible values (OR mask from): see 'Tamper flag
 *        masks', except TAMPER_ACK_MASK.
 */
#define DRY_PDD_EnableInterrupts(peripheralBase, Mask) ( \
    DRY_IER_REG(peripheralBase) |= \
     (uint32_t)(Mask) \
  )

/* ----------------------------------------------------------------------------
   -- DisableInterrupts
   ---------------------------------------------------------------------------- */

/**
 * Disables the interrupts specified by the mask parameter.
 * @param peripheralBase Peripheral base address.
 * @param Mask Interrupt mask. Possible values (OR mask from): see 'Tamper flag
 *        masks', except DRY_ICE_TAMPER_ACK_MASK.
 */
#define DRY_PDD_DisableInterrupts(peripheralBase, Mask) ( \
    DRY_IER_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)(Mask)) \
  )

/* ----------------------------------------------------------------------------
   -- GetTamperSeconds
   ---------------------------------------------------------------------------- */

/**
 * Returns the time in seconds (from the RTC Time Seconds Register) at which the
 * tamper flag was set.
 * @param peripheralBase Peripheral base address.
 */
#define DRY_PDD_GetTamperSeconds(peripheralBase) ( \
    DRY_TSR_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- EnableTamperDetection
   ---------------------------------------------------------------------------- */

/**
 * Enables the tamper detection flags specified by the mask parameter.
 * @param peripheralBase Peripheral base address.
 * @param Mask Tamper flags mask. Possible values (OR mask from): see 'Tamper
 *        flag masks', except TAMPER_ACK_MASK and DRY_ICE_TAMPER_MASK.
 * @param Enable Enable flag. Possible values: PDD_ENABLE, PDD_DISABLE.
 */
#define DRY_PDD_EnableTamperDetection(peripheralBase, Mask, Enable) ( \
    ((uint32_t)(Enable) == 0U) ? ( \
      DRY_TER_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)(Mask))) : ( \
      DRY_TER_REG(peripheralBase) |= \
       (uint32_t)(Mask)) \
  )

/* ----------------------------------------------------------------------------
   -- SetTamperPinOutput
   ---------------------------------------------------------------------------- */

/**
 * Sets tamper pin output data.
 * @param peripheralBase Peripheral base address.
 * @param Index Tamper pin index. Possible values: from 0 to 7.
 * @param Value Tamper pin output value. Possible values: see 'Tamper pin
 *        values'.
 */
#define DRY_PDD_SetTamperPinOutput(peripheralBase, Index, Value) ( \
    ((Value) == DRY_PDD_LOGIC_ZERO) ? ( \
      DRY_PDR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)((uint32_t)((uint32_t)0x1U << (Index)) << DRY_PDR_TPOD_SHIFT))) : ( \
      DRY_PDR_REG(peripheralBase) |= \
       (uint32_t)((uint32_t)((uint32_t)0x1U << (Index)) << DRY_PDR_TPOD_SHIFT)) \
  )

/* ----------------------------------------------------------------------------
   -- SetTamperPinDirection
   ---------------------------------------------------------------------------- */

/**
 * Sets tamper pin direction.
 * @param peripheralBase Peripheral base address.
 * @param Index Tamper pin index. Possible values: from 0 to 7.
 * @param Direction Tamper pin direction. Possible values: see 'Tamper pin
 *        directions'.
 */
#define DRY_PDD_SetTamperPinDirection(peripheralBase, Index, Direction) ( \
    ((Direction) == DRY_PDD_INPUT) ? ( \
      DRY_PDR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)((uint32_t)0x1U << (Index)))) : ( \
      DRY_PDR_REG(peripheralBase) |= \
       (uint32_t)((uint32_t)0x1U << (Index))) \
  )

/* ----------------------------------------------------------------------------
   -- SetTamperPinInput
   ---------------------------------------------------------------------------- */

/**
 * Sets tamper pin input data.
 * @param peripheralBase Peripheral base address.
 * @param Index Tamper pin index. Possible values: from 0 to 7.
 * @param Value Tamper pin input value. Possible values: see 'Tamper pin values'.
 */
#define DRY_PDD_SetTamperPinInput(peripheralBase, Index, Value) ( \
    ((Value) == DRY_PDD_LOGIC_ZERO) ? ( \
      DRY_PPR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)((uint32_t)((uint32_t)0x1U << (Index)) << DRY_PPR_TPID_SHIFT))) : ( \
      DRY_PPR_REG(peripheralBase) |= \
       (uint32_t)((uint32_t)((uint32_t)0x1U << (Index)) << DRY_PPR_TPID_SHIFT)) \
  )

/* ----------------------------------------------------------------------------
   -- SetTamperPinPolarity
   ---------------------------------------------------------------------------- */

/**
 * Sets tamper pin polarity.
 * @param peripheralBase Peripheral base address.
 * @param Index Tamper pin index. Possible values: from 0 to 7.
 * @param Polarity Tamper pin polarity. Possible values: see 'Tamper pin
 *        polarity'.
 */
#define DRY_PDD_SetTamperPinPolarity(peripheralBase, Index, Polarity) ( \
    ((Polarity) == DRY_PDD_NOT_INVERTED) ? ( \
      DRY_PPR_REG(peripheralBase) &= \
       (uint32_t)(~(uint32_t)((uint32_t)0x1U << (Index)))) : ( \
      DRY_PPR_REG(peripheralBase) |= \
       (uint32_t)((uint32_t)0x1U << (Index))) \
  )

/* ----------------------------------------------------------------------------
   -- SetActiveTamperPolynomial
   ---------------------------------------------------------------------------- */

/**
 * Sets the polynomial of the active tamper shift register. When set to zero,
 * the active tamper shift register is disabled. Once enabled, the active tamper
 * shift register updates once a second using the prescaler 1 Hz clock.
 * @param peripheralBase Peripheral base address.
 * @param Index Active tamper index.
 * @param Polynomial Polynomial of the active tamper shift register. Possible
 *        values: from 0x0000 to 0xFFFF.
 */
#define DRY_PDD_SetActiveTamperPolynomial(peripheralBase, Index, Polynomial) ( \
    DRY_ATR_REG(peripheralBase,(Index)) = \
     (uint32_t)(( \
      (uint32_t)(DRY_ATR_REG(peripheralBase,(Index)) & (uint32_t)(~(uint32_t)DRY_ATR_ATP_MASK))) | ( \
      (uint32_t)((uint32_t)(Polynomial) << DRY_ATR_ATP_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- SetActiveTamperShiftValue
   ---------------------------------------------------------------------------- */

/**
 * Sets the initial value of the active tamper shift register.
 * @param peripheralBase Peripheral base address.
 * @param Index Active tamper index.
 * @param Value Initial value of the active tamper shift register. Possible
 *        values: from 0x0000 to 0xFFFF.
 */
#define DRY_PDD_SetActiveTamperShiftValue(peripheralBase, Index, Value) ( \
    DRY_ATR_REG(peripheralBase,(Index)) = \
     (uint32_t)(( \
      (uint32_t)(DRY_ATR_REG(peripheralBase,(Index)) & (uint32_t)(~(uint32_t)DRY_ATR_ATSR_MASK))) | ( \
      (uint32_t)(Value))) \
  )

/* ----------------------------------------------------------------------------
   -- GetActiveTamperShiftValue
   ---------------------------------------------------------------------------- */

/**
 * Returns the value of the active tamper shift register in the range from
 * 0x0000 to 0xFFFF.
 * @param peripheralBase Peripheral base address.
 * @param Index Active tamper index.
 */
#define DRY_PDD_GetActiveTamperShiftValue(peripheralBase, Index) ( \
    (uint16_t)(DRY_ATR_REG(peripheralBase,(Index)) & DRY_ATR_ATSR_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- EnableTamperPinPull
   ---------------------------------------------------------------------------- */

/**
 * Enables the pull resistor on the tamper pin.
 * @param peripheralBase Peripheral base address.
 * @param Index Tamper pin index.
 * @param Enable Enable flag. Possible values: PDD_ENABLE, PDD_DISABLE.
 */
#define DRY_PDD_EnableTamperPinPull(peripheralBase, Index, Enable) ( \
    ((uint32_t)(Enable) == 0U) ? ( \
      DRY_PGFR_REG(peripheralBase,(Index)) &= \
       (uint32_t)(~(uint32_t)DRY_PGFR_TPE_MASK)) : ( \
      DRY_PGFR_REG(peripheralBase,(Index)) |= \
       DRY_PGFR_TPE_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- SetTamperPinExpectedValue
   ---------------------------------------------------------------------------- */

/**
 * Sets the expected value on the input pin.
 * @param peripheralBase Peripheral base address.
 * @param Index Tamper pin index.
 * @param Value Expected value. Possible values: see 'Tamper pin expected
 *        values'.
 */
#define DRY_PDD_SetTamperPinExpectedValue(peripheralBase, Index, Value) ( \
    DRY_PGFR_REG(peripheralBase,(Index)) = \
     (uint32_t)(( \
      (uint32_t)(( \
       DRY_PGFR_REG(peripheralBase,(Index))) & ( \
       (uint32_t)(~(uint32_t)DRY_PGFR_TPEX_MASK)))) | ( \
      (uint32_t)(Value))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableGlitchFilter
   ---------------------------------------------------------------------------- */

/**
 * Enables tamper pin glitch filter.
 * @param peripheralBase Peripheral base address.
 * @param Index Tamper pin index.
 * @param Enable Enable flag. Possible values: PDD_ENABLE, PDD_DISABLE.
 */
#define DRY_PDD_EnableGlitchFilter(peripheralBase, Index, Enable) ( \
    ((uint32_t)(Enable) == 0U) ? ( \
      DRY_PGFR_REG(peripheralBase,(Index)) &= \
       (uint32_t)(~(uint32_t)DRY_PGFR_GFE_MASK)) : ( \
      DRY_PGFR_REG(peripheralBase,(Index)) |= \
       DRY_PGFR_GFE_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- SetGlitchFilterPrescaler
   ---------------------------------------------------------------------------- */

/**
 * Sets the glitch filter prescaler.
 * @param peripheralBase Peripheral base address.
 * @param Index Tamper pin index.
 * @param Clock Prescaler clock. Possible values: see 'Glitch filter prescaler
 *        clocks'.
 */
#define DRY_PDD_SetGlitchFilterPrescaler(peripheralBase, Index, Clock) ( \
    DRY_PGFR_REG(peripheralBase,(Index)) = \
     (uint32_t)(( \
      (uint32_t)(( \
       DRY_PGFR_REG(peripheralBase,(Index))) & ( \
       (uint32_t)(~(uint32_t)DRY_PGFR_GFP_MASK)))) | ( \
      (uint32_t)(Clock))) \
  )

/* ----------------------------------------------------------------------------
   -- SetGlitchFilterWidth
   ---------------------------------------------------------------------------- */

/**
 * Configures the number of clock edges the input must remain stable for to be
 * passed through the glitch filter for tamper pin. The number of clock edges is
 * (GFW + 1) * 2 supporting a configuration of between 2 and 128 clock edges. Do
 * not change the glitch filter width when the glitch filter is enabled.
 * @param peripheralBase Peripheral base address.
 * @param Index Tamper pin index. Possible values: from 0 to 7.
 * @param Width Glitch filter width. Possible values: from 0 to 63.
 */
#define DRY_PDD_SetGlitchFilterWidth(peripheralBase, Index, Width) ( \
    DRY_PGFR_REG(peripheralBase,(Index)) = \
     (uint32_t)(( \
      (uint32_t)(( \
       DRY_PGFR_REG(peripheralBase,(Index))) & ( \
       (uint32_t)(~(uint32_t)DRY_PGFR_GFW_MASK)))) | ( \
      (uint32_t)(Width))) \
  )

/* ----------------------------------------------------------------------------
   -- LockWriteTillChipReset
   ---------------------------------------------------------------------------- */

/**
 * Locks the registers specified by the mask parameter for write until a chip
 * reset.
 * @param peripheralBase Peripheral base address.
 * @param Mask Locks mask. Possible values (OR mask from): see 'Lock masks',
 *        except KEY_SELECT_LOCK_MASK.
 */
#define DRY_PDD_LockWriteTillChipReset(peripheralBase, Mask) ( \
    DRY_WAC_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)(Mask)) \
  )

/* ----------------------------------------------------------------------------
   -- LockReadTillChipReset
   ---------------------------------------------------------------------------- */

/**
 * Locks the registers specified by the mask parameter for read until a chip
 * reset.
 * @param peripheralBase Peripheral base address.
 * @param Mask Locks mask. Possible values (OR mask from): see 'Lock masks',
 *        except KEY_SELECT_LOCK_MASK.
 */
#define DRY_PDD_LockReadTillChipReset(peripheralBase, Mask) ( \
    DRY_RAC_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)(Mask)) \
  )

/* ----------------------------------------------------------------------------
   -- SetSecureKeyWord
   ---------------------------------------------------------------------------- */

/**
 * Sets the value of the specified secure key word.
 * @param peripheralBase Peripheral base address.
 * @param Index Secure key word index. Possible values: from 0 to 7.
 * @param Value 32-bit wide secure key word value.
 */
#define DRY_PDD_SetSecureKeyWord(peripheralBase, Index, Value) ( \
    DRY_SKR_REG(peripheralBase,(Index)) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- GetSecureKeyWord
   ---------------------------------------------------------------------------- */

/**
 * Returns the 32-bit wide value of the specified secure key word.
 * @param peripheralBase Peripheral base address.
 * @param Index Secure key word index. Possible values: from 0 to 7.
 */
#define DRY_PDD_GetSecureKeyWord(peripheralBase, Index) ( \
    DRY_SKR_REG(peripheralBase,(Index)) \
  )

/* ----------------------------------------------------------------------------
   -- LockSecureKeyWriteTillChipReset
   ---------------------------------------------------------------------------- */

/**
 * Locks the secure key words specified by the mask parameter for write until
 * chip reset.
 * @param peripheralBase Peripheral base address.
 * @param Mask Secure key words mask. Possible values (OR mask from): see
 *        'Secure key word masks'.
 */
#define DRY_PDD_LockSecureKeyWriteTillChipReset(peripheralBase, Mask) ( \
    DRY_SWAC_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)(Mask)) \
  )

/* ----------------------------------------------------------------------------
   -- LockSecureKeyReadTillChipReset
   ---------------------------------------------------------------------------- */

/**
 * Locks the secure key words specified by the mask parameter for read until
 * chip reset.
 * @param peripheralBase Peripheral base address.
 * @param Mask Secure key words mask. Possible values (OR mask from): see
 *        'Secure key word masks'.
 */
#define DRY_PDD_LockSecureKeyReadTillChipReset(peripheralBase, Mask) ( \
    DRY_SRAC_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)(Mask)) \
  )
#endif  /* #if defined(DRY_PDD_H_) */

/* DRY_PDD.h, eof. */
