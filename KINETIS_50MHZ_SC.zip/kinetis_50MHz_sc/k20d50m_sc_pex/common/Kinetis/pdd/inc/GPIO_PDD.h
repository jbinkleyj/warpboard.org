/*
  PDD layer implementation for peripheral type GPIO
  (C) 2010 Freescale, Inc. All rights reserved.

  This file is static and it is generated from API-Factory
*/

#if !defined(GPIO_PDD_H_)
#define GPIO_PDD_H_

/* ----------------------------------------------------------------------------
   -- Test if supported MCU is active
   ---------------------------------------------------------------------------- */

#if !defined(MCU_ACTIVE)
  // No MCU is active
  #error GPIO PDD library: No derivative is active. Place proper #include with PDD memory map before including PDD library.
#elif \
      !defined(MCU_MK10D10) /* PTA, PTB, PTC, PTD, PTE */ && \
      !defined(MCU_MK10D5) /* PTA, PTB, PTC, PTD, PTE */ && \
      !defined(MCU_MK10D7) /* PTA, PTB, PTC, PTD, PTE */ && \
      !defined(MCU_MK10F12) /* PTA, PTB, PTC, PTD, PTE, PTF */ && \
      !defined(MCU_MK10DZ10) /* PTA, PTB, PTC, PTD, PTE */ && \
      !defined(MCU_MK11D5) /* PTA, PTB, PTC, PTD, PTE */ && \
      !defined(MCU_MK12D5) /* PTA, PTB, PTC, PTD, PTE */ && \
      !defined(MCU_MK20D10) /* PTA, PTB, PTC, PTD, PTE */ && \
      !defined(MCU_MK20D5) /* PTA, PTB, PTC, PTD, PTE */ && \
      !defined(MCU_MK20D7) /* PTA, PTB, PTC, PTD, PTE */ && \
      !defined(MCU_MK20F12) /* PTA, PTB, PTC, PTD, PTE, PTF */ && \
      !defined(MCU_MK20DZ10) /* PTA, PTB, PTC, PTD, PTE */ && \
      !defined(MCU_MK21D5) /* PTA, PTB, PTC, PTD, PTE */ && \
      !defined(MCU_MK22D5) /* PTA, PTB, PTC, PTD, PTE */ && \
      !defined(MCU_MK30D10) /* PTA, PTB, PTC, PTD, PTE */ && \
      !defined(MCU_MK30D7) /* PTA, PTB, PTC, PTD, PTE */ && \
      !defined(MCU_MK30DZ10) /* PTA, PTB, PTC, PTD, PTE */ && \
      !defined(MCU_MK40D10) /* PTA, PTB, PTC, PTD, PTE */ && \
      !defined(MCU_MK40D7) /* PTA, PTB, PTC, PTD, PTE */ && \
      !defined(MCU_MK40DZ10) /* PTA, PTB, PTC, PTD, PTE */ && \
      !defined(MCU_MK40X256VMD100) /* PTA, PTB, PTC, PTD, PTE */ && \
      !defined(MCU_MK50D10) /* PTA, PTB, PTC, PTD, PTE */ && \
      !defined(MCU_MK50D7) /* PTA, PTB, PTC, PTD, PTE */ && \
      !defined(MCU_MK50DZ10) /* PTA, PTB, PTC, PTD, PTE */ && \
      !defined(MCU_MK51D10) /* PTA, PTB, PTC, PTD, PTE */ && \
      !defined(MCU_MK51D7) /* PTA, PTB, PTC, PTD, PTE */ && \
      !defined(MCU_MK51DZ10) /* PTA, PTB, PTC, PTD, PTE */ && \
      !defined(MCU_MK52D10) /* PTA, PTB, PTC, PTD, PTE */ && \
      !defined(MCU_MK52DZ10) /* PTA, PTB, PTC, PTD, PTE */ && \
      !defined(MCU_MK53D10) /* PTA, PTB, PTC, PTD, PTE */ && \
      !defined(MCU_MK53DZ10) /* PTA, PTB, PTC, PTD, PTE */ && \
      !defined(MCU_MK60D10) /* PTA, PTB, PTC, PTD, PTE */ && \
      !defined(MCU_MK60F12) /* PTA, PTB, PTC, PTD, PTE, PTF */ && \
      !defined(MCU_MK60F15) /* PTA, PTB, PTC, PTD, PTE, PTF */ && \
      !defined(MCU_MK60DZ10) /* PTA, PTB, PTC, PTD, PTE */ && \
      !defined(MCU_MK60N512VMD100) /* PTA, PTB, PTC, PTD, PTE */ && \
      !defined(MCU_MK61F12) /* PTA, PTB, PTC, PTD, PTE, PTF */ && \
      !defined(MCU_MK61F15) /* PTA, PTB, PTC, PTD, PTE, PTF */ && \
      !defined(MCU_MK70F12) /* PTA, PTB, PTC, PTD, PTE, PTF */ && \
      !defined(MCU_MK70F15) /* PTA, PTB, PTC, PTD, PTE, PTF */ && \
      !defined(MCU_MKL04Z4) /* PTA, PTB */ && \
      !defined(MCU_MKL05Z4) /* PTA, PTB */ && \
      !defined(MCU_MKL14Z4) /* PTA, PTB, PTC, PTD, PTE */ && \
      !defined(MCU_MKL15Z4) /* PTA, PTB, PTC, PTD, PTE */ && \
      !defined(MCU_MKL24Z4) /* PTA, PTB, PTC, PTD, PTE */ && \
      !defined(MCU_MKL25Z4) /* PTA, PTB, PTC, PTD, PTE */ && \
      !defined(MCU_PCK20L4) /* PTA, PTB, PTC, PTD, PTE */
  // Unsupported MCU is active
  #error GPIO PDD library: Unsupported derivative is active.
#endif

#include "PDD_Types.h"

/* ----------------------------------------------------------------------------
   -- Method symbol definitions
   ---------------------------------------------------------------------------- */


/* ----------------------------------------------------------------------------
   -- GetPortDataInput
   ---------------------------------------------------------------------------- */

/**
 * Gets port data input independently of current direction setting.
 * @param peripheralBase Peripheral base address.
 */
#define GPIO_PDD_GetPortDataInput(peripheralBase) ( \
    GPIO_PDIR_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- SetPortDataOutput
   ---------------------------------------------------------------------------- */

/**
 * Sets port data output.
 * @param peripheralBase Peripheral base address.
 * @param Value Parameter specifying new data output value.
 */
#define GPIO_PDD_SetPortDataOutput(peripheralBase, Value) ( \
    GPIO_PDOR_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- GetPortDataOutput
   ---------------------------------------------------------------------------- */

/**
 * Gets port data output independently of current direction setting.
 * @param peripheralBase Peripheral base address.
 */
#define GPIO_PDD_GetPortDataOutput(peripheralBase) ( \
    GPIO_PDOR_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- ClearPortDataOutputMask
   ---------------------------------------------------------------------------- */

/**
 * Clears required bits of port data output.
 * @param peripheralBase Peripheral base address.
 * @param Mask Parameter specifying port pins which should be cleared.
 */
#define GPIO_PDD_ClearPortDataOutputMask(peripheralBase, Mask) ( \
    GPIO_PCOR_REG(peripheralBase) = \
     (uint32_t)(Mask) \
  )

/* ----------------------------------------------------------------------------
   -- SetPortDataOutputMask
   ---------------------------------------------------------------------------- */

/**
 * Sets required bits of port data output.
 * @param peripheralBase Peripheral base address.
 * @param Mask Parameter specifying port pins which should be set.
 */
#define GPIO_PDD_SetPortDataOutputMask(peripheralBase, Mask) ( \
    GPIO_PSOR_REG(peripheralBase) = \
     (uint32_t)(Mask) \
  )

/* ----------------------------------------------------------------------------
   -- TogglePortDataOutputMask
   ---------------------------------------------------------------------------- */

/**
 * Toggles required bits of port data output.
 * @param peripheralBase Peripheral base address.
 * @param Mask Parameter specifying port pins which should be inverted.
 */
#define GPIO_PDD_TogglePortDataOutputMask(peripheralBase, Mask) ( \
    GPIO_PTOR_REG(peripheralBase) = \
     (uint32_t)(Mask) \
  )

/* ----------------------------------------------------------------------------
   -- SetPortInputDirectionMask
   ---------------------------------------------------------------------------- */

/**
 * Sets required pins as input.
 * @param peripheralBase Peripheral base address.
 * @param Mask Parameter specifying port pins which should be set as input.
 */
#define GPIO_PDD_SetPortInputDirectionMask(peripheralBase, Mask) ( \
    GPIO_PDDR_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)(Mask)) \
  )

/* ----------------------------------------------------------------------------
   -- SetPortOutputDirectionMask
   ---------------------------------------------------------------------------- */

/**
 * Sets required pins as output.
 * @param peripheralBase Peripheral base address.
 * @param Mask Parameter specifying port pins which should be set as output.
 */
#define GPIO_PDD_SetPortOutputDirectionMask(peripheralBase, Mask) ( \
    GPIO_PDDR_REG(peripheralBase) |= \
     (uint32_t)(Mask) \
  )

/* ----------------------------------------------------------------------------
   -- SetPortDirection
   ---------------------------------------------------------------------------- */

/**
 * Sets direction of every pin in the port.
 * @param peripheralBase Peripheral base address.
 * @param Value Parameter specifying new direction for port pins.
 */
#define GPIO_PDD_SetPortDirection(peripheralBase, Value) ( \
    GPIO_PDDR_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- GetPortDirection
   ---------------------------------------------------------------------------- */

/**
 * Gets direction of every pin in the port.
 * @param peripheralBase Peripheral base address.
 */
#define GPIO_PDD_GetPortDirection(peripheralBase) ( \
    GPIO_PDDR_REG(peripheralBase) \
  )
#endif  /* #if defined(GPIO_PDD_H_) */

/* GPIO_PDD.h, eof. */
