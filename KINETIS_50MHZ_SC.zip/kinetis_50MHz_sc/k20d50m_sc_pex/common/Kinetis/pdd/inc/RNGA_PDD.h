/*
  PDD layer implementation for peripheral type RNG
  (C) 2010 Freescale, Inc. All rights reserved.

  This file is static and it is generated from API-Factory
*/

#if !defined(RNGA_PDD_H_)
#define RNGA_PDD_H_

/* ----------------------------------------------------------------------------
   -- Test if supported MCU is active
   ---------------------------------------------------------------------------- */

#if !defined(MCU_ACTIVE)
  // No MCU is active
  #error RNG PDD library: No derivative is active. Place proper #include with PDD memory map before including PDD library.
#elif \
      !defined(MCU_MK10F12) /* RNG */ && \
      !defined(MCU_MK11D5) /* RNG */ && \
      !defined(MCU_MK20F12) /* RNG */ && \
      !defined(MCU_MK21D5) /* RNG */ && \
      !defined(MCU_MK52D10) /* RNG */ && \
      !defined(MCU_MK53D10) /* RNG */ && \
      !defined(MCU_MK60D10) /* RNG */ && \
      !defined(MCU_MK60F12) /* RNG */ && \
      !defined(MCU_MK60F15) /* RNG */ && \
      !defined(MCU_MK61F12) /* RNG */ && \
      !defined(MCU_MK61F15) /* RNG */ && \
      !defined(MCU_MK70F12) /* RNG */ && \
      !defined(MCU_MK70F15) /* RNG */
  // Unsupported MCU is active
  #error RNG PDD library: Unsupported derivative is active.
#endif

#include "PDD_Types.h"

/* ----------------------------------------------------------------------------
   -- Method symbol definitions
   ---------------------------------------------------------------------------- */

/* Constants for mode setting. */
#define RNG_PDD_STARTED 0x1U                     /**< RNGA is running (GO bit is 1) */
#define RNG_PDD_STOPPED 0U                       /**< RNGA is stopped (GO bit is 0) */

/* Constants for sleep mode setting. */
#define RNG_PDD_START 0x1U                       /**< Put RNGA in sleep mode. */
#define RNG_PDD_STOP 0U                          /**< Wake up RNGA from sleep mode. */

/* Constants for sleep mode setting. */
#define RNG_PDD_SLEEPING 0x1U                    /**< RNGA is in sleep mode. */
#define RNG_PDD_RUNNING 0U                       /**< RNGA is running. */

/* Last read status */
#define RNG_PDD_READ_OK 0x1U                     /**< Last read was ok. */
#define RNG_PDD_UNDERFLOW_ERROR 0U               /**< Last read caused FIFO underflow error. */

/* Status of RNG. */
#define RNG_PDD_STATUS_SLEEP 0x10U               /**< RNGA is in sleep mode. */
#define RNG_PDD_STATUS_ERROR_INT 0x8U            /**< Error interrupt is pending. */
#define RNG_PDD_STATUS_UNDERFLOW_ERROR 0x4U      /**< Output register underflow error. */
#define RNG_PDD_STATUS_LAST_READ_CAUSED_UNDERFLOW 0x2U /**< Last read of output register caused undeflow error. */
#define RNG_PDD_STATUS_SECURITY_VIOLATION 0x1U   /**< Security violation detected. */


/* ----------------------------------------------------------------------------
   -- Started
   ---------------------------------------------------------------------------- */

/**
 * Returns whether RNGA was started by asserting GO bit in CR register.
 * @param peripheralBase Peripheral base address.
 */
#define RNG_PDD_Started(peripheralBase) ( \
    (uint8_t)(RNG_CR_REG(peripheralBase) & RNG_CR_GO_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- StartSleepMode
   ---------------------------------------------------------------------------- */

/**
 * Forces RNGA to sleep mode. Random numbers are not available in this mode.
 * @param peripheralBase Peripheral base address.
 */
#define RNG_PDD_StartSleepMode(peripheralBase) ( \
    RNG_CR_REG(peripheralBase) |= \
     RNG_CR_SLP_MASK \
  )

/* ----------------------------------------------------------------------------
   -- StopSleepMode
   ---------------------------------------------------------------------------- */

/**
 * Wakes up RNGA from sleep mode.
 * @param peripheralBase Peripheral base address.
 */
#define RNG_PDD_StopSleepMode(peripheralBase) ( \
    RNG_CR_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)RNG_CR_SLP_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- SetSleepMode
   ---------------------------------------------------------------------------- */

/**
 * Enable or disable RNGA sleep mode.
 * @param peripheralBase Peripheral base address.
 * @param Mode Sleep mode settings. Use constants from group "Constants for
 *        sleep mode setting.".
 */
#define RNG_PDD_SetSleepMode(peripheralBase, Mode) ( \
    RNG_CR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(RNG_CR_REG(peripheralBase) & (uint32_t)(~(uint32_t)RNG_CR_SLP_MASK))) | ( \
      (uint32_t)((uint32_t)(Mode) << RNG_CR_SLP_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- GetSleepMode
   ---------------------------------------------------------------------------- */

/**
 * Returns whether RNGA is in sleep mode.
 * @param peripheralBase Peripheral base address.
 */
#define RNG_PDD_GetSleepMode(peripheralBase) ( \
    (uint8_t)((uint32_t)(RNG_SR_REG(peripheralBase) & RNG_SR_SLP_MASK) >> RNG_SR_SLP_SHIFT) \
  )

/* ----------------------------------------------------------------------------
   -- GetFIFOSize
   ---------------------------------------------------------------------------- */

/**
 * Returns the FIFO size.
 * @param peripheralBase Peripheral base address.
 */
#define RNG_PDD_GetFIFOSize(peripheralBase) ( \
    (uint8_t)(( \
     (uint32_t)(RNG_SR_REG(peripheralBase) & RNG_SR_OREG_SIZE_MASK)) >> ( \
     RNG_SR_OREG_SIZE_SHIFT)) \
  )

/* ----------------------------------------------------------------------------
   -- GetFIFOLevel
   ---------------------------------------------------------------------------- */

/**
 * Returns FIFO level.
 * @param peripheralBase Peripheral base address.
 */
#define RNG_PDD_GetFIFOLevel(peripheralBase) ( \
    (uint8_t)(( \
     (uint32_t)(RNG_SR_REG(peripheralBase) & RNG_SR_OREG_LVL_MASK)) >> ( \
     RNG_SR_OREG_LVL_SHIFT)) \
  )

/* ----------------------------------------------------------------------------
   -- LastReadStatus
   ---------------------------------------------------------------------------- */

/**
 * Returns status of last read number.
 * @param peripheralBase Peripheral base address.
 */
#define RNG_PDD_LastReadStatus(peripheralBase) ( \
    (uint8_t)((uint32_t)(RNG_SR_REG(peripheralBase) & RNG_SR_LRS_MASK) >> RNG_SR_LRS_SHIFT) \
  )

/* ----------------------------------------------------------------------------
   -- GetStatusRegister
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the RNGA Status Register.
 * @param peripheralBase Peripheral base address.
 */
#define RNG_PDD_GetStatusRegister(peripheralBase) ( \
    RNG_SR_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- GetOutValue
   ---------------------------------------------------------------------------- */

/**
 * Returns the random data generated by the RNGA.
 * @param peripheralBase Peripheral base address.
 */
#define RNG_PDD_GetOutValue(peripheralBase) ( \
    RNG_OR_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- InsertEntropy
   ---------------------------------------------------------------------------- */

/**
 * Insert additional entropy to RNGA.
 * @param peripheralBase Peripheral base address.
 * @param EntropyValue New entropy value.
 */
#define RNG_PDD_InsertEntropy(peripheralBase, EntropyValue) ( \
    RNG_ER_REG(peripheralBase) = \
     (uint32_t)(EntropyValue) \
  )

/* ----------------------------------------------------------------------------
   -- ClearInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Clears the RNGA pending interrupt and error flag.
 * @param peripheralBase Peripheral base address.
 */
#define RNG_PDD_ClearInterrupt(peripheralBase) ( \
    RNG_CR_REG(peripheralBase) |= \
     RNG_CR_CLRI_MASK \
  )

/* ----------------------------------------------------------------------------
   -- EnableHigAssuranceMode
   ---------------------------------------------------------------------------- */

/**
 * Enable High Assurance mode of RNGA. This mode can be disabled only by
 * hardware reset.
 * @param peripheralBase Peripheral base address.
 */
#define RNG_PDD_EnableHigAssuranceMode(peripheralBase) ( \
    RNG_CR_REG(peripheralBase) |= \
     RNG_CR_HA_MASK \
  )

/* ----------------------------------------------------------------------------
   -- Start
   ---------------------------------------------------------------------------- */

/**
 * Start RNGA.
 * @param peripheralBase Peripheral base address.
 */
#define RNG_PDD_Start(peripheralBase) ( \
    RNG_CR_REG(peripheralBase) |= \
     RNG_CR_GO_MASK \
  )

/* ----------------------------------------------------------------------------
   -- EnableInterrupts
   ---------------------------------------------------------------------------- */

/**
 * Enables error interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define RNG_PDD_EnableInterrupts(peripheralBase) ( \
    RNG_CR_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)RNG_CR_INTM_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- DisableInterrupts
   ---------------------------------------------------------------------------- */

/**
 * Disables interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define RNG_PDD_DisableInterrupts(peripheralBase) ( \
    RNG_CR_REG(peripheralBase) |= \
     RNG_CR_INTM_MASK \
  )
#endif  /* #if defined(RNGA_PDD_H_) */

/* RNGA_PDD.h, eof. */
