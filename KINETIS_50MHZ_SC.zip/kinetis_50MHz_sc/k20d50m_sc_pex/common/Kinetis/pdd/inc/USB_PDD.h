/*
  PDD layer implementation for peripheral type USB
  (C) 2010 Freescale, Inc. All rights reserved.

  This file is static and it is generated from API-Factory
*/

#if !defined(USB_PDD_H_)
#define USB_PDD_H_

/* ----------------------------------------------------------------------------
   -- Test if supported MCU is active
   ---------------------------------------------------------------------------- */

#if !defined(MCU_ACTIVE)
  // No MCU is active
  #error USB PDD library: No derivative is active. Place proper #include with PDD memory map before including PDD library.
#elif \
      !defined(MCU_MK20D10) /* USB0 */ && \
      !defined(MCU_MK20D5) /* USB0 */ && \
      !defined(MCU_MK20D7) /* USB0 */ && \
      !defined(MCU_MK20F12) /* USB0 */ && \
      !defined(MCU_MK20DZ10) /* USB0 */ && \
      !defined(MCU_MK21D5) /* USB0 */ && \
      !defined(MCU_MK22D5) /* USB0 */ && \
      !defined(MCU_MK40D10) /* USB0 */ && \
      !defined(MCU_MK40D7) /* USB0 */ && \
      !defined(MCU_MK40DZ10) /* USB0 */ && \
      !defined(MCU_MK40X256VMD100) /* USB0 */ && \
      !defined(MCU_MK50D10) /* USB0 */ && \
      !defined(MCU_MK50D7) /* USB0 */ && \
      !defined(MCU_MK50DZ10) /* USB0 */ && \
      !defined(MCU_MK51D10) /* USB0 */ && \
      !defined(MCU_MK51D7) /* USB0 */ && \
      !defined(MCU_MK51DZ10) /* USB0 */ && \
      !defined(MCU_MK52D10) /* USB0 */ && \
      !defined(MCU_MK52DZ10) /* USB0 */ && \
      !defined(MCU_MK53D10) /* USB0 */ && \
      !defined(MCU_MK53DZ10) /* USB0 */ && \
      !defined(MCU_MK60D10) /* USB0 */ && \
      !defined(MCU_MK60F12) /* USB0 */ && \
      !defined(MCU_MK60F15) /* USB0 */ && \
      !defined(MCU_MK60DZ10) /* USB0 */ && \
      !defined(MCU_MK60N512VMD100) /* USB0 */ && \
      !defined(MCU_MK61F12) /* USB0 */ && \
      !defined(MCU_MK61F15) /* USB0 */ && \
      !defined(MCU_MK70F12) /* USB0 */ && \
      !defined(MCU_MK70F15) /* USB0 */ && \
      !defined(MCU_MKL24Z4) /* USB0 */ && \
      !defined(MCU_MKL25Z4) /* USB0 */ && \
      !defined(MCU_PCK20L4) /* USB0 */
  // Unsupported MCU is active
  #error USB PDD library: Unsupported derivative is active.
#endif

#include "PDD_Types.h"

/* ----------------------------------------------------------------------------
   -- Method symbol definitions
   ---------------------------------------------------------------------------- */

/* Otg status masks */
#define USB_PDD_A_VBUS_VALID USB_OTGSTAT_AVBUSVLD_MASK /**< A VBus valid signal mask */
#define USB_PDD_B_SESSION_END USB_OTGSTAT_BSESSEND_MASK /**< B session end signal mask */
#define USB_PDD_SESSION_VALID USB_OTGSTAT_SESS_VLD_MASK /**< Session valid signal mask */
#define USB_PDD_LINE_STABLE USB_OTGSTAT_LINESTATESTABLE_MASK /**< Line stable signal mask */
#define USB_PDD_ID USB_OTGSTAT_ID_MASK           /**< ID signal mask */

/* Otg interrupt masks */
#define USB_PDD_ALL_INT_FLAGS 0xFFU              /**< Value used to mask all Otg interrupts */

/* Otg interrupt masks. */
#define USB_PDD_A_VBUS_CHG_INT USB_OTGICR_AVBUSEN_MASK /**< Vbus change interrupt mask */
#define USB_PDD_B_SESS_CHG_INT USB_OTGICR_BSESSEN_MASK /**< B session change interrupt mask */
#define USB_PDD_SESS_VLD_CHG_INT USB_OTGICR_SESSVLDEN_MASK /**< Session valid change interrupt mask */
#define USB_PDD_LINE_STATE_CHG_INT USB_OTGICR_LINESTATEEN_MASK /**< Line state change interrupt mask */
#define USB_PDD_1_MSEC_INT USB_OTGICR_ONEMSECEN_MASK /**< 1 ms interrupt mask */
#define USB_PDD_ID_CHG_INT USB_OTGICR_IDEN_MASK  /**< ID change interrupt mask */

/* Usb interrupt masks */
#define USB_PDD_STALL_INT USB_INTEN_STALLEN_MASK /**< Stall interrupt mask */
#define USB_PDD_ATTACH_INT USB_INTEN_ATTACHEN_MASK /**< Attach interrupt mask */
#define USB_PDD_RESUME_INT USB_INTEN_RESUMEEN_MASK /**< Resume interrupt mask */
#define USB_PDD_SLEEP_INT USB_INTEN_SLEEPEN_MASK /**< Sleed interrupt mask */
#define USB_PDD_TOK_DNE_INT USB_INTEN_TOKDNEEN_MASK /**< Token done interrupt mask */
#define USB_PDD_SOF_TOK_INT USB_INTEN_SOFTOKEN_MASK /**< Star of frame interrupt mask */
#define USB_PDD_ERROR_INT USB_INTEN_ERROREN_MASK /**< Error interrupt mask */
#define USB_PDD_USB_RST_INT USB_INTEN_USBRSTEN_MASK /**< Bus reset interrupt mask */

/* Error interrupt masks */
#define USB_PDD_BTS_ERR_INT USB_ERREN_BTSERREN_MASK /**< BTS error interrupt mask */
#define USB_PDD_DMA_ERR_INT USB_ERREN_DMAERREN_MASK /**< DNA error interrupt mask */
#define USB_PDD_BTO_ERR_INT USB_ERREN_BTOERREN_MASK /**< BTO errot interrupt mask */
#define USB_PDD_DFN8_INT USB_ERREN_DFN8EN_MASK   /**< DFN8 error interrupt mask */
#define USB_PDD_CRC16_INT USB_ERREN_CRC16EN_MASK /**< CRC16 interrupt mask */
#define USB_PDD_CRC5_EOF_INT USB_ERREN_CRC5EOFEN_MASK /**< CRC5 or EOF error interrupt mask */
#define USB_PDD_PID_ERR_INT USB_ERREN_PIDERREN_MASK /**< PID error interrupt mask */

/* Conrol register masks */
#define USB_PDD_JSTATE USB_CTL_JSTATE_MASK       /**< J state mask */
#define USB_PDD_SE0 USB_CTL_SE0_MASK             /**< SE0 mask */

/* Otg output signal masks */
#define USB_PDD_DP_PU_SIGNAL USB_OBSERVE_DPPU_MASK /**< D+ pull-up signal mask */
#define USB_PDD_DP_PD_SIGNAL USB_OBSERVE_DPPD_MASK /**< D+ pull-down signal mask */
#define USB_PDD_DM_PD_SIGNAL USB_OBSERVE_DMPD_MASK /**< D- pull-down signal mask */

/* Otg input signal masks */
#define USB_PDD_DEVICE_VBUS_DETECT_SIGNAL USB_CONTROL_DPPULLUPNONOTG_MASK /**< Device mode Vbus detect signal mask */

/* Bus speed */
#define USB_PDD_LOW_SPEED 0U                     /**< Low speed constant */
#define USB_PDD_FULL_SPEED 0x80U                 /**< Full speed constant */
#define USB_PDD_RESET 0x40U                      /**< Bus reset state constant */


/* ----------------------------------------------------------------------------
   -- ReadOtgStatusReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the Otg status register.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_ReadOtgStatusReg(peripheralBase) ( \
    USB_OTGSTAT_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- BDevice
   ---------------------------------------------------------------------------- */

/**
 * Returns the value of the ID bit.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_BDevice(peripheralBase) ( \
    (uint8_t)(USB_OTGSTAT_REG(peripheralBase) & USB_OTGSTAT_ID_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- LineStateStable
   ---------------------------------------------------------------------------- */

/**
 * Returns the value of the Line stable bit.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_LineStateStable(peripheralBase) ( \
    (uint8_t)(USB_OTGSTAT_REG(peripheralBase) & USB_OTGSTAT_LINESTATESTABLE_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- SessionValid
   ---------------------------------------------------------------------------- */

/**
 * Returns the value of the Session valid bit.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_SessionValid(peripheralBase) ( \
    (uint8_t)(USB_OTGSTAT_REG(peripheralBase) & USB_OTGSTAT_SESS_VLD_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- BSessionEnd
   ---------------------------------------------------------------------------- */

/**
 * Returns the value of the B session end bit.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_BSessionEnd(peripheralBase) ( \
    (uint8_t)(USB_OTGSTAT_REG(peripheralBase) & USB_OTGSTAT_BSESSEND_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- AVBusValid
   ---------------------------------------------------------------------------- */

/**
 * Returns the value of the A Vbus valid bit.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_AVBusValid(peripheralBase) ( \
    (uint8_t)(USB_OTGSTAT_REG(peripheralBase) & USB_OTGSTAT_AVBUSVLD_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetOtgInterruptFlags
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the Otg interrupt status register.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_GetOtgInterruptFlags(peripheralBase) ( \
    USB_OTGISTAT_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- ClearOtgInterruptFlags
   ---------------------------------------------------------------------------- */

/**
 * Clears flags defined by the Mask parameter.
 * @param peripheralBase Peripheral base address.
 * @param Mask Interrupt mask.
 */
#define USB_PDD_ClearOtgInterruptFlags(peripheralBase, Mask) ( \
    USB_OTGISTAT_REG(peripheralBase) = \
     (uint8_t)(Mask) \
  )

/* ----------------------------------------------------------------------------
   -- GetIdChgInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Returns the value of the ID changed flag.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_GetIdChgInterruptFlag(peripheralBase) ( \
    (uint8_t)(USB_OTGISTAT_REG(peripheralBase) & USB_OTGISTAT_IDCHG_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- Get1msInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Returns the value of the 1 ms interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_Get1msInterruptFlag(peripheralBase) ( \
    (uint8_t)(USB_OTGISTAT_REG(peripheralBase) & USB_OTGISTAT_ONEMSEC_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetLineStateChgInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Returns the value of the Line state change flag.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_GetLineStateChgInterruptFlag(peripheralBase) ( \
    (uint8_t)(USB_OTGISTAT_REG(peripheralBase) & USB_OTGISTAT_LINE_STATE_CHG_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetSessVldChgInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Returns the value of the Session valalid changed flag.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_GetSessVldChgInterruptFlag(peripheralBase) ( \
    (uint8_t)(USB_OTGISTAT_REG(peripheralBase) & USB_OTGISTAT_SESSVLDCHG_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetBsessVldChgInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Returns the value of the B session end changed flag.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_GetBsessVldChgInterruptFlag(peripheralBase) ( \
    (uint8_t)(USB_OTGISTAT_REG(peripheralBase) & USB_OTGISTAT_B_SESS_CHG_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetAVbusChgInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Returns the value of the A Vbus changed flag.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_GetAVbusChgInterruptFlag(peripheralBase) ( \
    (uint8_t)(USB_OTGISTAT_REG(peripheralBase) & USB_OTGISTAT_AVBUSCHG_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- ClearIdChgInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Clears the ID changed flag.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_ClearIdChgInterruptFlag(peripheralBase) ( \
    USB_OTGISTAT_REG(peripheralBase) |= \
     USB_OTGISTAT_IDCHG_MASK \
  )

/* ----------------------------------------------------------------------------
   -- Clear1msInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Clears the 1 ms flag.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_Clear1msInterruptFlag(peripheralBase) ( \
    USB_OTGISTAT_REG(peripheralBase) |= \
     USB_OTGISTAT_ONEMSEC_MASK \
  )

/* ----------------------------------------------------------------------------
   -- ClearLineStateChgInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Clears the Line state changed flag.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_ClearLineStateChgInterruptFlag(peripheralBase) ( \
    USB_OTGISTAT_REG(peripheralBase) |= \
     USB_OTGISTAT_LINE_STATE_CHG_MASK \
  )

/* ----------------------------------------------------------------------------
   -- ClearSessVldChgInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Clears the Session valid changed flag.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_ClearSessVldChgInterruptFlag(peripheralBase) ( \
    USB_OTGISTAT_REG(peripheralBase) |= \
     USB_OTGISTAT_SESSVLDCHG_MASK \
  )

/* ----------------------------------------------------------------------------
   -- ClearBsessVldChgInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Clears the B session end changed flag.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_ClearBsessVldChgInterruptFlag(peripheralBase) ( \
    USB_OTGISTAT_REG(peripheralBase) |= \
     USB_OTGISTAT_B_SESS_CHG_MASK \
  )

/* ----------------------------------------------------------------------------
   -- ClearAVbusChgInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Clears the A Vbus changed flag.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_ClearAVbusChgInterruptFlag(peripheralBase) ( \
    USB_OTGISTAT_REG(peripheralBase) |= \
     USB_OTGISTAT_AVBUSCHG_MASK \
  )

/* ----------------------------------------------------------------------------
   -- GetOtgInterruptMask
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the Otg interrupt enable register.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_GetOtgInterruptMask(peripheralBase) ( \
    USB_OTGICR_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- SetOtgInterruptMask
   ---------------------------------------------------------------------------- */

/**
 * Enables interrupts defined by the Mask parameter.
 * @param peripheralBase Peripheral base address.
 * @param Mask Interrupt mask.
 */
#define USB_PDD_SetOtgInterruptMask(peripheralBase, Mask) ( \
    USB_OTGICR_REG(peripheralBase) = \
     (uint8_t)(Mask) \
  )

/* ----------------------------------------------------------------------------
   -- EnableIdChgInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables the ID changed interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_EnableIdChgInterrupt(peripheralBase) ( \
    USB_OTGICR_REG(peripheralBase) |= \
     USB_OTGICR_IDEN_MASK \
  )

/* ----------------------------------------------------------------------------
   -- Enable1msInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables the 1 ms interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_Enable1msInterrupt(peripheralBase) ( \
    USB_OTGICR_REG(peripheralBase) |= \
     USB_OTGICR_ONEMSECEN_MASK \
  )

/* ----------------------------------------------------------------------------
   -- EnableLineStateChgInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables the Line stable interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_EnableLineStateChgInterrupt(peripheralBase) ( \
    USB_OTGICR_REG(peripheralBase) |= \
     USB_OTGICR_LINESTATEEN_MASK \
  )

/* ----------------------------------------------------------------------------
   -- EnableSessVldChgInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables the Session valid changed interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_EnableSessVldChgInterrupt(peripheralBase) ( \
    USB_OTGICR_REG(peripheralBase) |= \
     USB_OTGICR_SESSVLDEN_MASK \
  )

/* ----------------------------------------------------------------------------
   -- EnableBsessVldChgInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables the B session end changed interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_EnableBsessVldChgInterrupt(peripheralBase) ( \
    USB_OTGICR_REG(peripheralBase) |= \
     USB_OTGICR_BSESSEN_MASK \
  )

/* ----------------------------------------------------------------------------
   -- EnableAVbusChgInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables the A Vbus changed interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_EnableAVbusChgInterrupt(peripheralBase) ( \
    USB_OTGICR_REG(peripheralBase) |= \
     USB_OTGICR_AVBUSEN_MASK \
  )

/* ----------------------------------------------------------------------------
   -- DisableIdChgInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables the ID changed interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_DisableIdChgInterrupt(peripheralBase) ( \
    USB_OTGICR_REG(peripheralBase) &= \
     (uint8_t)(~(uint8_t)USB_OTGICR_IDEN_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- Disable1msInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables the 1 ms interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_Disable1msInterrupt(peripheralBase) ( \
    USB_OTGICR_REG(peripheralBase) &= \
     (uint8_t)(~(uint8_t)USB_OTGICR_ONEMSECEN_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- DisableLineStateChgInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables the Line state changed interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_DisableLineStateChgInterrupt(peripheralBase) ( \
    USB_OTGICR_REG(peripheralBase) &= \
     (uint8_t)(~(uint8_t)USB_OTGICR_LINESTATEEN_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- DisableSessVldChgInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables the Session valid changed interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_DisableSessVldChgInterrupt(peripheralBase) ( \
    USB_OTGICR_REG(peripheralBase) &= \
     (uint8_t)(~(uint8_t)USB_OTGICR_SESSVLDEN_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- DisableBsessVldChgInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables the B session end changed interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_DisableBsessVldChgInterrupt(peripheralBase) ( \
    USB_OTGICR_REG(peripheralBase) &= \
     (uint8_t)(~(uint8_t)USB_OTGICR_BSESSEN_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- DisableAVbusChgInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables the A Vbus changed interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_DisableAVbusChgInterrupt(peripheralBase) ( \
    USB_OTGICR_REG(peripheralBase) &= \
     (uint8_t)(~(uint8_t)USB_OTGICR_AVBUSEN_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetUsbInterruptFlags
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the Usb interrupt status register.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_GetUsbInterruptFlags(peripheralBase) ( \
    USB_ISTAT_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- ClearUsbInterruptFlags
   ---------------------------------------------------------------------------- */

/**
 * Clears flags defined by the Mask parameter.
 * @param peripheralBase Peripheral base address.
 * @param Mask Interrupt mask.
 */
#define USB_PDD_ClearUsbInterruptFlags(peripheralBase, Mask) ( \
    USB_ISTAT_REG(peripheralBase) = \
     (uint8_t)(Mask) \
  )

/* ----------------------------------------------------------------------------
   -- GetStallInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Returnes the Stall interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_GetStallInterruptFlag(peripheralBase) ( \
    (uint8_t)(USB_ISTAT_REG(peripheralBase) & USB_ISTAT_STALL_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetAttachInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Returnes the Attach interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_GetAttachInterruptFlag(peripheralBase) ( \
    (uint8_t)(USB_ISTAT_REG(peripheralBase) & USB_ISTAT_ATTACH_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetResumeInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Returnes the Resume interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_GetResumeInterruptFlag(peripheralBase) ( \
    (uint8_t)(USB_ISTAT_REG(peripheralBase) & USB_ISTAT_RESUME_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetSuspendInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Returnes the Suspend interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_GetSuspendInterruptFlag(peripheralBase) ( \
    (uint8_t)(USB_ISTAT_REG(peripheralBase) & USB_ISTAT_SLEEP_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetTokenDoneInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Returnes the Token done interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_GetTokenDoneInterruptFlag(peripheralBase) ( \
    (uint8_t)(USB_ISTAT_REG(peripheralBase) & USB_ISTAT_TOKDNE_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetSofInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Returnes the Sof interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_GetSofInterruptFlag(peripheralBase) ( \
    (uint8_t)(USB_ISTAT_REG(peripheralBase) & USB_ISTAT_SOFTOK_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetErrorInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Returnes the Error interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_GetErrorInterruptFlag(peripheralBase) ( \
    (uint8_t)(USB_ISTAT_REG(peripheralBase) & USB_ISTAT_ERROR_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetBusResetInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Returnes the Bus reset interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_GetBusResetInterruptFlag(peripheralBase) ( \
    (uint8_t)(USB_ISTAT_REG(peripheralBase) & USB_ISTAT_USBRST_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- ClearStallInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Clears the Stall interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_ClearStallInterruptFlag(peripheralBase) ( \
    USB_ISTAT_REG(peripheralBase) = \
     USB_ISTAT_STALL_MASK \
  )

/* ----------------------------------------------------------------------------
   -- ClearAttachInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Clears the Attach interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_ClearAttachInterruptFlag(peripheralBase) ( \
    USB_ISTAT_REG(peripheralBase) = \
     USB_ISTAT_ATTACH_MASK \
  )

/* ----------------------------------------------------------------------------
   -- ClearResumeInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Clears the Resume interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_ClearResumeInterruptFlag(peripheralBase) ( \
    USB_ISTAT_REG(peripheralBase) = \
     USB_ISTAT_RESUME_MASK \
  )

/* ----------------------------------------------------------------------------
   -- ClearSuspendInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Clears the Suspend interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_ClearSuspendInterruptFlag(peripheralBase) ( \
    USB_ISTAT_REG(peripheralBase) = \
     USB_ISTAT_SLEEP_MASK \
  )

/* ----------------------------------------------------------------------------
   -- ClearTokenDoneInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Clears the Token done interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_ClearTokenDoneInterruptFlag(peripheralBase) ( \
    USB_ISTAT_REG(peripheralBase) = \
     USB_ISTAT_TOKDNE_MASK \
  )

/* ----------------------------------------------------------------------------
   -- ClearSofInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Clears the Sof interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_ClearSofInterruptFlag(peripheralBase) ( \
    USB_ISTAT_REG(peripheralBase) = \
     USB_ISTAT_SOFTOK_MASK \
  )

/* ----------------------------------------------------------------------------
   -- ClearErrorInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Clears the Error interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_ClearErrorInterruptFlag(peripheralBase) ( \
    USB_ISTAT_REG(peripheralBase) = \
     USB_ISTAT_ERROR_MASK \
  )

/* ----------------------------------------------------------------------------
   -- ClearBusResetInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Clears the Bus reset interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_ClearBusResetInterruptFlag(peripheralBase) ( \
    USB_ISTAT_REG(peripheralBase) = \
     USB_ISTAT_USBRST_MASK \
  )

/* ----------------------------------------------------------------------------
   -- GetUsbInterruptMask
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the Usb interrupt enable register.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_GetUsbInterruptMask(peripheralBase) ( \
    USB_INTEN_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- SetUsbInterruptMask
   ---------------------------------------------------------------------------- */

/**
 * Enables interrupts defined by the Mask parameter.
 * @param peripheralBase Peripheral base address.
 * @param Mask Interrupt mask.
 */
#define USB_PDD_SetUsbInterruptMask(peripheralBase, Mask) ( \
    USB_INTEN_REG(peripheralBase) = \
     (uint8_t)(Mask) \
  )

/* ----------------------------------------------------------------------------
   -- EnableStallInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables the Stall interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_EnableStallInterrupt(peripheralBase) ( \
    USB_INTEN_REG(peripheralBase) |= \
     USB_INTEN_STALLEN_MASK \
  )

/* ----------------------------------------------------------------------------
   -- EnableAttachInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables the Attach interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_EnableAttachInterrupt(peripheralBase) ( \
    USB_INTEN_REG(peripheralBase) |= \
     USB_INTEN_ATTACHEN_MASK \
  )

/* ----------------------------------------------------------------------------
   -- EnableResumeInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables the Reume interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_EnableResumeInterrupt(peripheralBase) ( \
    USB_INTEN_REG(peripheralBase) |= \
     USB_INTEN_RESUMEEN_MASK \
  )

/* ----------------------------------------------------------------------------
   -- EnableSuspendInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables the Suspend  interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_EnableSuspendInterrupt(peripheralBase) ( \
    USB_INTEN_REG(peripheralBase) |= \
     USB_INTEN_SLEEPEN_MASK \
  )

/* ----------------------------------------------------------------------------
   -- EnableTokenDoneInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables the Token done interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_EnableTokenDoneInterrupt(peripheralBase) ( \
    USB_INTEN_REG(peripheralBase) |= \
     USB_INTEN_TOKDNEEN_MASK \
  )

/* ----------------------------------------------------------------------------
   -- EnableSofInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables the Sof interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_EnableSofInterrupt(peripheralBase) ( \
    USB_INTEN_REG(peripheralBase) |= \
     USB_INTEN_SOFTOKEN_MASK \
  )

/* ----------------------------------------------------------------------------
   -- EnableErrorInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables the Error interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_EnableErrorInterrupt(peripheralBase) ( \
    USB_INTEN_REG(peripheralBase) |= \
     USB_INTEN_ERROREN_MASK \
  )

/* ----------------------------------------------------------------------------
   -- EnableBusResetInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables the Bus reset interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_EnableBusResetInterrupt(peripheralBase) ( \
    USB_INTEN_REG(peripheralBase) |= \
     USB_INTEN_USBRSTEN_MASK \
  )

/* ----------------------------------------------------------------------------
   -- DisableStallInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables the Stall interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_DisableStallInterrupt(peripheralBase) ( \
    USB_INTEN_REG(peripheralBase) &= \
     (uint8_t)(~(uint8_t)USB_INTEN_STALLEN_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- DisableAttachInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables the Attach interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_DisableAttachInterrupt(peripheralBase) ( \
    USB_INTEN_REG(peripheralBase) &= \
     (uint8_t)(~(uint8_t)USB_INTEN_ATTACHEN_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- DisableResumeInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables the Resume interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_DisableResumeInterrupt(peripheralBase) ( \
    USB_INTEN_REG(peripheralBase) &= \
     (uint8_t)(~(uint8_t)USB_INTEN_RESUMEEN_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- DisableSuspendInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables the Suspend interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_DisableSuspendInterrupt(peripheralBase) ( \
    USB_INTEN_REG(peripheralBase) &= \
     (uint8_t)(~(uint8_t)USB_INTEN_SLEEPEN_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- DisableTokenDoneInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables the Token done interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_DisableTokenDoneInterrupt(peripheralBase) ( \
    USB_INTEN_REG(peripheralBase) &= \
     (uint8_t)(~(uint8_t)USB_INTEN_TOKDNEEN_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- DisableSofInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables the Sof interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_DisableSofInterrupt(peripheralBase) ( \
    USB_INTEN_REG(peripheralBase) &= \
     (uint8_t)(~(uint8_t)USB_INTEN_SOFTOKEN_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- DisableErrorInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables the Error interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_DisableErrorInterrupt(peripheralBase) ( \
    USB_INTEN_REG(peripheralBase) &= \
     (uint8_t)(~(uint8_t)USB_INTEN_ERROREN_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- DisableBusResetInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables the Bus reset interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_DisableBusResetInterrupt(peripheralBase) ( \
    USB_INTEN_REG(peripheralBase) &= \
     (uint8_t)(~(uint8_t)USB_INTEN_USBRSTEN_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetErrorsInterruptFlags
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the Error interrupt status register.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_GetErrorsInterruptFlags(peripheralBase) ( \
    USB_ERRSTAT_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- ClearErrorsInterruptFlags
   ---------------------------------------------------------------------------- */

/**
 * Clears flags defined by the Mask parameter.
 * @param peripheralBase Peripheral base address.
 * @param Mask Interrupt mask.
 */
#define USB_PDD_ClearErrorsInterruptFlags(peripheralBase, Mask) ( \
    USB_ERRSTAT_REG(peripheralBase) = \
     (uint8_t)(Mask) \
  )

/* ----------------------------------------------------------------------------
   -- GetBtsErrInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Returns the BTS error interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_GetBtsErrInterruptFlag(peripheralBase) ( \
    (uint8_t)(USB_ERRSTAT_REG(peripheralBase) & USB_ERRSTAT_BTSERR_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetDmaErrInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Returns the DMA error interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_GetDmaErrInterruptFlag(peripheralBase) ( \
    (uint8_t)(USB_ERRSTAT_REG(peripheralBase) & USB_ERRSTAT_DMAERR_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetBtoErrInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Returns the BTO error interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_GetBtoErrInterruptFlag(peripheralBase) ( \
    (uint8_t)(USB_ERRSTAT_REG(peripheralBase) & USB_ERRSTAT_BTOERR_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetDnf8ErrInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Returns the DNF8 error interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_GetDnf8ErrInterruptFlag(peripheralBase) ( \
    (uint8_t)(USB_ERRSTAT_REG(peripheralBase) & USB_ERRSTAT_DFN8_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetCrc16ErrInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Returns the CRC16 error interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_GetCrc16ErrInterruptFlag(peripheralBase) ( \
    (uint8_t)(USB_ERRSTAT_REG(peripheralBase) & USB_ERRSTAT_CRC16_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetCrc5EofErrInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Returns the CRC5 or EOF error interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_GetCrc5EofErrInterruptFlag(peripheralBase) ( \
    (uint8_t)(USB_ERRSTAT_REG(peripheralBase) & USB_ERRSTAT_CRC5EOF_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetPidErrInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Returns the PID error interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_GetPidErrInterruptFlag(peripheralBase) ( \
    (uint8_t)(USB_ERRSTAT_REG(peripheralBase) & USB_ERRSTAT_PIDERR_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- ClearBtsErrInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Clears the BTS error interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_ClearBtsErrInterruptFlag(peripheralBase) ( \
    USB_ERRSTAT_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(USB_ERRSTAT_REG(peripheralBase) | USB_ERRSTAT_BTSERR_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_PIDERR_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_CRC5EOF_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_CRC16_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_DFN8_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_BTOERR_MASK)) & ( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_DMAERR_MASK)))))))) \
  )

/* ----------------------------------------------------------------------------
   -- ClearDmaErrInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Clears the DMA error interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_ClearDmaErrInterruptFlag(peripheralBase) ( \
    USB_ERRSTAT_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(USB_ERRSTAT_REG(peripheralBase) | USB_ERRSTAT_DMAERR_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_PIDERR_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_CRC5EOF_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_CRC16_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_DFN8_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_BTOERR_MASK)) & ( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_BTSERR_MASK)))))))) \
  )

/* ----------------------------------------------------------------------------
   -- ClearBtoErrInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Clears the BTO error interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_ClearBtoErrInterruptFlag(peripheralBase) ( \
    USB_ERRSTAT_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(USB_ERRSTAT_REG(peripheralBase) | USB_ERRSTAT_BTOERR_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_PIDERR_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_CRC5EOF_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_CRC16_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_DFN8_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_DMAERR_MASK)) & ( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_BTSERR_MASK)))))))) \
  )

/* ----------------------------------------------------------------------------
   -- ClearDnf8ErrInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Clears the DFN8 error interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_ClearDnf8ErrInterruptFlag(peripheralBase) ( \
    USB_ERRSTAT_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(USB_ERRSTAT_REG(peripheralBase) | USB_ERRSTAT_DFN8_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_PIDERR_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_CRC5EOF_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_CRC16_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_BTOERR_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_DMAERR_MASK)) & ( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_BTSERR_MASK)))))))) \
  )

/* ----------------------------------------------------------------------------
   -- ClearCrc16ErrInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Clears the CRC16 error interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_ClearCrc16ErrInterruptFlag(peripheralBase) ( \
    USB_ERRSTAT_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(USB_ERRSTAT_REG(peripheralBase) | USB_ERRSTAT_CRC16_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_PIDERR_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_CRC5EOF_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_DFN8_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_BTOERR_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_DMAERR_MASK)) & ( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_BTSERR_MASK)))))))) \
  )

/* ----------------------------------------------------------------------------
   -- ClearCrc5EofErrInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Clears the CRC5 or EOF error interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_ClearCrc5EofErrInterruptFlag(peripheralBase) ( \
    USB_ERRSTAT_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(USB_ERRSTAT_REG(peripheralBase) | USB_ERRSTAT_CRC5EOF_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_PIDERR_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_CRC16_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_DFN8_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_BTOERR_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_DMAERR_MASK)) & ( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_BTSERR_MASK)))))))) \
  )

/* ----------------------------------------------------------------------------
   -- ClearPidErrInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Clears the PID error interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_ClearPidErrInterruptFlag(peripheralBase) ( \
    USB_ERRSTAT_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(USB_ERRSTAT_REG(peripheralBase) | USB_ERRSTAT_PIDERR_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_CRC5EOF_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_CRC16_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_DFN8_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_BTOERR_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_DMAERR_MASK)) & ( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_BTSERR_MASK)))))))) \
  )

/* ----------------------------------------------------------------------------
   -- GetErrorInterruptMask
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the Error interrupt enable register.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_GetErrorInterruptMask(peripheralBase) ( \
    USB_ERREN_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- SetErrorInterruptMask
   ---------------------------------------------------------------------------- */

/**
 * Enables interrupts defined by the Mask parameter.
 * @param peripheralBase Peripheral base address.
 * @param Mask Interrupt mask.
 */
#define USB_PDD_SetErrorInterruptMask(peripheralBase, Mask) ( \
    USB_ERREN_REG(peripheralBase) = \
     (uint8_t)(Mask) \
  )

/* ----------------------------------------------------------------------------
   -- EnableBtsErrInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables the BTS error interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_EnableBtsErrInterrupt(peripheralBase) ( \
    USB_ERRSTAT_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(USB_ERRSTAT_REG(peripheralBase) | USB_ERRSTAT_BTSERR_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_PIDERR_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_CRC5EOF_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_CRC16_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_DFN8_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_BTOERR_MASK)) & ( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_DMAERR_MASK)))))))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableDmaErrInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables the DMA error interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_EnableDmaErrInterrupt(peripheralBase) ( \
    USB_ERRSTAT_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(USB_ERRSTAT_REG(peripheralBase) | USB_ERRSTAT_DMAERR_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_PIDERR_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_CRC5EOF_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_CRC16_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_DFN8_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_BTOERR_MASK)) & ( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_BTSERR_MASK)))))))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableBtoErrInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables the BTO error interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_EnableBtoErrInterrupt(peripheralBase) ( \
    USB_ERRSTAT_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(USB_ERRSTAT_REG(peripheralBase) | USB_ERRSTAT_BTOERR_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_PIDERR_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_CRC5EOF_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_CRC16_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_DFN8_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_DMAERR_MASK)) & ( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_BTSERR_MASK)))))))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableDnf8ErrInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables the DNF8 error interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_EnableDnf8ErrInterrupt(peripheralBase) ( \
    USB_ERRSTAT_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(USB_ERRSTAT_REG(peripheralBase) | USB_ERRSTAT_DFN8_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_PIDERR_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_CRC5EOF_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_CRC16_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_BTOERR_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_DMAERR_MASK)) & ( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_BTSERR_MASK)))))))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableCrc16ErrInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables the CRC16 error interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_EnableCrc16ErrInterrupt(peripheralBase) ( \
    USB_ERRSTAT_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(USB_ERRSTAT_REG(peripheralBase) | USB_ERRSTAT_CRC16_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_PIDERR_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_CRC5EOF_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_DFN8_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_BTOERR_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_DMAERR_MASK)) & ( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_BTSERR_MASK)))))))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableCrc5EofErrInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables the CRC5 or EOF error interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_EnableCrc5EofErrInterrupt(peripheralBase) ( \
    USB_ERRSTAT_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(USB_ERRSTAT_REG(peripheralBase) | USB_ERRSTAT_CRC5EOF_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_PIDERR_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_CRC16_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_DFN8_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_BTOERR_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_DMAERR_MASK)) & ( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_BTSERR_MASK)))))))) \
  )

/* ----------------------------------------------------------------------------
   -- EnablePidErrInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables the PID error interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_EnablePidErrInterrupt(peripheralBase) ( \
    USB_ERRSTAT_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(USB_ERRSTAT_REG(peripheralBase) | USB_ERRSTAT_PIDERR_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_CRC5EOF_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_CRC16_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_DFN8_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_BTOERR_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_DMAERR_MASK)) & ( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_BTSERR_MASK)))))))) \
  )

/* ----------------------------------------------------------------------------
   -- DisableBtsErrInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables the BTS error interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_DisableBtsErrInterrupt(peripheralBase) ( \
    USB_ERRSTAT_REG(peripheralBase) &= \
     (uint8_t)(( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_BTSERR_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_PIDERR_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_CRC5EOF_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_CRC16_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_DFN8_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_BTOERR_MASK)) & ( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_DMAERR_MASK)))))))) \
  )

/* ----------------------------------------------------------------------------
   -- DisableDmaErrInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables the DMA error interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_DisableDmaErrInterrupt(peripheralBase) ( \
    USB_ERRSTAT_REG(peripheralBase) &= \
     (uint8_t)(( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_DMAERR_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_PIDERR_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_CRC5EOF_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_CRC16_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_DFN8_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_BTOERR_MASK)) & ( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_BTSERR_MASK)))))))) \
  )

/* ----------------------------------------------------------------------------
   -- DisableBtoErrInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables the BTO error interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_DisableBtoErrInterrupt(peripheralBase) ( \
    USB_ERRSTAT_REG(peripheralBase) &= \
     (uint8_t)(( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_BTOERR_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_PIDERR_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_CRC5EOF_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_CRC16_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_DFN8_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_DMAERR_MASK)) & ( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_BTSERR_MASK)))))))) \
  )

/* ----------------------------------------------------------------------------
   -- DisableDnf8ErrInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables the DNF8 error interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_DisableDnf8ErrInterrupt(peripheralBase) ( \
    USB_ERRSTAT_REG(peripheralBase) &= \
     (uint8_t)(( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_DFN8_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_PIDERR_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_CRC5EOF_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_CRC16_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_BTOERR_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_DMAERR_MASK)) & ( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_BTSERR_MASK)))))))) \
  )

/* ----------------------------------------------------------------------------
   -- DisableCrc16ErrInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables the CRC16 error interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_DisableCrc16ErrInterrupt(peripheralBase) ( \
    USB_ERRSTAT_REG(peripheralBase) &= \
     (uint8_t)(( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_CRC16_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_PIDERR_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_CRC5EOF_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_DFN8_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_BTOERR_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_DMAERR_MASK)) & ( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_BTSERR_MASK)))))))) \
  )

/* ----------------------------------------------------------------------------
   -- DisableCrc5EofErrInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables the CRC5 or EOF error interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_DisableCrc5EofErrInterrupt(peripheralBase) ( \
    USB_ERRSTAT_REG(peripheralBase) &= \
     (uint8_t)(( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_CRC5EOF_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_PIDERR_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_CRC16_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_DFN8_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_BTOERR_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_DMAERR_MASK)) & ( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_BTSERR_MASK)))))))) \
  )

/* ----------------------------------------------------------------------------
   -- DisablePidErrInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables the PID error interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_DisablePidErrInterrupt(peripheralBase) ( \
    USB_ERRSTAT_REG(peripheralBase) &= \
     (uint8_t)(( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_PIDERR_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_CRC5EOF_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_CRC16_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_DFN8_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_BTOERR_MASK)) & (( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_DMAERR_MASK)) & ( \
      (uint8_t)(~(uint8_t)USB_ERRSTAT_BTSERR_MASK)))))))) \
  )

/* ----------------------------------------------------------------------------
   -- ReadOtgStstusReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the Otg status register.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_ReadOtgStstusReg(peripheralBase) ( \
    USB_OTGSTAT_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- GetLineStateStableState
   ---------------------------------------------------------------------------- */

/**
 * Returns the value of the Line stable bit.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_GetLineStateStableState(peripheralBase) ( \
    (uint8_t)(USB_OTGSTAT_REG(peripheralBase) & USB_OTGSTAT_LINESTATESTABLE_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- ReadOtgControlReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the Otg control register.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_ReadOtgControlReg(peripheralBase) ( \
    USB_OTGCTL_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteOtgControlReg
   ---------------------------------------------------------------------------- */

/**
 * Writes Value to the Otg control register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value written to the Otg control register.
 */
#define USB_PDD_WriteOtgControlReg(peripheralBase, Value) ( \
    USB_OTGCTL_REG(peripheralBase) = \
     (uint8_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- EnableDpPullUp
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables D+ pull up.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state.
 */
#define USB_PDD_EnableDpPullUp(peripheralBase, State) ( \
    USB_OTGCTL_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(USB_OTGCTL_REG(peripheralBase) & (uint8_t)(~(uint8_t)USB_OTGCTL_DPHIGH_MASK))) | ( \
      (uint8_t)((uint8_t)(State) << USB_OTGCTL_DPHIGH_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableDpPullDown
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables D+ pull down.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state.
 */
#define USB_PDD_EnableDpPullDown(peripheralBase, State) ( \
    USB_OTGCTL_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(USB_OTGCTL_REG(peripheralBase) & (uint8_t)(~(uint8_t)USB_OTGCTL_DPLOW_MASK))) | ( \
      (uint8_t)((uint8_t)(State) << USB_OTGCTL_DPLOW_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableDmPullDown
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables D- pull up.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state.
 */
#define USB_PDD_EnableDmPullDown(peripheralBase, State) ( \
    USB_OTGCTL_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(USB_OTGCTL_REG(peripheralBase) & (uint8_t)(~(uint8_t)USB_OTGCTL_DMLOW_MASK))) | ( \
      (uint8_t)((uint8_t)(State) << USB_OTGCTL_DMLOW_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableVBUS
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables VBUS.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state.
 */
#define USB_PDD_EnableVBUS(peripheralBase, State) ( \
    USB_OTGCTL_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(USB_OTGCTL_REG(peripheralBase) & (uint8_t)(~(uint8_t)USB_OTGCTL__MASK))) | ( \
      (uint8_t)((uint8_t)(State) << USB_OTGCTL__SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableOtgTermination
   ---------------------------------------------------------------------------- */

/**
 * Enables OTG termination.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state.
 */
#define USB_PDD_EnableOtgTermination(peripheralBase, State) ( \
    USB_OTGCTL_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(USB_OTGCTL_REG(peripheralBase) & (uint8_t)(~(uint8_t)USB_OTGCTL_OTGEN_MASK))) | ( \
      (uint8_t)((uint8_t)(State) << USB_OTGCTL_OTGEN_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableVbusCharge
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables VBus charge.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state.
 */
#define USB_PDD_EnableVbusCharge(peripheralBase, State) ( \
    USB_OTGCTL_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(USB_OTGCTL_REG(peripheralBase) & (uint8_t)(~(uint8_t)((uint8_t)0x1U << 1U)))) | ( \
      (uint8_t)((uint8_t)(State) << 1U))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableVbusDischarge
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables VBus discharge.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state.
 */
#define USB_PDD_EnableVbusDischarge(peripheralBase, State) ( \
    USB_OTGCTL_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(USB_OTGCTL_REG(peripheralBase) & (uint8_t)(~(uint8_t)0x1U))) | ( \
      (uint8_t)(State))) \
  )

/* ----------------------------------------------------------------------------
   -- SetDeviceModeFullSpeedTermination
   ---------------------------------------------------------------------------- */

/**
 * Sets full speed device termination.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_SetDeviceModeFullSpeedTermination(peripheralBase) ( \
    USB_OTGCTL_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(( \
       USB_OTGCTL_REG(peripheralBase)) | (( \
       USB_OTGCTL_DPHIGH_MASK) | ( \
       USB_OTGCTL_OTGEN_MASK)))) & (( \
      (uint8_t)(~(uint8_t)USB_OTGCTL_DPLOW_MASK)) & ( \
      (uint8_t)(~(uint8_t)USB_OTGCTL_DMLOW_MASK)))) \
  )

/* ----------------------------------------------------------------------------
   -- SetHostModeTermination
   ---------------------------------------------------------------------------- */

/**
 * Sets full speed host termination.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_SetHostModeTermination(peripheralBase) ( \
    USB_OTGCTL_REG(peripheralBase) = \
     0x34U \
  )

/* ----------------------------------------------------------------------------
   -- SetNoTermination
   ---------------------------------------------------------------------------- */

/**
 * Disables all pull resistors.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_SetNoTermination(peripheralBase) ( \
    USB_OTGCTL_REG(peripheralBase) = \
     0x4U \
  )

/* ----------------------------------------------------------------------------
   -- ReadStatusReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the Status register.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_ReadStatusReg(peripheralBase) ( \
    USB_STAT_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- GetTransmitIndicator
   ---------------------------------------------------------------------------- */

/**
 * Returns the value of the TX bit in the Status register.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_GetTransmitIndicator(peripheralBase) ( \
    (uint8_t)(USB_STAT_REG(peripheralBase) & USB_STAT_TX_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- ReadControlReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the Control register.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_ReadControlReg(peripheralBase) ( \
    USB_CTL_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteControlReg
   ---------------------------------------------------------------------------- */

/**
 * Writes Value to the Control register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value written to the Control register.
 */
#define USB_PDD_WriteControlReg(peripheralBase, Value) ( \
    USB_CTL_REG(peripheralBase) = \
     (uint8_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- GetBusSpeed
   ---------------------------------------------------------------------------- */

/**
 * Returns current bus speed.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_GetBusSpeed(peripheralBase) ( \
    (uint8_t)(USB_CTL_REG(peripheralBase) & (uint8_t)((uint8_t)0x3U << 6U)) \
  )

/* ----------------------------------------------------------------------------
   -- GetSE0
   ---------------------------------------------------------------------------- */

/**
 * Returns state of the SEO signal.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_GetSE0(peripheralBase) ( \
    (uint8_t)(USB_CTL_REG(peripheralBase) & USB_CTL_SE0_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- EnableDevice
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables Device mode.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state.
 */
#define USB_PDD_EnableDevice(peripheralBase, State) ( \
    USB_CTL_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(USB_CTL_REG(peripheralBase) & (uint8_t)(~(uint8_t)USB_CTL_USBENSOFEN_MASK))) | ( \
      (uint8_t)(State))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableSof
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables SOF.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state.
 */
#define USB_PDD_EnableSof(peripheralBase, State) ( \
    USB_CTL_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(USB_CTL_REG(peripheralBase) & (uint8_t)(~(uint8_t)USB_CTL_USBENSOFEN_MASK))) | ( \
      (uint8_t)(State))) \
  )

/* ----------------------------------------------------------------------------
   -- ResetBdtPingPong
   ---------------------------------------------------------------------------- */

/**
 * Resets internal logic.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_ResetBdtPingPong(peripheralBase) ( \
    (USB_CTL_REG(peripheralBase) |= \
     USB_CTL_ODDRST_MASK), \
    (USB_CTL_REG(peripheralBase) &= \
     (uint8_t)(~(uint8_t)USB_CTL_ODDRST_MASK)) \
  )

/* ----------------------------------------------------------------------------
   -- StartResumeSignaling
   ---------------------------------------------------------------------------- */

/**
 * Starts/stops resume signaling.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state.
 */
#define USB_PDD_StartResumeSignaling(peripheralBase, State) ( \
    USB_CTL_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(USB_CTL_REG(peripheralBase) & (uint8_t)(~(uint8_t)USB_CTL_RESUME_MASK))) | ( \
      (uint8_t)((uint8_t)(State) << USB_CTL_RESUME_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- GetResumeSignalState
   ---------------------------------------------------------------------------- */

/**
 * Returns state of resume enable bit.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_GetResumeSignalState(peripheralBase) ( \
    (uint8_t)(USB_CTL_REG(peripheralBase) & USB_CTL_RESUME_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- EnableHost
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables Host mode.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state.
 */
#define USB_PDD_EnableHost(peripheralBase, State) ( \
    USB_CTL_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(USB_CTL_REG(peripheralBase) & (uint8_t)(~(uint8_t)USB_CTL_HOSTMODEEN_MASK))) | ( \
      (uint8_t)((uint8_t)(State) << USB_CTL_HOSTMODEEN_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- StartResetSignaling
   ---------------------------------------------------------------------------- */

/**
 * Starts/stops reset signaling.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state.
 */
#define USB_PDD_StartResetSignaling(peripheralBase, State) ( \
    USB_CTL_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(USB_CTL_REG(peripheralBase) & (uint8_t)(~(uint8_t)USB_CTL_RESET_MASK))) | ( \
      (uint8_t)((uint8_t)(State) << USB_CTL_RESET_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- GetResetSignalState
   ---------------------------------------------------------------------------- */

/**
 * Returns state of reset enable bit.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_GetResetSignalState(peripheralBase) ( \
    (uint8_t)(USB_CTL_REG(peripheralBase) & USB_CTL_RESET_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- ClearTxSuspendFlag
   ---------------------------------------------------------------------------- */

/**
 * Clears TxSuspend flag.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_ClearTxSuspendFlag(peripheralBase) ( \
    USB_CTL_REG(peripheralBase) &= \
     (uint8_t)(~(uint8_t)USB_CTL_TXSUSPENDTOKENBUSY_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- ClearTokenBusyFlag
   ---------------------------------------------------------------------------- */

/**
 * Clears TokenBusy flag.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_ClearTokenBusyFlag(peripheralBase) ( \
    USB_CTL_REG(peripheralBase) &= \
     (uint8_t)(~(uint8_t)USB_CTL_TXSUSPENDTOKENBUSY_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetTokenBusyFlag
   ---------------------------------------------------------------------------- */

/**
 * Returns state of TokenBusy flag.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_GetTokenBusyFlag(peripheralBase) ( \
    (uint8_t)(USB_CTL_REG(peripheralBase) & USB_CTL_TXSUSPENDTOKENBUSY_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- DisableModule
   ---------------------------------------------------------------------------- */

/**
 * Disables module.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_DisableModule(peripheralBase) ( \
    USB_CTL_REG(peripheralBase) = \
     0U \
  )

/* ----------------------------------------------------------------------------
   -- ReadAddressReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the Address register.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_ReadAddressReg(peripheralBase) ( \
    USB_ADDR_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteAddressReg
   ---------------------------------------------------------------------------- */

/**
 * Writes Value to the Address register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value written to the Address register.
 */
#define USB_PDD_WriteAddressReg(peripheralBase, Value) ( \
    USB_ADDR_REG(peripheralBase) = \
     (uint8_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- EnableLowSpeed
   ---------------------------------------------------------------------------- */

/**
 * Enables low speed mode.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state.
 */
#define USB_PDD_EnableLowSpeed(peripheralBase, State) ( \
    USB_ADDR_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(USB_ADDR_REG(peripheralBase) & (uint8_t)(~(uint8_t)USB_ADDR_LSEN_MASK))) | ( \
      (uint8_t)((uint8_t)(State) << USB_ADDR_LSEN_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- SetDeviceAddress
   ---------------------------------------------------------------------------- */

/**
 * Sets device address.
 * @param peripheralBase Peripheral base address.
 * @param Address New device address.
 */
#define USB_PDD_SetDeviceAddress(peripheralBase, Address) ( \
    USB_ADDR_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(USB_ADDR_REG(peripheralBase) & (uint8_t)(~(uint8_t)USB_ADDR_ADDR_MASK))) | ( \
      (uint8_t)(Address))) \
  )

/* ----------------------------------------------------------------------------
   -- GetFrameNumberHigh
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the Frame number high register.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_GetFrameNumberHigh(peripheralBase) ( \
    USB_FRMNUMH_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- SetFrameNumberHigh
   ---------------------------------------------------------------------------- */

/**
 * Writes Data to the Frame number high register.
 * @param peripheralBase Peripheral base address.
 * @param Data Value written to the high part of the Frame number register.
 */
#define USB_PDD_SetFrameNumberHigh(peripheralBase, Data) ( \
    USB_FRMNUMH_REG(peripheralBase) = \
     (uint8_t)(Data) \
  )

/* ----------------------------------------------------------------------------
   -- GetFrameNumberLow
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the Frame number low register.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_GetFrameNumberLow(peripheralBase) ( \
    USB_FRMNUML_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- SetFrameNumberLow
   ---------------------------------------------------------------------------- */

/**
 * Writes Data to the Frame number low register.
 * @param peripheralBase Peripheral base address.
 * @param Data Value written to the low part of the Frame number register.
 */
#define USB_PDD_SetFrameNumberLow(peripheralBase, Data) ( \
    USB_FRMNUML_REG(peripheralBase) = \
     (uint8_t)(Data) \
  )

/* ----------------------------------------------------------------------------
   -- ReadTokenReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the Token register.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_ReadTokenReg(peripheralBase) ( \
    USB_TOKEN_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteTokenReg
   ---------------------------------------------------------------------------- */

/**
 * Writes Data to the Token register.
 * @param peripheralBase Peripheral base address.
 * @param Data Value written to the Token register.
 */
#define USB_PDD_WriteTokenReg(peripheralBase, Data) ( \
    USB_TOKEN_REG(peripheralBase) = \
     (uint8_t)(Data) \
  )

/* ----------------------------------------------------------------------------
   -- ReadSofTresholdReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the Sof treshold register.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_ReadSofTresholdReg(peripheralBase) ( \
    USB_SOFTHLD_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- SetSofTresholdReg
   ---------------------------------------------------------------------------- */

/**
 * Writes Data to the Sof theshold register.
 * @param peripheralBase Peripheral base address.
 * @param Data Value written to the Sof treshold register.
 */
#define USB_PDD_SetSofTresholdReg(peripheralBase, Data) ( \
    USB_SOFTHLD_REG(peripheralBase) = \
     (uint8_t)(Data) \
  )

/* ----------------------------------------------------------------------------
   -- ReadEp0CtrlReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the EP0 control register.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_ReadEp0CtrlReg(peripheralBase) ( \
    USB_ENDPT_REG(peripheralBase,0U) \
  )

/* ----------------------------------------------------------------------------
   -- WriteEp0CtrlReg
   ---------------------------------------------------------------------------- */

/**
 * Writes Data to the EP0 control register.
 * @param peripheralBase Peripheral base address.
 * @param Data Value written to the EP0 control register.
 */
#define USB_PDD_WriteEp0CtrlReg(peripheralBase, Data) ( \
    USB_ENDPT_REG(peripheralBase,0U) = \
     (uint8_t)(Data) \
  )

/* ----------------------------------------------------------------------------
   -- GetEpCtrlRegAddr
   ---------------------------------------------------------------------------- */

/**
 * Returns the address of the EP_x register.
 * @param peripheralBase Peripheral base address.
 * @param EpNum Endpoint number.
 */
#define USB_PDD_GetEpCtrlRegAddr(peripheralBase, EpNum) ( \
    (void *)&(USB_ENDPT_REG(peripheralBase,(EpNum))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableDirectLowSpeedDevice
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables direct low speed device.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state.
 */
#define USB_PDD_EnableDirectLowSpeedDevice(peripheralBase, State) ( \
    USB_ENDPT_REG(peripheralBase,0U) = \
     (uint8_t)(( \
      (uint8_t)(( \
       USB_ENDPT_REG(peripheralBase,0U)) & ( \
       (uint8_t)(~(uint8_t)USB_ENDPT_HOSTWOHUB_MASK)))) | ( \
      (uint8_t)((uint8_t)(State) << USB_ENDPT_HOSTWOHUB_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- StallControlEP
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables Stall feature for given EP.
 * @param peripheralBase Peripheral base address.
 * @param EpNum Endpoint number.
 * @param State Requested state.
 */
#define USB_PDD_StallControlEP(peripheralBase, EpNum, State) ( \
    USB_ENDPT_REG(peripheralBase,(EpNum)) = \
     (uint8_t)(( \
      (uint8_t)(( \
       USB_ENDPT_REG(peripheralBase,(EpNum))) & ( \
       (uint8_t)(~(uint8_t)USB_ENDPT_EPSTALL_MASK)))) | ( \
      (uint8_t)((uint8_t)(State) << USB_ENDPT_EPSTALL_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableControlEP
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables Control EP.
 * @param peripheralBase Peripheral base address.
 * @param EpNum Endpoint number.
 * @param State Requested state.
 */
#define USB_PDD_EnableControlEP(peripheralBase, EpNum, State) ( \
    ((State) == PDD_DISABLE) ? ( \
      USB_ENDPT_REG(peripheralBase,(EpNum)) &= \
       (uint8_t)(( \
        (uint8_t)(~(uint8_t)USB_ENDPT_RETRYDIS_MASK)) & (( \
        (uint8_t)(~(uint8_t)USB_ENDPT_EPCTLDIS_MASK)) & (( \
        (uint8_t)(~(uint8_t)USB_ENDPT_EPRXEN_MASK)) & (( \
        (uint8_t)(~(uint8_t)USB_ENDPT_EPTXEN_MASK)) & (( \
        (uint8_t)(~(uint8_t)USB_ENDPT_EPSTALL_MASK)) & ( \
        (uint8_t)(~(uint8_t)USB_ENDPT_EPHSHK_MASK)))))))) : ( \
      USB_ENDPT_REG(peripheralBase,(EpNum)) = \
       (uint8_t)(( \
        (uint8_t)(( \
         USB_ENDPT_REG(peripheralBase,(EpNum))) & (( \
         (uint8_t)(~(uint8_t)USB_ENDPT_RETRYDIS_MASK)) & (( \
         (uint8_t)(~(uint8_t)USB_ENDPT_EPCTLDIS_MASK)) & ( \
         (uint8_t)(~(uint8_t)USB_ENDPT_EPSTALL_MASK)))))) | (( \
        USB_ENDPT_EPRXEN_MASK) | (( \
        USB_ENDPT_EPTXEN_MASK) | ( \
        USB_ENDPT_EPHSHK_MASK))))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableBulkOrIntRxEP
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables Bulk or Interrupt Rx EP.
 * @param peripheralBase Peripheral base address.
 * @param EpNum Endpoint number.
 * @param State Requested state.
 */
#define USB_PDD_EnableBulkOrIntRxEP(peripheralBase, EpNum, State) ( \
    ((State) == PDD_DISABLE) ? ( \
      USB_ENDPT_REG(peripheralBase,(EpNum)) &= \
       (uint8_t)(~(uint8_t)USB_ENDPT_EPRXEN_MASK)) : ( \
      USB_ENDPT_REG(peripheralBase,(EpNum)) = \
       (uint8_t)(( \
        (uint8_t)(( \
         USB_ENDPT_REG(peripheralBase,(EpNum))) & (( \
         (uint8_t)(~(uint8_t)USB_ENDPT_RETRYDIS_MASK)) & ( \
         (uint8_t)(~(uint8_t)USB_ENDPT_EPSTALL_MASK))))) | (( \
        USB_ENDPT_EPCTLDIS_MASK) | (( \
        USB_ENDPT_EPRXEN_MASK) | ( \
        USB_ENDPT_EPHSHK_MASK))))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableBulkOrIntTxEP
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables Bulk or Interrupt Tx EP.
 * @param peripheralBase Peripheral base address.
 * @param EpNum Endpoint number.
 * @param State Requested state.
 */
#define USB_PDD_EnableBulkOrIntTxEP(peripheralBase, EpNum, State) ( \
    ((State) == PDD_DISABLE) ? ( \
      USB_ENDPT_REG(peripheralBase,(EpNum)) &= \
       (uint8_t)(~(uint8_t)USB_ENDPT_EPTXEN_MASK)) : ( \
      USB_ENDPT_REG(peripheralBase,(EpNum)) = \
       (uint8_t)(( \
        (uint8_t)(( \
         USB_ENDPT_REG(peripheralBase,(EpNum))) & (( \
         (uint8_t)(~(uint8_t)USB_ENDPT_RETRYDIS_MASK)) & ( \
         (uint8_t)(~(uint8_t)USB_ENDPT_EPSTALL_MASK))))) | (( \
        USB_ENDPT_EPCTLDIS_MASK) | (( \
        USB_ENDPT_EPTXEN_MASK) | ( \
        USB_ENDPT_EPHSHK_MASK))))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableIsoRxEP
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables Isochronous Rx EP.
 * @param peripheralBase Peripheral base address.
 * @param EpNum Endpoint number.
 * @param State Requested state.
 */
#define USB_PDD_EnableIsoRxEP(peripheralBase, EpNum, State) ( \
    ((State) == PDD_DISABLE) ? ( \
      USB_ENDPT_REG(peripheralBase,(EpNum)) &= \
       (uint8_t)(~(uint8_t)USB_ENDPT_EPRXEN_MASK)) : ( \
      USB_ENDPT_REG(peripheralBase,(EpNum)) = \
       (uint8_t)(( \
        (uint8_t)(( \
         USB_ENDPT_REG(peripheralBase,(EpNum))) & (( \
         (uint8_t)(~(uint8_t)USB_ENDPT_RETRYDIS_MASK)) & (( \
         (uint8_t)(~(uint8_t)USB_ENDPT_EPSTALL_MASK)) & ( \
         (uint8_t)(~(uint8_t)USB_ENDPT_EPHSHK_MASK)))))) | (( \
        USB_ENDPT_EPCTLDIS_MASK) | ( \
        USB_ENDPT_EPRXEN_MASK)))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableIsoTxEP
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables Isochronous Tx EP.
 * @param peripheralBase Peripheral base address.
 * @param EpNum Endpoint number.
 * @param State Requested state.
 */
#define USB_PDD_EnableIsoTxEP(peripheralBase, EpNum, State) ( \
    ((State) == PDD_DISABLE) ? ( \
      USB_ENDPT_REG(peripheralBase,(EpNum)) &= \
       (uint8_t)(~(uint8_t)USB_ENDPT_EPTXEN_MASK)) : ( \
      USB_ENDPT_REG(peripheralBase,(EpNum)) = \
       (uint8_t)(( \
        (uint8_t)(( \
         USB_ENDPT_REG(peripheralBase,(EpNum))) & (( \
         (uint8_t)(~(uint8_t)USB_ENDPT_HOSTWOHUB_MASK)) & (( \
         (uint8_t)(~(uint8_t)USB_ENDPT_RETRYDIS_MASK)) & (( \
         (uint8_t)(~(uint8_t)USB_ENDPT_EPSTALL_MASK)) & ( \
         (uint8_t)(~(uint8_t)USB_ENDPT_EPHSHK_MASK))))))) | (( \
        USB_ENDPT_EPCTLDIS_MASK) | ( \
        USB_ENDPT_EPTXEN_MASK)))) \
  )

/* ----------------------------------------------------------------------------
   -- DisableRxEP
   ---------------------------------------------------------------------------- */

/**
 * Disables Rx EP.
 * @param peripheralBase Peripheral base address.
 * @param EpNum Endpoint number.
 */
#define USB_PDD_DisableRxEP(peripheralBase, EpNum) ( \
    USB_ENDPT_REG(peripheralBase,(EpNum)) &= \
     (uint8_t)(~(uint8_t)USB_ENDPT_EPRXEN_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- DisableTxEP
   ---------------------------------------------------------------------------- */

/**
 * Disables Tx EP.
 * @param peripheralBase Peripheral base address.
 * @param EpNum Endpoint number.
 */
#define USB_PDD_DisableTxEP(peripheralBase, EpNum) ( \
    USB_ENDPT_REG(peripheralBase,(EpNum)) &= \
     (uint8_t)(~(uint8_t)USB_ENDPT_EPTXEN_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- ReadUsbControlReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the USB control register.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_ReadUsbControlReg(peripheralBase) ( \
    USB_USBCTRL_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteUsbControlReg
   ---------------------------------------------------------------------------- */

/**
 * Writes Value to the Usb control register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value written to the Usb control register.
 */
#define USB_PDD_WriteUsbControlReg(peripheralBase, Value) ( \
    USB_USBCTRL_REG(peripheralBase) = \
     (uint8_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- SuspendTransceiver
   ---------------------------------------------------------------------------- */

/**
 * Suspends/Wakes up transceiver.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state.
 */
#define USB_PDD_SuspendTransceiver(peripheralBase, State) ( \
    USB_USBCTRL_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(USB_USBCTRL_REG(peripheralBase) & (uint8_t)(~(uint8_t)USB_USBCTRL_SUSP_MASK))) | ( \
      (uint8_t)((uint8_t)(State) << USB_USBCTRL_SUSP_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableWeakPullDowns
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables week pull downs.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state.
 */
#define USB_PDD_EnableWeakPullDowns(peripheralBase, State) ( \
    USB_USBCTRL_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(USB_USBCTRL_REG(peripheralBase) & (uint8_t)(~(uint8_t)USB_USBCTRL_PDE_MASK))) | ( \
      (uint8_t)((uint8_t)(State) << USB_USBCTRL_PDE_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- ReadOtgSignalObserveReg
   ---------------------------------------------------------------------------- */

/**
 * Returns content of the Otg observe register.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_ReadOtgSignalObserveReg(peripheralBase) ( \
    USB_OBSERVE_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteOtgSignalObservelReg
   ---------------------------------------------------------------------------- */

/**
 * Writes Value to the OTG observe register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value written to the Otg observel register.
 */
#define USB_PDD_WriteOtgSignalObservelReg(peripheralBase, Value) ( \
    USB_OBSERVE_REG(peripheralBase) = \
     (uint8_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- GetDpPullUpSignalState
   ---------------------------------------------------------------------------- */

/**
 * Returns state of the D+ pull up signal.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_GetDpPullUpSignalState(peripheralBase) ( \
    (uint8_t)(USB_OBSERVE_REG(peripheralBase) & USB_OBSERVE_DPPU_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetDpPullDownSignalState
   ---------------------------------------------------------------------------- */

/**
 * Returns state of the D+ pull down signal.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_GetDpPullDownSignalState(peripheralBase) ( \
    (uint8_t)(USB_OBSERVE_REG(peripheralBase) & USB_OBSERVE_DPPD_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetDmPullDownSignalState
   ---------------------------------------------------------------------------- */

/**
 * Returns state of the D- pull up signal.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_GetDmPullDownSignalState(peripheralBase) ( \
    (uint8_t)(USB_OBSERVE_REG(peripheralBase) & USB_OBSERVE_DMPD_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- ReadOtgSignalControlReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the Otg control register.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_ReadOtgSignalControlReg(peripheralBase) ( \
    USB_CONTROL_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteOtgSignalControlReg
   ---------------------------------------------------------------------------- */

/**
 * Writes Value to the OTG control register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value written to the Otg control register.
 */
#define USB_PDD_WriteOtgSignalControlReg(peripheralBase, Value) ( \
    USB_CONTROL_REG(peripheralBase) = \
     (uint8_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadTransceiverControlReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the Transceiver control register.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_ReadTransceiverControlReg(peripheralBase) ( \
    USB_USBTRC0_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteTransceiverControlReg
   ---------------------------------------------------------------------------- */

/**
 * Writes Value to the Transceiver control register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value written to the Transceiver control register.
 */
#define USB_PDD_WriteTransceiverControlReg(peripheralBase, Value) ( \
    USB_USBTRC0_REG(peripheralBase) = \
     (uint8_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ResetModule
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MK20DZ10)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MKL24Z4)) || (defined(MCU_MKL25Z4)))
/**
 * Starts module reset.
 * @param peripheralBase Peripheral base address.
 */
  #define USB_PDD_ResetModule(peripheralBase) ( \
      USB_USBTRC0_REG(peripheralBase) |= \
       (uint8_t)(USB_USBTRC0_USBRESET_MASK | 0x40U) \
    )
#else /* (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK52D10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_PCK20L4)) */
/**
 * Starts module reset.
 * @param peripheralBase Peripheral base address.
 */
  #define USB_PDD_ResetModule(peripheralBase) ( \
      USB_USBTRC0_REG(peripheralBase) |= \
       USB_USBTRC0_USBRESET_MASK \
    )
#endif /* (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK52D10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_PCK20L4)) */

/* ----------------------------------------------------------------------------
   -- GetModuleResetPendingFlag
   ---------------------------------------------------------------------------- */

/**
 * Returns state of module reset pending flag.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_GetModuleResetPendingFlag(peripheralBase) ( \
    (uint8_t)(USB_USBTRC0_REG(peripheralBase) & USB_USBTRC0_USBRESET_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- ClearAsyncResumeInterruptFlag
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MK20DZ10)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MKL24Z4)) || (defined(MCU_MKL25Z4)))
/**
 * Clears asynchronous resume interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
  #define USB_PDD_ClearAsyncResumeInterruptFlag(peripheralBase) ( \
      USB_USBTRC0_REG(peripheralBase) |= \
       (uint8_t)(USB_USBTRC0_SYNC_DET_MASK | 0x40U) \
    )
#else /* (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK52D10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_PCK20L4)) */
/**
 * Clears asynchronous resume interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
  #define USB_PDD_ClearAsyncResumeInterruptFlag(peripheralBase) ( \
      USB_USBTRC0_REG(peripheralBase) |= \
       USB_USBTRC0_SYNC_DET_MASK \
    )
#endif /* (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK52D10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_PCK20L4)) */

/* ----------------------------------------------------------------------------
   -- EnableAsyncResumeInterrupt
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MK20DZ10)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MKL24Z4)) || (defined(MCU_MKL25Z4)))
/**
 * Enables asynchronous resume interrupt.
 * @param peripheralBase Peripheral base address.
 */
  #define USB_PDD_EnableAsyncResumeInterrupt(peripheralBase) ( \
      USB_USBTRC0_REG(peripheralBase) |= \
       (uint8_t)(USB_USBTRC0_USBRESMEN_MASK | 0x40U) \
    )
#else /* (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK52D10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_PCK20L4)) */
/**
 * Enables asynchronous resume interrupt.
 * @param peripheralBase Peripheral base address.
 */
  #define USB_PDD_EnableAsyncResumeInterrupt(peripheralBase) ( \
      USB_USBTRC0_REG(peripheralBase) |= \
       USB_USBTRC0_USBRESMEN_MASK \
    )
#endif /* (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK52D10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_PCK20L4)) */

/* ----------------------------------------------------------------------------
   -- DisableAsyncResumeInterrupt
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MK20DZ10)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MKL24Z4)) || (defined(MCU_MKL25Z4)))
/**
 * Disables asynchronous resume interrupt.
 * @param peripheralBase Peripheral base address.
 */
  #define USB_PDD_DisableAsyncResumeInterrupt(peripheralBase) ( \
      USB_USBTRC0_REG(peripheralBase) = \
       (uint8_t)(( \
        (uint8_t)(( \
         USB_USBTRC0_REG(peripheralBase)) & ( \
         (uint8_t)(~(uint8_t)USB_USBTRC0_USBRESMEN_MASK)))) | ( \
        0x40U)) \
    )
#else /* (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK52D10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_PCK20L4)) */
/**
 * Disables asynchronous resume interrupt.
 * @param peripheralBase Peripheral base address.
 */
  #define USB_PDD_DisableAsyncResumeInterrupt(peripheralBase) ( \
      USB_USBTRC0_REG(peripheralBase) &= \
       (uint8_t)(~(uint8_t)USB_USBTRC0_USBRESMEN_MASK) \
    )
#endif /* (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK52D10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_PCK20L4)) */

/* ----------------------------------------------------------------------------
   -- ReadFrameAdjustmentReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the Frame Adjustment register.
 * @param peripheralBase Peripheral base address.
 */
#define USB_PDD_ReadFrameAdjustmentReg(peripheralBase) ( \
    USB_USBFRMADJUST_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteFrameAdjustmentReg
   ---------------------------------------------------------------------------- */

/**
 * Writes Value to the Frame adjustment register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value written to the Frame adjustment register.
 */
#define USB_PDD_WriteFrameAdjustmentReg(peripheralBase, Value) ( \
    USB_USBFRMADJUST_REG(peripheralBase) = \
     (uint8_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- SetFrameAdjustment
   ---------------------------------------------------------------------------- */

/**
 * Sets frame adjustment. In Host mode, the frame adjustment is a twos
 * complement number that adjusts the period of each USB frame in 12-MHz clock periods. A
 * SOF is normally generated every 12,000 12-MHz clock cycles. The Frame Adjust
 * Register can adjust this by -128 to +127 to compensate for inaccuracies in the
 * USB 48-MHz clock. Changes to the ADJ bit take effect at the next start of the
 * next frame.
 * @param peripheralBase Peripheral base address.
 * @param Value Value written to the Frame adjustment register.
 */
#define USB_PDD_SetFrameAdjustment(peripheralBase, Value) ( \
    USB_USBFRMADJUST_REG(peripheralBase) = \
     (uint8_t)(Value) \
  )
#endif  /* #if defined(USB_PDD_H_) */

/* USB_PDD.h, eof. */
