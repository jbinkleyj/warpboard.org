/*
  PDD layer implementation for peripheral type I2S
  (C) 2010 Freescale, Inc. All rights reserved.

  This file is static and it is generated from API-Factory
*/

#if !defined(I2S_PDD_H_)
#define I2S_PDD_H_

/* ----------------------------------------------------------------------------
   -- Test if supported MCU is active
   ---------------------------------------------------------------------------- */

#if !defined(MCU_ACTIVE)
  // No MCU is active
  #error I2S PDD library: No derivative is active. Place proper #include with PDD memory map before including PDD library.
#elif \
      !defined(MCU_MK10DZ10) /* I2S0 */ && \
      !defined(MCU_MK20DZ10) /* I2S0 */ && \
      !defined(MCU_MK30DZ10) /* I2S0 */ && \
      !defined(MCU_MK40DZ10) /* I2S0 */ && \
      !defined(MCU_MK40X256VMD100) /* I2S0 */ && \
      !defined(MCU_MK50DZ10) /* I2S0 */ && \
      !defined(MCU_MK51DZ10) /* I2S0 */ && \
      !defined(MCU_MK52DZ10) /* I2S0 */ && \
      !defined(MCU_MK53DZ10) /* I2S0 */ && \
      !defined(MCU_MK60DZ10) /* I2S0 */ && \
      !defined(MCU_MK60N512VMD100) /* I2S0 */
  // Unsupported MCU is active
  #error I2S PDD library: Unsupported derivative is active.
#endif

#include "PDD_Types.h"

/* ----------------------------------------------------------------------------
   -- Method symbol definitions
   ---------------------------------------------------------------------------- */

/* Receive and transmit section masks. */
#define I2S_PDD_RECEIVER I2S_CR_RE_MASK          /**< Receive section mask. */
#define I2S_PDD_TRANSMITTER I2S_CR_TE_MASK       /**< Transmit section mask. */

/* Frame clock disable masks. */
#define I2S_PDD_RX_FRAME_CLOCK_DISABLE I2S_CR_RFRCLKDIS_MASK /**< Receive frame clock mask. */
#define I2S_PDD_TX_FRAME_CLOCK_DISABLE I2S_CR_TFRCLKDIS_MASK /**< Transmit frame clock mask. */

/* Interrupt masks for EnableDmasInterrupts, DisableDmasInterrupts, some of them
   for GetInterruptFlag, some of them for ClearInterruptFlags */
#define I2S_PDD_RX_FRAME_COMPLETE_INT I2S_ISR_RFRC_MASK /**< Receive frame complete */
#define I2S_PDD_TX_FRAME_COMPLETE_INT I2S_ISR_TRFC_MASK /**< Transmit frame complete */
#define I2S_PDD_RX_DMA_ENABLE I2S_IER_RDMAE_MASK /**< Receive DMA enable, unusable for GetInterruptFlags nor ClearInterruptFlags */
#define I2S_PDD_RECEIVER_INT I2S_IER_RIE_MASK    /**< Receive interrupt enable, unusable for GetInterruptFlags nor ClearInterruptFlags */
#define I2S_PDD_TX_DMA_ENABLE I2S_IER_TDMAE_MASK /**< Transmit DMA enable, unusable for GetInterruptFlags nor ClearInterruptFlags */
#define I2S_PDD_TRANSMITTER_INT I2S_IER_TIE_MASK /**< Transmit interrupt enable, unusable for GetInterruptFlags nor ClearInterruptFlags */
#define I2S_PDD_COMMAND_ADDRESS_UPDATE_INT I2S_ISR_CMDAU_MASK /**< Command address update, unusable for ClearInterruptFlags */
#define I2S_PDD_COMMAND_DATA_UPDATE_INT I2S_ISR_CMDDU_MASK /**< Command data update, unusable for ClearInterruptFlags */
#define I2S_PDD_RX_TAG_UPDATE_INT I2S_ISR_RXT_MASK /**< Receive tag update, unusable for ClearInterruptFlags */
#define I2S_PDD_RX_DATA_READY_1_INT I2S_ISR_RDR1_MASK /**< Receive data ready 1, unusable for ClearInterruptFlags */
#define I2S_PDD_RX_DATA_READY_0_INT I2S_ISR_RDR0_MASK /**< Receive data ready 0, unusable for ClearInterruptFlags */
#define I2S_PDD_TX_DATA_EMPTY_1_INT I2S_ISR_TDE1_MASK /**< Transmit data empty 1, unusable for ClearInterruptFlags */
#define I2S_PDD_TX_DATA_EMPTY_0_INT I2S_ISR_TDE0_MASK /**< Transmit data empty 0, unusable for ClearInterruptFlags */
#define I2S_PDD_RX_OVERRUN_1_INT I2S_ISR_ROE1_MASK /**< Receive overrun 1 */
#define I2S_PDD_RX_OVERRUN_0_INT I2S_ISR_ROE0_MASK /**< Receive overrun 0 */
#define I2S_PDD_TX_UNDERRUN_1_INT I2S_ISR_TUE1_MASK /**< Transmit underrun 1 */
#define I2S_PDD_TX_UNDERRUN_0_INT I2S_ISR_TUE0_MASK /**< Transmit underrun 0 */
#define I2S_PDD_TX_FRAME_SYNC_INT I2S_ISR_TFS_MASK /**< Transmit frame sync, unusable for ClearInterruptFlags */
#define I2S_PDD_RX_FRAME_SYNC_INT I2S_ISR_RFS_MASK /**< Recieve frame sync, unusable for ClearInterruptFlags */
#define I2S_PDD_TX_LAST_TIME_SLOT_INT I2S_ISR_TLS_MASK /**< Transmit last time slot, unusable for ClearInterruptFlags */
#define I2S_PDD_RX_LAST_TIME_SLOT_INT I2S_ISR_RLS_MASK /**< Receive last time slot, unusable for ClearInterruptFlags */
#define I2S_PDD_RX_FIFO_FULL_1_INT I2S_ISR_RFF1_MASK /**< Receive FIFO full 1, unusable for ClearInterruptFlags */
#define I2S_PDD_RX_FIFO_FULL_0_INT I2S_ISR_RFF0_MASK /**< Receive FIFO full 0, unusable for ClearInterruptFlags */
#define I2S_PDD_TX_FIFO_EMPTY_1_INT I2S_ISR_TFE1_MASK /**< Transmit FIFO empty 1, unusable for ClearInterruptFlags */
#define I2S_PDD_TX_FIFO_EMPTY_0_INT I2S_ISR_TFE0_MASK /**< Transmit FIFO empty 0, unusable for ClearInterruptFlags */
#define I2S_PDD_ALL_INT 0x1AFFFFFU               /**< All interrupt flags, unusable for ClearInterruptFlags */

/* Slot masks for EnableAC97Channels, DisableAC97Channels,
   GetAC97ChannelStatusMask */
#define I2S_PDD_AC97_DATA_SLOT_3 0x1U            /**< The 3rd data channel mask. */
#define I2S_PDD_AC97_DATA_SLOT_4 0x2U            /**< The 4th data channel mask. */
#define I2S_PDD_AC97_DATA_SLOT_5 0x4U            /**< The 5th data channel mask. */
#define I2S_PDD_AC97_DATA_SLOT_6 0x8U            /**< The 6th data channel mask. */
#define I2S_PDD_AC97_DATA_SLOT_7 0x10U           /**< The 7th data channel mask. */
#define I2S_PDD_AC97_DATA_SLOT_8 0x20U           /**< The 8th data channel mask. */
#define I2S_PDD_AC97_DATA_SLOT_9 0x40U           /**< The 9th data channel mask. */
#define I2S_PDD_AC97_DATA_SLOT_10 0x80U          /**< The 10th data channel mask. */
#define I2S_PDD_AC97_DATA_SLOT_11 0x100U         /**< The 11th data channel mask. */
#define I2S_PDD_AC97_DATA_SLOT_12 0x200U         /**< The 12th data channel mask. */

/* Clock source constants for SetClockSource. */
#define I2S_PDD_DIVIDED_CORE_SYSTEM_CLOCK 0U     /**< Divided core system clock source. */
#define I2S_PDD_DIVIDED_PLL_FLL_CLOCK 0x1U       /**< Divided PLL or FLL clock source. */
#define I2S_PDD_EXTAL_CLOCK 0x2U                 /**< Extal clock source. */
#define I2S_PDD_EXTERNAL_CLOCK 0x3U              /**< External clock source. */

/* AC97 command constant. */
#define I2S_PDD_AC97_WRITE_COMMAND 0x10U         /**< AC97 write command. */
#define I2S_PDD_AC97_READ_COMMAND 0x8U           /**< AC97 read command. */


/* ----------------------------------------------------------------------------
   -- WriteTxData0Reg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the Tx Data 0 register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value stored to the Data0 register.
 */
#define I2S_PDD_WriteTxData0Reg(peripheralBase, Value) ( \
    I2S_TX0_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- WriteTxData1Reg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the Tx Data 1 register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value stored to the Data1 register.
 */
#define I2S_PDD_WriteTxData1Reg(peripheralBase, Value) ( \
    I2S_TX1_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadRxData0Reg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the Rx Data 0 register.
 * @param peripheralBase Peripheral base address.
 */
#define I2S_PDD_ReadRxData0Reg(peripheralBase) ( \
    I2S_RX0_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- ReadRxData1Reg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the Rx Data 1 register.
 * @param peripheralBase Peripheral base address.
 */
#define I2S_PDD_ReadRxData1Reg(peripheralBase) ( \
    I2S_RX1_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- EnableReceiver
   ---------------------------------------------------------------------------- */

/**
 * Enables the receive section.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state of receive section.
 */
#define I2S_PDD_EnableReceiver(peripheralBase, State) ( \
    I2S_CR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(I2S_CR_REG(peripheralBase) & (uint32_t)(~(uint32_t)I2S_CR_RE_MASK))) | ( \
      (uint32_t)((uint32_t)(State) << I2S_CR_RE_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableTransmitter
   ---------------------------------------------------------------------------- */

/**
 * Enables the transmit section.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state of transmit section.
 */
#define I2S_PDD_EnableTransmitter(peripheralBase, State) ( \
    I2S_CR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(I2S_CR_REG(peripheralBase) & (uint32_t)(~(uint32_t)I2S_CR_TE_MASK))) | ( \
      (uint32_t)((uint32_t)(State) << I2S_CR_TE_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableRxTx
   ---------------------------------------------------------------------------- */

/**
 * Allows to enable receive and transmit section.
 * @param peripheralBase Peripheral base address.
 * @param Mask Mask of receive and transmit section to enable. Use constants
 *        from group "Receive and transmit section masks.".
 */
#define I2S_PDD_EnableRxTx(peripheralBase, Mask) ( \
    I2S_CR_REG(peripheralBase) |= \
     (uint32_t)(Mask) \
  )

/* ----------------------------------------------------------------------------
   -- DisableRxTx
   ---------------------------------------------------------------------------- */

/**
 * Allows to disable receive and transmit section.
 * @param peripheralBase Peripheral base address.
 * @param Mask Mask of receive and transmit section to enable. Use constants
 *        from group "Receive and transmit section masks.".
 */
#define I2S_PDD_DisableRxTx(peripheralBase, Mask) ( \
    I2S_CR_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)(Mask)) \
  )

/* ----------------------------------------------------------------------------
   -- EnableDevice
   ---------------------------------------------------------------------------- */

/**
 * Enables the device.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state of device.
 */
#define I2S_PDD_EnableDevice(peripheralBase, State) ( \
    I2S_CR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(I2S_CR_REG(peripheralBase) & (uint32_t)(~(uint32_t)I2S_CR_I2SEN_MASK))) | ( \
      (uint32_t)(State))) \
  )

/* ----------------------------------------------------------------------------
   -- WriteControlReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the Control register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value stored to the control register.
 */
#define I2S_PDD_WriteControlReg(peripheralBase, Value) ( \
    I2S_CR_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadControlReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the Control register.
 * @param peripheralBase Peripheral base address.
 */
#define I2S_PDD_ReadControlReg(peripheralBase) ( \
    I2S_CR_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- GetInterruptFlags
   ---------------------------------------------------------------------------- */

/**
 * Returns interrupt flag bits.
 * @param peripheralBase Peripheral base address.
 * @return Use constants from group "Interrupt masks for EnableDmasInterrupts,
 *         DisableDmasInterrupts, some of them for GetInterruptFlag, some of them
 *         for ClearInterruptFlags" for processing return value.
 */
#define I2S_PDD_GetInterruptFlags(peripheralBase) ( \
    I2S_ISR_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- ClearInterruptFlags
   ---------------------------------------------------------------------------- */

/**
 * Clears interrupt flag bits defined by mask parameter.
 * @param peripheralBase Peripheral base address.
 * @param Mask Mask of interrupt flags to clear. Use constants from group
 *        "Interrupt masks for EnableDmasInterrupts, DisableDmasInterrupts, some of
 *        them for GetInterruptFlag, some of them for ClearInterruptFlags".
 */
#define I2S_PDD_ClearInterruptFlags(peripheralBase, Mask) ( \
    I2S_ISR_REG(peripheralBase) = \
     (uint32_t)(Mask) \
  )

/* ----------------------------------------------------------------------------
   -- EnableDmasInterrupts
   ---------------------------------------------------------------------------- */

/**
 * Enables DMAs and interrupts defined by mask parameter.
 * @param peripheralBase Peripheral base address.
 * @param Mask Mask of DMAs and interrupts. Use constants from group "Interrupt
 *        masks for EnableDmasInterrupts, DisableDmasInterrupts, some of them for
 *        GetInterruptFlag, some of them for ClearInterruptFlags".
 */
#define I2S_PDD_EnableDmasInterrupts(peripheralBase, Mask) ( \
    I2S_IER_REG(peripheralBase) |= \
     (uint32_t)(Mask) \
  )

/* ----------------------------------------------------------------------------
   -- DisableDmasInterrupts
   ---------------------------------------------------------------------------- */

/**
 * Disables DMAs and interrupts defined by mask parameter.
 * @param peripheralBase Peripheral base address.
 * @param Mask Mask of DMAs and interrupts. Use constants from group "Interrupt
 *        masks for EnableDmasInterrupts, DisableDmasInterrupts, some of them for
 *        GetInterruptFlag, some of them for ClearInterruptFlags".
 */
#define I2S_PDD_DisableDmasInterrupts(peripheralBase, Mask) ( \
    I2S_IER_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)(Mask)) \
  )

/* ----------------------------------------------------------------------------
   -- WriteInterruptEnableReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the Interrupt enable register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value stored to the interrupt enable register.
 */
#define I2S_PDD_WriteInterruptEnableReg(peripheralBase, Value) ( \
    I2S_IER_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadInterruptEnableReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the Interrupt enable register.
 * @param peripheralBase Peripheral base address.
 */
#define I2S_PDD_ReadInterruptEnableReg(peripheralBase) ( \
    I2S_IER_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteTransmitConfigurationReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the Transmit configuration register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value stored to the transmit configuration register.
 */
#define I2S_PDD_WriteTransmitConfigurationReg(peripheralBase, Value) ( \
    I2S_TCR_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadTransmitConfigurationReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the Transmit configuration register.
 * @param peripheralBase Peripheral base address.
 */
#define I2S_PDD_ReadTransmitConfigurationReg(peripheralBase) ( \
    I2S_TCR_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteReceiveConfigurationReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the Receive configuration register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value stored to the receive configuration register.
 */
#define I2S_PDD_WriteReceiveConfigurationReg(peripheralBase, Value) ( \
    I2S_RCR_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadReceiveConfigurationReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the Receive configuration register.
 * @param peripheralBase Peripheral base address.
 */
#define I2S_PDD_ReadReceiveConfigurationReg(peripheralBase) ( \
    I2S_RCR_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteTransmitClockControlReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the Transmit clock control register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value stored to the transmit clock control register.
 */
#define I2S_PDD_WriteTransmitClockControlReg(peripheralBase, Value) ( \
    I2S_TCCR_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadTransmitClockControlReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the Transmit clock control register.
 * @param peripheralBase Peripheral base address.
 */
#define I2S_PDD_ReadTransmitClockControlReg(peripheralBase) ( \
    I2S_TCCR_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteReceiveClockControlReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the Receive clock control register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value stored to the receive clock control register.
 */
#define I2S_PDD_WriteReceiveClockControlReg(peripheralBase, Value) ( \
    I2S_RCCR_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadReceiveClockControlReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the Receive clock control register.
 * @param peripheralBase Peripheral base address.
 */
#define I2S_PDD_ReadReceiveClockControlReg(peripheralBase) ( \
    I2S_RCCR_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- GetRxFIFOCounter1
   ---------------------------------------------------------------------------- */

/**
 * Returns receive FIFO counter 1.
 * @param peripheralBase Peripheral base address.
 */
#define I2S_PDD_GetRxFIFOCounter1(peripheralBase) ( \
    (uint8_t)(( \
     (uint32_t)(I2S_FCSR_REG(peripheralBase) & I2S_FCSR_RFCNT1_MASK)) >> ( \
     I2S_FCSR_RFCNT1_SHIFT)) \
  )

/* ----------------------------------------------------------------------------
   -- GetRxFIFOCounter0
   ---------------------------------------------------------------------------- */

/**
 * Returns receive FIFO counter 0.
 * @param peripheralBase Peripheral base address.
 */
#define I2S_PDD_GetRxFIFOCounter0(peripheralBase) ( \
    (uint8_t)(( \
     (uint32_t)(I2S_FCSR_REG(peripheralBase) & I2S_FCSR_RFCNT0_MASK)) >> ( \
     I2S_FCSR_RFCNT0_SHIFT)) \
  )

/* ----------------------------------------------------------------------------
   -- GetTxFIFOCounter1
   ---------------------------------------------------------------------------- */

/**
 * Returns transmit FIFO counter 1.
 * @param peripheralBase Peripheral base address.
 */
#define I2S_PDD_GetTxFIFOCounter1(peripheralBase) ( \
    (uint8_t)(( \
     (uint32_t)(I2S_FCSR_REG(peripheralBase) & I2S_FCSR_TFCNT1_MASK)) >> ( \
     I2S_FCSR_TFCNT1_SHIFT)) \
  )

/* ----------------------------------------------------------------------------
   -- GetTxFIFOCounter0
   ---------------------------------------------------------------------------- */

/**
 * Returns transmit FIFO counter 0.
 * @param peripheralBase Peripheral base address.
 */
#define I2S_PDD_GetTxFIFOCounter0(peripheralBase) ( \
    (uint8_t)(( \
     (uint32_t)(I2S_FCSR_REG(peripheralBase) & I2S_FCSR_TFCNT0_MASK)) >> ( \
     I2S_FCSR_TFCNT0_SHIFT)) \
  )

/* ----------------------------------------------------------------------------
   -- SetRxFIFOFullWatermark1
   ---------------------------------------------------------------------------- */

/**
 * Sets receive FIFO full watermark 1.
 * @param peripheralBase Peripheral base address.
 * @param Value Parameter specifying new value.
 */
#define I2S_PDD_SetRxFIFOFullWatermark1(peripheralBase, Value) ( \
    I2S_FCSR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(I2S_FCSR_REG(peripheralBase) & (uint32_t)(~(uint32_t)I2S_FCSR_RFWM1_MASK))) | ( \
      (uint32_t)((uint32_t)(Value) << I2S_FCSR_RFWM1_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- SetRxFIFOFullWatermark0
   ---------------------------------------------------------------------------- */

/**
 * Sets receive FIFO full watermark 0.
 * @param peripheralBase Peripheral base address.
 * @param Value Parameter specifying new value.
 */
#define I2S_PDD_SetRxFIFOFullWatermark0(peripheralBase, Value) ( \
    I2S_FCSR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(I2S_FCSR_REG(peripheralBase) & (uint32_t)(~(uint32_t)I2S_FCSR_RFWM0_MASK))) | ( \
      (uint32_t)((uint32_t)(Value) << I2S_FCSR_RFWM0_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- SetTxFIFOFullWatermark1
   ---------------------------------------------------------------------------- */

/**
 * Sets transmit FIFO full watermark 1.
 * @param peripheralBase Peripheral base address.
 * @param Value Parameter specifying new value. Value 0 is reserved.
 */
#define I2S_PDD_SetTxFIFOFullWatermark1(peripheralBase, Value) ( \
    I2S_FCSR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(I2S_FCSR_REG(peripheralBase) & (uint32_t)(~(uint32_t)I2S_FCSR_TFWM1_MASK))) | ( \
      (uint32_t)((uint32_t)(Value) << I2S_FCSR_TFWM1_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- SetTxFIFOFullWatermark0
   ---------------------------------------------------------------------------- */

/**
 * Sets transmit FIFO full watermark 0.
 * @param peripheralBase Peripheral base address.
 * @param Value Parameter specifying new value. Value 0 is reserved.
 */
#define I2S_PDD_SetTxFIFOFullWatermark0(peripheralBase, Value) ( \
    I2S_FCSR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(I2S_FCSR_REG(peripheralBase) & (uint32_t)(~(uint32_t)I2S_FCSR_TFWM0_MASK))) | ( \
      (uint32_t)(Value))) \
  )

/* ----------------------------------------------------------------------------
   -- WriteFIFOControlStatusReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the FIFO control status register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value stored to the FIFO control status register.
 */
#define I2S_PDD_WriteFIFOControlStatusReg(peripheralBase, Value) ( \
    I2S_FCSR_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadFIFOControlStatusReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the FIFO control status register.
 * @param peripheralBase Peripheral base address.
 */
#define I2S_PDD_ReadFIFOControlStatusReg(peripheralBase) ( \
    I2S_FCSR_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteTxTimeSlotMaskReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the transmit time slot mask register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value stored to the transmit time slot mask register.
 */
#define I2S_PDD_WriteTxTimeSlotMaskReg(peripheralBase, Value) ( \
    I2S_TMSK_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadTxTimeSlotMaskReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the transmit time slot register.
 * @param peripheralBase Peripheral base address.
 */
#define I2S_PDD_ReadTxTimeSlotMaskReg(peripheralBase) ( \
    I2S_TMSK_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteRxTimeSlotMaskReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the receive time slot mask register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value stored to the receive time slot mask register.
 */
#define I2S_PDD_WriteRxTimeSlotMaskReg(peripheralBase, Value) ( \
    I2S_RMSK_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadRxTimeSlotMaskReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the receive time slot register.
 * @param peripheralBase Peripheral base address.
 */
#define I2S_PDD_ReadRxTimeSlotMaskReg(peripheralBase) ( \
    I2S_RMSK_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- EnableAC97Mode
   ---------------------------------------------------------------------------- */

/**
 * Enables the AC97 mode.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state of AC97 mode.
 */
#define I2S_PDD_EnableAC97Mode(peripheralBase, State) ( \
    I2S_ACNT_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(I2S_ACNT_REG(peripheralBase) & (uint32_t)(~(uint32_t)I2S_ACNT_AC97EN_MASK))) | ( \
      (uint32_t)(State))) \
  )

/* ----------------------------------------------------------------------------
   -- SetAC97Command
   ---------------------------------------------------------------------------- */

/**
 * Selects AC97 command.
 * @param peripheralBase Peripheral base address.
 * @param Command Parameter specifying AC97 command.
 */
#define I2S_PDD_SetAC97Command(peripheralBase, Command) ( \
    I2S_ACNT_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(I2S_ACNT_REG(peripheralBase) & (uint32_t)(~(uint32_t)((uint32_t)0x3U << 3U)))) | ( \
      (uint32_t)(Command))) \
  )

/* ----------------------------------------------------------------------------
   -- WriteAC97ControlReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the AC97 control register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value stored to the AC97 control register.
 */
#define I2S_PDD_WriteAC97ControlReg(peripheralBase, Value) ( \
    I2S_ACNT_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadAC97ControlReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the AC97 control register.
 * @param peripheralBase Peripheral base address.
 */
#define I2S_PDD_ReadAC97ControlReg(peripheralBase) ( \
    I2S_ACNT_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteAC97CommandAddressReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the AC97 command address register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value stored to the AC97 command address register.
 */
#define I2S_PDD_WriteAC97CommandAddressReg(peripheralBase, Value) ( \
    I2S_ACADD_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadAC97CommandAddressReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the AC97 command address register.
 * @param peripheralBase Peripheral base address.
 */
#define I2S_PDD_ReadAC97CommandAddressReg(peripheralBase) ( \
    I2S_ACADD_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteAC97CommandDataReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the AC97 command data register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value stored to the AC97 command data register.
 */
#define I2S_PDD_WriteAC97CommandDataReg(peripheralBase, Value) ( \
    I2S_ACDAT_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadAC97CommandDataReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the AC97 command data register.
 * @param peripheralBase Peripheral base address.
 */
#define I2S_PDD_ReadAC97CommandDataReg(peripheralBase) ( \
    I2S_ACDAT_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteAC97TagReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the AC97 tag register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value stored to the AC97 tag register.
 */
#define I2S_PDD_WriteAC97TagReg(peripheralBase, Value) ( \
    I2S_ATAG_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadAC97TagReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the AC97 tag register.
 * @param peripheralBase Peripheral base address.
 */
#define I2S_PDD_ReadAC97TagReg(peripheralBase) ( \
    I2S_ATAG_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- EnableAC97Channels
   ---------------------------------------------------------------------------- */

/**
 * Enables AC97 channels.
 * @param peripheralBase Peripheral base address.
 * @param Mask Mask of AC97 channels. Use constants from group "Slot masks for
 *        EnableAC97Channels, DisableAC97Channels, GetAC97ChannelStatusMask".
 */
#define I2S_PDD_EnableAC97Channels(peripheralBase, Mask) ( \
    I2S_ACCEN_REG(peripheralBase) = \
     (uint32_t)(Mask) \
  )

/* ----------------------------------------------------------------------------
   -- WriteAC97ChannelEnableReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the AC97 channel enable register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value stored to the AC97 channel enable register.
 */
#define I2S_PDD_WriteAC97ChannelEnableReg(peripheralBase, Value) ( \
    I2S_ACCEN_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- DisableAC97Channels
   ---------------------------------------------------------------------------- */

/**
 * Disables AC97 channels.
 * @param peripheralBase Peripheral base address.
 * @param Mask Mask of AC97 channels. Use constants from group "Slot masks for
 *        EnableAC97Channels, DisableAC97Channels, GetAC97ChannelStatusMask".
 */
#define I2S_PDD_DisableAC97Channels(peripheralBase, Mask) ( \
    I2S_ACCDIS_REG(peripheralBase) = \
     (uint32_t)(Mask) \
  )

/* ----------------------------------------------------------------------------
   -- WriteAC97ChannelDisableReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the AC97 channel disable register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value stored to the AC97 chanel disable register.
 */
#define I2S_PDD_WriteAC97ChannelDisableReg(peripheralBase, Value) ( \
    I2S_ACCDIS_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- GetAC97ChannelStatusMask
   ---------------------------------------------------------------------------- */

/**
 * Returns AC97 channel enable bits.
 * @param peripheralBase Peripheral base address.
 * @return Use constants from group "Slot masks for EnableAC97Channels,
 *         DisableAC97Channels, GetAC97ChannelStatusMask" for processing return value.
 */
#define I2S_PDD_GetAC97ChannelStatusMask(peripheralBase) ( \
    I2S_ACCST_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- ReadAC97ChannelStatusReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the AC97 channel status register.
 * @param peripheralBase Peripheral base address.
 */
#define I2S_PDD_ReadAC97ChannelStatusReg(peripheralBase) ( \
    I2S_ACCST_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- SetClockSource
   ---------------------------------------------------------------------------- */

/**
 * Selects clock source (in SIM module).
 * @param peripheralBase Peripheral base address.
 * @param Source Requested state of clock source. Use constants from group
 *        "Clock source constants for SetClockSource.".
 */
#define I2S_PDD_SetClockSource(peripheralBase, Source) ( \
    SIM_SOPT2_REG(SIM_BASE_PTR) = \
     (( \
      (uint32_t)(SIM_SOPT2_REG(SIM_BASE_PTR) & (uint32_t)(~(uint32_t)SIM_SOPT2_I2SSRC_MASK))) | ( \
      (uint32_t)((uint32_t)(Source) << SIM_SOPT2_I2SSRC_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- SetClockDivider
   ---------------------------------------------------------------------------- */

/**
 * Sets clock divider (in SIM module).
 * @param peripheralBase Peripheral base address.
 * @param Value Value specifying division.
 */
#define I2S_PDD_SetClockDivider(peripheralBase, Value) ( \
    SIM_CLKDIV2_REG(SIM_BASE_PTR) = \
     (( \
      (uint32_t)(SIM_CLKDIV2_REG(SIM_BASE_PTR) & (uint32_t)(~(uint32_t)SIM_CLKDIV2_I2SDIV_MASK))) | ( \
      (uint32_t)((uint32_t)(Value) << SIM_CLKDIV2_I2SDIV_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- SetClockMultiplier
   ---------------------------------------------------------------------------- */

/**
 * Sets clock multiplier (in SIM module).
 * @param peripheralBase Peripheral base address.
 * @param Value Value specifying multiplication.
 */
#define I2S_PDD_SetClockMultiplier(peripheralBase, Value) ( \
    SIM_CLKDIV2_REG(SIM_BASE_PTR) = \
     (( \
      (uint32_t)(SIM_CLKDIV2_REG(SIM_BASE_PTR) & (uint32_t)(~(uint32_t)SIM_CLKDIV2_I2SFRAC_MASK))) | ( \
      (uint32_t)((uint32_t)(Value) << SIM_CLKDIV2_I2SFRAC_SHIFT))) \
  )
#endif  /* #if defined(I2S_PDD_H_) */

/* I2S_PDD.h, eof. */
