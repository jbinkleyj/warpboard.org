/*
  PDD layer implementation for peripheral type SPI
  (C) 2010 Freescale, Inc. All rights reserved.

  This file is static and it is generated from API-Factory
*/

#if !defined(SPI_PDD_H_)
#define SPI_PDD_H_

/* ----------------------------------------------------------------------------
   -- Test if supported MCU is active
   ---------------------------------------------------------------------------- */

#if !defined(MCU_ACTIVE)
  // No MCU is active
  #error SPI PDD library: No derivative is active. Place proper #include with PDD memory map before including PDD library.
#elif \
      !defined(MCU_MK10D10) /* SPI0, SPI1, SPI2 */ && \
      !defined(MCU_MK10D5) /* SPI0 */ && \
      !defined(MCU_MK10D7) /* SPI0, SPI1 */ && \
      !defined(MCU_MK10F12) /* SPI0, SPI1, SPI2 */ && \
      !defined(MCU_MK10DZ10) /* SPI0, SPI1, SPI2 */ && \
      !defined(MCU_MK11D5) /* SPI0, SPI1 */ && \
      !defined(MCU_MK12D5) /* SPI0, SPI1 */ && \
      !defined(MCU_MK20D10) /* SPI0, SPI1, SPI2 */ && \
      !defined(MCU_MK20D5) /* SPI0 */ && \
      !defined(MCU_MK20D7) /* SPI0, SPI1 */ && \
      !defined(MCU_MK20F12) /* SPI0, SPI1, SPI2 */ && \
      !defined(MCU_MK20DZ10) /* SPI0, SPI1, SPI2 */ && \
      !defined(MCU_MK21D5) /* SPI0, SPI1 */ && \
      !defined(MCU_MK22D5) /* SPI0, SPI1 */ && \
      !defined(MCU_MK30D10) /* SPI0, SPI1, SPI2 */ && \
      !defined(MCU_MK30D7) /* SPI0, SPI1 */ && \
      !defined(MCU_MK30DZ10) /* SPI0, SPI1, SPI2 */ && \
      !defined(MCU_MK40D10) /* SPI0, SPI1, SPI2 */ && \
      !defined(MCU_MK40D7) /* SPI0, SPI1 */ && \
      !defined(MCU_MK40DZ10) /* SPI0, SPI1, SPI2 */ && \
      !defined(MCU_MK40X256VMD100) /* SPI0, SPI1, SPI2 */ && \
      !defined(MCU_MK50D10) /* SPI0, SPI1, SPI2 */ && \
      !defined(MCU_MK50D7) /* SPI0, SPI1 */ && \
      !defined(MCU_MK50DZ10) /* SPI0, SPI1, SPI2 */ && \
      !defined(MCU_MK51D10) /* SPI0, SPI1, SPI2 */ && \
      !defined(MCU_MK51D7) /* SPI0, SPI1 */ && \
      !defined(MCU_MK51DZ10) /* SPI0, SPI1, SPI2 */ && \
      !defined(MCU_MK52D10) /* SPI0, SPI1, SPI2 */ && \
      !defined(MCU_MK52DZ10) /* SPI0, SPI1, SPI2 */ && \
      !defined(MCU_MK53D10) /* SPI0, SPI1, SPI2 */ && \
      !defined(MCU_MK53DZ10) /* SPI0, SPI1, SPI2 */ && \
      !defined(MCU_MK60D10) /* SPI0, SPI1, SPI2 */ && \
      !defined(MCU_MK60F12) /* SPI0, SPI1, SPI2 */ && \
      !defined(MCU_MK60F15) /* SPI0, SPI1, SPI2 */ && \
      !defined(MCU_MK60DZ10) /* SPI0, SPI1, SPI2 */ && \
      !defined(MCU_MK60N512VMD100) /* SPI0, SPI1, SPI2 */ && \
      !defined(MCU_MK61F12) /* SPI0, SPI1, SPI2 */ && \
      !defined(MCU_MK61F15) /* SPI0, SPI1, SPI2 */ && \
      !defined(MCU_MK70F12) /* SPI0, SPI1, SPI2 */ && \
      !defined(MCU_MK70F15) /* SPI0, SPI1, SPI2 */ && \
      !defined(MCU_MKL04Z4) /* SPI0 */ && \
      !defined(MCU_MKL05Z4) /* SPI0 */ && \
      !defined(MCU_MKL14Z4) /* SPI0, SPI1 */ && \
      !defined(MCU_MKL15Z4) /* SPI0, SPI1 */ && \
      !defined(MCU_MKL24Z4) /* SPI0, SPI1 */ && \
      !defined(MCU_MKL25Z4) /* SPI0, SPI1 */ && \
      !defined(MCU_PCK20L4) /* SPI0 */
  // Unsupported MCU is active
  #error SPI PDD library: Unsupported derivative is active.
#endif

#include "PDD_Types.h"

/* ----------------------------------------------------------------------------
   -- Method symbol definitions
   ---------------------------------------------------------------------------- */

/* Interrupt/DMA masks */
#define SPI_PDD_TRANSFER_COMPLETE_INT SPI_SR_TCF_MASK /**< Transfer complete interrupt mask. */
#define SPI_PDD_QUEUE_FINISHED_INT SPI_SR_EOQF_MASK /**< Queue finished interrupt mask. */
#define SPI_PDD_TX_FIFO_UNDERFLOW_INT SPI_SR_TFUF_MASK /**< Transmit FIFO underflow interrupt mask. */
#define SPI_PDD_TX_FIFO_FILL_INT_DMA SPI_SR_TFFF_MASK /**< Transmit FIFO fill interrupt mask. */
#define SPI_PDD_RX_FIFO_OVERFLOW_INT SPI_SR_RFOF_MASK /**< Receive FIFO overflow interrupt mask. */
#define SPI_PDD_RX_FIFO_DRAIN_INT_DMA SPI_SR_RFDF_MASK /**< Receive FIFO drain interrupt mask. */
#define SPI_PDD_ALL_INT 0x9A0A0000U              /**< All interrupt masks. */

/* Request mask for DMA or interrupt selection */
#define SPI_PDD_NO_DMA 0U                        /**< None DMA or interrupt request selection. */
#define SPI_PDD_TX_FIFO_FILL_DMA SPI_RSER_TFFF_DIRS_MASK /**< Transmit FIFO fill DMA or interrupt request select. */
#define SPI_PDD_RX_FIFO_DRAIN_DMA SPI_RSER_RFDF_DIRS_MASK /**< Receive FIFO drain DMA or interrupt request select. */

/* Rx buffer full (or fault) and Tx buffer empty interrupt masks constant. */
#define SPI_PDD_RX_BUFFER_FULL_OR_FAULT SPI_C1_SPIE_MASK /**< Receiver buffer full and mode fault mask. */
#define SPI_PDD_TX_BUFFER_EMPTY SPI_C1_SPTIE_MASK /**< Transmitter buffer empty mask. */

/* Status flags constants (for ReadStatusReg, GetInterruptFlags,
   ClearInterruptFlags macros). */
#define SPI_PDD_RX_BUFFER_FULL SPI_S_SPRF_MASK   /**< Read buffer or FIFO full flag. */
#define SPI_PDD_MATCH SPI_S_SPMF_MASK            /**< SPI match flag. */
#define SPI_PDD_TX_BUFFER_EMPTYG SPI_S_SPTEF_MASK /**< Transmit buffer or FIFO empty flag. */
#define SPI_PDD_MASTER_FAULT SPI_S_MODF_MASK     /**< Master mode fault flag. */

/* SPI mode constants (for SetMasterSlaveMode). */
#define SPI_PDD_MASTER_MODE 0x1U                 /**< Master mode. */
#define SPI_PDD_SLAVE_MODE 0U                    /**< Slave mode. */

/* SPI clock polarity constants (for SetClockPolarity macro). */
#define SPI_PDD_ACTIVE_HIGH 0U                   /**< Active-high SPI clock (idles low). */
#define SPI_PDD_ACTIVE_LOW 0x8U                  /**< Active-low SPI clock (idles high). */

/* SPI clock phase constants (for SetClockPhase macro). */
#define SPI_PDD_FIRST_EDGE 0U                    /**< First edge on SPSCK occurs at the middle of the first cycle of a data transfer. */
#define SPI_PDD_SECOND_EDGE 0x4U                 /**< First edge on SPSCK occurs at the start of the first cycle of a data transfer. */

/* SPI slave select pin function constants (for SetSlaveSelectPinFunction
   macro). */
#define SPI_PDD_SS_AS_GPIO 0U                    /**< Slave select pin configured as GPIO. */
#define SPI_PDD_SS_FOR_FAULT_DETECT 0x1U         /**< Slave select pin configured for fault detection. */
#define SPI_PDD_SS_AUTOMATIC_OUTPUT 0x2U         /**< Slave select pin configured for automatic SPI output. */

/* SPI data shift order constants (for SetDataShiftOrder macro). */
#define SPI_PDD_LSB_FIRST 0x1U                   /**< Data transfers start with least significant bit. */
#define SPI_PDD_MSB_FIRST 0U                     /**< Data transfers start with most significant bit. */

/* SPI data length constants (for SetWordLength, GetWordLength macro). */
#define SPI_PDD_8_BIT 0U                         /**< 8-bit SPI shift register, match register and buffers. */
#define SPI_PDD_16_BIT 0x1U                      /**< 16-bit SPI shift register, match register and buffers. */


/* ----------------------------------------------------------------------------
   -- SetMasterSlaveMode
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MKL04Z4)) || (defined(MCU_MKL05Z4)) || (defined(MCU_MKL14Z4)) || (defined(MCU_MKL15Z4)) || (defined(MCU_MKL24Z4)) || (defined(MCU_MKL25Z4)))
/**
 * Select master or slave mode.
 * @param peripheralBase Peripheral base address.
 * @param Mode SPI mode value. The user should use one from the enumerated
 *        values.
 */
  #define SPI_PDD_SetMasterSlaveMode(peripheralBase, Mode) ( \
      SPI_C1_REG(peripheralBase) = \
       (uint8_t)(( \
        (uint8_t)(SPI_C1_REG(peripheralBase) & (uint8_t)(~(uint8_t)SPI_C1_MSTR_MASK))) | ( \
        (uint8_t)((uint8_t)(Mode) << SPI_C1_MSTR_SHIFT))) \
    )
#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_PCK20L4)) */
/**
 * Select master or slave mode.
 * @param peripheralBase Peripheral base address.
 * @param Mode Device mode.
 */
  #define SPI_PDD_SetMasterSlaveMode(peripheralBase, Mode) ( \
      SPI_MCR_REG(peripheralBase) = \
       (uint32_t)(( \
        (uint32_t)(SPI_MCR_REG(peripheralBase) & (uint32_t)(~(uint32_t)SPI_MCR_MSTR_MASK))) | ( \
        (uint32_t)((uint32_t)(Mode) << SPI_MCR_MSTR_SHIFT))) \
    )
#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_PCK20L4)) */

/* ----------------------------------------------------------------------------
   -- EnableContinuousClock
   ---------------------------------------------------------------------------- */

/**
 * Enables continuous clock.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state of continuous clock.
 */
#define SPI_PDD_EnableContinuousClock(peripheralBase, State) ( \
    SPI_MCR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(SPI_MCR_REG(peripheralBase) & (uint32_t)(~(uint32_t)SPI_MCR_CONT_SCKE_MASK))) | ( \
      (uint32_t)((uint32_t)(State) << SPI_MCR_CONT_SCKE_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableDevice
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MKL04Z4)) || (defined(MCU_MKL05Z4)) || (defined(MCU_MKL14Z4)) || (defined(MCU_MKL15Z4)) || (defined(MCU_MKL24Z4)) || (defined(MCU_MKL25Z4)))
/**
 * Enables/disables SPI device.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state of device.
 */
  #define SPI_PDD_EnableDevice(peripheralBase, State) ( \
      SPI_C1_REG(peripheralBase) = \
       (uint8_t)(( \
        (uint8_t)(SPI_C1_REG(peripheralBase) & (uint8_t)(~(uint8_t)SPI_C1_SPE_MASK))) | ( \
        (uint8_t)((uint8_t)(State) << SPI_C1_SPE_SHIFT))) \
    )
#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_PCK20L4)) */
/**
 * Enables the device.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state of device.
 */
  #define SPI_PDD_EnableDevice(peripheralBase, State) ( \
      ((State) == PDD_DISABLE) ? ( \
        SPI_MCR_REG(peripheralBase) |= \
         (uint32_t)((uint32_t)0x1U << SPI_MCR_MDIS_SHIFT)) : ( \
        SPI_MCR_REG(peripheralBase) &= \
         (uint32_t)(~(uint32_t)SPI_MCR_MDIS_MASK)) \
    )
#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_PCK20L4)) */

/* ----------------------------------------------------------------------------
   -- ClearTxFIFO
   ---------------------------------------------------------------------------- */

/**
 * Clears Tx FIFO.
 * @param peripheralBase Peripheral base address.
 */
#define SPI_PDD_ClearTxFIFO(peripheralBase) ( \
    SPI_MCR_REG(peripheralBase) |= \
     SPI_MCR_CLR_TXF_MASK \
  )

/* ----------------------------------------------------------------------------
   -- ClearRxFIFO
   ---------------------------------------------------------------------------- */

/**
 * Clears Rx FIFO.
 * @param peripheralBase Peripheral base address.
 */
#define SPI_PDD_ClearRxFIFO(peripheralBase) ( \
    SPI_MCR_REG(peripheralBase) |= \
     SPI_MCR_CLR_RXF_MASK \
  )

/* ----------------------------------------------------------------------------
   -- EnableHaltMode
   ---------------------------------------------------------------------------- */

/**
 * Enables halt mode.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state of halt mode.
 */
#define SPI_PDD_EnableHaltMode(peripheralBase, State) ( \
    SPI_MCR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(SPI_MCR_REG(peripheralBase) & (uint32_t)(~(uint32_t)SPI_MCR_HALT_MASK))) | ( \
      (uint32_t)(State))) \
  )

/* ----------------------------------------------------------------------------
   -- WriteModuleConfigurationReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the Module configuration register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value stored to the module configuration register.
 */
#define SPI_PDD_WriteModuleConfigurationReg(peripheralBase, Value) ( \
    SPI_MCR_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadModuleConfigurationReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the Module configuration register.
 * @param peripheralBase Peripheral base address.
 */
#define SPI_PDD_ReadModuleConfigurationReg(peripheralBase) ( \
    SPI_MCR_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- SetTransferCounter
   ---------------------------------------------------------------------------- */

/**
 * Sets transfer counter.
 * @param peripheralBase Peripheral base address.
 * @param Value Parameter specifying new value.
 */
#define SPI_PDD_SetTransferCounter(peripheralBase, Value) ( \
    SPI_TCR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(SPI_TCR_REG(peripheralBase) & (uint32_t)(~(uint32_t)SPI_TCR_SPI_TCNT_MASK))) | ( \
      (uint32_t)((uint32_t)(Value) << SPI_TCR_SPI_TCNT_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- GetTransferCounter
   ---------------------------------------------------------------------------- */

/**
 * Returns transfer counter.
 * @param peripheralBase Peripheral base address.
 */
#define SPI_PDD_GetTransferCounter(peripheralBase) ( \
    (uint16_t)(( \
     (uint32_t)(SPI_TCR_REG(peripheralBase) & SPI_TCR_SPI_TCNT_MASK)) >> ( \
     SPI_TCR_SPI_TCNT_SHIFT)) \
  )

/* ----------------------------------------------------------------------------
   -- WriteTransferCountReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the Transfer count register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value stored to the transfer count register.
 */
#define SPI_PDD_WriteTransferCountReg(peripheralBase, Value) ( \
    SPI_TCR_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadTransferCountReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the Transfer count register.
 * @param peripheralBase Peripheral base address.
 */
#define SPI_PDD_ReadTransferCountReg(peripheralBase) ( \
    SPI_TCR_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteMasterClockTransferAttributeReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value intended for master mode to the Clock transfer attribute
 * register.
 * @param peripheralBase Peripheral base address.
 * @param Index Attribute index.
 * @param Value Value stored to the master clock transfer attribute register.
 */
#define SPI_PDD_WriteMasterClockTransferAttributeReg(peripheralBase, Index, Value) ( \
    SPI_CTAR_REG(peripheralBase,(Index)) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadMasterClockTransferAttributeReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the Clock transfer attribute register for master mode.
 * @param peripheralBase Peripheral base address.
 * @param Index Attribute index.
 */
#define SPI_PDD_ReadMasterClockTransferAttributeReg(peripheralBase, Index) ( \
    SPI_CTAR_REG(peripheralBase,(Index)) \
  )

/* ----------------------------------------------------------------------------
   -- WriteSlaveClockTransferAttributeReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value intended for slave mode to the Clock transfer attribute register.
 * @param peripheralBase Peripheral base address.
 * @param Index Attribute index.
 * @param Value Value stored to the slave clock transfer attribute register.
 */
#define SPI_PDD_WriteSlaveClockTransferAttributeReg(peripheralBase, Index, Value) ( \
    SPI_CTAR_SLAVE_REG(peripheralBase,(Index)) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadSlaveClockTransferAttributeReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the Clock transfer attribute register for slave mode.
 * @param peripheralBase Peripheral base address.
 * @param Index Attribute index.
 */
#define SPI_PDD_ReadSlaveClockTransferAttributeReg(peripheralBase, Index) ( \
    SPI_CTAR_SLAVE_REG(peripheralBase,(Index)) \
  )

/* ----------------------------------------------------------------------------
   -- EnableDmasInterrupts
   ---------------------------------------------------------------------------- */

/**
 * Enables DMA/interrupt requests defined by mask parameter.
 * @param peripheralBase Peripheral base address.
 * @param Mask Mask of DMA/interrupt requests. Use constants from group
 *        "Interrupt/DMA masks".
 */
#define SPI_PDD_EnableDmasInterrupts(peripheralBase, Mask) ( \
    SPI_RSER_REG(peripheralBase) |= \
     (uint32_t)(Mask) \
  )

/* ----------------------------------------------------------------------------
   -- DisableDmasInterrupts
   ---------------------------------------------------------------------------- */

/**
 * Disables DMA/interrupt requests defined by mask parameter.
 * @param peripheralBase Peripheral base address.
 * @param Mask Mask of DMA/interrupt requests. Use constants from group
 *        "Interrupt/DMA masks".
 */
#define SPI_PDD_DisableDmasInterrupts(peripheralBase, Mask) ( \
    SPI_RSER_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)(Mask)) \
  )

/* ----------------------------------------------------------------------------
   -- SelectDmasInterrupts
   ---------------------------------------------------------------------------- */

/**
 * Selects DMA or interrupt for request defined by mask parameter.
 * @param peripheralBase Peripheral base address.
 * @param Mask Mask of DMA/interrupt requests. Use constants from group "Request
 *        mask for DMA or interrupt selection".
 */
#define SPI_PDD_SelectDmasInterrupts(peripheralBase, Mask) ( \
    SPI_RSER_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       SPI_RSER_REG(peripheralBase)) & ( \
       (uint32_t)(~(uint32_t)(SPI_RSER_TFFF_DIRS_MASK | SPI_RSER_RFDF_DIRS_MASK))))) | ( \
      (uint32_t)(Mask))) \
  )

/* ----------------------------------------------------------------------------
   -- WriteDmaInterruptEnableReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the DMA interrupt enable register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value stored to the DMA interrupt enable register.
 */
#define SPI_PDD_WriteDmaInterruptEnableReg(peripheralBase, Value) ( \
    SPI_RSER_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadDmaInterruptEnableReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the DMA interrupt enable register.
 * @param peripheralBase Peripheral base address.
 */
#define SPI_PDD_ReadDmaInterruptEnableReg(peripheralBase) ( \
    SPI_RSER_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- GetInterruptFlags
   ---------------------------------------------------------------------------- */

/**
 * Returns interrupt flags.
 * @param peripheralBase Peripheral base address.
 */
#define SPI_PDD_GetInterruptFlags(peripheralBase) ( \
    (uint32_t)(( \
     SPI_SR_REG(peripheralBase)) & ( \
     (uint32_t)(( \
      SPI_SR_TCF_MASK) | (( \
      SPI_SR_EOQF_MASK) | (( \
      SPI_SR_TFUF_MASK) | (( \
      SPI_SR_TFFF_MASK) | (( \
      SPI_SR_RFOF_MASK) | ( \
      SPI_SR_RFDF_MASK)))))))) \
  )

/* ----------------------------------------------------------------------------
   -- ClearInterruptFlags
   ---------------------------------------------------------------------------- */

/**
 * Clears interrupt flag bits defined by mask parameter.
 * @param peripheralBase Peripheral base address.
 * @param Mask Mask of interrupt flags to clear. Use constants from group
 *        "Interrupt/DMA masks".
 */
#define SPI_PDD_ClearInterruptFlags(peripheralBase, Mask) ( \
    SPI_SR_REG(peripheralBase) = \
     (uint32_t)(Mask) \
  )

/* ----------------------------------------------------------------------------
   -- GetTxRxActiveFlag
   ---------------------------------------------------------------------------- */

/**
 * Returns Tx/Rx active flag.
 * @param peripheralBase Peripheral base address.
 */
#define SPI_PDD_GetTxRxActiveFlag(peripheralBase) ( \
    (uint32_t)(SPI_SR_REG(peripheralBase) & SPI_SR_TXRXS_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetTxFIFOCounter
   ---------------------------------------------------------------------------- */

/**
 * Returns transmit FIFO counter.
 * @param peripheralBase Peripheral base address.
 */
#define SPI_PDD_GetTxFIFOCounter(peripheralBase) ( \
    (uint8_t)(( \
     (uint32_t)(SPI_SR_REG(peripheralBase) & SPI_SR_TXCTR_MASK)) >> ( \
     SPI_SR_TXCTR_SHIFT)) \
  )

/* ----------------------------------------------------------------------------
   -- GetRxFIFOCounter
   ---------------------------------------------------------------------------- */

/**
 * Returns receive FIFO counter.
 * @param peripheralBase Peripheral base address.
 */
#define SPI_PDD_GetRxFIFOCounter(peripheralBase) ( \
    (uint8_t)(( \
     (uint32_t)(SPI_SR_REG(peripheralBase) & SPI_SR_RXCTR_MASK)) >> ( \
     SPI_SR_RXCTR_SHIFT)) \
  )

/* ----------------------------------------------------------------------------
   -- GetTxNextPointer
   ---------------------------------------------------------------------------- */

/**
 * Returns pointer to TX FIFO entry which is transmitted during the next
 * transfer.
 * @param peripheralBase Peripheral base address.
 */
#define SPI_PDD_GetTxNextPointer(peripheralBase) ( \
    (uint8_t)(( \
     (uint32_t)(SPI_SR_REG(peripheralBase) & SPI_SR_TXNXTPTR_MASK)) >> ( \
     SPI_SR_TXNXTPTR_SHIFT)) \
  )

/* ----------------------------------------------------------------------------
   -- GetRxNextPointer
   ---------------------------------------------------------------------------- */

/**
 * Returns pointer to RX FIFO entry which is transmitted during the next
 * transfer.
 * @param peripheralBase Peripheral base address.
 */
#define SPI_PDD_GetRxNextPointer(peripheralBase) ( \
    (uint8_t)(SPI_SR_REG(peripheralBase) & SPI_SR_POPNXTPTR_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- WriteStatusReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the Status register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value stored to the status register.
 */
#define SPI_PDD_WriteStatusReg(peripheralBase, Value) ( \
    SPI_SR_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadStatusReg
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MKL04Z4)) || (defined(MCU_MKL05Z4)) || (defined(MCU_MKL14Z4)) || (defined(MCU_MKL15Z4)) || (defined(MCU_MKL24Z4)) || (defined(MCU_MKL25Z4)))
/**
 * Returns the value of the status register.
 * @param peripheralBase Peripheral base address.
 * @return Use constants from group "Status flags constants (for ReadStatusReg,
 *         GetInterruptFlags, ClearInterruptFlags macros)." for processing return
 *         value.
 */
  #define SPI_PDD_ReadStatusReg(peripheralBase) ( \
      SPI_S_REG(peripheralBase) \
    )
#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_PCK20L4)) */
/**
 * Returns the content of the Status register.
 * @param peripheralBase Peripheral base address.
 */
  #define SPI_PDD_ReadStatusReg(peripheralBase) ( \
      SPI_SR_REG(peripheralBase) \
    )
#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_PCK20L4)) */

/* ----------------------------------------------------------------------------
   -- WriteMasterPushTxFIFOReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value intended for master mode to the Push TX FIFO register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value stored to the master push Tx FIFO register.
 */
#define SPI_PDD_WriteMasterPushTxFIFOReg(peripheralBase, Value) ( \
    SPI_PUSHR_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- WriteSlavePushTxFIFOReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value intended for slave mode to the Push TX FIFO register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value stored to the slave push Tx FIFO register.
 */
#define SPI_PDD_WriteSlavePushTxFIFOReg(peripheralBase, Value) ( \
    SPI_PUSHR_SLAVE_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadPopRxFIFOReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the Pop Rx FIFO register.
 * @param peripheralBase Peripheral base address.
 */
#define SPI_PDD_ReadPopRxFIFOReg(peripheralBase) ( \
    SPI_POPR_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- EnableInterruptMask
   ---------------------------------------------------------------------------- */

/**
 * Enables interrupt requests defined by mask parameter.
 * @param peripheralBase Peripheral base address.
 * @param Mask Mask of interrupt requests. Use constants from group "Rx buffer
 *        full (or fault) and Tx buffer empty interrupt masks constant.".
 */
#define SPI_PDD_EnableInterruptMask(peripheralBase, Mask) ( \
    SPI_C1_REG(peripheralBase) |= \
     (uint8_t)(Mask) \
  )

/* ----------------------------------------------------------------------------
   -- DisableInterruptMask
   ---------------------------------------------------------------------------- */

/**
 * Disables interrupt requests defined by mask parameter.
 * @param peripheralBase Peripheral base address.
 * @param Mask Mask of interrupt requests. Use constants from group "Rx buffer
 *        full (or fault) and Tx buffer empty interrupt masks constant.".
 */
#define SPI_PDD_DisableInterruptMask(peripheralBase, Mask) ( \
    SPI_C1_REG(peripheralBase) &= \
     (uint8_t)(~(uint8_t)(Mask)) \
  )

/* ----------------------------------------------------------------------------
   -- SetClockPolarity
   ---------------------------------------------------------------------------- */

/**
 * Sets the SPI clock polarity.
 * @param peripheralBase Peripheral base address.
 * @param Polarity SPI polarity value. The user should use one from the
 *        enumerated values.
 */
#define SPI_PDD_SetClockPolarity(peripheralBase, Polarity) ( \
    SPI_C1_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(SPI_C1_REG(peripheralBase) & (uint8_t)(~(uint8_t)SPI_C1_CPOL_MASK))) | ( \
      (uint8_t)(Polarity))) \
  )

/* ----------------------------------------------------------------------------
   -- SetClockPhase
   ---------------------------------------------------------------------------- */

/**
 * Sets the SPI clock phase.
 * @param peripheralBase Peripheral base address.
 * @param Phase SPI phase value. The user should use one from the enumerated
 *        values.
 */
#define SPI_PDD_SetClockPhase(peripheralBase, Phase) ( \
    SPI_C1_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(SPI_C1_REG(peripheralBase) & (uint8_t)(~(uint8_t)SPI_C1_CPHA_MASK))) | ( \
      (uint8_t)(Phase))) \
  )

/* ----------------------------------------------------------------------------
   -- SetSlaveSelectPinFunction
   ---------------------------------------------------------------------------- */

/**
 * Sets the SPI slave select pin function.
 * @param peripheralBase Peripheral base address.
 * @param Function Slave select pin function. The user should use one from the
 *        enumerated values.
 */
#define SPI_PDD_SetSlaveSelectPinFunction(peripheralBase, Function) ( \
    ((Function) == SPI_PDD_SS_AS_GPIO) ? ( \
      (SPI_C1_REG(peripheralBase) &= \
       (uint8_t)(~(uint8_t)SPI_C1_SSOE_MASK)), \
      (SPI_C2_REG(peripheralBase) &= \
       (uint8_t)(~(uint8_t)SPI_C2_MODFEN_MASK))) : ( \
      ((Function) == SPI_PDD_SS_FOR_FAULT_DETECT) ? ( \
       (SPI_C1_REG(peripheralBase) &= \
        (uint8_t)(~(uint8_t)SPI_C1_SSOE_MASK)), \
       (SPI_C2_REG(peripheralBase) |= \
        SPI_C2_MODFEN_MASK)) : ( \
       (SPI_C1_REG(peripheralBase) |= \
        SPI_C1_SSOE_MASK), \
       (SPI_C2_REG(peripheralBase) |= \
        SPI_C2_MODFEN_MASK)) \
     ) \
  )

/* ----------------------------------------------------------------------------
   -- SetDataShiftOrder
   ---------------------------------------------------------------------------- */

/**
 * Sets the SPI data shift order.
 * @param peripheralBase Peripheral base address.
 * @param Order SPI data shift order value. The user should use one from the
 *        enumerated values.
 */
#define SPI_PDD_SetDataShiftOrder(peripheralBase, Order) ( \
    SPI_C1_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(SPI_C1_REG(peripheralBase) & (uint8_t)(~(uint8_t)SPI_C1_LSBFE_MASK))) | ( \
      (uint8_t)(Order))) \
  )

/* ----------------------------------------------------------------------------
   -- SetDataFeatures
   ---------------------------------------------------------------------------- */

/**
 * Sets data transmission features(shift order, clock polarity and phase)
 * defined by mask parameter.
 * @param peripheralBase Peripheral base address.
 * @param Mask Mask of data features requests.
 */
#define SPI_PDD_SetDataFeatures(peripheralBase, Mask) ( \
    SPI_C1_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(( \
       SPI_C1_REG(peripheralBase)) & ( \
       (uint8_t)(~(uint8_t)(SPI_C1_LSBFE_MASK | (SPI_C1_CPOL_MASK | SPI_C1_CPHA_MASK)))))) | ( \
      (uint8_t)(Mask))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableMatchInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables receive data buffer hardware match interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define SPI_PDD_EnableMatchInterrupt(peripheralBase) ( \
    SPI_C2_REG(peripheralBase) |= \
     SPI_C2_SPMIE_MASK \
  )

/* ----------------------------------------------------------------------------
   -- DisableMatchInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables receive data buffer hardware match interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define SPI_PDD_DisableMatchInterrupt(peripheralBase) ( \
    SPI_C2_REG(peripheralBase) &= \
     (uint8_t)(~(uint8_t)SPI_C2_SPMIE_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- EnableTransmitDma
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables a transmit DMA request.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state of transmit DMA request.
 */
#define SPI_PDD_EnableTransmitDma(peripheralBase, State) ( \
    SPI_C2_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(SPI_C2_REG(peripheralBase) & (uint8_t)(~(uint8_t)SPI_C2_TXDMAE_MASK))) | ( \
      (uint8_t)((uint8_t)(State) << SPI_C2_TXDMAE_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableOutputInBidirectionalMode
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables pin direction in a bidirectional mode.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state of output pin in bidirectional mode.
 */
#define SPI_PDD_EnableOutputInBidirectionalMode(peripheralBase, State) ( \
    SPI_C2_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(SPI_C2_REG(peripheralBase) & (uint8_t)(~(uint8_t)SPI_C2_BIDIROE_MASK))) | ( \
      (uint8_t)((uint8_t)(State) << SPI_C2_BIDIROE_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableReceiveDma
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables a receive DMA request.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state of receive DMA request.
 */
#define SPI_PDD_EnableReceiveDma(peripheralBase, State) ( \
    SPI_C2_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(SPI_C2_REG(peripheralBase) & (uint8_t)(~(uint8_t)SPI_C2_RXDMAE_MASK))) | ( \
      (uint8_t)((uint8_t)(State) << SPI_C2_RXDMAE_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableOperateInWaitMode
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables operate in wait mode.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state of device in wait mode.
 */
#define SPI_PDD_EnableOperateInWaitMode(peripheralBase, State) ( \
    ((State) == PDD_ENABLE) ? ( \
      SPI_C2_REG(peripheralBase) &= \
       (uint8_t)(~(uint8_t)SPI_C2_SPISWAI_MASK)) : ( \
      SPI_C2_REG(peripheralBase) |= \
       (uint8_t)((uint8_t)0x1U << SPI_C2_SPISWAI_SHIFT)) \
  )

/* ----------------------------------------------------------------------------
   -- EnableLowPowerInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables generation of an asynchronous interrupt to wake the CPU from
 * wait mode or stop mode.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state of the asynchronous interrupt.
 */
#define SPI_PDD_EnableLowPowerInterrupt(peripheralBase, State) ( \
    SPI_C2_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(SPI_C2_REG(peripheralBase) & (uint8_t)(~(uint8_t)SPI_C2_SPLPIE_MASK))) | ( \
      (uint8_t)((uint8_t)(State) << SPI_C2_SPLPIE_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableBidirectionalMode
   ---------------------------------------------------------------------------- */

/**
 * Enables/disables bidirectional mode.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state of bidirectional mode.
 */
#define SPI_PDD_EnableBidirectionalMode(peripheralBase, State) ( \
    SPI_C2_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(SPI_C2_REG(peripheralBase) & (uint8_t)(~(uint8_t)SPI_C2_SPC0_MASK))) | ( \
      (uint8_t)(State))) \
  )

/* ----------------------------------------------------------------------------
   -- SetBaudRatePrescaler
   ---------------------------------------------------------------------------- */

/**
 * Sets the SPI baud rate prescale divisor.
 * @param peripheralBase Peripheral base address.
 * @param Prescaler Baud rate prescale divisor value[0..7].
 */
#define SPI_PDD_SetBaudRatePrescaler(peripheralBase, Prescaler) ( \
    SPI_BR_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(SPI_BR_REG(peripheralBase) & (uint8_t)(~(uint8_t)SPI_BR_SPPR_MASK))) | ( \
      (uint8_t)((uint8_t)(Prescaler) << SPI_BR_SPPR_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- SetBaudRateDivisor
   ---------------------------------------------------------------------------- */

/**
 * Sets the SPI baud rate divisor.
 * @param peripheralBase Peripheral base address.
 * @param Divisor Baud rate divisor value[0..15].
 */
#define SPI_PDD_SetBaudRateDivisor(peripheralBase, Divisor) ( \
    SPI_BR_REG(peripheralBase) = \
     (uint8_t)(( \
      (uint8_t)(SPI_BR_REG(peripheralBase) & (uint8_t)(~(uint8_t)SPI_BR_SPR_MASK))) | ( \
      (uint8_t)(Divisor))) \
  )

/* ----------------------------------------------------------------------------
   -- WriteBaudRateReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the baud rate register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value stored to the baud rate register.
 */
#define SPI_PDD_WriteBaudRateReg(peripheralBase, Value) ( \
    SPI_BR_REG(peripheralBase) = \
     (uint8_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- WriteData8Bit
   ---------------------------------------------------------------------------- */

/**
 * Writes 8 bit data value to the data register.
 * @param peripheralBase Peripheral base address.
 * @param Data 8 bit data value.
 */
#define SPI_PDD_WriteData8Bit(peripheralBase, Data) ( \
    SPI_D_REG(peripheralBase) = \
     (uint8_t)(Data) \
  )

/* ----------------------------------------------------------------------------
   -- ReadData8bit
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the 8 bit data register.
 * @param peripheralBase Peripheral base address.
 */
#define SPI_PDD_ReadData8bit(peripheralBase) ( \
    SPI_D_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- SetMatch8BitValue
   ---------------------------------------------------------------------------- */

/**
 * Writes 8 bit match value to the match register.
 * @param peripheralBase Peripheral base address.
 * @param Value 8 bit match value.
 */
#define SPI_PDD_SetMatch8BitValue(peripheralBase, Value) ( \
    SPI_M_REG(peripheralBase) = \
     (uint8_t)(Value) \
  )
#endif  /* #if defined(SPI_PDD_H_) */

/* SPI_PDD.h, eof. */
