/*
  PDD layer implementation for peripheral type DMA
  (C) 2010 Freescale, Inc. All rights reserved.

  This file is static and it is generated from API-Factory
*/

#if !defined(DMA_PDD_H_)
#define DMA_PDD_H_

/* ----------------------------------------------------------------------------
   -- Test if supported MCU is active
   ---------------------------------------------------------------------------- */

#if !defined(MCU_ACTIVE)
  // No MCU is active
  #error DMA PDD library: No derivative is active. Place proper #include with PDD memory map before including PDD library.
#elif \
      !defined(MCU_MK10D10) /* DMA */ && \
      !defined(MCU_MK10D5) /* DMA */ && \
      !defined(MCU_MK10D7) /* DMA */ && \
      !defined(MCU_MK10F12) /* DMA */ && \
      !defined(MCU_MK10DZ10) /* DMA */ && \
      !defined(MCU_MK11D5) /* DMA */ && \
      !defined(MCU_MK12D5) /* DMA */ && \
      !defined(MCU_MK20D10) /* DMA */ && \
      !defined(MCU_MK20D5) /* DMA */ && \
      !defined(MCU_MK20D7) /* DMA */ && \
      !defined(MCU_MK20F12) /* DMA */ && \
      !defined(MCU_MK20DZ10) /* DMA */ && \
      !defined(MCU_MK21D5) /* DMA */ && \
      !defined(MCU_MK22D5) /* DMA */ && \
      !defined(MCU_MK30D10) /* DMA */ && \
      !defined(MCU_MK30D7) /* DMA */ && \
      !defined(MCU_MK30DZ10) /* DMA */ && \
      !defined(MCU_MK40D10) /* DMA */ && \
      !defined(MCU_MK40D7) /* DMA */ && \
      !defined(MCU_MK40DZ10) /* DMA */ && \
      !defined(MCU_MK40X256VMD100) /* DMA */ && \
      !defined(MCU_MK50D10) /* DMA */ && \
      !defined(MCU_MK50D7) /* DMA */ && \
      !defined(MCU_MK50DZ10) /* DMA */ && \
      !defined(MCU_MK51D10) /* DMA */ && \
      !defined(MCU_MK51D7) /* DMA */ && \
      !defined(MCU_MK51DZ10) /* DMA */ && \
      !defined(MCU_MK52D10) /* DMA */ && \
      !defined(MCU_MK52DZ10) /* DMA */ && \
      !defined(MCU_MK53D10) /* DMA */ && \
      !defined(MCU_MK53DZ10) /* DMA */ && \
      !defined(MCU_MK60D10) /* DMA */ && \
      !defined(MCU_MK60F12) /* DMA */ && \
      !defined(MCU_MK60F15) /* DMA */ && \
      !defined(MCU_MK60DZ10) /* DMA */ && \
      !defined(MCU_MK60N512VMD100) /* DMA */ && \
      !defined(MCU_MK61F12) /* DMA */ && \
      !defined(MCU_MK61F15) /* DMA */ && \
      !defined(MCU_MK70F12) /* DMA */ && \
      !defined(MCU_MK70F15) /* DMA */ && \
      !defined(MCU_MKL04Z4) /* DMA */ && \
      !defined(MCU_MKL05Z4) /* DMA */ && \
      !defined(MCU_MKL14Z4) /* DMA */ && \
      !defined(MCU_MKL15Z4) /* DMA */ && \
      !defined(MCU_MKL24Z4) /* DMA */ && \
      !defined(MCU_MKL25Z4) /* DMA */ && \
      !defined(MCU_PCK20L4) /* DMA */
  // Unsupported MCU is active
  #error DMA PDD library: Unsupported derivative is active.
#endif

#include "PDD_Types.h"

/* ----------------------------------------------------------------------------
   -- Method symbol definitions
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MK10D5)) || (defined(MCU_MK20D5)))
/* DMA channel number constants. */
  #define DMA_PDD_CHANNEL_0 0U                     /**< Channel 0. */
  #define DMA_PDD_CHANNEL_1 0x1U                   /**< Channel 1. */
  #define DMA_PDD_CHANNEL_2 0x2U                   /**< Channel 2. */
  #define DMA_PDD_CHANNEL_3 0x3U                   /**< Channel 3. */

#elif ((defined(MCU_MKL04Z4)) || (defined(MCU_MKL05Z4)) || (defined(MCU_MKL14Z4)) || (defined(MCU_MKL15Z4)) || (defined(MCU_MKL24Z4)) || (defined(MCU_MKL25Z4)) || (defined(MCU_PCK20L4)))
/* DMA channel constants. */
  #define DMA_PDD_CHANNEL_0 0U                     /**< Channel 0. */
  #define DMA_PDD_CHANNEL_1 0x1U                   /**< Channel 1. */
  #define DMA_PDD_CHANNEL_2 0x2U                   /**< Channel 2. */
  #define DMA_PDD_CHANNEL_3 0x3U                   /**< Channel 3. */

#elif ((defined(MCU_MK10F12)) || (defined(MCU_MK20F12)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)))
/* DMA channel number constants. */
  #define DMA_PDD_CHANNEL_0 0U                     /**< Channel 0. */
  #define DMA_PDD_CHANNEL_1 0x1U                   /**< Channel 1. */
  #define DMA_PDD_CHANNEL_2 0x2U                   /**< Channel 2. */
  #define DMA_PDD_CHANNEL_3 0x3U                   /**< Channel 3. */
  #define DMA_PDD_CHANNEL_4 0x4U                   /**< Channel 4. */
  #define DMA_PDD_CHANNEL_5 0x5U                   /**< Channel 5. */
  #define DMA_PDD_CHANNEL_6 0x6U                   /**< Channel 6. */
  #define DMA_PDD_CHANNEL_7 0x7U                   /**< Channel 7. */
  #define DMA_PDD_CHANNEL_8 0x8U                   /**< Channel 8. */
  #define DMA_PDD_CHANNEL_9 0x9U                   /**< Channel 9. */
  #define DMA_PDD_CHANNEL_10 0xAU                  /**< Channel 10. */
  #define DMA_PDD_CHANNEL_11 0xBU                  /**< Channel 11. */
  #define DMA_PDD_CHANNEL_12 0xCU                  /**< Channel 12. */
  #define DMA_PDD_CHANNEL_13 0xDU                  /**< Channel 13. */
  #define DMA_PDD_CHANNEL_14 0xEU                  /**< Channel 14. */
  #define DMA_PDD_CHANNEL_15 0xFU                  /**< Channel 15. */
  #define DMA_PDD_CHANNEL_16 0x10U                 /**< Channel 16. */
  #define DMA_PDD_CHANNEL_17 0x11U                 /**< Channel 17. */
  #define DMA_PDD_CHANNEL_18 0x12U                 /**< Channel 18. */
  #define DMA_PDD_CHANNEL_19 0x13U                 /**< Channel 19. */
  #define DMA_PDD_CHANNEL_20 0x14U                 /**< Channel 20. */
  #define DMA_PDD_CHANNEL_21 0x15U                 /**< Channel 21. */
  #define DMA_PDD_CHANNEL_22 0x16U                 /**< Channel 22. */
  #define DMA_PDD_CHANNEL_23 0x17U                 /**< Channel 23. */
  #define DMA_PDD_CHANNEL_24 0x18U                 /**< Channel 24. */
  #define DMA_PDD_CHANNEL_25 0x19U                 /**< Channel 25. */
  #define DMA_PDD_CHANNEL_26 0x1AU                 /**< Channel 26. */
  #define DMA_PDD_CHANNEL_27 0x1BU                 /**< Channel 27. */
  #define DMA_PDD_CHANNEL_28 0x1CU                 /**< Channel 28. */
  #define DMA_PDD_CHANNEL_29 0x1DU                 /**< Channel 29. */
  #define DMA_PDD_CHANNEL_30 0x1EU                 /**< Channel 30. */
  #define DMA_PDD_CHANNEL_31 0x1FU                 /**< Channel 31. */

#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60N512VMD100)) */
/* DMA channel number constants. */
  #define DMA_PDD_CHANNEL_0 0U                     /**< Channel 0. */
  #define DMA_PDD_CHANNEL_1 0x1U                   /**< Channel 1. */
  #define DMA_PDD_CHANNEL_2 0x2U                   /**< Channel 2. */
  #define DMA_PDD_CHANNEL_3 0x3U                   /**< Channel 3. */
  #define DMA_PDD_CHANNEL_4 0x4U                   /**< Channel 4. */
  #define DMA_PDD_CHANNEL_5 0x5U                   /**< Channel 5. */
  #define DMA_PDD_CHANNEL_6 0x6U                   /**< Channel 6. */
  #define DMA_PDD_CHANNEL_7 0x7U                   /**< Channel 7. */
  #define DMA_PDD_CHANNEL_8 0x8U                   /**< Channel 8. */
  #define DMA_PDD_CHANNEL_9 0x9U                   /**< Channel 9. */
  #define DMA_PDD_CHANNEL_10 0xAU                  /**< Channel 10. */
  #define DMA_PDD_CHANNEL_11 0xBU                  /**< Channel 11. */
  #define DMA_PDD_CHANNEL_12 0xCU                  /**< Channel 12. */
  #define DMA_PDD_CHANNEL_13 0xDU                  /**< Channel 13. */
  #define DMA_PDD_CHANNEL_14 0xEU                  /**< Channel 14. */
  #define DMA_PDD_CHANNEL_15 0xFU                  /**< Channel 15. */

#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60N512VMD100)) */
#if ((defined(MCU_MK10D5)) || (defined(MCU_MK20D5)))
/* DMA channel mask constants. */
  #define DMA_PDD_CHANNEL_MASK_0 0x1U              /**< Channel 0. */
  #define DMA_PDD_CHANNEL_MASK_1 0x2U              /**< Channel 1. */
  #define DMA_PDD_CHANNEL_MASK_2 0x4U              /**< Channel 2. */
  #define DMA_PDD_CHANNEL_MASK_3 0x8U              /**< Channel 3. */

#elif ((defined(MCU_MK10F12)) || (defined(MCU_MK20F12)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)))
/* DMA channel mask constants. */
  #define DMA_PDD_CHANNEL_MASK_0 0x1U              /**< Channel 0. */
  #define DMA_PDD_CHANNEL_MASK_1 0x2U              /**< Channel 1. */
  #define DMA_PDD_CHANNEL_MASK_2 0x4U              /**< Channel 2. */
  #define DMA_PDD_CHANNEL_MASK_3 0x8U              /**< Channel 3. */
  #define DMA_PDD_CHANNEL_MASK_4 0x10U             /**< Channel 4. */
  #define DMA_PDD_CHANNEL_MASK_5 0x20U             /**< Channel 5. */
  #define DMA_PDD_CHANNEL_MASK_6 0x40U             /**< Channel 6. */
  #define DMA_PDD_CHANNEL_MASK_7 0x80U             /**< Channel 7. */
  #define DMA_PDD_CHANNEL_MASK_8 0x100U            /**< Channel 8. */
  #define DMA_PDD_CHANNEL_MASK_9 0x200U            /**< Channel 9. */
  #define DMA_PDD_CHANNEL_MASK_10 0x400U           /**< Channel 10. */
  #define DMA_PDD_CHANNEL_MASK_11 0x800U           /**< Channel 11. */
  #define DMA_PDD_CHANNEL_MASK_12 0x1000U          /**< Channel 12. */
  #define DMA_PDD_CHANNEL_MASK_13 0x2000U          /**< Channel 13. */
  #define DMA_PDD_CHANNEL_MASK_14 0x4000U          /**< Channel 14. */
  #define DMA_PDD_CHANNEL_MASK_15 0x8000U          /**< Channel 15. */
  #define DMA_PDD_CHANNEL_MASK_16 0x10000U         /**< Channel 16. */
  #define DMA_PDD_CHANNEL_MASK_17 0x20000U         /**< Channel 17. */
  #define DMA_PDD_CHANNEL_MASK_18 0x40000U         /**< Channel 18. */
  #define DMA_PDD_CHANNEL_MASK_19 0x80000U         /**< Channel 19. */
  #define DMA_PDD_CHANNEL_MASK_20 0x100000U        /**< Channel 20. */
  #define DMA_PDD_CHANNEL_MASK_21 0x200000U        /**< Channel 21. */
  #define DMA_PDD_CHANNEL_MASK_22 0x400000U        /**< Channel 22. */
  #define DMA_PDD_CHANNEL_MASK_23 0x800000U        /**< Channel 23. */
  #define DMA_PDD_CHANNEL_MASK_24 0x1000000U       /**< Channel 24. */
  #define DMA_PDD_CHANNEL_MASK_25 0x2000000U       /**< Channel 25. */
  #define DMA_PDD_CHANNEL_MASK_26 0x4000000U       /**< Channel 26. */
  #define DMA_PDD_CHANNEL_MASK_27 0x8000000U       /**< Channel 27. */
  #define DMA_PDD_CHANNEL_MASK_28 0x10000000U      /**< Channel 28. */
  #define DMA_PDD_CHANNEL_MASK_29 0x20000000U      /**< Channel 29. */
  #define DMA_PDD_CHANNEL_MASK_30 0x40000000U      /**< Channel 30. */
  #define DMA_PDD_CHANNEL_MASK_31 0x80000000U      /**< Channel 31. */

#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60N512VMD100)) */
/* DMA channel mask constants. */
  #define DMA_PDD_CHANNEL_MASK_0 0x1U              /**< Channel 0. */
  #define DMA_PDD_CHANNEL_MASK_1 0x2U              /**< Channel 1. */
  #define DMA_PDD_CHANNEL_MASK_2 0x4U              /**< Channel 2. */
  #define DMA_PDD_CHANNEL_MASK_3 0x8U              /**< Channel 3. */
  #define DMA_PDD_CHANNEL_MASK_4 0x10U             /**< Channel 4. */
  #define DMA_PDD_CHANNEL_MASK_5 0x20U             /**< Channel 5. */
  #define DMA_PDD_CHANNEL_MASK_6 0x40U             /**< Channel 6. */
  #define DMA_PDD_CHANNEL_MASK_7 0x80U             /**< Channel 7. */
  #define DMA_PDD_CHANNEL_MASK_8 0x100U            /**< Channel 8. */
  #define DMA_PDD_CHANNEL_MASK_9 0x200U            /**< Channel 9. */
  #define DMA_PDD_CHANNEL_MASK_10 0x400U           /**< Channel 10. */
  #define DMA_PDD_CHANNEL_MASK_11 0x800U           /**< Channel 11. */
  #define DMA_PDD_CHANNEL_MASK_12 0x1000U          /**< Channel 12. */
  #define DMA_PDD_CHANNEL_MASK_13 0x2000U          /**< Channel 13. */
  #define DMA_PDD_CHANNEL_MASK_14 0x4000U          /**< Channel 14. */
  #define DMA_PDD_CHANNEL_MASK_15 0x8000U          /**< Channel 15. */

#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60N512VMD100)) */
/* Channel major loop linking disabled bit mask. */
#define DMA_PDD_MAJOR_LINK_DISABLED 0U           /**< Channel major loop linking disabled */

/* Channel major loop linking enabled bit mask. */
#define DMA_PDD_MAJOR_LINK_ENABLED DMA_CSR_MAJORELINK_MASK /**< Channel major loop linking enabled */

/* Channel scatter/gather disabled bit mask. */
#define DMA_PDD_SCATTER_GATHER_DISABLED 0U       /**< Channel scatter/gather disabled */

/* Channel scatter/gather enabled bit mask. */
#define DMA_PDD_SCATTER_GATHER_ENABLED DMA_CSR_ESG_MASK /**< Channel scatter/gather enabled */

/* Enable channel after request bit mask. */
#define DMA_PDD_ENABLE_AFTER_REQUEST 0U          /**< Enable channel after request */

/* Disable channel after request bit mask. */
#define DMA_PDD_DISABLE_AFTER_REQUEST DMA_CSR_DREQ_MASK /**< Disable channel after request */

/* Minor loop offset bit position value. */
#define DMA_PDD_MINOR_LOOP_OFFSET_SHIFT 0U       /**< Minor loop offset bit position value. */

/* Constants used in SetChannelPriority. */
#define DMA_PDD_DCHPRI_DPA_MASK DMA_DCHPRI3_DPA_MASK /**< Disable preempt ability bit mask. */
#define DMA_PDD_DCHPRI_CHPRI_MASK DMA_DCHPRI3_CHPRI_MASK /**< Channel arbitration priority bit group mask. */
#define DMA_PDD_DCHPRI_ECP_SHIFT 0x7U            /**< Enable channel preemption bit position. */
#define DMA_PDD_DCHPRI_CHPRI_SHIFT 0U            /**< Channel arbitration priority bit group position. */

/* Constant specifying if DMA channel can be temporarily suspended by the
   service request of a higher priority channel. */
#define DMA_PDD_CHANNEL_CAN_BE_PREEMPTED 0U      /**< Channel can be preempted. */
#define DMA_PDD_CHANNEL_CANNOT_BE_PREEMPTED DMA_DCHPRI3_ECP_MASK /**< Channel can't be preempted. */

/* Constant specifying if DMA channel can suspend a lower priority channel. */
#define DMA_PDD_CHANNEL_CAN_PREEMPT_OTHER 0U     /**< Channel can suspend other channels. */
#define DMA_PDD_CHANNEL_CANNOT_PREEMPT_OTHER DMA_DCHPRI3_DPA_MASK /**< Channel can't suspend other channels. */

#if ((defined(MCU_MKL04Z4)) || (defined(MCU_MKL05Z4)) || (defined(MCU_MKL14Z4)) || (defined(MCU_MKL15Z4)) || (defined(MCU_MKL24Z4)) || (defined(MCU_MKL25Z4)) || (defined(MCU_PCK20L4)))
/* Circular buffer size constants. */
  #define DMA_PDD_CIRCULAR_BUFFER_DISABLED 0U      /**< Circular buffer disabled. */
  #define DMA_PDD_CIRCULAR_BUFFER_16_BYTES 0x1U    /**< 16 bytes circular buffer. */
  #define DMA_PDD_CIRCULAR_BUFFER_32_BYTES 0x2U    /**< 32 bytes circular buffer. */
  #define DMA_PDD_CIRCULAR_BUFFER_64_BYTES 0x3U    /**< 64 bytes circular buffer. */
  #define DMA_PDD_CIRCULAR_BUFFER_128_BYTES 0x4U   /**< 128 bytes circular buffer. */
  #define DMA_PDD_CIRCULAR_BUFFER_256_BYTES 0x5U   /**< 256 bytes circular buffer. */
  #define DMA_PDD_CIRCULAR_BUFFER_512_BYTES 0x6U   /**< 512 bytes circular buffer. */
  #define DMA_PDD_CIRCULAR_BUFFER_1_KBYTE 0x7U     /**< 1 Kbyte circular buffer. */
  #define DMA_PDD_CIRCULAR_BUFFER_2_KBYTES 0x8U    /**< 2 Kbytes circular buffer. */
  #define DMA_PDD_CIRCULAR_BUFFER_4_KBYTES 0x9U    /**< 4 Kbytes circular buffer. */
  #define DMA_PDD_CIRCULAR_BUFFER_8_KBYTES 0xAU    /**< 8 Kbytes circular buffer. */
  #define DMA_PDD_CIRCULAR_BUFFER_16_KBYTES 0xBU   /**< 16 Kbytes circular buffer. */
  #define DMA_PDD_CIRCULAR_BUFFER_32_KBYTES 0xCU   /**< 32 Kbytes circular buffer. */
  #define DMA_PDD_CIRCULAR_BUFFER_64_KBYTES 0xDU   /**< 64 Kbytes circular buffer. */
  #define DMA_PDD_CIRCULAR_BUFFER_128_KBYTES 0xEU  /**< 128 Kbytes circular buffer. */
  #define DMA_PDD_CIRCULAR_BUFFER_256_KBYTES 0xFU  /**< 256 Kbytes circular buffer. */

#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */
/* Circular buffer size constants. */
  #define DMA_PDD_CIRCULAR_BUFFER_DISABLED 0U      /**< Circular buffer disabled. */
  #define DMA_PDD_CIRCULAR_BUFFER_2_BYTES 0x1U     /**< 2 bytes circular buffer. */
  #define DMA_PDD_CIRCULAR_BUFFER_4_BYTES 0x2U     /**< 4 bytes circular buffer. */
  #define DMA_PDD_CIRCULAR_BUFFER_8_BYTES 0x3U     /**< 8 bytes circular buffer. */
  #define DMA_PDD_CIRCULAR_BUFFER_16_BYTES 0x4U    /**< 16 bytes circular buffer. */
  #define DMA_PDD_CIRCULAR_BUFFER_32_BYTES 0x5U    /**< 32 bytes circular buffer. */
  #define DMA_PDD_CIRCULAR_BUFFER_64_BYTES 0x6U    /**< 64 bytes circular buffer. */
  #define DMA_PDD_CIRCULAR_BUFFER_128_BYTES 0x7U   /**< 128 bytes circular buffer. */
  #define DMA_PDD_CIRCULAR_BUFFER_256_BYTES 0x8U   /**< 256 bytes circular buffer. */
  #define DMA_PDD_CIRCULAR_BUFFER_512_BYTES 0x9U   /**< 512 bytes circular buffer. */
  #define DMA_PDD_CIRCULAR_BUFFER_1_KBYTE 0xAU     /**< 1 Kbyte circular buffer. */
  #define DMA_PDD_CIRCULAR_BUFFER_2_KBYTES 0xBU    /**< 2 Kbytes circular buffer. */
  #define DMA_PDD_CIRCULAR_BUFFER_4_KBYTES 0xCU    /**< 4 Kbytes circular buffer. */
  #define DMA_PDD_CIRCULAR_BUFFER_8_KBYTES 0xDU    /**< 8 Kbytes circular buffer. */
  #define DMA_PDD_CIRCULAR_BUFFER_16_KBYTES 0xEU   /**< 16 Kbytes circular buffer. */
  #define DMA_PDD_CIRCULAR_BUFFER_32_KBYTES 0xFU   /**< 32 Kbytes circular buffer. */
  #define DMA_PDD_CIRCULAR_BUFFER_64_KBYTES 0x10U  /**< 64 Kbytes circular buffer. */
  #define DMA_PDD_CIRCULAR_BUFFER_128_KBYTES 0x11U /**< 128 Kbytes circular buffer. */
  #define DMA_PDD_CIRCULAR_BUFFER_256_KBYTES 0x12U /**< 256 Kbytes circular buffer. */
  #define DMA_PDD_CIRCULAR_BUFFER_512_KBYTES 0x13U /**< 512 Kbytes circular buffer. */
  #define DMA_PDD_CIRCULAR_BUFFER_1_MBYTE 0x14U    /**< 1 Mbyte circular buffer. */
  #define DMA_PDD_CIRCULAR_BUFFER_2_MBYTES 0x15U   /**< 2 Mbytes circular buffer. */
  #define DMA_PDD_CIRCULAR_BUFFER_4_MBYTES 0x16U   /**< 4 Mbytes circular buffer. */
  #define DMA_PDD_CIRCULAR_BUFFER_8_MBYTES 0x17U   /**< 8 Mbytes circular buffer. */
  #define DMA_PDD_CIRCULAR_BUFFER_16_MBYTES 0x18U  /**< 16 Mbytes circular buffer. */
  #define DMA_PDD_CIRCULAR_BUFFER_32_MBYTES 0x19U  /**< 32 Mbytes circular buffer. */
  #define DMA_PDD_CIRCULAR_BUFFER_64_MBYTES 0x1AU  /**< 64 Mbytes circular buffer. */
  #define DMA_PDD_CIRCULAR_BUFFER_128_MBYTES 0x1BU /**< 128 Mbytes circular buffer. */
  #define DMA_PDD_CIRCULAR_BUFFER_256_MBYTES 0x1CU /**< 256 Mbytes circular buffer. */
  #define DMA_PDD_CIRCULAR_BUFFER_512_MBYTES 0x1DU /**< 512 Mbytes circular buffer. */
  #define DMA_PDD_CIRCULAR_BUFFER_1_GBYTE 0x1EU    /**< 1 Gbyte circular buffer. */
  #define DMA_PDD_CIRCULAR_BUFFER_2_GBYTES 0x1FU   /**< 2 Gbytes circular buffer. */

#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */
#if ((defined(MCU_MKL04Z4)) || (defined(MCU_MKL05Z4)) || (defined(MCU_MKL14Z4)) || (defined(MCU_MKL15Z4)) || (defined(MCU_MKL24Z4)) || (defined(MCU_MKL25Z4)) || (defined(MCU_PCK20L4)))
/* Channel activity status constants. */
  #define DMA_PDD_TRANSFER_DONE_FLAG DMA_DSR_BCR_DONE_MASK /**< Transfer done flag. */
  #define DMA_PDD_TRANSFER_BUSY_FLAG DMA_DSR_BCR_BSY_MASK /**< Transfer in progress flag. */
  #define DMA_PDD_TRANSFER_REQUEST_PENDING_FLAG DMA_DSR_BCR_REQ_MASK /**< Transfer request pending flag. */

#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */
/* Channel activity status constants. */
  #define DMA_PDD_TRANSFER_DONE_FLAG DMA_CSR_DONE_MASK /**< Transfer done flag. */
  #define DMA_PDD_TRANSFER_ACTIVE_FLAG DMA_CSR_ACTIVE_MASK /**< Transfer in progress flag. */

#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */
#if ((defined(MCU_MKL04Z4)) || (defined(MCU_MKL05Z4)) || (defined(MCU_MKL14Z4)) || (defined(MCU_MKL15Z4)) || (defined(MCU_MKL24Z4)) || (defined(MCU_MKL25Z4)) || (defined(MCU_PCK20L4)))
/* Transfer complete interrupt enable/disable constants. */
  #define DMA_PDD_TRANSFER_COMPLETE_ENABLE DMA_DCR_EINT_MASK /**< Transfer complete interrupt enabled. */
  #define DMA_PDD_TRANSFER_COMPLETE_DISABLE 0U     /**< Transfer complete interrupt disabled. */

#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */
/* Transfer complete interrupt enable/disable constants. */
  #define DMA_PDD_TRANSFER_COMPLETE_ENABLE DMA_CSR_INTMAJOR_MASK /**< Transfer complete interrupt enabled. */
  #define DMA_PDD_TRANSFER_COMPLETE_DISABLE 0U     /**< Transfer complete interrupt disabled. */

#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */
/* Interrupts' mask. */
#define DMA_PDD_TRANSFER_COMPLETE_INTERRUPT DMA_DCR_EINT_MASK /**< Transfer complete interrupt mask. */

/* Interrupts' flags. */
#define DMA_PDD_TRANSFER_COMPLETE_FLAG DMA_DSR_BCR_DONE_MASK /**< Transfer complete flag. */

/* Channel request source constants. */
#define DMA_PDD_CHANNEL_SOURCE_0 0U              /**< Channel request source 0. */
#define DMA_PDD_CHANNEL_SOURCE_1 0x1U            /**< Channel request source 1. */
#define DMA_PDD_CHANNEL_SOURCE_2 0x2U            /**< Channel request source 2. */
#define DMA_PDD_CHANNEL_SOURCE_3 0x3U            /**< Channel request source 3. */
#define DMA_PDD_CHANNEL_SOURCE_4 0x4U            /**< Channel request source 4. */
#define DMA_PDD_CHANNEL_SOURCE_5 0x5U            /**< Channel request source 5. */
#define DMA_PDD_CHANNEL_SOURCE_6 0x6U            /**< Channel request source 6. */
#define DMA_PDD_CHANNEL_SOURCE_7 0x7U            /**< Channel request source 7. */
#define DMA_PDD_CHANNEL_SOURCE_8 0x8U            /**< Channel request source 8. */
#define DMA_PDD_CHANNEL_SOURCE_9 0x9U            /**< Channel request source 9. */
#define DMA_PDD_CHANNEL_SOURCE_10 0xAU           /**< Channel request source 10. */
#define DMA_PDD_CHANNEL_SOURCE_11 0xBU           /**< Channel request source 11. */
#define DMA_PDD_CHANNEL_SOURCE_12 0xCU           /**< Channel request source 12. */
#define DMA_PDD_CHANNEL_SOURCE_13 0xDU           /**< Channel request source 13. */
#define DMA_PDD_CHANNEL_SOURCE_14 0xEU           /**< Channel request source 14. */
#define DMA_PDD_CHANNEL_SOURCE_15 0xFU           /**< Channel request source 15. */

/* Channel error status constants. */
#define DMA_PDD_CONFIGURATION_ERROR_FLAG DMA_DSR_BCR_CE_MASK /**< Configuration error flag. */
#define DMA_PDD_ERROR_ON_SOURCE_FLAG DMA_DSR_BCR_BES_MASK /**< Error on source side flag. */
#define DMA_PDD_ERROR_ON_DESTINATION_FLAG DMA_DSR_BCR_BED_MASK /**< Error on destination side flag. */

/* Set all or only one DMA channel. Used in Set/Clear macros to distinct between
   setting/clearing attribute of one specified channel or of all channels. */
#define DMA_PDD_ONE_CHANNEL 0U                   /**< Set only one DMA channel. */
#define DMA_PDD_ALL_CHANNELS DMA_SERQ_SAER_MASK  /**< Set all DMA channels. */

#if ((defined(MCU_MKL04Z4)) || (defined(MCU_MKL05Z4)) || (defined(MCU_MKL14Z4)) || (defined(MCU_MKL15Z4)) || (defined(MCU_MKL24Z4)) || (defined(MCU_MKL25Z4)) || (defined(MCU_PCK20L4)))
/* DMA data transfer block size. */
  #define DMA_PDD_8_BIT 0x1U                       /**< 8-bit transfer size. */
  #define DMA_PDD_16_BIT 0x2U                      /**< 16-bit transfer size. */
  #define DMA_PDD_32_BIT 0U                        /**< 32-bit transfer size. */

#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */
/* DMA data transfer block size. */
  #define DMA_PDD_8_BIT 0U                         /**< 8-bit transfer size. */
  #define DMA_PDD_16_BIT 0x1U                      /**< 16-bit transfer size. */
  #define DMA_PDD_32_BIT 0x2U                      /**< 32-bit transfer size. */
  #define DMA_PDD_16_BYTE 0x4U                     /**< 16-byte transfer size. */

#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */
/* DMA stall time value. */
#define DMA_PDD_NO_STALL 0U                      /**< No stall. */
#define DMA_PDD_STALL_4_CYCLES 0x8000U           /**< Stall 4 cycles. */
#define DMA_PDD_STALL_8_CYCLES 0xC000U           /**< Stall 8 cycles. */

/* DMA data transfer size. */
#define DMA_PDD_LINKING_DISABLED 0U              /**< Channel linking disabled. */
#define DMA_PDD_CYCLE_STEAL_AND_TRANSFER_COMPLETE_LINKING 0x10U /**< Channel linked after each cycle-steal transfer and after transfer complete. */
#define DMA_PDD_CYCLE_STEAL_LINKING 0x20U        /**< Channel linked only after each cycle-steal transfer. */
#define DMA_PDD_TRANSFER_COMPLETE_LINKING 0x30U  /**< Channel linked only after transfer complete. */


/* ----------------------------------------------------------------------------
   -- WriteControlReg
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MKL04Z4)) || (defined(MCU_MKL05Z4)) || (defined(MCU_MKL14Z4)) || (defined(MCU_MKL15Z4)) || (defined(MCU_MKL24Z4)) || (defined(MCU_MKL25Z4)) || (defined(MCU_PCK20L4)))
/**
 * Writes to DMA channel control register.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number. Use constants from group "DMA channel
 *        constants.".
 * @param Value DMA channel control register value.
 */
  #define DMA_PDD_WriteControlReg(peripheralBase, Channel, Value) ( \
      DMA_DCR_REG(peripheralBase,(Channel)) = \
       (uint32_t)(Value) \
    )
#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */
/**
 * Writes to DMA control register.
 * @param peripheralBase Peripheral base address.
 * @param Value DMA control register value.
 */
  #define DMA_PDD_WriteControlReg(peripheralBase, Value) ( \
      DMA_CR_REG(peripheralBase) = \
       (uint32_t)(Value) \
    )
#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */

/* ----------------------------------------------------------------------------
   -- ReadControlReg
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MKL04Z4)) || (defined(MCU_MKL05Z4)) || (defined(MCU_MKL14Z4)) || (defined(MCU_MKL15Z4)) || (defined(MCU_MKL24Z4)) || (defined(MCU_MKL25Z4)) || (defined(MCU_PCK20L4)))
/**
 * Returns DMA control register.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number. Use constants from group "DMA channel
 *        constants.".
 */
  #define DMA_PDD_ReadControlReg(peripheralBase, Channel) ( \
      DMA_DCR_REG(peripheralBase,(Channel)) \
    )
#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */
/**
 * Returns DMA control register.
 * @param peripheralBase Peripheral base address.
 */
  #define DMA_PDD_ReadControlReg(peripheralBase) ( \
      DMA_CR_REG(peripheralBase) \
    )
#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */

/* ----------------------------------------------------------------------------
   -- CancelTransfer
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MKL04Z4)) || (defined(MCU_MKL05Z4)) || (defined(MCU_MKL14Z4)) || (defined(MCU_MKL15Z4)) || (defined(MCU_MKL24Z4)) || (defined(MCU_MKL25Z4)) || (defined(MCU_PCK20L4)))
/**
 * Cancels remaining data transfer.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number. Use constants from group "DMA channel
 *        constants.".
 */
  #define DMA_PDD_CancelTransfer(peripheralBase, Channel) ( \
      DMA_DSR_BCR_REG(peripheralBase,(Channel)) |= \
       DMA_DSR_BCR_DONE_MASK \
    )
#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */
/**
 * Cancels remaining data transfer.
 * @param peripheralBase Peripheral base address.
 */
  #define DMA_PDD_CancelTransfer(peripheralBase) ( \
      DMA_CR_REG(peripheralBase) |= \
       DMA_CR_CX_MASK \
    )
#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */

/* ----------------------------------------------------------------------------
   -- ErrorCancelTransfer
   ---------------------------------------------------------------------------- */

/**
 * Cancels remaining data transfer with error generation.
 * @param peripheralBase Peripheral base address.
 */
#define DMA_PDD_ErrorCancelTransfer(peripheralBase) ( \
    DMA_CR_REG(peripheralBase) |= \
     DMA_CR_ECX_MASK \
  )

/* ----------------------------------------------------------------------------
   -- EnableMinorLoopMapping
   ---------------------------------------------------------------------------- */

/**
 * Enables or disables minor loop mapping.
 * @param peripheralBase Peripheral base address.
 * @param State Parameter specifying if minor loop mapping will be enabled or
 *        disabled.
 */
#define DMA_PDD_EnableMinorLoopMapping(peripheralBase, State) ( \
    DMA_CR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(DMA_CR_REG(peripheralBase) & (uint32_t)(~(uint32_t)DMA_CR_EMLM_MASK))) | ( \
      (uint32_t)((uint32_t)(State) << DMA_CR_EMLM_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- GetMinorLoopMappingEnabled
   ---------------------------------------------------------------------------- */

/**
 * Returns minor loop mapping state.
 * @param peripheralBase Peripheral base address.
 */
#define DMA_PDD_GetMinorLoopMappingEnabled(peripheralBase) ( \
    (uint32_t)(DMA_CR_REG(peripheralBase) & DMA_CR_EMLM_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- EnableContinuousLinkMode
   ---------------------------------------------------------------------------- */

/**
 * Enables or disables minor loop continuous link mode.
 * @param peripheralBase Peripheral base address.
 * @param State Parameter specifying if minor loop continuous link mode will be
 *        enabled or disabled.
 */
#define DMA_PDD_EnableContinuousLinkMode(peripheralBase, State) ( \
    DMA_CR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(DMA_CR_REG(peripheralBase) & (uint32_t)(~(uint32_t)DMA_CR_CLM_MASK))) | ( \
      (uint32_t)((uint32_t)(State) << DMA_CR_CLM_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- GetContinuousLinkModeEnabled
   ---------------------------------------------------------------------------- */

/**
 * Returns minor loop continuous link mode state.
 * @param peripheralBase Peripheral base address.
 */
#define DMA_PDD_GetContinuousLinkModeEnabled(peripheralBase) ( \
    (uint32_t)(DMA_CR_REG(peripheralBase) & DMA_CR_CLM_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- HaltOperations
   ---------------------------------------------------------------------------- */

/**
 * Halts DMA operations.
 * @param peripheralBase Peripheral base address.
 */
#define DMA_PDD_HaltOperations(peripheralBase) ( \
    DMA_CR_REG(peripheralBase) |= \
     DMA_CR_HALT_MASK \
  )

/* ----------------------------------------------------------------------------
   -- ResumeOperations
   ---------------------------------------------------------------------------- */

/**
 * Resumes halted DMA operations.
 * @param peripheralBase Peripheral base address.
 */
#define DMA_PDD_ResumeOperations(peripheralBase) ( \
    DMA_CR_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)DMA_CR_HALT_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- EnableHaltOnError
   ---------------------------------------------------------------------------- */

/**
 * Enables or disables stalling of DMA operations after error occurs.
 * @param peripheralBase Peripheral base address.
 * @param State Parameter specifying if error occurance halts DMA operations.
 */
#define DMA_PDD_EnableHaltOnError(peripheralBase, State) ( \
    DMA_CR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(DMA_CR_REG(peripheralBase) & (uint32_t)(~(uint32_t)DMA_CR_HOE_MASK))) | ( \
      (uint32_t)((uint32_t)(State) << DMA_CR_HOE_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- GetHaltOnErrorEnabled
   ---------------------------------------------------------------------------- */

/**
 * Returns DMA operations halt on error state.
 * @param peripheralBase Peripheral base address.
 */
#define DMA_PDD_GetHaltOnErrorEnabled(peripheralBase) ( \
    (uint32_t)(DMA_CR_REG(peripheralBase) & DMA_CR_HOE_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- EnableRoundRobinArbitration
   ---------------------------------------------------------------------------- */

/**
 * Enables or disables round robin channel arbitration.
 * @param peripheralBase Peripheral base address.
 * @param State Parameter specifying if round robin channel arbitration is
 *        enabled or disabled.
 */
#define DMA_PDD_EnableRoundRobinArbitration(peripheralBase, State) ( \
    DMA_CR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(DMA_CR_REG(peripheralBase) & (uint32_t)(~(uint32_t)DMA_CR_ERCA_MASK))) | ( \
      (uint32_t)((uint32_t)(State) << DMA_CR_ERCA_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- GetRoundRobinArbitrationEnabled
   ---------------------------------------------------------------------------- */

/**
 * Returns round robin channel arbitration state.
 * @param peripheralBase Peripheral base address.
 */
#define DMA_PDD_GetRoundRobinArbitrationEnabled(peripheralBase) ( \
    (uint32_t)(DMA_CR_REG(peripheralBase) & DMA_CR_ERCA_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- EnableDebug
   ---------------------------------------------------------------------------- */

/**
 * Enables or disables DMA operations in debug mode.
 * @param peripheralBase Peripheral base address.
 * @param State Parameter specifying if DMA operations in debug mode are enabled
 *        or disabled.
 */
#define DMA_PDD_EnableDebug(peripheralBase, State) ( \
    DMA_CR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(DMA_CR_REG(peripheralBase) & (uint32_t)(~(uint32_t)DMA_CR_EDBG_MASK))) | ( \
      (uint32_t)((uint32_t)(State) << DMA_CR_EDBG_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- GetDebugEnabled
   ---------------------------------------------------------------------------- */

/**
 * Returns DMA operations in debug mode state.
 * @param peripheralBase Peripheral base address.
 */
#define DMA_PDD_GetDebugEnabled(peripheralBase) ( \
    (uint32_t)(DMA_CR_REG(peripheralBase) & DMA_CR_EDBG_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetErrorStatusRegister
   ---------------------------------------------------------------------------- */

/**
 * Returns DMA channel error status register provading information about last
 * recorded channel error.
 * @param peripheralBase Peripheral base address.
 */
#define DMA_PDD_GetErrorStatusRegister(peripheralBase) ( \
    DMA_ES_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- GetErrorStatusFlags
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MK10F12)) || (defined(MCU_MK20F12)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)))
/**
 * Returns DMA channel error status flags provading information about last
 * recorded channel error.
 * @param peripheralBase Peripheral base address.
 */
  #define DMA_PDD_GetErrorStatusFlags(peripheralBase) ( \
      (uint32_t)(( \
       DMA_ES_REG(peripheralBase)) & ( \
       (uint32_t)(( \
        DMA_ES_ECX_MASK) | (( \
        DMA_ES_GPE_MASK) | (( \
        DMA_ES_CPE_MASK) | (( \
        DMA_ES_SAE_MASK) | (( \
        DMA_ES_SOE_MASK) | (( \
        DMA_ES_DAE_MASK) | (( \
        DMA_ES_DOE_MASK) | (( \
        DMA_ES_NCE_MASK) | (( \
        DMA_ES_SGE_MASK) | (( \
        DMA_ES_SBE_MASK) | ( \
        DMA_ES_DBE_MASK))))))))))))) \
    )
#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60N512VMD100)) */
/**
 * Returns DMA channel error status flags provading information about last
 * recorded channel error.
 * @param peripheralBase Peripheral base address.
 */
  #define DMA_PDD_GetErrorStatusFlags(peripheralBase) ( \
      (uint32_t)(( \
       DMA_ES_REG(peripheralBase)) & ( \
       (uint32_t)(( \
        DMA_ES_ECX_MASK) | (( \
        DMA_ES_CPE_MASK) | (( \
        DMA_ES_SAE_MASK) | (( \
        DMA_ES_SOE_MASK) | (( \
        DMA_ES_DAE_MASK) | (( \
        DMA_ES_DOE_MASK) | (( \
        DMA_ES_NCE_MASK) | (( \
        DMA_ES_SGE_MASK) | (( \
        DMA_ES_SBE_MASK) | ( \
        DMA_ES_DBE_MASK)))))))))))) \
    )
#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60N512VMD100)) */

/* ----------------------------------------------------------------------------
   -- GetErrorStatusChannel
   ---------------------------------------------------------------------------- */

/**
 * Returns DMA channel provading information about last recorded channel error.
 * @param peripheralBase Peripheral base address.
 */
#define DMA_PDD_GetErrorStatusChannel(peripheralBase) ( \
    (uint8_t)(( \
     (uint32_t)(DMA_ES_REG(peripheralBase) & DMA_ES_ERRCHN_MASK)) >> ( \
     DMA_ES_ERRCHN_SHIFT)) \
  )

/* ----------------------------------------------------------------------------
   -- DCHPRI_REG
   ---------------------------------------------------------------------------- */

/**
 * SetChannelPriority channel parameter conversion.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel index.
 */
#define DMA_PDD_DCHPRI_REG(peripheralBase, Channel) ( \
    (&DMA_DCHPRI3_REG(peripheralBase))[Channel^3U] \
  )

/* ----------------------------------------------------------------------------
   -- SetChannelPriority
   ---------------------------------------------------------------------------- */

/**
 * Sets DMA channel priority register.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel index.
 * @param EnablePreemption Parameter specifying if DMA channel can be
 *        temporarily suspended by the service request of a higher priority channel.
 * @param EnablePreemptAbility Parameter specifying if DMA channel can suspend a
 *        lower priority channel.
 * @param Priority Data word value.
 */
#define DMA_PDD_SetChannelPriority(peripheralBase, Channel, EnablePreemption, EnablePreemptAbility, Priority) ( \
    (DMA_PDD_DCHPRI_REG(peripheralBase, Channel) = ( \
      (EnablePreemptAbility) ? ( \
        (uint8_t)((uint8_t)(EnablePreemption) << DMA_DCHPRI3_ECP_SHIFT) | \
        (uint8_t)((((uint8_t)(Priority) & DMA_DCHPRI3_CHPRI_MASK) << DMA_DCHPRI3_CHPRI_SHIFT)) \
      ) : ( \
        (uint8_t)((uint8_t)(EnablePreemption) << DMA_DCHPRI3_ECP_SHIFT) | \
        (uint8_t)((((uint8_t)(Priority) & DMA_DCHPRI3_CHPRI_MASK) << DMA_DCHPRI3_CHPRI_SHIFT)) | \
        (DMA_DCHPRI3_DPA_MASK)  \
      ) \
    )) \
  )

/* ----------------------------------------------------------------------------
   -- WriteEnableRegs
   ---------------------------------------------------------------------------- */

/**
 * Writes to DMA set/clear error interrupts and channel requests enable
 * registers.
 * @param peripheralBase Peripheral base address.
 * @param Value DMA control registers value.
 */
#define DMA_PDD_WriteEnableRegs(peripheralBase, Value) ( \
    DMA_CEEI_REG(peripheralBase) = (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- WriteFlagRegs
   ---------------------------------------------------------------------------- */

/**
 * Writes to DMA clear done status, clear error and interrupt flags and set
 * start channel request registers.
 * @param peripheralBase Peripheral base address.
 * @param Value DMA flag registers value.
 */
#define DMA_PDD_WriteFlagRegs(peripheralBase, Value) ( \
    DMA_CDNE_REG(peripheralBase) = (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- EnableRequestMask
   ---------------------------------------------------------------------------- */

/**
 * Enables DMA channels requests specified by Mask parameter, rest is not
 * changed.
 * @param peripheralBase Peripheral base address.
 * @param Mask Mask of DMA requests to be enabled.
 */
#define DMA_PDD_EnableRequestMask(peripheralBase, Mask) ( \
    DMA_ERQ_REG(peripheralBase) |= \
     (uint32_t)(Mask) \
  )

/* ----------------------------------------------------------------------------
   -- DisableRequestMask
   ---------------------------------------------------------------------------- */

/**
 * Disables DMA channels requests specified by Mask parameter, rest is not
 * changed.
 * @param peripheralBase Peripheral base address.
 * @param Mask Mask of DMA requests to be disabled.
 */
#define DMA_PDD_DisableRequestMask(peripheralBase, Mask) ( \
    DMA_ERQ_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)(Mask)) \
  )

/* ----------------------------------------------------------------------------
   -- SetRequestEnableMask
   ---------------------------------------------------------------------------- */

/**
 * Sets DMA channels requests.
 * @param peripheralBase Peripheral base address.
 * @param Mask Mask of DMA requests to be enabled.
 */
#define DMA_PDD_SetRequestEnableMask(peripheralBase, Mask) ( \
    DMA_ERQ_REG(peripheralBase) = \
     (uint32_t)(Mask) \
  )

/* ----------------------------------------------------------------------------
   -- GetRequestEnableMask
   ---------------------------------------------------------------------------- */

/**
 * Returns mask of enabled DMA channels requests.
 * @param peripheralBase Peripheral base address.
 */
#define DMA_PDD_GetRequestEnableMask(peripheralBase) ( \
    DMA_ERQ_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- SetRequestEnable
   ---------------------------------------------------------------------------- */

/**
 * Sets DMA channel request. If AllChannels = '1' then all requests are enabled
 * regardless of Channel parameter.
 * @param peripheralBase Peripheral base address.
 * @param AllChannels Enable all DMA channel requests.
 * @param Channel DMA channel request number.
 */
#define DMA_PDD_SetRequestEnable(peripheralBase, AllChannels, Channel) ( \
    DMA_SERQ_REG(peripheralBase) = \
     (uint8_t)((uint8_t)(AllChannels) | (uint8_t)(Channel)) \
  )

/* ----------------------------------------------------------------------------
   -- ClearRequestEnable
   ---------------------------------------------------------------------------- */

/**
 * Clears DMA channel request. If AllChannels = '1' then all requests are
 * disabled regardless of Channel parameter.
 * @param peripheralBase Peripheral base address.
 * @param AllChannels Disable all DMA channel requests.
 * @param Channel DMA channel request number.
 */
#define DMA_PDD_ClearRequestEnable(peripheralBase, AllChannels, Channel) ( \
    DMA_CERQ_REG(peripheralBase) = \
     (uint8_t)((uint8_t)(AllChannels) | (uint8_t)(Channel)) \
  )

/* ----------------------------------------------------------------------------
   -- EnableErrorInterruptMask
   ---------------------------------------------------------------------------- */

/**
 * Enables DMA channels error interrupts specified by Mask parameter, rest is
 * not changed.
 * @param peripheralBase Peripheral base address.
 * @param Mask Mask of DMA error interrupts to be enabled.
 */
#define DMA_PDD_EnableErrorInterruptMask(peripheralBase, Mask) ( \
    DMA_EEI_REG(peripheralBase) |= \
     (uint32_t)(Mask) \
  )

/* ----------------------------------------------------------------------------
   -- DisableErrorInterruptMask
   ---------------------------------------------------------------------------- */

/**
 * Disables DMA channels error interrupts specified by Mask parameter, rest is
 * not changed.
 * @param peripheralBase Peripheral base address.
 * @param Mask Mask of DMA error interrupts to be disabled.
 */
#define DMA_PDD_DisableErrorInterruptMask(peripheralBase, Mask) ( \
    DMA_EEI_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)(Mask)) \
  )

/* ----------------------------------------------------------------------------
   -- SetErrorInterruptEnableMask
   ---------------------------------------------------------------------------- */

/**
 * Sets DMA channels error interrupts.
 * @param peripheralBase Peripheral base address.
 * @param Mask Mask of DMA error interrupts to be enabled.
 */
#define DMA_PDD_SetErrorInterruptEnableMask(peripheralBase, Mask) ( \
    DMA_EEI_REG(peripheralBase) = \
     (uint32_t)(Mask) \
  )

/* ----------------------------------------------------------------------------
   -- GetErrorInterruptEnableMask
   ---------------------------------------------------------------------------- */

/**
 * Returns mask of DMA channels error interrupts.
 * @param peripheralBase Peripheral base address.
 */
#define DMA_PDD_GetErrorInterruptEnableMask(peripheralBase) ( \
    DMA_EEI_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- SetErrorInterruptEnable
   ---------------------------------------------------------------------------- */

/**
 * Sets DMA channel error interrupt. If AllChannels = '1' then all interrupts
 * are enabled regardless of Channel parameter.
 * @param peripheralBase Peripheral base address.
 * @param AllChannels Enable all DMA error interrupts.
 * @param Channel DMA error interrupt channel number.
 */
#define DMA_PDD_SetErrorInterruptEnable(peripheralBase, AllChannels, Channel) ( \
    DMA_SEEI_REG(peripheralBase) = \
     (uint8_t)((uint8_t)(AllChannels) | (uint8_t)(Channel)) \
  )

/* ----------------------------------------------------------------------------
   -- ClearErrorInterruptEnable
   ---------------------------------------------------------------------------- */

/**
 * Clears DMA channel error interrupt. If AllChannels = '1' then all interrupts
 * are disabled regardless of Channel parameter.
 * @param peripheralBase Peripheral base address.
 * @param AllChannels Disable all DMA error interrupts.
 * @param Channel DMA error interrupt channel number.
 */
#define DMA_PDD_ClearErrorInterruptEnable(peripheralBase, AllChannels, Channel) ( \
    DMA_CEEI_REG(peripheralBase) = \
     (uint8_t)((uint8_t)(AllChannels) | (uint8_t)(Channel)) \
  )

/* ----------------------------------------------------------------------------
   -- ClearInterruptFlags
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MKL04Z4)) || (defined(MCU_MKL05Z4)) || (defined(MCU_MKL14Z4)) || (defined(MCU_MKL15Z4)) || (defined(MCU_MKL24Z4)) || (defined(MCU_MKL25Z4)) || (defined(MCU_PCK20L4)))
/**
 * Clears interrupt flag bits defined by mask parameter.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number. Use constants from group "DMA channel
 *        constants.".
 * @param Mask Mask of interrupt's flags to clear. Use constants from group
 *        "Interrupts' flags.".
 */
  #define DMA_PDD_ClearInterruptFlags(peripheralBase, Channel, Mask) ( \
      DMA_DSR_BCR_REG(peripheralBase,(Channel)) |= \
       (uint32_t)(Mask) \
    )
#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */
/**
 * Clears DMA channel interrupt request flag. If AllChannels = '1' then all
 * requests are cleared regardless of Channel parameter.
 * @param peripheralBase Peripheral base address.
 * @param AllChannels Clear all DMA interrupt requests.
 * @param Channel DMA interrupt request channel number.
 */
  #define DMA_PDD_ClearInterruptFlags(peripheralBase, AllChannels, Channel) ( \
      DMA_CINT_REG(peripheralBase) = \
       (uint8_t)((uint8_t)(AllChannels) | (uint8_t)(Channel)) \
    )
#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */

/* ----------------------------------------------------------------------------
   -- ClearInterruptFlagsMask
   ---------------------------------------------------------------------------- */

/**
 * Clears DMA channels interrupt requests specified by Mask parameter, rest is
 * not changed.
 * @param peripheralBase Peripheral base address.
 * @param Mask Mask of DMA interrupt requests to be cleared.
 */
#define DMA_PDD_ClearInterruptFlagsMask(peripheralBase, Mask) ( \
    DMA_INT_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)(Mask)) \
  )

/* ----------------------------------------------------------------------------
   -- GetInterruptFlagsMask
   ---------------------------------------------------------------------------- */

/**
 * Returns mask of DMA channels interrupt requests.
 * @param peripheralBase Peripheral base address.
 */
#define DMA_PDD_GetInterruptFlagsMask(peripheralBase) ( \
    DMA_INT_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- ClearErrorFlags
   ---------------------------------------------------------------------------- */

/**
 * Clears DMA channel error flag. If AllChannels = '1' then all errors are
 * cleared regardless of Channel parameter.
 * @param peripheralBase Peripheral base address.
 * @param AllChannels Clear all DMA errors.
 * @param Channel DMA error channel number.
 */
#define DMA_PDD_ClearErrorFlags(peripheralBase, AllChannels, Channel) ( \
    DMA_CERR_REG(peripheralBase) = \
     (uint8_t)((uint8_t)(AllChannels) | (uint8_t)(Channel)) \
  )

/* ----------------------------------------------------------------------------
   -- ClearErrorFlagsMask
   ---------------------------------------------------------------------------- */

/**
 * Clears DMA channels error flags specified by Mask parameter, rest is not
 * changed.
 * @param peripheralBase Peripheral base address.
 * @param Mask Mask of DMA errors to be cleared.
 */
#define DMA_PDD_ClearErrorFlagsMask(peripheralBase, Mask) ( \
    DMA_ERR_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)(Mask)) \
  )

/* ----------------------------------------------------------------------------
   -- GetErrorFlagsMask
   ---------------------------------------------------------------------------- */

/**
 * Returns mask of DMA channel error flags.
 * @param peripheralBase Peripheral base address.
 */
#define DMA_PDD_GetErrorFlagsMask(peripheralBase) ( \
    DMA_ERR_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- StartTransfer
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MKL04Z4)) || (defined(MCU_MKL05Z4)) || (defined(MCU_MKL14Z4)) || (defined(MCU_MKL15Z4)) || (defined(MCU_MKL24Z4)) || (defined(MCU_MKL25Z4)) || (defined(MCU_PCK20L4)))
/**
 * Starts DMA channel transfer request via a software initiated service request.
 * If AllChannels = '1' then transfer start is requested for all channels
 * regardless of Channel parameter.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number. Use constants from group "DMA channel
 *        constants.".
 */
  #define DMA_PDD_StartTransfer(peripheralBase, Channel) ( \
      DMA_DCR_REG(peripheralBase,(Channel)) |= \
       DMA_DCR_START_MASK \
    )
#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */
/**
 * Starts DMA channel transfer request via a software initiated service request.
 * If AllChannels = '1' then transfer start is requested for all channels
 * regardless of Channel parameter.
 * @param peripheralBase Peripheral base address.
 * @param AllChannels Request transfer start for all channels.
 * @param Channel DMA channel number.
 */
  #define DMA_PDD_StartTransfer(peripheralBase, AllChannels, Channel) ( \
      DMA_SSRT_REG(peripheralBase) = \
       (uint8_t)((uint8_t)(AllChannels) | (uint8_t)(Channel)) \
    )
#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */

/* ----------------------------------------------------------------------------
   -- ClearDoneFlags
   ---------------------------------------------------------------------------- */

/**
 * Clears DMA channel done status. If AllChannels = '1' then all status of all
 * channels are cleared regardless of Channel parameter.
 * @param peripheralBase Peripheral base address.
 * @param AllChannels Clear all DMA channels status.
 * @param Channel DMA status channel number.
 */
#define DMA_PDD_ClearDoneFlags(peripheralBase, AllChannels, Channel) ( \
    DMA_CDNE_REG(peripheralBase) = \
     (uint8_t)((uint8_t)(AllChannels) | (uint8_t)(Channel)) \
  )

/* ----------------------------------------------------------------------------
   -- GetRequestFlagsMask
   ---------------------------------------------------------------------------- */

/**
 * Returns mask of DMA channels requests status.
 * @param peripheralBase Peripheral base address.
 */
#define DMA_PDD_GetRequestFlagsMask(peripheralBase) ( \
    DMA_HRS_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- SetSourceAddress
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MKL04Z4)) || (defined(MCU_MKL05Z4)) || (defined(MCU_MKL14Z4)) || (defined(MCU_MKL15Z4)) || (defined(MCU_MKL24Z4)) || (defined(MCU_MKL25Z4)) || (defined(MCU_PCK20L4)))
/**
 * Sets DMA channel source address.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number. Use constants from group "DMA channel
 *        constants.".
 * @param Address DMA channel source address.
 */
  #define DMA_PDD_SetSourceAddress(peripheralBase, Channel, Address) ( \
      DMA_SAR_REG(peripheralBase,(Channel)) = \
       (uint32_t)(Address) \
    )
#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */
/**
 * Sets DMA channel source address.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 * @param Address DMA channel source address.
 */
  #define DMA_PDD_SetSourceAddress(peripheralBase, Channel, Address) ( \
      DMA_SADDR_REG(peripheralBase,(Channel)) = \
       (uint32_t)(Address) \
    )
#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */

/* ----------------------------------------------------------------------------
   -- GetSourceAddress
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MKL04Z4)) || (defined(MCU_MKL05Z4)) || (defined(MCU_MKL14Z4)) || (defined(MCU_MKL15Z4)) || (defined(MCU_MKL24Z4)) || (defined(MCU_MKL25Z4)) || (defined(MCU_PCK20L4)))
/**
 * Returns DMA channel source address.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number. Use constants from group "DMA channel
 *        constants.".
 */
  #define DMA_PDD_GetSourceAddress(peripheralBase, Channel) ( \
      DMA_SAR_REG(peripheralBase,(Channel)) \
    )
#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */
/**
 * Returns DMA channel source address.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 */
  #define DMA_PDD_GetSourceAddress(peripheralBase, Channel) ( \
      DMA_SADDR_REG(peripheralBase,(Channel)) \
    )
#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */

/* ----------------------------------------------------------------------------
   -- SetDestinationAddress
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MKL04Z4)) || (defined(MCU_MKL05Z4)) || (defined(MCU_MKL14Z4)) || (defined(MCU_MKL15Z4)) || (defined(MCU_MKL24Z4)) || (defined(MCU_MKL25Z4)) || (defined(MCU_PCK20L4)))
/**
 * Sets DMA channel destination address.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number. Use constants from group "DMA channel
 *        constants.".
 * @param Address DMA channel destination address.
 */
  #define DMA_PDD_SetDestinationAddress(peripheralBase, Channel, Address) ( \
      DMA_DAR_REG(peripheralBase,(Channel)) = \
       (uint32_t)(Address) \
    )
#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */
/**
 * Sets DMA channel destination address.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 * @param Address DMA channel destination address.
 */
  #define DMA_PDD_SetDestinationAddress(peripheralBase, Channel, Address) ( \
      DMA_DADDR_REG(peripheralBase,(Channel)) = \
       (uint32_t)(Address) \
    )
#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */

/* ----------------------------------------------------------------------------
   -- GetDestinationAddress
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MKL04Z4)) || (defined(MCU_MKL05Z4)) || (defined(MCU_MKL14Z4)) || (defined(MCU_MKL15Z4)) || (defined(MCU_MKL24Z4)) || (defined(MCU_MKL25Z4)) || (defined(MCU_PCK20L4)))
/**
 * Returns DMA channel destination address.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number. Use constants from group "DMA channel
 *        constants.".
 */
  #define DMA_PDD_GetDestinationAddress(peripheralBase, Channel) ( \
      DMA_DAR_REG(peripheralBase,(Channel)) \
    )
#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */
/**
 * Returns DMA channel destination address.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 */
  #define DMA_PDD_GetDestinationAddress(peripheralBase, Channel) ( \
      DMA_DADDR_REG(peripheralBase,(Channel)) \
    )
#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */

/* ----------------------------------------------------------------------------
   -- SetSourceAddressOffset
   ---------------------------------------------------------------------------- */

/**
 * Sets DMA channel source address offset.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 * @param Offset DMA channel source address offset.
 */
#define DMA_PDD_SetSourceAddressOffset(peripheralBase, Channel, Offset) ( \
    DMA_SOFF_REG(peripheralBase,(Channel)) = \
     (uint16_t)(Offset) \
  )

/* ----------------------------------------------------------------------------
   -- GetSourceAddressOffset
   ---------------------------------------------------------------------------- */

/**
 * Returns DMA channel source address offset.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 */
#define DMA_PDD_GetSourceAddressOffset(peripheralBase, Channel) ( \
    DMA_SOFF_REG(peripheralBase,(Channel)) \
  )

/* ----------------------------------------------------------------------------
   -- SetDestinationAddressOffset
   ---------------------------------------------------------------------------- */

/**
 * Sets DMA channel destination address offset.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 * @param Offset DMA channel destination address offset.
 */
#define DMA_PDD_SetDestinationAddressOffset(peripheralBase, Channel, Offset) ( \
    DMA_DOFF_REG(peripheralBase,(Channel)) = \
     (uint16_t)(Offset) \
  )

/* ----------------------------------------------------------------------------
   -- GetDestinationAddressOffset
   ---------------------------------------------------------------------------- */

/**
 * Returns DMA channel destination address offset.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 */
#define DMA_PDD_GetDestinationAddressOffset(peripheralBase, Channel) ( \
    DMA_DOFF_REG(peripheralBase,(Channel)) \
  )

/* ----------------------------------------------------------------------------
   -- WriteTransferAttributesReg
   ---------------------------------------------------------------------------- */

/**
 * Writes to DMA channel transfer attributes register.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 * @param Value Transfer attributes register value.
 */
#define DMA_PDD_WriteTransferAttributesReg(peripheralBase, Channel, Value) ( \
    DMA_ATTR_REG(peripheralBase,(Channel)) = \
     (uint16_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadTransferAttributesReg
   ---------------------------------------------------------------------------- */

/**
 * Returns DMA channel transfer attributes register.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 */
#define DMA_PDD_ReadTransferAttributesReg(peripheralBase, Channel) ( \
    DMA_ATTR_REG(peripheralBase,(Channel)) \
  )

/* ----------------------------------------------------------------------------
   -- SetSourceAddressModulo
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MKL04Z4)) || (defined(MCU_MKL05Z4)) || (defined(MCU_MKL14Z4)) || (defined(MCU_MKL15Z4)) || (defined(MCU_MKL24Z4)) || (defined(MCU_MKL25Z4)) || (defined(MCU_PCK20L4)))
/**
 * Sets DMA channel source address modulo.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number. Use constants from group "DMA channel
 *        constants.".
 * @param Modulo DMA channel source address modulo. Use constants from group
 *        "Circular buffer size constants.".
 */
  #define DMA_PDD_SetSourceAddressModulo(peripheralBase, Channel, Modulo) ( \
      DMA_DCR_REG(peripheralBase,(Channel)) = \
       (uint32_t)(( \
        (uint32_t)(( \
         DMA_DCR_REG(peripheralBase,(Channel))) & ( \
         (uint32_t)(~(uint32_t)DMA_DCR_SMOD_MASK)))) | ( \
        (uint32_t)((uint32_t)(Modulo) << DMA_DCR_SMOD_SHIFT))) \
    )
#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */
/**
 * Sets DMA channel source address modulo.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 * @param Modulo DMA channel source address modulo.
 */
  #define DMA_PDD_SetSourceAddressModulo(peripheralBase, Channel, Modulo) ( \
      DMA_ATTR_REG(peripheralBase,(Channel)) = \
       (uint16_t)(( \
        (uint16_t)(( \
         DMA_ATTR_REG(peripheralBase,(Channel))) & ( \
         (uint16_t)(~(uint16_t)DMA_ATTR_SMOD_MASK)))) | ( \
        (uint16_t)((uint16_t)(Modulo) << DMA_ATTR_SMOD_SHIFT))) \
    )
#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */

/* ----------------------------------------------------------------------------
   -- GetSourceAddressModulo
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MKL04Z4)) || (defined(MCU_MKL05Z4)) || (defined(MCU_MKL14Z4)) || (defined(MCU_MKL15Z4)) || (defined(MCU_MKL24Z4)) || (defined(MCU_MKL25Z4)) || (defined(MCU_PCK20L4)))
/**
 * Returns DMA channel source address modulo.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number. Use constants from group "DMA channel
 *        constants.".
 * @return Use constants from group "Circular buffer size constants." for
 *         processing return value.
 */
  #define DMA_PDD_GetSourceAddressModulo(peripheralBase, Channel) ( \
      (uint8_t)(( \
       (uint32_t)(DMA_DCR_REG(peripheralBase,(Channel)) & DMA_DCR_SMOD_MASK)) >> ( \
       DMA_DCR_SMOD_SHIFT)) \
    )
#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */
/**
 * Returns DMA channel source address modulo.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 */
  #define DMA_PDD_GetSourceAddressModulo(peripheralBase, Channel) ( \
      (uint8_t)(( \
       (uint16_t)(DMA_ATTR_REG(peripheralBase,(Channel)) & DMA_ATTR_SMOD_MASK)) >> ( \
       DMA_ATTR_SMOD_SHIFT)) \
    )
#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */

/* ----------------------------------------------------------------------------
   -- SetSourceDataTransferSize
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MKL04Z4)) || (defined(MCU_MKL05Z4)) || (defined(MCU_MKL14Z4)) || (defined(MCU_MKL15Z4)) || (defined(MCU_MKL24Z4)) || (defined(MCU_MKL25Z4)) || (defined(MCU_PCK20L4)))
/**
 * Sets DMA channel source data tranfer size.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number. Use constants from group "DMA channel
 *        constants.".
 * @param Size DMA channel source data tranfer block size.
 */
  #define DMA_PDD_SetSourceDataTransferSize(peripheralBase, Channel, Size) ( \
      DMA_DCR_REG(peripheralBase,(Channel)) = \
       (uint32_t)(( \
        (uint32_t)(( \
         DMA_DCR_REG(peripheralBase,(Channel))) & ( \
         (uint32_t)(~(uint32_t)DMA_DCR_SSIZE_MASK)))) | ( \
        (uint32_t)((uint32_t)(Size) << DMA_DCR_SSIZE_SHIFT))) \
    )
#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */
/**
 * Sets DMA channel source data tranfer size.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 * @param Size DMA channel source data tranfer block size.
 */
  #define DMA_PDD_SetSourceDataTransferSize(peripheralBase, Channel, Size) ( \
      DMA_ATTR_REG(peripheralBase,(Channel)) = \
       (uint16_t)(( \
        (uint16_t)(( \
         DMA_ATTR_REG(peripheralBase,(Channel))) & ( \
         (uint16_t)(~(uint16_t)DMA_ATTR_SSIZE_MASK)))) | ( \
        (uint16_t)((uint16_t)(Size) << DMA_ATTR_SSIZE_SHIFT))) \
    )
#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */

/* ----------------------------------------------------------------------------
   -- GetSourceDataTransferSize
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MKL04Z4)) || (defined(MCU_MKL05Z4)) || (defined(MCU_MKL14Z4)) || (defined(MCU_MKL15Z4)) || (defined(MCU_MKL24Z4)) || (defined(MCU_MKL25Z4)) || (defined(MCU_PCK20L4)))
/**
 * Returns DMA channel source data tranfer size.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number. Use constants from group "DMA channel
 *        constants.".
 */
  #define DMA_PDD_GetSourceDataTransferSize(peripheralBase, Channel) ( \
      (uint8_t)(( \
       (uint32_t)(DMA_DCR_REG(peripheralBase,(Channel)) & DMA_DCR_SSIZE_MASK)) >> ( \
       DMA_DCR_SSIZE_SHIFT)) \
    )
#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */
/**
 * Returns DMA channel source data tranfer size.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 */
  #define DMA_PDD_GetSourceDataTransferSize(peripheralBase, Channel) ( \
      (uint8_t)(( \
       (uint16_t)(DMA_ATTR_REG(peripheralBase,(Channel)) & DMA_ATTR_SSIZE_MASK)) >> ( \
       DMA_ATTR_SSIZE_SHIFT)) \
    )
#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */

/* ----------------------------------------------------------------------------
   -- SetDestinationAddressModulo
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MKL04Z4)) || (defined(MCU_MKL05Z4)) || (defined(MCU_MKL14Z4)) || (defined(MCU_MKL15Z4)) || (defined(MCU_MKL24Z4)) || (defined(MCU_MKL25Z4)) || (defined(MCU_PCK20L4)))
/**
 * Sets DMA channel destination address modulo.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number. Use constants from group "DMA channel
 *        constants.".
 * @param Modulo DMA channel destination address modulo. Use constants from
 *        group "Circular buffer size constants.".
 */
  #define DMA_PDD_SetDestinationAddressModulo(peripheralBase, Channel, Modulo) ( \
      DMA_DCR_REG(peripheralBase,(Channel)) = \
       (uint32_t)(( \
        (uint32_t)(( \
         DMA_DCR_REG(peripheralBase,(Channel))) & ( \
         (uint32_t)(~(uint32_t)DMA_DCR_DMOD_MASK)))) | ( \
        (uint32_t)((uint32_t)(Modulo) << DMA_DCR_DMOD_SHIFT))) \
    )
#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */
/**
 * Sets DMA channel destination address modulo.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 * @param Modulo DMA channel destination address modulo.
 */
  #define DMA_PDD_SetDestinationAddressModulo(peripheralBase, Channel, Modulo) ( \
      DMA_ATTR_REG(peripheralBase,(Channel)) = \
       (uint16_t)(( \
        (uint16_t)(( \
         DMA_ATTR_REG(peripheralBase,(Channel))) & ( \
         (uint16_t)(~(uint16_t)DMA_ATTR_DMOD_MASK)))) | ( \
        (uint16_t)((uint16_t)(Modulo) << DMA_ATTR_DMOD_SHIFT))) \
    )
#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */

/* ----------------------------------------------------------------------------
   -- GetDestinationAddressModulo
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MKL04Z4)) || (defined(MCU_MKL05Z4)) || (defined(MCU_MKL14Z4)) || (defined(MCU_MKL15Z4)) || (defined(MCU_MKL24Z4)) || (defined(MCU_MKL25Z4)) || (defined(MCU_PCK20L4)))
/**
 * Returns DMA channel destination address modulo.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number. Use constants from group "DMA channel
 *        constants.".
 * @return Use constants from group "Circular buffer size constants." for
 *         processing return value.
 */
  #define DMA_PDD_GetDestinationAddressModulo(peripheralBase, Channel) ( \
      (uint8_t)(( \
       (uint32_t)(DMA_DCR_REG(peripheralBase,(Channel)) & DMA_DCR_DMOD_MASK)) >> ( \
       DMA_DCR_DMOD_SHIFT)) \
    )
#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */
/**
 * Returns DMA channel destination address modulo.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 */
  #define DMA_PDD_GetDestinationAddressModulo(peripheralBase, Channel) ( \
      (uint8_t)(( \
       (uint16_t)(DMA_ATTR_REG(peripheralBase,(Channel)) & DMA_ATTR_DMOD_MASK)) >> ( \
       DMA_ATTR_DMOD_SHIFT)) \
    )
#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */

/* ----------------------------------------------------------------------------
   -- SetDestinationDataTransferSize
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MKL04Z4)) || (defined(MCU_MKL05Z4)) || (defined(MCU_MKL14Z4)) || (defined(MCU_MKL15Z4)) || (defined(MCU_MKL24Z4)) || (defined(MCU_MKL25Z4)) || (defined(MCU_PCK20L4)))
/**
 * Sets DMA channel destination data tranfer size.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number. Use constants from group "DMA channel
 *        constants.".
 * @param Size DMA channel destination data tranfer block size.
 */
  #define DMA_PDD_SetDestinationDataTransferSize(peripheralBase, Channel, Size) ( \
      DMA_DCR_REG(peripheralBase,(Channel)) = \
       (uint32_t)(( \
        (uint32_t)(( \
         DMA_DCR_REG(peripheralBase,(Channel))) & ( \
         (uint32_t)(~(uint32_t)DMA_DCR_DSIZE_MASK)))) | ( \
        (uint32_t)((uint32_t)(Size) << DMA_DCR_DSIZE_SHIFT))) \
    )
#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */
/**
 * Sets DMA channel destination data tranfer size.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 * @param Size DMA channel destination data tranfer block size.
 */
  #define DMA_PDD_SetDestinationDataTransferSize(peripheralBase, Channel, Size) ( \
      DMA_ATTR_REG(peripheralBase,(Channel)) = \
       (uint16_t)(( \
        (uint16_t)(( \
         DMA_ATTR_REG(peripheralBase,(Channel))) & ( \
         (uint16_t)(~(uint16_t)DMA_ATTR_DSIZE_MASK)))) | ( \
        (uint16_t)(Size))) \
    )
#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */

/* ----------------------------------------------------------------------------
   -- GetDestinationDataTransferSize
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MKL04Z4)) || (defined(MCU_MKL05Z4)) || (defined(MCU_MKL14Z4)) || (defined(MCU_MKL15Z4)) || (defined(MCU_MKL24Z4)) || (defined(MCU_MKL25Z4)) || (defined(MCU_PCK20L4)))
/**
 * Returns DMA channel destination data tranfer size.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number. Use constants from group "DMA channel
 *        constants.".
 */
  #define DMA_PDD_GetDestinationDataTransferSize(peripheralBase, Channel) ( \
      (uint8_t)(( \
       (uint32_t)(DMA_DCR_REG(peripheralBase,(Channel)) & DMA_DCR_DSIZE_MASK)) >> ( \
       DMA_DCR_DSIZE_SHIFT)) \
    )
#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */
/**
 * Returns DMA channel destination data tranfer size.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 */
  #define DMA_PDD_GetDestinationDataTransferSize(peripheralBase, Channel) ( \
      (uint8_t)(DMA_ATTR_REG(peripheralBase,(Channel)) & DMA_ATTR_DSIZE_MASK) \
    )
#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */

/* ----------------------------------------------------------------------------
   -- WriteMinorLoopReg
   ---------------------------------------------------------------------------- */

/**
 * Writes to DMA channel minor loop register.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 * @param Value DMA channel minor loop register value.
 */
#define DMA_PDD_WriteMinorLoopReg(peripheralBase, Channel, Value) ( \
    DMA_NBYTES_MLNO_REG(peripheralBase,(Channel)) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadMinorLoopReg
   ---------------------------------------------------------------------------- */

/**
 * Returns DMA channel minor loop register.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 */
#define DMA_PDD_ReadMinorLoopReg(peripheralBase, Channel) ( \
    DMA_NBYTES_MLNO_REG(peripheralBase,(Channel)) \
  )

/* ----------------------------------------------------------------------------
   -- SetByteCount32
   ---------------------------------------------------------------------------- */

/**
 * Sets DMA channel minor byte transfer count.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 * @param Value 32-bit DMA channel byte count.
 */
#define DMA_PDD_SetByteCount32(peripheralBase, Channel, Value) ( \
    DMA_NBYTES_MLNO_REG(peripheralBase,(Channel)) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- GetByteCount32
   ---------------------------------------------------------------------------- */

/**
 * Returns DMA channel minor byte transfer count.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 */
#define DMA_PDD_GetByteCount32(peripheralBase, Channel) ( \
    DMA_NBYTES_MLNO_REG(peripheralBase,(Channel)) \
  )

/* ----------------------------------------------------------------------------
   -- SetByteCount30
   ---------------------------------------------------------------------------- */

/**
 * Sets DMA channel minor byte transfer count.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 * @param Value 30-bit DMA channel byte count.
 */
#define DMA_PDD_SetByteCount30(peripheralBase, Channel, Value) ( \
    DMA_NBYTES_MLOFFNO_REG(peripheralBase,(Channel)) = \
     (uint32_t)(( \
      (uint32_t)(( \
       DMA_NBYTES_MLOFFNO_REG(peripheralBase,(Channel))) & ( \
       (uint32_t)(~(uint32_t)DMA_NBYTES_MLOFFNO_NBYTES_MASK)))) | ( \
      (uint32_t)(Value))) \
  )

/* ----------------------------------------------------------------------------
   -- GetByteCount30
   ---------------------------------------------------------------------------- */

/**
 * Returns DMA channel minor byte transfer count.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 */
#define DMA_PDD_GetByteCount30(peripheralBase, Channel) ( \
    (uint32_t)(( \
     DMA_NBYTES_MLOFFNO_REG(peripheralBase,(Channel))) & ( \
     DMA_NBYTES_MLOFFNO_NBYTES_MASK)) \
  )

/* ----------------------------------------------------------------------------
   -- SetByteCount10
   ---------------------------------------------------------------------------- */

/**
 * Sets DMA channel minor byte transfer count.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 * @param Value 10-bit DMA channel byte count.
 */
#define DMA_PDD_SetByteCount10(peripheralBase, Channel, Value) ( \
    DMA_NBYTES_MLOFFYES_REG(peripheralBase,(Channel)) = \
     (uint32_t)(( \
      (uint32_t)(( \
       DMA_NBYTES_MLOFFYES_REG(peripheralBase,(Channel))) & ( \
       (uint32_t)(~(uint32_t)DMA_NBYTES_MLOFFYES_NBYTES_MASK)))) | ( \
      (uint32_t)(Value))) \
  )

/* ----------------------------------------------------------------------------
   -- GetByteCount10
   ---------------------------------------------------------------------------- */

/**
 * Returns DMA channel minor byte transfer count.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 */
#define DMA_PDD_GetByteCount10(peripheralBase, Channel) ( \
    (uint32_t)(( \
     DMA_NBYTES_MLOFFYES_REG(peripheralBase,(Channel))) & ( \
     DMA_NBYTES_MLOFFYES_NBYTES_MASK)) \
  )

/* ----------------------------------------------------------------------------
   -- EnableSourceMinorLoopOffset
   ---------------------------------------------------------------------------- */

/**
 * Enables or disables DMA channel source minor loop offset.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 * @param State Parameter specifying if DMA channel source minor loop offset
 *        will be enabled or disabled.
 */
#define DMA_PDD_EnableSourceMinorLoopOffset(peripheralBase, Channel, State) ( \
    DMA_NBYTES_MLOFFYES_REG(peripheralBase,(Channel)) = \
     (uint32_t)(( \
      (uint32_t)(( \
       DMA_NBYTES_MLOFFYES_REG(peripheralBase,(Channel))) & ( \
       (uint32_t)(~(uint32_t)DMA_NBYTES_MLOFFYES_SMLOE_MASK)))) | ( \
      (uint32_t)((uint32_t)(State) << DMA_NBYTES_MLOFFYES_SMLOE_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableDestinationMinorLoopOffset
   ---------------------------------------------------------------------------- */

/**
 * Enables or disables DMA channel destination minor loop offset.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 * @param State Parameter specifying if DMA channel source minor loop offset
 *        will be enabled or disabled.
 */
#define DMA_PDD_EnableDestinationMinorLoopOffset(peripheralBase, Channel, State) ( \
    DMA_NBYTES_MLOFFYES_REG(peripheralBase,(Channel)) = \
     (uint32_t)(( \
      (uint32_t)(( \
       DMA_NBYTES_MLOFFYES_REG(peripheralBase,(Channel))) & ( \
       (uint32_t)(~(uint32_t)DMA_NBYTES_MLOFFYES_DMLOE_MASK)))) | ( \
      (uint32_t)((uint32_t)(State) << DMA_NBYTES_MLOFFYES_DMLOE_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- GetMinorLoopOffsetEnabled
   ---------------------------------------------------------------------------- */

/**
 * Returns source and destination minor loop offset enable bits state.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 */
#define DMA_PDD_GetMinorLoopOffsetEnabled(peripheralBase, Channel) ( \
    (uint32_t)(( \
     DMA_NBYTES_MLOFFYES_REG(peripheralBase,(Channel))) & ( \
     (uint32_t)(DMA_NBYTES_MLOFFYES_SMLOE_MASK | DMA_NBYTES_MLOFFYES_DMLOE_MASK))) \
  )

/* ----------------------------------------------------------------------------
   -- SetMinorLoopOffset
   ---------------------------------------------------------------------------- */

/**
 * Sets DMA channel minor loop offset.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 * @param AddressOffset Address offset added to source and/or destination
 *        address.
 */
#define DMA_PDD_SetMinorLoopOffset(peripheralBase, Channel, AddressOffset) ( \
    DMA_NBYTES_MLOFFYES_REG(peripheralBase,(Channel)) = \
     (uint32_t)(( \
      (uint32_t)(( \
       DMA_NBYTES_MLOFFYES_REG(peripheralBase,(Channel))) & ( \
       (uint32_t)(~(uint32_t)DMA_NBYTES_MLOFFYES_MLOFF_MASK)))) | ( \
      (uint32_t)((uint32_t)(AddressOffset) << DMA_NBYTES_MLOFFYES_MLOFF_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- GetMinorLoopOffset
   ---------------------------------------------------------------------------- */

/**
 * Returns DMA channel minor loop offset.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 */
#define DMA_PDD_GetMinorLoopOffset(peripheralBase, Channel) ( \
    (uint32_t)(( \
     (uint32_t)(( \
      DMA_NBYTES_MLOFFYES_REG(peripheralBase,(Channel))) & ( \
      DMA_NBYTES_MLOFFYES_MLOFF_MASK))) >> ( \
     DMA_NBYTES_MLOFFYES_MLOFF_SHIFT)) \
  )

/* ----------------------------------------------------------------------------
   -- WriteCurrentMajorLoopCountReg
   ---------------------------------------------------------------------------- */

/**
 * Writes to DMA channel current minor loop link major loop count register.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 * @param Value DMA channel minor loop link major loop count register value.
 */
#define DMA_PDD_WriteCurrentMajorLoopCountReg(peripheralBase, Channel, Value) ( \
    DMA_CITER_ELINKNO_REG(peripheralBase,(Channel)) = \
     (uint16_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadCurrentMajorLoopCountReg
   ---------------------------------------------------------------------------- */

/**
 * Reads DMA channel current minor loop link major loop count register.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 * @param Value DMA channel minor loop link major loop count register value.
 */
#define DMA_PDD_ReadCurrentMajorLoopCountReg(peripheralBase, Channel, Value) ( \
    DMA_CITER_ELINKNO_REG(peripheralBase,(Channel)) \
  )

/* ----------------------------------------------------------------------------
   -- EnableCurrentMinorLoopLinking
   ---------------------------------------------------------------------------- */

/**
 * Enables or disables DMA channel current minor loop linking.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 * @param State Parameter specifying if DMA channel linking will be enabled or
 *        disabled.
 */
#define DMA_PDD_EnableCurrentMinorLoopLinking(peripheralBase, Channel, State) ( \
    DMA_CITER_ELINKNO_REG(peripheralBase,(Channel)) = \
     (uint16_t)(( \
      (uint16_t)(( \
       DMA_CITER_ELINKNO_REG(peripheralBase,(Channel))) & ( \
       (uint16_t)(~(uint16_t)DMA_CITER_ELINKNO_ELINK_MASK)))) | ( \
      (uint16_t)((uint16_t)(State) << DMA_CITER_ELINKNO_ELINK_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- GetCurrentMinorLoopLinkingEnabled
   ---------------------------------------------------------------------------- */

/**
 * Returns current minor loop linking state.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 */
#define DMA_PDD_GetCurrentMinorLoopLinkingEnabled(peripheralBase, Channel) ( \
    (uint16_t)(DMA_CITER_ELINKNO_REG(peripheralBase,(Channel)) & DMA_CITER_ELINKNO_ELINK_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- SetCurrentMajorLoopCount15
   ---------------------------------------------------------------------------- */

/**
 * Sets DMA channel current major loop count when channel linking is disabled.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 * @param Value 15-bit DMA channel major loop count.
 */
#define DMA_PDD_SetCurrentMajorLoopCount15(peripheralBase, Channel, Value) ( \
    DMA_CITER_ELINKNO_REG(peripheralBase,(Channel)) = \
     (uint16_t)(( \
      (uint16_t)(( \
       DMA_CITER_ELINKNO_REG(peripheralBase,(Channel))) & ( \
       (uint16_t)(~(uint16_t)DMA_CITER_ELINKNO_CITER_MASK)))) | ( \
      (uint16_t)(Value))) \
  )

/* ----------------------------------------------------------------------------
   -- SetCurrentMajorLoopCount9
   ---------------------------------------------------------------------------- */

/**
 * Sets DMA channel current major loop count when channel linking is enabled.
 * @param peripheralBase Peripheral base address.
 * @param Channel 9-bit DMA channel number.
 * @param Value DMA channel major loop count.
 */
#define DMA_PDD_SetCurrentMajorLoopCount9(peripheralBase, Channel, Value) ( \
    DMA_CITER_ELINKYES_REG(peripheralBase,(Channel)) = \
     (uint16_t)(( \
      (uint16_t)(( \
       DMA_CITER_ELINKYES_REG(peripheralBase,(Channel))) & ( \
       (uint16_t)(~(uint16_t)DMA_CITER_ELINKYES_CITER_MASK)))) | ( \
      (uint16_t)(Value))) \
  )

/* ----------------------------------------------------------------------------
   -- GetCurrentMajorLoopCount15
   ---------------------------------------------------------------------------- */

/**
 * Returns DMA channel current major loop count when channel linking is disabled.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 */
#define DMA_PDD_GetCurrentMajorLoopCount15(peripheralBase, Channel) ( \
    (uint16_t)(DMA_CITER_ELINKNO_REG(peripheralBase,(Channel)) & DMA_CITER_ELINKNO_CITER_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetCurrentMajorLoopCount9
   ---------------------------------------------------------------------------- */

/**
 * Returns DMA channel current major loop count when channel linking is enabled.
 * @param peripheralBase Peripheral base address.
 * @param Channel 9-bit DMA channel number.
 */
#define DMA_PDD_GetCurrentMajorLoopCount9(peripheralBase, Channel) ( \
    (uint16_t)(( \
     DMA_CITER_ELINKYES_REG(peripheralBase,(Channel))) & ( \
     DMA_CITER_ELINKYES_CITER_MASK)) \
  )

/* ----------------------------------------------------------------------------
   -- SetCurrentMinorLinkChannel
   ---------------------------------------------------------------------------- */

/**
 * Sets DMA channel current link number when channel linking is enabled.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 * @param Value DMA channel number.
 */
#define DMA_PDD_SetCurrentMinorLinkChannel(peripheralBase, Channel, Value) ( \
    DMA_CITER_ELINKYES_REG(peripheralBase,(Channel)) = \
     (uint16_t)(( \
      (uint16_t)(( \
       DMA_CITER_ELINKYES_REG(peripheralBase,(Channel))) & ( \
       (uint16_t)(~(uint16_t)DMA_CITER_ELINKYES_LINKCH_MASK)))) | ( \
      (uint16_t)((uint16_t)(Value) << DMA_CITER_ELINKYES_LINKCH_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- GetCurrentMinorLinkChannel
   ---------------------------------------------------------------------------- */

/**
 * Returns DMA channel current link number when channel linking is enabled.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 */
#define DMA_PDD_GetCurrentMinorLinkChannel(peripheralBase, Channel) ( \
    (uint8_t)(( \
     (uint16_t)(( \
      DMA_CITER_ELINKYES_REG(peripheralBase,(Channel))) & ( \
      DMA_CITER_ELINKYES_LINKCH_MASK))) >> ( \
     DMA_CITER_ELINKYES_LINKCH_SHIFT)) \
  )

/* ----------------------------------------------------------------------------
   -- WriteBeginningMajorLoopCountReg
   ---------------------------------------------------------------------------- */

/**
 * Writes to DMA channel beginning minor loop link major loop count register.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 * @param Value DMA channel minor loop link major loop count register value.
 */
#define DMA_PDD_WriteBeginningMajorLoopCountReg(peripheralBase, Channel, Value) ( \
    DMA_BITER_ELINKNO_REG(peripheralBase,(Channel)) = \
     (uint16_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadBeginningMajorLoopCountReg
   ---------------------------------------------------------------------------- */

/**
 * Reads DMA channel beginning minor loop link major loop count register.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 * @param Value DMA channel minor loop link major loop count register value.
 */
#define DMA_PDD_ReadBeginningMajorLoopCountReg(peripheralBase, Channel, Value) ( \
    DMA_CITER_ELINKNO_REG(peripheralBase,(Channel)) \
  )

/* ----------------------------------------------------------------------------
   -- EnableBeginningMinorLoopLinking
   ---------------------------------------------------------------------------- */

/**
 * Enables or disables DMA channel beginning minor loop linking.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 * @param State Parameter specifying if DMA channel linking will be enabled or
 *        disabled.
 */
#define DMA_PDD_EnableBeginningMinorLoopLinking(peripheralBase, Channel, State) ( \
    DMA_BITER_ELINKNO_REG(peripheralBase,(Channel)) = \
     (uint16_t)(( \
      (uint16_t)(( \
       DMA_BITER_ELINKNO_REG(peripheralBase,(Channel))) & ( \
       (uint16_t)(~(uint16_t)DMA_BITER_ELINKNO_ELINK_MASK)))) | ( \
      (uint16_t)((uint16_t)(State) << DMA_BITER_ELINKNO_ELINK_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- GetBeginningMinorLoopLinkingEnabled
   ---------------------------------------------------------------------------- */

/**
 * Returns beginning minor loop linking state.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 */
#define DMA_PDD_GetBeginningMinorLoopLinkingEnabled(peripheralBase, Channel) ( \
    (uint16_t)(DMA_BITER_ELINKNO_REG(peripheralBase,(Channel)) & DMA_BITER_ELINKNO_ELINK_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- SetBeginningMajorLoopCount15
   ---------------------------------------------------------------------------- */

/**
 * Sets DMA channel major beginning loop count when channel linking is disabled.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 * @param Value 15-bit DMA channel major loop count.
 */
#define DMA_PDD_SetBeginningMajorLoopCount15(peripheralBase, Channel, Value) ( \
    DMA_BITER_ELINKNO_REG(peripheralBase,(Channel)) = \
     (uint16_t)(( \
      (uint16_t)(( \
       DMA_BITER_ELINKNO_REG(peripheralBase,(Channel))) & ( \
       (uint16_t)(~(uint16_t)DMA_BITER_ELINKNO_BITER_MASK)))) | ( \
      (uint16_t)(Value))) \
  )

/* ----------------------------------------------------------------------------
   -- GetBeginningMajorLoopCount15
   ---------------------------------------------------------------------------- */

/**
 * Returns DMA channel major beginning loop count when channel linking is
 * disabled.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 */
#define DMA_PDD_GetBeginningMajorLoopCount15(peripheralBase, Channel) ( \
    (uint16_t)(DMA_BITER_ELINKNO_REG(peripheralBase,(Channel)) & DMA_BITER_ELINKNO_BITER_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- SetBeginningMajorLoopCount9
   ---------------------------------------------------------------------------- */

/**
 * Sets DMA channel beginning major loop count when channel linking is enabled.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 * @param Value 9-bit DMA channel major loop count.
 */
#define DMA_PDD_SetBeginningMajorLoopCount9(peripheralBase, Channel, Value) ( \
    DMA_BITER_ELINKYES_REG(peripheralBase,(Channel)) = \
     (uint16_t)(( \
      (uint16_t)(( \
       DMA_BITER_ELINKYES_REG(peripheralBase,(Channel))) & ( \
       (uint16_t)(~(uint16_t)DMA_BITER_ELINKYES_BITER_MASK)))) | ( \
      (uint16_t)(Value))) \
  )

/* ----------------------------------------------------------------------------
   -- GetBeginningMajorLoopCount9
   ---------------------------------------------------------------------------- */

/**
 * Returns DMA channel major beginning loop count when channel linking is
 * disabled.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 */
#define DMA_PDD_GetBeginningMajorLoopCount9(peripheralBase, Channel) ( \
    (uint16_t)(( \
     DMA_BITER_ELINKYES_REG(peripheralBase,(Channel))) & ( \
     DMA_BITER_ELINKYES_BITER_MASK)) \
  )

/* ----------------------------------------------------------------------------
   -- SetBeginningMinorLinkChannel
   ---------------------------------------------------------------------------- */

/**
 * Sets DMA channel beginning link number when channel linking is enabled.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 * @param Value DMA channel number.
 */
#define DMA_PDD_SetBeginningMinorLinkChannel(peripheralBase, Channel, Value) ( \
    DMA_BITER_ELINKYES_REG(peripheralBase,(Channel)) = \
     (uint16_t)(( \
      (uint16_t)(( \
       DMA_BITER_ELINKYES_REG(peripheralBase,(Channel))) & ( \
       (uint16_t)(~(uint16_t)DMA_BITER_ELINKYES_LINKCH_MASK)))) | ( \
      (uint16_t)((uint16_t)(Value) << DMA_BITER_ELINKYES_LINKCH_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- SetLastSourceAddressAdjustment
   ---------------------------------------------------------------------------- */

/**
 * Sets DMA channel last source address adjustment.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 * @param Value DMA channel last source address adjustment.
 */
#define DMA_PDD_SetLastSourceAddressAdjustment(peripheralBase, Channel, Value) ( \
    DMA_SLAST_REG(peripheralBase,(Channel)) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- GetLastSourceAddressAdjustment
   ---------------------------------------------------------------------------- */

/**
 * Returns DMA channel last source address adjustment.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 */
#define DMA_PDD_GetLastSourceAddressAdjustment(peripheralBase, Channel) ( \
    DMA_SLAST_REG(peripheralBase,(Channel)) \
  )

/* ----------------------------------------------------------------------------
   -- SetLastDestinationAddressAdjustment_ScatterGather
   ---------------------------------------------------------------------------- */

/**
 * Sets DMA channel last destination address adjustment or address for next TCD
 * to be loaded into this channel.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 * @param Value DMA channel last destination address adjustment or TCD address.
 */
#define DMA_PDD_SetLastDestinationAddressAdjustment_ScatterGather(peripheralBase, Channel, Value) ( \
    DMA_DLAST_SGA_REG(peripheralBase,(Channel)) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- GetLastDestinationAddressAdjustment_ScatterGather
   ---------------------------------------------------------------------------- */

/**
 * Returns DMA channel last destination address adjustment.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 */
#define DMA_PDD_GetLastDestinationAddressAdjustment_ScatterGather(peripheralBase, Channel) ( \
    DMA_DLAST_SGA_REG(peripheralBase,(Channel)) \
  )

/* ----------------------------------------------------------------------------
   -- WriteControlStatusReg
   ---------------------------------------------------------------------------- */

/**
 * Writes to DMA channel control status register.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 * @param Value Channel control status register value.
 */
#define DMA_PDD_WriteControlStatusReg(peripheralBase, Channel, Value) ( \
    DMA_CSR_REG(peripheralBase,(Channel)) = \
     (uint16_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadControlStatusReg
   ---------------------------------------------------------------------------- */

/**
 * Reads DMA channel control status register.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 */
#define DMA_PDD_ReadControlStatusReg(peripheralBase, Channel) ( \
    DMA_CSR_REG(peripheralBase,(Channel)) \
  )

/* ----------------------------------------------------------------------------
   -- SetStallTime
   ---------------------------------------------------------------------------- */

/**
 * Bandwidth control - forces DMA to stall after each r/w operation for selected
 * period of time.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 * @param StallTime Selects one of stall time values.
 */
#define DMA_PDD_SetStallTime(peripheralBase, Channel, StallTime) ( \
    DMA_CSR_REG(peripheralBase,(Channel)) = \
     (uint16_t)(( \
      (uint16_t)(( \
       DMA_CSR_REG(peripheralBase,(Channel))) & ( \
       (uint16_t)(~(uint16_t)DMA_CSR_BWC_MASK)))) | ( \
      (uint16_t)(StallTime))) \
  )

/* ----------------------------------------------------------------------------
   -- GetStallTime
   ---------------------------------------------------------------------------- */

/**
 * Returns bandwidth control stall time value.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 */
#define DMA_PDD_GetStallTime(peripheralBase, Channel) ( \
    (uint8_t)(( \
     (uint16_t)(DMA_CSR_REG(peripheralBase,(Channel)) & DMA_CSR_BWC_MASK)) >> ( \
     DMA_CSR_BWC_SHIFT)) \
  )

/* ----------------------------------------------------------------------------
   -- SetMajorLinkChannel
   ---------------------------------------------------------------------------- */

/**
 * Sets DMA channel major link number.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 * @param Value DMA channel number.
 */
#define DMA_PDD_SetMajorLinkChannel(peripheralBase, Channel, Value) ( \
    DMA_CSR_REG(peripheralBase,(Channel)) = \
     (uint16_t)(( \
      (uint16_t)(( \
       DMA_CSR_REG(peripheralBase,(Channel))) & ( \
       (uint16_t)(~(uint16_t)DMA_CSR_MAJORLINKCH_MASK)))) | ( \
      (uint16_t)((uint16_t)(Value) << DMA_CSR_MAJORLINKCH_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- GetMajorLinkChannel
   ---------------------------------------------------------------------------- */

/**
 * Returns DMA channel major link number.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 */
#define DMA_PDD_GetMajorLinkChannel(peripheralBase, Channel) ( \
    (uint8_t)(( \
     (uint16_t)(DMA_CSR_REG(peripheralBase,(Channel)) & DMA_CSR_MAJORLINKCH_MASK)) >> ( \
     DMA_CSR_MAJORLINKCH_SHIFT)) \
  )

/* ----------------------------------------------------------------------------
   -- GetChannelActivityFlags
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MKL04Z4)) || (defined(MCU_MKL05Z4)) || (defined(MCU_MKL14Z4)) || (defined(MCU_MKL15Z4)) || (defined(MCU_MKL24Z4)) || (defined(MCU_MKL25Z4)) || (defined(MCU_PCK20L4)))
/**
 * Returns DMA channel request pending, busy and done status.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number. Use constants from group "DMA channel
 *        constants.".
 * @return Use constants from group "Channel activity status constants." for
 *         processing return value.
 */
  #define DMA_PDD_GetChannelActivityFlags(peripheralBase, Channel) ( \
      (uint32_t)(( \
       DMA_DSR_BCR_REG(peripheralBase,(Channel))) & ( \
       (uint32_t)(DMA_DSR_BCR_REQ_MASK | (DMA_DSR_BCR_BSY_MASK | DMA_DSR_BCR_DONE_MASK)))) \
    )
#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */
/**
 * Returns channel done and channel active status.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 */
  #define DMA_PDD_GetChannelActivityFlags(peripheralBase, Channel) ( \
      (uint16_t)(( \
       DMA_CSR_REG(peripheralBase,(Channel))) & ( \
       (uint16_t)(DMA_CSR_DONE_MASK | DMA_CSR_ACTIVE_MASK))) \
    )
#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */

/* ----------------------------------------------------------------------------
   -- ClearChannelActivityFlags
   ---------------------------------------------------------------------------- */

/**
 * Clears channel activity status flags.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 * @param ChannelActivityFlags DMA channel activity status flags.
 */
#define DMA_PDD_ClearChannelActivityFlags(peripheralBase, Channel, ChannelActivityFlags) ( \
    DMA_CSR_REG(peripheralBase,(Channel)) &= \
     (uint16_t)(~(uint16_t)(ChannelActivityFlags)) \
  )

/* ----------------------------------------------------------------------------
   -- GetDoneFlag
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MKL04Z4)) || (defined(MCU_MKL05Z4)) || (defined(MCU_MKL14Z4)) || (defined(MCU_MKL15Z4)) || (defined(MCU_MKL24Z4)) || (defined(MCU_MKL25Z4)) || (defined(MCU_PCK20L4)))
/**
 * Returns channel done status.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number. Use constants from group "DMA channel
 *        constants.".
 */
  #define DMA_PDD_GetDoneFlag(peripheralBase, Channel) ( \
      (uint32_t)(DMA_DSR_BCR_REG(peripheralBase,(Channel)) & DMA_DSR_BCR_DONE_MASK) \
    )
#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */
/**
 * Returns channel done status.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 */
  #define DMA_PDD_GetDoneFlag(peripheralBase, Channel) ( \
      (uint16_t)(DMA_CSR_REG(peripheralBase,(Channel)) & DMA_CSR_DONE_MASK) \
    )
#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */

/* ----------------------------------------------------------------------------
   -- GetActiveFlag
   ---------------------------------------------------------------------------- */

/**
 * Returns channel active status.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 */
#define DMA_PDD_GetActiveFlag(peripheralBase, Channel) ( \
    (uint16_t)(DMA_CSR_REG(peripheralBase,(Channel)) & DMA_CSR_ACTIVE_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- EnableMajorLoopLinking
   ---------------------------------------------------------------------------- */

/**
 * Enables or disables DMA channel major loop linking.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 * @param State Parameter specifying if DMA channel linking will be enabled or
 *        disabled.
 */
#define DMA_PDD_EnableMajorLoopLinking(peripheralBase, Channel, State) ( \
    DMA_CSR_REG(peripheralBase,(Channel)) = \
     (uint16_t)(( \
      (uint16_t)(( \
       DMA_CSR_REG(peripheralBase,(Channel))) & ( \
       (uint16_t)(~(uint16_t)DMA_CSR_MAJORELINK_MASK)))) | ( \
      (uint16_t)((uint16_t)(State) << DMA_CSR_MAJORELINK_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- GetMajorLoopLinkingEnabled
   ---------------------------------------------------------------------------- */

/**
 * Returns major loop linking state.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 */
#define DMA_PDD_GetMajorLoopLinkingEnabled(peripheralBase, Channel) ( \
    (uint16_t)(DMA_CSR_REG(peripheralBase,(Channel)) & DMA_CSR_MAJORELINK_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- EnableScatterGather
   ---------------------------------------------------------------------------- */

/**
 * Enables or disables DMA channel scatter/gather processing.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 * @param State Parameter specifying if DMA channel scatter/gather processing
 *        will be enabled or disabled.
 */
#define DMA_PDD_EnableScatterGather(peripheralBase, Channel, State) ( \
    DMA_CSR_REG(peripheralBase,(Channel)) = \
     (uint16_t)(( \
      (uint16_t)(( \
       DMA_CSR_REG(peripheralBase,(Channel))) & ( \
       (uint16_t)(~(uint16_t)DMA_CSR_ESG_MASK)))) | ( \
      (uint16_t)((uint16_t)(State) << DMA_CSR_ESG_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- GetScatterGatherEnabled
   ---------------------------------------------------------------------------- */

/**
 * Returns scatter/gather processing state.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 */
#define DMA_PDD_GetScatterGatherEnabled(peripheralBase, Channel) ( \
    (uint16_t)(DMA_CSR_REG(peripheralBase,(Channel)) & DMA_CSR_ESG_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- EnableRequestAutoDisable
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MKL04Z4)) || (defined(MCU_MKL05Z4)) || (defined(MCU_MKL14Z4)) || (defined(MCU_MKL15Z4)) || (defined(MCU_MKL24Z4)) || (defined(MCU_MKL25Z4)) || (defined(MCU_PCK20L4)))
/**
 * Enables or disables DMA channel automaticall request clearing.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number. Use constants from group "DMA channel
 *        constants.".
 * @param State Parameter specifying if DMA channel automaticall request
 *        clearing will be enabled or disabled.
 */
  #define DMA_PDD_EnableRequestAutoDisable(peripheralBase, Channel, State) ( \
      DMA_DCR_REG(peripheralBase,(Channel)) = \
       (uint32_t)(( \
        (uint32_t)(( \
         DMA_DCR_REG(peripheralBase,(Channel))) & ( \
         (uint32_t)(~(uint32_t)DMA_DCR_D_REQ_MASK)))) | ( \
        (uint32_t)((uint32_t)(State) << DMA_DCR_D_REQ_SHIFT))) \
    )
#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */
/**
 * Enables or disables DMA channel automaticall request clearing.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 * @param State Parameter specifying if DMA channel automaticall request
 *        clearing will be enabled or disabled.
 */
  #define DMA_PDD_EnableRequestAutoDisable(peripheralBase, Channel, State) ( \
      DMA_CSR_REG(peripheralBase,(Channel)) = \
       (uint16_t)(( \
        (uint16_t)(( \
         DMA_CSR_REG(peripheralBase,(Channel))) & ( \
         (uint16_t)(~(uint16_t)DMA_CSR_DREQ_MASK)))) | ( \
        (uint16_t)((uint16_t)(State) << DMA_CSR_DREQ_SHIFT))) \
    )
#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */

/* ----------------------------------------------------------------------------
   -- GetRequestAutoDisableEnabled
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MKL04Z4)) || (defined(MCU_MKL05Z4)) || (defined(MCU_MKL14Z4)) || (defined(MCU_MKL15Z4)) || (defined(MCU_MKL24Z4)) || (defined(MCU_MKL25Z4)) || (defined(MCU_PCK20L4)))
/**
 * Returns automaticall request clearing state.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number. Use constants from group "DMA channel
 *        constants.".
 */
  #define DMA_PDD_GetRequestAutoDisableEnabled(peripheralBase, Channel) ( \
      (uint32_t)(DMA_DCR_REG(peripheralBase,(Channel)) & DMA_DCR_D_REQ_MASK) \
    )
#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */
/**
 * Returns automaticall request clearing state.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 */
  #define DMA_PDD_GetRequestAutoDisableEnabled(peripheralBase, Channel) ( \
      (uint16_t)(DMA_CSR_REG(peripheralBase,(Channel)) & DMA_CSR_DREQ_MASK) \
    )
#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */

/* ----------------------------------------------------------------------------
   -- EnableTransferCompleteInterrupt
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MKL04Z4)) || (defined(MCU_MKL05Z4)) || (defined(MCU_MKL14Z4)) || (defined(MCU_MKL15Z4)) || (defined(MCU_MKL24Z4)) || (defined(MCU_MKL25Z4)) || (defined(MCU_PCK20L4)))
/**
 * Enables or disables channel transfer complete interrupt.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number. Use constants from group "DMA channel
 *        constants.".
 * @param State Parameter specifying if DMA channel transfer complete interrupt
 *        will be enabled or disabled.
 */
  #define DMA_PDD_EnableTransferCompleteInterrupt(peripheralBase, Channel, State) ( \
      DMA_DCR_REG(peripheralBase,(Channel)) = \
       (uint32_t)(( \
        (uint32_t)(( \
         DMA_DCR_REG(peripheralBase,(Channel))) & ( \
         (uint32_t)(~(uint32_t)DMA_DCR_EINT_MASK)))) | ( \
        (uint32_t)((uint32_t)(State) << DMA_DCR_EINT_SHIFT))) \
    )
#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */
/**
 * Enables or disables channel transfer complete interrupt.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 * @param State Parameter specifying if DMA channel transfer complete interrupt
 *        will be enabled or disabled.
 */
  #define DMA_PDD_EnableTransferCompleteInterrupt(peripheralBase, Channel, State) ( \
      DMA_CSR_REG(peripheralBase,(Channel)) = \
       (uint16_t)(( \
        (uint16_t)(( \
         DMA_CSR_REG(peripheralBase,(Channel))) & ( \
         (uint16_t)(~(uint16_t)DMA_CSR_INTMAJOR_MASK)))) | ( \
        (uint16_t)((uint16_t)(State) << DMA_CSR_INTMAJOR_SHIFT))) \
    )
#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */

/* ----------------------------------------------------------------------------
   -- GetTransferCompleteInterruptEnabled
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MKL04Z4)) || (defined(MCU_MKL05Z4)) || (defined(MCU_MKL14Z4)) || (defined(MCU_MKL15Z4)) || (defined(MCU_MKL24Z4)) || (defined(MCU_MKL25Z4)) || (defined(MCU_PCK20L4)))
/**
 * Returns transfer complete enable interrupt state.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number. Use constants from group "DMA channel
 *        constants.".
 */
  #define DMA_PDD_GetTransferCompleteInterruptEnabled(peripheralBase, Channel) ( \
      (uint32_t)(DMA_DCR_REG(peripheralBase,(Channel)) & DMA_DCR_EINT_MASK) \
    )
#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */
/**
 * Returns transfer complete enable interrupt state.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 */
  #define DMA_PDD_GetTransferCompleteInterruptEnabled(peripheralBase, Channel) ( \
      (uint16_t)(DMA_CSR_REG(peripheralBase,(Channel)) & DMA_CSR_INTMAJOR_MASK) \
    )
#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) */

/* ----------------------------------------------------------------------------
   -- EnableTransferHalfInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables or disables channel transfer half interrupt.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 * @param State Parameter specifying if DMA channel transfer half interrupt will
 *        be enabled or disabled.
 */
#define DMA_PDD_EnableTransferHalfInterrupt(peripheralBase, Channel, State) ( \
    DMA_CSR_REG(peripheralBase,(Channel)) = \
     (uint16_t)(( \
      (uint16_t)(( \
       DMA_CSR_REG(peripheralBase,(Channel))) & ( \
       (uint16_t)(~(uint16_t)DMA_CSR_INTHALF_MASK)))) | ( \
      (uint16_t)((uint16_t)(State) << DMA_CSR_INTHALF_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- GetTransferHalfInterruptEnabled
   ---------------------------------------------------------------------------- */

/**
 * Returns transfer half enable interrupt state.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number.
 */
#define DMA_PDD_GetTransferHalfInterruptEnabled(peripheralBase, Channel) ( \
    (uint16_t)(DMA_CSR_REG(peripheralBase,(Channel)) & DMA_CSR_INTHALF_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- SetChannelGroup1Priority
   ---------------------------------------------------------------------------- */

/**
 * Sets group 1 priority level.
 * @param peripheralBase Peripheral base address.
 * @param Priority Parameter specifying group priority 1 level when fixed
 *        priority group arbitration is enabled.
 */
#define DMA_PDD_SetChannelGroup1Priority(peripheralBase, Priority) ( \
    DMA_CR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(DMA_CR_REG(peripheralBase) & (uint32_t)(~(uint32_t)DMA_CR_GRP1PRI_MASK))) | ( \
      (uint32_t)((uint32_t)(Priority) << DMA_CR_GRP1PRI_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- SetChannelGroup0Priority
   ---------------------------------------------------------------------------- */

/**
 * Sets group 0 priority level.
 * @param peripheralBase Peripheral base address.
 * @param Priority Parameter specifying group priority 1 level when fixed
 *        priority group arbitration is enabled.
 */
#define DMA_PDD_SetChannelGroup0Priority(peripheralBase, Priority) ( \
    DMA_CR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(DMA_CR_REG(peripheralBase) & (uint32_t)(~(uint32_t)DMA_CR_GRP0PRI_MASK))) | ( \
      (uint32_t)((uint32_t)(Priority) << DMA_CR_GRP0PRI_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableRoundRobinGroupArbitration
   ---------------------------------------------------------------------------- */

/**
 * Enables or disables round robin group arbitration.
 * @param peripheralBase Peripheral base address.
 * @param State Parameter specifying if round robin group arbitration is enabled
 *        or disabled.
 */
#define DMA_PDD_EnableRoundRobinGroupArbitration(peripheralBase, State) ( \
    DMA_CR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(DMA_CR_REG(peripheralBase) & (uint32_t)(~(uint32_t)DMA_CR_ERGA_MASK))) | ( \
      (uint32_t)((uint32_t)(State) << DMA_CR_ERGA_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- GetRoundRobinGroupArbitrationEnabled
   ---------------------------------------------------------------------------- */

/**
 * Returns round robin group arbitration state.
 * @param peripheralBase Peripheral base address.
 */
#define DMA_PDD_GetRoundRobinGroupArbitrationEnabled(peripheralBase) ( \
    (uint32_t)(DMA_CR_REG(peripheralBase) & DMA_CR_ERGA_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetChannelGroupPriority
   ---------------------------------------------------------------------------- */

/**
 * Returns group priority assigned to specified DMA channel.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel index.
 */
#define DMA_PDD_GetChannelGroupPriority(peripheralBase, Channel) ( \
    (uint8_t)( \
      (DMA_PDD_DCHPRI_REG(peripheralBase, Channel) & DMA_DCHPRI3_GRPPRI_MASK) >> DMA_DCHPRI3_GRPPRI_SHIFT \
    ) \
  )

/* ----------------------------------------------------------------------------
   -- EnableInterrupts
   ---------------------------------------------------------------------------- */

/**
 * Enables interrupts defined by mask parameter.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number. Use constants from group "DMA channel
 *        constants.".
 * @param Mask Mask of interrupts to enable. Use constants from group
 *        "Interrupts' mask.".
 */
#define DMA_PDD_EnableInterrupts(peripheralBase, Channel, Mask) ( \
    DMA_DCR_REG(peripheralBase,(Channel)) |= \
     (uint32_t)(Mask) \
  )

/* ----------------------------------------------------------------------------
   -- DisableInterrupts
   ---------------------------------------------------------------------------- */

/**
 * Disables interrupts defined by mask parameter.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number. Use constants from group "DMA channel
 *        constants.".
 * @param Mask Mask of interrupts to disable. Use constants from group
 *        "Interrupts' mask.".
 */
#define DMA_PDD_DisableInterrupts(peripheralBase, Channel, Mask) ( \
    DMA_DCR_REG(peripheralBase,(Channel)) &= \
     (uint32_t)(~(uint32_t)(Mask)) \
  )

/* ----------------------------------------------------------------------------
   -- GetInterruptFlags
   ---------------------------------------------------------------------------- */

/**
 * Returns interrupt flag bits.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number. Use constants from group "DMA channel
 *        constants.".
 * @return Use constants from group "Interrupts' flags." for processing return
 *         value.
 */
#define DMA_PDD_GetInterruptFlags(peripheralBase, Channel) ( \
    (uint32_t)(DMA_DSR_BCR_REG(peripheralBase,(Channel)) & DMA_DSR_BCR_DONE_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- WriteStatusByteCountRegister
   ---------------------------------------------------------------------------- */

/**
 * Writes to DMA channel status and byte count control register.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number. Use constants from group "DMA channel
 *        constants.".
 * @param Value DMA channel request control register value.
 */
#define DMA_PDD_WriteStatusByteCountRegister(peripheralBase, Channel, Value) ( \
    DMA_DSR_BCR_REG(peripheralBase,(Channel)) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- GetStatusByteCountRegister
   ---------------------------------------------------------------------------- */

/**
 * Returns DMA channel status and byte count register.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number. Use constants from group "DMA channel
 *        constants.".
 */
#define DMA_PDD_GetStatusByteCountRegister(peripheralBase, Channel) ( \
    DMA_DSR_BCR_REG(peripheralBase,(Channel)) \
  )

/* ----------------------------------------------------------------------------
   -- WriteStatusRegister
   ---------------------------------------------------------------------------- */

/**
 * Writes to DMA channel status register.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number. Use constants from group "DMA channel
 *        constants.".
 * @param Value DMA channel request control register value.
 */
#define DMA_PDD_WriteStatusRegister(peripheralBase, Channel, Value) ( \
    DMA_DSR_REG(peripheralBase,(Channel)) = \
     (uint8_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- GetStatusRegister
   ---------------------------------------------------------------------------- */

/**
 * Returns DMA channel status register provading information about last recorded
 * channel error.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number. Use constants from group "DMA channel
 *        constants.".
 */
#define DMA_PDD_GetStatusRegister(peripheralBase, Channel) ( \
    DMA_DSR_REG(peripheralBase,(Channel)) \
  )

/* ----------------------------------------------------------------------------
   -- ClearDoneFlag
   ---------------------------------------------------------------------------- */

/**
 * Clears channel done status.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number. Use constants from group "DMA channel
 *        constants.".
 */
#define DMA_PDD_ClearDoneFlag(peripheralBase, Channel) ( \
    DMA_DSR_BCR_REG(peripheralBase,(Channel)) |= \
     DMA_DSR_BCR_DONE_MASK \
  )

/* ----------------------------------------------------------------------------
   -- GetBusyFlag
   ---------------------------------------------------------------------------- */

/**
 * Returns channel busy status.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number. Use constants from group "DMA channel
 *        constants.".
 */
#define DMA_PDD_GetBusyFlag(peripheralBase, Channel) ( \
    (uint32_t)(DMA_DSR_BCR_REG(peripheralBase,(Channel)) & DMA_DSR_BCR_BSY_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetRequestPendingFlag
   ---------------------------------------------------------------------------- */

/**
 * Returns channel request pending status.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number. Use constants from group "DMA channel
 *        constants.".
 */
#define DMA_PDD_GetRequestPendingFlag(peripheralBase, Channel) ( \
    (uint32_t)(DMA_DSR_BCR_REG(peripheralBase,(Channel)) & DMA_DSR_BCR_REQ_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetChannelErrorFlags
   ---------------------------------------------------------------------------- */

/**
 * Returns DMA channel configuration error, bus error on source and bus error on
 * destination status.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number. Use constants from group "DMA channel
 *        constants.".
 * @return Use constants from group "Channel error status constants." for
 *         processing return value.
 */
#define DMA_PDD_GetChannelErrorFlags(peripheralBase, Channel) ( \
    (uint32_t)(( \
     DMA_DSR_BCR_REG(peripheralBase,(Channel))) & ( \
     (uint32_t)(DMA_DSR_BCR_CE_MASK | (DMA_DSR_BCR_BES_MASK | DMA_DSR_BCR_BED_MASK)))) \
  )

/* ----------------------------------------------------------------------------
   -- SetByteCount
   ---------------------------------------------------------------------------- */

/**
 * Sets DMA channel byte transfer count.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number. Use constants from group "DMA channel
 *        constants.".
 * @param Value 24-bit DMA channel byte count.
 */
#define DMA_PDD_SetByteCount(peripheralBase, Channel, Value) ( \
    DMA_DSR_BCR_REG(peripheralBase,(Channel)) = \
     (uint32_t)(( \
      (uint32_t)(( \
       DMA_DSR_BCR_REG(peripheralBase,(Channel))) & (( \
       (uint32_t)(~(uint32_t)DMA_DSR_BCR_BCR_MASK)) & ( \
       (uint32_t)(~(uint32_t)DMA_DSR_BCR_DONE_MASK))))) | ( \
      (uint32_t)(Value))) \
  )

/* ----------------------------------------------------------------------------
   -- GetByteCount
   ---------------------------------------------------------------------------- */

/**
 * Returns DMA channel byte transfer count.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number. Use constants from group "DMA channel
 *        constants.".
 */
#define DMA_PDD_GetByteCount(peripheralBase, Channel) ( \
    (uint32_t)(DMA_DSR_BCR_REG(peripheralBase,(Channel)) & DMA_DSR_BCR_BCR_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- EnablePeripheralRequest
   ---------------------------------------------------------------------------- */

/**
 * Enables or disables peripheral requests.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number. Use constants from group "DMA channel
 *        constants.".
 * @param State Parameter specifying if DMA channel peripheral requests will be
 *        enabled or ignored.
 */
#define DMA_PDD_EnablePeripheralRequest(peripheralBase, Channel, State) ( \
    DMA_DCR_REG(peripheralBase,(Channel)) = \
     (uint32_t)(( \
      (uint32_t)(( \
       DMA_DCR_REG(peripheralBase,(Channel))) & ( \
       (uint32_t)(~(uint32_t)DMA_DCR_ERQ_MASK)))) | ( \
      (uint32_t)((uint32_t)(State) << DMA_DCR_ERQ_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- GetPeripheralRequestEnabled
   ---------------------------------------------------------------------------- */

/**
 * Returns peripheral requests enable state.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number. Use constants from group "DMA channel
 *        constants.".
 */
#define DMA_PDD_GetPeripheralRequestEnabled(peripheralBase, Channel) ( \
    (uint32_t)(DMA_DCR_REG(peripheralBase,(Channel)) & DMA_DCR_ERQ_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- EnableCycleSteal
   ---------------------------------------------------------------------------- */

/**
 * Enables or disables cycle steal mode (single read/write transfer per request).
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number. Use constants from group "DMA channel
 *        constants.".
 * @param State Parameter specifying if DMA channel cycle-steal mode will be
 *        enabled or disabled.
 */
#define DMA_PDD_EnableCycleSteal(peripheralBase, Channel, State) ( \
    DMA_DCR_REG(peripheralBase,(Channel)) = \
     (uint32_t)(( \
      (uint32_t)(DMA_DCR_REG(peripheralBase,(Channel)) & (uint32_t)(~(uint32_t)DMA_DCR_CS_MASK))) | ( \
      (uint32_t)((uint32_t)(State) << DMA_DCR_CS_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- GetCycleStealEnabled
   ---------------------------------------------------------------------------- */

/**
 * Returns cycle steal mode state.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number. Use constants from group "DMA channel
 *        constants.".
 */
#define DMA_PDD_GetCycleStealEnabled(peripheralBase, Channel) ( \
    (uint32_t)(DMA_DCR_REG(peripheralBase,(Channel)) & DMA_DCR_CS_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- EnableAutoAlign
   ---------------------------------------------------------------------------- */

/**
 * Enables or disables auto-align mode.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number. Use constants from group "DMA channel
 *        constants.".
 * @param State Parameter specifying if DMA channel transfers will be transfers
 *        are optimized based on the address and size or not.
 */
#define DMA_PDD_EnableAutoAlign(peripheralBase, Channel, State) ( \
    DMA_DCR_REG(peripheralBase,(Channel)) = \
     (uint32_t)(( \
      (uint32_t)(DMA_DCR_REG(peripheralBase,(Channel)) & (uint32_t)(~(uint32_t)DMA_DCR_AA_MASK))) | ( \
      (uint32_t)((uint32_t)(State) << DMA_DCR_AA_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- GetAutoAlignEnabled
   ---------------------------------------------------------------------------- */

/**
 * Returns auto-align mode state.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number. Use constants from group "DMA channel
 *        constants.".
 */
#define DMA_PDD_GetAutoAlignEnabled(peripheralBase, Channel) ( \
    (uint32_t)(DMA_DCR_REG(peripheralBase,(Channel)) & DMA_DCR_AA_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- EnableAsynchronousRequests
   ---------------------------------------------------------------------------- */

/**
 * Enables or disables asynchronous requests.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number. Use constants from group "DMA channel
 *        constants.".
 * @param State Parameter specifying if DMA channel transfers will be transfers
 *        are optimized based on the address and size or not.
 */
#define DMA_PDD_EnableAsynchronousRequests(peripheralBase, Channel, State) ( \
    DMA_DCR_REG(peripheralBase,(Channel)) = \
     (uint32_t)(( \
      (uint32_t)(( \
       DMA_DCR_REG(peripheralBase,(Channel))) & ( \
       (uint32_t)(~(uint32_t)DMA_DCR_EADREQ_MASK)))) | ( \
      (uint32_t)((uint32_t)(State) << DMA_DCR_EADREQ_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- GetAsynchronousRequestsEnabled
   ---------------------------------------------------------------------------- */

/**
 * Returns auto-align mode state.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number. Use constants from group "DMA channel
 *        constants.".
 */
#define DMA_PDD_GetAsynchronousRequestsEnabled(peripheralBase, Channel) ( \
    (uint32_t)(DMA_DCR_REG(peripheralBase,(Channel)) & DMA_DCR_EADREQ_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- EnableSourceAddressIncrement
   ---------------------------------------------------------------------------- */

/**
 * Enables or disables source address incrementation.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number. Use constants from group "DMA channel
 *        constants.".
 * @param State Parameter specifying if DMA channel source address increments
 *        after each successful transfer (according to transfer size) or not.
 */
#define DMA_PDD_EnableSourceAddressIncrement(peripheralBase, Channel, State) ( \
    DMA_DCR_REG(peripheralBase,(Channel)) = \
     (uint32_t)(( \
      (uint32_t)(( \
       DMA_DCR_REG(peripheralBase,(Channel))) & ( \
       (uint32_t)(~(uint32_t)DMA_DCR_SINC_MASK)))) | ( \
      (uint32_t)((uint32_t)(State) << DMA_DCR_SINC_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- GetSourceAddressIncrementEnabled
   ---------------------------------------------------------------------------- */

/**
 * Returns source address incrementation enable state.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number. Use constants from group "DMA channel
 *        constants.".
 */
#define DMA_PDD_GetSourceAddressIncrementEnabled(peripheralBase, Channel) ( \
    (uint32_t)(DMA_DCR_REG(peripheralBase,(Channel)) & DMA_DCR_SINC_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- EnableDestinationAddressIncrement
   ---------------------------------------------------------------------------- */

/**
 * Enables or disables destination address incrementation.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number. Use constants from group "DMA channel
 *        constants.".
 * @param State Parameter specifying if DMA channel destination address
 *        increments after each successful transfer (according to transfer size) or not.
 */
#define DMA_PDD_EnableDestinationAddressIncrement(peripheralBase, Channel, State) ( \
    DMA_DCR_REG(peripheralBase,(Channel)) = \
     (uint32_t)(( \
      (uint32_t)(( \
       DMA_DCR_REG(peripheralBase,(Channel))) & ( \
       (uint32_t)(~(uint32_t)DMA_DCR_DINC_MASK)))) | ( \
      (uint32_t)((uint32_t)(State) << DMA_DCR_DINC_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- GetDestinationAddressIncrementEnabled
   ---------------------------------------------------------------------------- */

/**
 * Returns destination address incrementation enable state.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number. Use constants from group "DMA channel
 *        constants.".
 */
#define DMA_PDD_GetDestinationAddressIncrementEnabled(peripheralBase, Channel) ( \
    (uint32_t)(DMA_DCR_REG(peripheralBase,(Channel)) & DMA_DCR_DINC_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- SetChannelLinkingMode
   ---------------------------------------------------------------------------- */

/**
 * Sets DMA channel linking mode.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number. Use constants from group "DMA channel
 *        constants.".
 * @param Mode DMA channel linking mode.
 */
#define DMA_PDD_SetChannelLinkingMode(peripheralBase, Channel, Mode) ( \
    DMA_DCR_REG(peripheralBase,(Channel)) = \
     (uint32_t)(( \
      (uint32_t)(( \
       DMA_DCR_REG(peripheralBase,(Channel))) & ( \
       (uint32_t)(~(uint32_t)DMA_DCR_LINKCC_MASK)))) | ( \
      (uint32_t)(Mode))) \
  )

/* ----------------------------------------------------------------------------
   -- GetChannelLinkingMode
   ---------------------------------------------------------------------------- */

/**
 * Returns DMA channel linking mode.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number. Use constants from group "DMA channel
 *        constants.".
 */
#define DMA_PDD_GetChannelLinkingMode(peripheralBase, Channel) ( \
    (uint8_t)(( \
     (uint32_t)(DMA_DCR_REG(peripheralBase,(Channel)) & DMA_DCR_LINKCC_MASK)) >> ( \
     DMA_DCR_LINKCC_SHIFT)) \
  )

/* ----------------------------------------------------------------------------
   -- SetLinkChannel1
   ---------------------------------------------------------------------------- */

/**
 * Sets DMA channel link 1.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number. Use constants from group "DMA channel
 *        constants.".
 * @param Value Linked DMA channel number. Use constants from group "DMA channel
 *        constants".
 */
#define DMA_PDD_SetLinkChannel1(peripheralBase, Channel, Value) ( \
    DMA_DCR_REG(peripheralBase,(Channel)) = \
     (uint32_t)(( \
      (uint32_t)(( \
       DMA_DCR_REG(peripheralBase,(Channel))) & ( \
       (uint32_t)(~(uint32_t)DMA_DCR_LCH1_MASK)))) | ( \
      (uint32_t)((uint32_t)(Value) << DMA_DCR_LCH1_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- GetLinkChannel1
   ---------------------------------------------------------------------------- */

/**
 * Returns DMA channel link 1 channel number. Use constants from group "DMA
 * channel constants" for processing return value.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number. Use constants from group "DMA channel
 *        constants.".
 */
#define DMA_PDD_GetLinkChannel1(peripheralBase, Channel) ( \
    (uint8_t)(( \
     (uint32_t)(DMA_DCR_REG(peripheralBase,(Channel)) & DMA_DCR_LCH1_MASK)) >> ( \
     DMA_DCR_LCH1_SHIFT)) \
  )

/* ----------------------------------------------------------------------------
   -- SetLinkChannel2
   ---------------------------------------------------------------------------- */

/**
 * Sets DMA channel link 2.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number. Use constants from group "DMA channel
 *        constants.".
 * @param Value Linked DMA channel number. Use constants from group "DMA channel
 *        constants".
 */
#define DMA_PDD_SetLinkChannel2(peripheralBase, Channel, Value) ( \
    DMA_DCR_REG(peripheralBase,(Channel)) = \
     (uint32_t)(( \
      (uint32_t)(( \
       DMA_DCR_REG(peripheralBase,(Channel))) & ( \
       (uint32_t)(~(uint32_t)DMA_DCR_LCH2_MASK)))) | ( \
      (uint32_t)(Value))) \
  )

/* ----------------------------------------------------------------------------
   -- GetLinkChannel2
   ---------------------------------------------------------------------------- */

/**
 * Returns DMA channel link 2 channel number. Use constants from group "DMA
 * channel constants" for processing return value.
 * @param peripheralBase Peripheral base address.
 * @param Channel DMA channel number. Use constants from group "DMA channel
 *        constants.".
 */
#define DMA_PDD_GetLinkChannel2(peripheralBase, Channel) ( \
    (uint8_t)(DMA_DCR_REG(peripheralBase,(Channel)) & DMA_DCR_LCH2_MASK) \
  )
#endif  /* #if defined(DMA_PDD_H_) */

/* DMA_PDD.h, eof. */
