/*
  PDD layer implementation for peripheral type ADC
  (C) 2010 Freescale, Inc. All rights reserved.

  This file is static and it is generated from API-Factory
*/

#if !defined(ADC_PDD_H_)
#define ADC_PDD_H_

/* ----------------------------------------------------------------------------
   -- Test if supported MCU is active
   ---------------------------------------------------------------------------- */

#if !defined(MCU_ACTIVE)
  // No MCU is active
  #error ADC PDD library: No derivative is active. Place proper #include with PDD memory map before including PDD library.
#elif \
      !defined(MCU_MK10D10) /* ADC0, ADC1 */ && \
      !defined(MCU_MK10D5) /* ADC0 */ && \
      !defined(MCU_MK10D7) /* ADC0, ADC1 */ && \
      !defined(MCU_MK10F12) /* ADC0, ADC1, ADC2, ADC3 */ && \
      !defined(MCU_MK10DZ10) /* ADC0, ADC1 */ && \
      !defined(MCU_MK11D5) /* ADC0 */ && \
      !defined(MCU_MK12D5) /* ADC0 */ && \
      !defined(MCU_MK20D10) /* ADC0, ADC1 */ && \
      !defined(MCU_MK20D5) /* ADC0 */ && \
      !defined(MCU_MK20D7) /* ADC0, ADC1 */ && \
      !defined(MCU_MK20F12) /* ADC0, ADC1, ADC2, ADC3 */ && \
      !defined(MCU_MK20DZ10) /* ADC0, ADC1 */ && \
      !defined(MCU_MK21D5) /* ADC0 */ && \
      !defined(MCU_MK22D5) /* ADC0 */ && \
      !defined(MCU_MK30D10) /* ADC0, ADC1 */ && \
      !defined(MCU_MK30D7) /* ADC0, ADC1 */ && \
      !defined(MCU_MK30DZ10) /* ADC0, ADC1 */ && \
      !defined(MCU_MK40D10) /* ADC0, ADC1 */ && \
      !defined(MCU_MK40D7) /* ADC0, ADC1 */ && \
      !defined(MCU_MK40DZ10) /* ADC0, ADC1 */ && \
      !defined(MCU_MK40X256VMD100) /* ADC0, ADC1 */ && \
      !defined(MCU_MK50D10) /* ADC0, ADC1 */ && \
      !defined(MCU_MK50D7) /* ADC0, ADC1 */ && \
      !defined(MCU_MK50DZ10) /* ADC0, ADC1 */ && \
      !defined(MCU_MK51D10) /* ADC0, ADC1 */ && \
      !defined(MCU_MK51D7) /* ADC0, ADC1 */ && \
      !defined(MCU_MK51DZ10) /* ADC0, ADC1 */ && \
      !defined(MCU_MK52D10) /* ADC0, ADC1 */ && \
      !defined(MCU_MK52DZ10) /* ADC0, ADC1 */ && \
      !defined(MCU_MK53D10) /* ADC0, ADC1 */ && \
      !defined(MCU_MK53DZ10) /* ADC0, ADC1 */ && \
      !defined(MCU_MK60D10) /* ADC0, ADC1 */ && \
      !defined(MCU_MK60F12) /* ADC0, ADC1, ADC2, ADC3 */ && \
      !defined(MCU_MK60F15) /* ADC0, ADC1, ADC2, ADC3 */ && \
      !defined(MCU_MK60DZ10) /* ADC0, ADC1 */ && \
      !defined(MCU_MK60N512VMD100) /* ADC0, ADC1 */ && \
      !defined(MCU_MK61F12) /* ADC0, ADC1, ADC2, ADC3 */ && \
      !defined(MCU_MK61F15) /* ADC0, ADC1, ADC2, ADC3 */ && \
      !defined(MCU_MK70F12) /* ADC0, ADC1, ADC2, ADC3 */ && \
      !defined(MCU_MK70F15) /* ADC0, ADC1, ADC2, ADC3 */ && \
      !defined(MCU_MKL04Z4) /* ADC0 */ && \
      !defined(MCU_MKL05Z4) /* ADC0 */ && \
      !defined(MCU_MKL14Z4) /* ADC0 */ && \
      !defined(MCU_MKL15Z4) /* ADC0 */ && \
      !defined(MCU_MKL24Z4) /* ADC0 */ && \
      !defined(MCU_MKL25Z4) /* ADC0 */ && \
      !defined(MCU_PCK20L4) /* ADC0 */
  // Unsupported MCU is active
  #error ADC PDD library: Unsupported derivative is active.
#endif

#include "PDD_Types.h"

/* ----------------------------------------------------------------------------
   -- Method symbol definitions
   ---------------------------------------------------------------------------- */

#if ((defined(MCU_MKL04Z4)) || (defined(MCU_MKL05Z4)) || (defined(MCU_MKL14Z4)) || (defined(MCU_MKL24Z4)))
/* Channel constants for channel selection */
  #define ADC_PDD_SINGLE_ENDED_DAD0 0U             /**< Single-ended mode, channel 0 */
  #define ADC_PDD_SINGLE_ENDED_DAD1 0x1U           /**< Single-ended mode, channel 1 */
  #define ADC_PDD_SINGLE_ENDED_DAD2 0x2U           /**< Single-ended mode, channel 2 */
  #define ADC_PDD_SINGLE_ENDED_DAD3 0x3U           /**< Single-ended mode, channel 3 */
  #define ADC_PDD_SINGLE_ENDED_AD4 0x4U            /**< Single-ended mode, channel 4 */
  #define ADC_PDD_SINGLE_ENDED_AD5 0x5U            /**< Single-ended mode, channel 5 */
  #define ADC_PDD_SINGLE_ENDED_AD6 0x6U            /**< Single-ended mode, channel 6 */
  #define ADC_PDD_SINGLE_ENDED_AD7 0x7U            /**< Single-ended mode, channel 7 */
  #define ADC_PDD_SINGLE_ENDED_AD8 0x8U            /**< Single-ended mode, channel 8 */
  #define ADC_PDD_SINGLE_ENDED_AD9 0x9U            /**< Single-ended mode, channel 9 */
  #define ADC_PDD_SINGLE_ENDED_AD10 0xAU           /**< Single-ended mode, channel 10 */
  #define ADC_PDD_SINGLE_ENDED_AD11 0xBU           /**< Single-ended mode, channel 11 */
  #define ADC_PDD_SINGLE_ENDED_AD12 0xCU           /**< Single-ended mode, channel 12 */
  #define ADC_PDD_SINGLE_ENDED_AD13 0xDU           /**< Single-ended mode, channel 13 */
  #define ADC_PDD_SINGLE_ENDED_AD14 0xEU           /**< Single-ended mode, channel 14 */
  #define ADC_PDD_SINGLE_ENDED_AD15 0xFU           /**< Single-ended mode, channel 15 */
  #define ADC_PDD_SINGLE_ENDED_AD16 0x10U          /**< Single-ended mode, channel 16 */
  #define ADC_PDD_SINGLE_ENDED_AD17 0x11U          /**< Single-ended mode, channel 17 */
  #define ADC_PDD_SINGLE_ENDED_AD18 0x12U          /**< Single-ended mode, channel 18 */
  #define ADC_PDD_SINGLE_ENDED_AD19 0x13U          /**< Single-ended mode, channel 19 */
  #define ADC_PDD_SINGLE_ENDED_AD20 0x14U          /**< Single-ended mode, channel 20 */
  #define ADC_PDD_SINGLE_ENDED_AD21 0x15U          /**< Single-ended mode, channel 21 */
  #define ADC_PDD_SINGLE_ENDED_AD22 0x16U          /**< Single-ended mode, channel 22 */
  #define ADC_PDD_SINGLE_ENDED_AD23 0x17U          /**< Single-ended mode, channel 23 */
  #define ADC_PDD_SINGLE_ENDED_AD24 0x18U          /**< Single-ended mode, channel 24 */
  #define ADC_PDD_SINGLE_ENDED_AD25 0x19U          /**< Single-ended mode, channel 25 */
  #define ADC_PDD_SINGLE_ENDED_AD26 0x1AU          /**< Single-ended mode, channel 26 */
  #define ADC_PDD_SINGLE_ENDED_AD27 0x1BU          /**< Single-ended mode, channel 27 */
  #define ADC_PDD_SINGLE_ENDED_AD28 0x1CU          /**< Single-ended mode, channel 28 */
  #define ADC_PDD_SINGLE_ENDED_AD29 0x1DU          /**< Single-ended mode, channel 29 */
  #define ADC_PDD_SINGLE_ENDED_AD30 0x1EU          /**< Single-ended mode, channel 30 */
  #define ADC_PDD_MODULE_DISABLED 0x1FU            /**< Module disabled */
  #define ADC_PDD_SINGLE_ENDED_TEMP_SENSOR 0x1AU   /**< Single-ended mode, temp sensor. This constant is deprecated. It will not be supported in the future. */
  #define ADC_PDD_SINGLE_ENDED_BANDGAP 0x1BU       /**< Single-ended mode, bandgap. This constant is deprecated. It will not be supported in the future. */
  #define ADC_PDD_SINGLE_ENDED_VREFSH 0x1DU        /**< Single-ended mode, VREFSH. This constant is deprecated. It will not be supported in the future. */
  #define ADC_PDD_SINGLE_ENDED_VREFSL 0x1EU        /**< Single-ended mode, VREFSL. This constant is deprecated. It will not be supported in the future. */

#else /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_MKL15Z4)) || (defined(MCU_MKL25Z4)) || (defined(MCU_PCK20L4)) */
/* Channel constants for channel selection */
  #define ADC_PDD_DIFFERENTIAL_DADP0_DADM0 0x20U   /**< Differential mode, positive and negative channel 0 */
  #define ADC_PDD_DIFFERENTIAL_DADP1_DADM1 0x21U   /**< Differential mode, positive and negative channel 1 */
  #define ADC_PDD_DIFFERENTIAL_DADP2_DADM2 0x22U   /**< Differential mode, positive and negative channel 2 */
  #define ADC_PDD_DIFFERENTIAL_DADP3_DADM3 0x23U   /**< Differential mode, positive and negative channel 3 */
  #define ADC_PDD_SINGLE_ENDED_DAD0 0U             /**< Single-ended mode, channel 0 */
  #define ADC_PDD_SINGLE_ENDED_DAD1 0x1U           /**< Single-ended mode, channel 1 */
  #define ADC_PDD_SINGLE_ENDED_DAD2 0x2U           /**< Single-ended mode, channel 2 */
  #define ADC_PDD_SINGLE_ENDED_DAD3 0x3U           /**< Single-ended mode, channel 3 */
  #define ADC_PDD_SINGLE_ENDED_AD4 0x4U            /**< Single-ended mode, channel 4 */
  #define ADC_PDD_SINGLE_ENDED_AD5 0x5U            /**< Single-ended mode, channel 5 */
  #define ADC_PDD_SINGLE_ENDED_AD6 0x6U            /**< Single-ended mode, channel 6 */
  #define ADC_PDD_SINGLE_ENDED_AD7 0x7U            /**< Single-ended mode, channel 7 */
  #define ADC_PDD_SINGLE_ENDED_AD8 0x8U            /**< Single-ended mode, channel 8 */
  #define ADC_PDD_SINGLE_ENDED_AD9 0x9U            /**< Single-ended mode, channel 9 */
  #define ADC_PDD_SINGLE_ENDED_AD10 0xAU           /**< Single-ended mode, channel 10 */
  #define ADC_PDD_SINGLE_ENDED_AD11 0xBU           /**< Single-ended mode, channel 11 */
  #define ADC_PDD_SINGLE_ENDED_AD12 0xCU           /**< Single-ended mode, channel 12 */
  #define ADC_PDD_SINGLE_ENDED_AD13 0xDU           /**< Single-ended mode, channel 13 */
  #define ADC_PDD_SINGLE_ENDED_AD14 0xEU           /**< Single-ended mode, channel 14 */
  #define ADC_PDD_SINGLE_ENDED_AD15 0xFU           /**< Single-ended mode, channel 15 */
  #define ADC_PDD_SINGLE_ENDED_AD16 0x10U          /**< Single-ended mode, channel 16 */
  #define ADC_PDD_SINGLE_ENDED_AD17 0x11U          /**< Single-ended mode, channel 17 */
  #define ADC_PDD_SINGLE_ENDED_AD18 0x12U          /**< Single-ended mode, channel 18 */
  #define ADC_PDD_SINGLE_ENDED_AD19 0x13U          /**< Single-ended mode, channel 19 */
  #define ADC_PDD_SINGLE_ENDED_AD20 0x14U          /**< Single-ended mode, channel 20 */
  #define ADC_PDD_SINGLE_ENDED_AD21 0x15U          /**< Single-ended mode, channel 21 */
  #define ADC_PDD_SINGLE_ENDED_AD22 0x16U          /**< Single-ended mode, channel 22 */
  #define ADC_PDD_SINGLE_ENDED_AD23 0x17U          /**< Single-ended mode, channel 23 */
  #define ADC_PDD_SINGLE_ENDED_AD24 0x18U          /**< Single-ended mode, channel 24 */
  #define ADC_PDD_SINGLE_ENDED_AD25 0x19U          /**< Single-ended mode, channel 25 */
  #define ADC_PDD_SINGLE_ENDED_AD26 0x1AU          /**< Single-ended mode, channel 26 */
  #define ADC_PDD_SINGLE_ENDED_AD27 0x1BU          /**< Single-ended mode, channel 27 */
  #define ADC_PDD_SINGLE_ENDED_AD28 0x1CU          /**< Single-ended mode, channel 28 */
  #define ADC_PDD_SINGLE_ENDED_AD29 0x1DU          /**< Single-ended mode, channel 29 */
  #define ADC_PDD_SINGLE_ENDED_AD30 0x1EU          /**< Single-ended mode, channel 30 */
  #define ADC_PDD_MODULE_DISABLED 0x1FU            /**< Module disabled */
  #define ADC_PDD_DIFFERENTIAL_BANDGAP 0x3BU       /**< Differential mode, positive and negative bandgap. This constant is deprecated. It will not be supported in the future. */
  #define ADC_PDD_DIFFERENTIAL_VREFSH 0x3DU        /**< Differential mode, positive and negative VREFS. This constant is deprecated. It will not be supported in the future. */
  #define ADC_PDD_SINGLE_ENDED_TEMP_SENSOR 0x1AU   /**< Single-ended mode, temp sensor. This constant is deprecated. It will not be supported in the future. */
  #define ADC_PDD_SINGLE_ENDED_BANDGAP 0x1BU       /**< Single-ended mode, bandgap. This constant is deprecated. It will not be supported in the future. */
  #define ADC_PDD_SINGLE_ENDED_VREFSH 0x1DU        /**< Single-ended mode, VREFSH. This constant is deprecated. It will not be supported in the future. */
  #define ADC_PDD_SINGLE_ENDED_VREFSL 0x1EU        /**< Single-ended mode, VREFSL. This constant is deprecated. It will not be supported in the future. */

#endif /* (defined(MCU_MK10D10)) || (defined(MCU_MK10D5)) || (defined(MCU_MK10D7)) || (defined(MCU_MK10DZ10)) || (defined(MCU_MK10F12)) || (defined(MCU_MK11D5)) || (defined(MCU_MK12D5)) || (defined(MCU_MK20D10)) || (defined(MCU_MK20D5)) || (defined(MCU_MK20D7)) || (defined(MCU_MK20DZ10)) || (defined(MCU_MK20F12)) || (defined(MCU_MK21D5)) || (defined(MCU_MK22D5)) || (defined(MCU_MK30D10)) || (defined(MCU_MK30D7)) || (defined(MCU_MK30DZ10)) || (defined(MCU_MK40D10)) || (defined(MCU_MK40D7)) || (defined(MCU_MK40DZ10)) || (defined(MCU_MK40X256VMD100)) || (defined(MCU_MK50D10)) || (defined(MCU_MK50D7)) || (defined(MCU_MK50DZ10)) || (defined(MCU_MK51D10)) || (defined(MCU_MK51D7)) || (defined(MCU_MK51DZ10)) || (defined(MCU_MK52D10)) || (defined(MCU_MK52DZ10)) || (defined(MCU_MK53D10)) || (defined(MCU_MK53DZ10)) || (defined(MCU_MK60D10)) || (defined(MCU_MK60DZ10)) || (defined(MCU_MK60F12)) || (defined(MCU_MK60F15)) || (defined(MCU_MK60N512VMD100)) || (defined(MCU_MK61F12)) || (defined(MCU_MK61F15)) || (defined(MCU_MK70F12)) || (defined(MCU_MK70F15)) || (defined(MCU_MKL15Z4)) || (defined(MCU_MKL25Z4)) || (defined(MCU_PCK20L4)) */
/* Constants for trigger type selection */
#define ADC_PDD_SW_TRIGGER 0U                    /**< SW trigger */
#define ADC_PDD_HW_TRIGGER 0x40U                 /**< HW trigger */

/* Constants for compare function selection */
#define ADC_PDD_COMPARE_DISABLED 0U              /**< Compare function disabled */
#define ADC_PDD_LESS_THAN 0x20U                  /**< Compare function enabled to 'less than' */
#define ADC_PDD_GREATER_THAN_OR_EQUAL 0x30U      /**< Compare function enabled to 'greater than or equal' */
#define ADC_PDD_RANGE_NOT_INCLUSIVE 0x28U        /**< Compare function enabled to 'range, not inclusive' */
#define ADC_PDD_RANGE_INCLUSIVE 0x38U            /**< Compare function enabled to 'range, inclusive' */

/* Constants for one conversion or continuous selection */
#define ADC_PDD_ONE_CONVERSION 0U                /**< One conversion mode */
#define ADC_PDD_CONTINUOUS_CONVERSIONS 0x8U      /**< Continuous conversion mode */

/* Constants for average type selection */
#define ADC_PDD_AVERAGE_DISABLED 0U              /**< Average function disabled */
#define ADC_PDD_4_SAMPLES_AVERAGED 0x4U          /**< Average function with 4 samples */
#define ADC_PDD_8_SAMPLES_AVERAGED 0x5U          /**< Average function with 8 samples */
#define ADC_PDD_16_SAMPLES_AVERAGED 0x6U         /**< Average function with 16 samples */
#define ADC_PDD_32_SAMPLES_AVERAGED 0x7U         /**< Average function with 32 samples */


/* ----------------------------------------------------------------------------
   -- SetChannel
   ---------------------------------------------------------------------------- */

/**
 * Set channel.
 * @param peripheralBase Peripheral base address.
 * @param Index Register index.
 * @param Value Parameter specifying new channel.
 */
#define ADC_PDD_SetChannel(peripheralBase, Index, Value) ( \
    ADC_SC1_REG(peripheralBase,(Index)) = \
     (uint32_t)(( \
      (uint32_t)(ADC_SC1_REG(peripheralBase,(Index)) & (uint32_t)(~(uint32_t)ADC_SC1_ADCH_MASK))) | ( \
      (uint32_t)(Value))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableConversionCompleteInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enable conversion complete interrupt.
 * @param peripheralBase Peripheral base address.
 * @param Index Register index.
 */
#define ADC_PDD_EnableConversionCompleteInterrupt(peripheralBase, Index) ( \
    ADC_SC1_REG(peripheralBase,(Index)) |= \
     ADC_SC1_AIEN_MASK \
  )

/* ----------------------------------------------------------------------------
   -- DisableConversionCompleteInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disable conversion complete interrupt.
 * @param peripheralBase Peripheral base address.
 * @param Index Register index.
 */
#define ADC_PDD_DisableConversionCompleteInterrupt(peripheralBase, Index) ( \
    ADC_SC1_REG(peripheralBase,(Index)) &= \
     (uint32_t)(~(uint32_t)ADC_SC1_AIEN_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetConversionCompleteFlag
   ---------------------------------------------------------------------------- */

/**
 * Returns conversion complete flag.
 * @param peripheralBase Peripheral base address.
 * @param Index Register index.
 */
#define ADC_PDD_GetConversionCompleteFlag(peripheralBase, Index) ( \
    (uint32_t)(ADC_SC1_REG(peripheralBase,(Index)) & ADC_SC1_COCO_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- WriteStatusControl1Reg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the Status and control 1 register.
 * @param peripheralBase Peripheral base address.
 * @param Index Register index.
 * @param Value Parameter specifying new register value.
 */
#define ADC_PDD_WriteStatusControl1Reg(peripheralBase, Index, Value) ( \
    ADC_SC1_REG(peripheralBase,(Index)) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadStatusControl1Reg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the Status and control 1 register.
 * @param peripheralBase Peripheral base address.
 * @param Index Register index.
 */
#define ADC_PDD_ReadStatusControl1Reg(peripheralBase, Index) ( \
    ADC_SC1_REG(peripheralBase,(Index)) \
  )

/* ----------------------------------------------------------------------------
   -- WriteConfiguration1Reg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the Configuration 1 register.
 * @param peripheralBase Peripheral base address.
 * @param Value Parameter specifying new register value.
 */
#define ADC_PDD_WriteConfiguration1Reg(peripheralBase, Value) ( \
    ADC_CFG1_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadConfiguration1Reg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the Configuration 1 register.
 * @param peripheralBase Peripheral base address.
 */
#define ADC_PDD_ReadConfiguration1Reg(peripheralBase) ( \
    ADC_CFG1_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteConfiguration2Reg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the Configuration 2 register.
 * @param peripheralBase Peripheral base address.
 * @param Value Parameter specifying new register value.
 */
#define ADC_PDD_WriteConfiguration2Reg(peripheralBase, Value) ( \
    ADC_CFG2_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadConfiguration2Reg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the Configuration 2 register.
 * @param peripheralBase Peripheral base address.
 */
#define ADC_PDD_ReadConfiguration2Reg(peripheralBase) ( \
    ADC_CFG2_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- GetConversionActiveFlag
   ---------------------------------------------------------------------------- */

/**
 * Returns conversion active flag.
 * @param peripheralBase Peripheral base address.
 */
#define ADC_PDD_GetConversionActiveFlag(peripheralBase) ( \
    (uint32_t)(ADC_SC2_REG(peripheralBase) & ADC_SC2_ADACT_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- SetCompareValue1Raw
   ---------------------------------------------------------------------------- */

/**
 * Sets compare value 1.
 * @param peripheralBase Peripheral base address.
 * @param Value Parameter specifying new compare value 1.
 */
#define ADC_PDD_SetCompareValue1Raw(peripheralBase, Value) ( \
    ADC_CV1_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- GetCompareValue1Raw
   ---------------------------------------------------------------------------- */

/**
 * Returns compare value 1.
 * @param peripheralBase Peripheral base address.
 */
#define ADC_PDD_GetCompareValue1Raw(peripheralBase) ( \
    ADC_CV1_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- SetCompareValue2Raw
   ---------------------------------------------------------------------------- */

/**
 * Sets compare value 2.
 * @param peripheralBase Peripheral base address.
 * @param Value Parameter specifying new compare value 2.
 */
#define ADC_PDD_SetCompareValue2Raw(peripheralBase, Value) ( \
    ADC_CV2_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- GetCompareValue2Raw
   ---------------------------------------------------------------------------- */

/**
 * Returns compare value 2.
 * @param peripheralBase Peripheral base address.
 */
#define ADC_PDD_GetCompareValue2Raw(peripheralBase) ( \
    ADC_CV2_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- SetConversionTriggerType
   ---------------------------------------------------------------------------- */

/**
 * Sets conversion trigger type.
 * @param peripheralBase Peripheral base address.
 * @param Mode Trigger mode.
 */
#define ADC_PDD_SetConversionTriggerType(peripheralBase, Mode) ( \
    ADC_SC2_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(ADC_SC2_REG(peripheralBase) & (uint32_t)(~(uint32_t)ADC_SC2_ADTRG_MASK))) | ( \
      (uint32_t)(Mode))) \
  )

/* ----------------------------------------------------------------------------
   -- GetConversionTriggerType
   ---------------------------------------------------------------------------- */

/**
 * Returns conversion trigger type.
 * @param peripheralBase Peripheral base address.
 */
#define ADC_PDD_GetConversionTriggerType(peripheralBase) ( \
    (uint32_t)(ADC_SC2_REG(peripheralBase) & ADC_SC2_ADTRG_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- SetCompareFunction
   ---------------------------------------------------------------------------- */

/**
 * Sets compare type.
 * @param peripheralBase Peripheral base address.
 * @param Mode Compare mode.
 */
#define ADC_PDD_SetCompareFunction(peripheralBase, Mode) ( \
    ADC_SC2_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(ADC_SC2_REG(peripheralBase) & (uint32_t)(~(uint32_t)((uint32_t)0x7U << 3U)))) | ( \
      (uint32_t)(Mode))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableDmaRequest
   ---------------------------------------------------------------------------- */

/**
 * DMA enable request.
 * @param peripheralBase Peripheral base address.
 * @param State Parameter specifying if DMA requests will be enabled or disabled.
 */
#define ADC_PDD_EnableDmaRequest(peripheralBase, State) ( \
    ADC_SC2_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(ADC_SC2_REG(peripheralBase) & (uint32_t)(~(uint32_t)ADC_SC2_DMAEN_MASK))) | ( \
      (uint32_t)((uint32_t)(State) << ADC_SC2_DMAEN_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- WriteStatusControl2Reg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the Status and control 2 register.
 * @param peripheralBase Peripheral base address.
 * @param Value Parameter specifying new register value.
 */
#define ADC_PDD_WriteStatusControl2Reg(peripheralBase, Value) ( \
    ADC_SC2_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadStatusControl2Reg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the Status and control 2 register.
 * @param peripheralBase Peripheral base address.
 */
#define ADC_PDD_ReadStatusControl2Reg(peripheralBase) ( \
    ADC_SC2_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- StartCalibration
   ---------------------------------------------------------------------------- */

/**
 * Starts calibration.
 * @param peripheralBase Peripheral base address.
 */
#define ADC_PDD_StartCalibration(peripheralBase) ( \
    ADC_SC3_REG(peripheralBase) |= \
     ADC_SC3_CAL_MASK \
  )

/* ----------------------------------------------------------------------------
   -- GetCalibrationActiveFlag
   ---------------------------------------------------------------------------- */

/**
 * Returns calibration active flag.
 * @param peripheralBase Peripheral base address.
 */
#define ADC_PDD_GetCalibrationActiveFlag(peripheralBase) ( \
    (uint32_t)(ADC_SC3_REG(peripheralBase) & ADC_SC3_CAL_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- GetCalibrationFailedStatusFlag
   ---------------------------------------------------------------------------- */

/**
 * Returns calibration failed status flag.
 * @param peripheralBase Peripheral base address.
 */
#define ADC_PDD_GetCalibrationFailedStatusFlag(peripheralBase) ( \
    (uint32_t)(ADC_SC3_REG(peripheralBase) & ADC_SC3_CALF_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- SetContinuousMode
   ---------------------------------------------------------------------------- */

/**
 * Sets one conversion or continuous mode.
 * @param peripheralBase Peripheral base address.
 * @param Mode One conversion or continuous mode.
 */
#define ADC_PDD_SetContinuousMode(peripheralBase, Mode) ( \
    ADC_SC3_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(ADC_SC3_REG(peripheralBase) & (uint32_t)(~(uint32_t)ADC_SC3_ADCO_MASK))) | ( \
      (uint32_t)(Mode))) \
  )

/* ----------------------------------------------------------------------------
   -- GetContinuousMode
   ---------------------------------------------------------------------------- */

/**
 * Returns one conversion or continuous mode.
 * @param peripheralBase Peripheral base address.
 */
#define ADC_PDD_GetContinuousMode(peripheralBase) ( \
    (uint32_t)(ADC_SC3_REG(peripheralBase) & ADC_SC3_ADCO_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- SetAverageFunction
   ---------------------------------------------------------------------------- */

/**
 * Sets average function.
 * @param peripheralBase Peripheral base address.
 * @param Mode Average mode.
 */
#define ADC_PDD_SetAverageFunction(peripheralBase, Mode) ( \
    ADC_SC3_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(ADC_SC3_REG(peripheralBase) & (uint32_t)(~(uint32_t)0x7U))) | ( \
      (uint32_t)(Mode))) \
  )

/* ----------------------------------------------------------------------------
   -- WriteStatusControl3Reg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the Status and control 3 register.
 * @param peripheralBase Peripheral base address.
 * @param Value Parameter specifying new register value.
 */
#define ADC_PDD_WriteStatusControl3Reg(peripheralBase, Value) ( \
    ADC_SC3_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadStatusControl3Reg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the Status and control 3 register.
 * @param peripheralBase Peripheral base address.
 */
#define ADC_PDD_ReadStatusControl3Reg(peripheralBase) ( \
    ADC_SC3_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- GetResultValueRaw
   ---------------------------------------------------------------------------- */

/**
 * Returns transfer counter.
 * @param peripheralBase Peripheral base address.
 * @param Index Register index.
 */
#define ADC_PDD_GetResultValueRaw(peripheralBase, Index) ( \
    ADC_R_REG(peripheralBase,(Index)) \
  )

/* ----------------------------------------------------------------------------
   -- SetOffsetCorrectionValue
   ---------------------------------------------------------------------------- */

/**
 * Sets offset error correction value in 2's complement and left justified
 * format.
 * @param peripheralBase Peripheral base address.
 * @param Value Parameter specifying new offset correction value.
 */
#define ADC_PDD_SetOffsetCorrectionValue(peripheralBase, Value) ( \
    ADC_OFS_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- GetOffsetCorrectionValue
   ---------------------------------------------------------------------------- */

/**
 * Returns offset error correction value in 2's complement and left justified
 * format.
 * @param peripheralBase Peripheral base address.
 */
#define ADC_PDD_GetOffsetCorrectionValue(peripheralBase) ( \
    ADC_OFS_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- SetPlusGainValue
   ---------------------------------------------------------------------------- */

/**
 * Sets plus-side gain value.
 * @param peripheralBase Peripheral base address.
 * @param Value Parameter specifying new value.
 */
#define ADC_PDD_SetPlusGainValue(peripheralBase, Value) ( \
    ADC_PG_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- SetMinusGainValue
   ---------------------------------------------------------------------------- */

/**
 * Sets minus-side gain value.
 * @param peripheralBase Peripheral base address.
 * @param Value Parameter specifying new value.
 */
#define ADC_PDD_SetMinusGainValue(peripheralBase, Value) ( \
    ADC_MG_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- GetPlus0CalibrationValue
   ---------------------------------------------------------------------------- */

/**
 * Returns plus-side general calibration value 0.
 * @param peripheralBase Peripheral base address.
 */
#define ADC_PDD_GetPlus0CalibrationValue(peripheralBase) ( \
    ADC_CLP0_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- GetPlus1CalibrationValue
   ---------------------------------------------------------------------------- */

/**
 * Returns plus-side general calibration value 1.
 * @param peripheralBase Peripheral base address.
 */
#define ADC_PDD_GetPlus1CalibrationValue(peripheralBase) ( \
    ADC_CLP1_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- GetPlus2CalibrationValue
   ---------------------------------------------------------------------------- */

/**
 * Returns plus-side general calibration value 2.
 * @param peripheralBase Peripheral base address.
 */
#define ADC_PDD_GetPlus2CalibrationValue(peripheralBase) ( \
    ADC_CLP2_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- GetPlus3CalibrationValue
   ---------------------------------------------------------------------------- */

/**
 * Returns plus-side general calibration value 3.
 * @param peripheralBase Peripheral base address.
 */
#define ADC_PDD_GetPlus3CalibrationValue(peripheralBase) ( \
    ADC_CLP3_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- GetPlus4CalibrationValue
   ---------------------------------------------------------------------------- */

/**
 * Returns plus-side general calibration value 4.
 * @param peripheralBase Peripheral base address.
 */
#define ADC_PDD_GetPlus4CalibrationValue(peripheralBase) ( \
    ADC_CLP4_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- GetPlusSCalibrationValue
   ---------------------------------------------------------------------------- */

/**
 * Returns plus-side general calibration value S.
 * @param peripheralBase Peripheral base address.
 */
#define ADC_PDD_GetPlusSCalibrationValue(peripheralBase) ( \
    ADC_CLPS_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- GetPlusDCalibrationValue
   ---------------------------------------------------------------------------- */

/**
 * Returns plus-side general calibration value D.
 * @param peripheralBase Peripheral base address.
 */
#define ADC_PDD_GetPlusDCalibrationValue(peripheralBase) ( \
    ADC_CLPD_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- GetMinus0CalibrationValue
   ---------------------------------------------------------------------------- */

/**
 * Returns minus-side general calibration value 0.
 * @param peripheralBase Peripheral base address.
 */
#define ADC_PDD_GetMinus0CalibrationValue(peripheralBase) ( \
    ADC_CLM0_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- GetMinus1CalibrationValue
   ---------------------------------------------------------------------------- */

/**
 * Returns minus-side general calibration value 1.
 * @param peripheralBase Peripheral base address.
 */
#define ADC_PDD_GetMinus1CalibrationValue(peripheralBase) ( \
    ADC_CLM1_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- GetMinus2CalibrationValue
   ---------------------------------------------------------------------------- */

/**
 * Returns minus-side general calibration value 2.
 * @param peripheralBase Peripheral base address.
 */
#define ADC_PDD_GetMinus2CalibrationValue(peripheralBase) ( \
    ADC_CLM2_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- GetMinus3CalibrationValue
   ---------------------------------------------------------------------------- */

/**
 * Returns minus-side general calibration value 3.
 * @param peripheralBase Peripheral base address.
 */
#define ADC_PDD_GetMinus3CalibrationValue(peripheralBase) ( \
    ADC_CLM3_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- GetMinus4CalibrationValue
   ---------------------------------------------------------------------------- */

/**
 * Returns minus-side general calibration value 4.
 * @param peripheralBase Peripheral base address.
 */
#define ADC_PDD_GetMinus4CalibrationValue(peripheralBase) ( \
    ADC_CLM4_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- GetMinusSCalibrationValue
   ---------------------------------------------------------------------------- */

/**
 * Returns minus-side general calibration value S.
 * @param peripheralBase Peripheral base address.
 */
#define ADC_PDD_GetMinusSCalibrationValue(peripheralBase) ( \
    ADC_CLMS_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- GetMinusDCalibrationValue
   ---------------------------------------------------------------------------- */

/**
 * Returns minus-side general calibration value D.
 * @param peripheralBase Peripheral base address.
 */
#define ADC_PDD_GetMinusDCalibrationValue(peripheralBase) ( \
    ADC_CLMD_REG(peripheralBase) \
  )
#endif  /* #if defined(ADC_PDD_H_) */

/* ADC_PDD.h, eof. */
