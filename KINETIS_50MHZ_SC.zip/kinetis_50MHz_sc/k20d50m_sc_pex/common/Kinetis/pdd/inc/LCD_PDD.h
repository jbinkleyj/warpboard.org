/*
  PDD layer implementation for peripheral type LCD
  (C) 2010 Freescale, Inc. All rights reserved.

  This file is static and it is generated from API-Factory
*/

#if !defined(LCD_PDD_H_)
#define LCD_PDD_H_

/* ----------------------------------------------------------------------------
   -- Test if supported MCU is active
   ---------------------------------------------------------------------------- */

#if !defined(MCU_ACTIVE)
  // No MCU is active
  #error LCD PDD library: No derivative is active. Place proper #include with PDD memory map before including PDD library.
#elif \
      !defined(MCU_MK30D10) /* LCD */ && \
      !defined(MCU_MK30D7) /* LCD */ && \
      !defined(MCU_MK30DZ10) /* LCD */ && \
      !defined(MCU_MK40D10) /* LCD */ && \
      !defined(MCU_MK40D7) /* LCD */ && \
      !defined(MCU_MK40DZ10) /* LCD */ && \
      !defined(MCU_MK40X256VMD100) /* LCD */ && \
      !defined(MCU_MK51D10) /* LCD */ && \
      !defined(MCU_MK51D7) /* LCD */ && \
      !defined(MCU_MK51DZ10) /* LCD */ && \
      !defined(MCU_MK53D10) /* LCD */ && \
      !defined(MCU_MK53DZ10) /* LCD */
  // Unsupported MCU is active
  #error LCD PDD library: Unsupported derivative is active.
#endif

#include "PDD_Types.h"

/* ----------------------------------------------------------------------------
   -- Method symbol definitions
   ---------------------------------------------------------------------------- */

/* Interrupt masks (for EnableInterrupts, DisableInterrupts macros). */
#define LCD_PDD_FRAME_FREQUENCY LCD_GCR_FDCIEN_MASK /**< Frame frequency interrupt mask */
#define LCD_PDD_FAULT_DETECT_COMPLETE LCD_GCR_LCDIEN_MASK /**< Fault detect complete interrupt mask */

/* Load adjust constants (for SetLoadAdjust macro). */
#define LCD_PDD_LOW_LOAD_RESISTOR_NET 0U         /**< Low load (LCD glass capacitance 2nF or lower), resistor net. */
#define LCD_PDD_HIGH_LOAD_RESISTOR_NET 0x1U      /**< High Load (LCD glass capacitance 8nF or lower), resistor net. */
#define LCD_PDD_FAST_CLK_CHPUMP_8NF 0x2U         /**< Fastest clock source for charge pump (LCD glass capacitance 8nF or lower). */
#define LCD_PDD_MIDDLE_CLK_CHPUMP_6NF 0x3U       /**< Intermediate clock source for charge pump (LCD glass capacitance 6nF or lower). */
#define LCD_PDD_MIDDLE_CLK_CHPUMP_4NF 0x4U       /**< Intermediate clock source for charge pump (LCD glass capacitance 4nF or lower). */
#define LCD_PDD_SLOW_CLK_CHPUMP_2NF 0x5U         /**< Slowest clock source for charge pump (LCD glass capacitance 2nF or lower). */

/* Voltage supply constants (for SetVoltageSupplyControl macro). */
#define LCD_PDD_VLL2_FROM_VDD 0U                 /**< Drive VLL2 internally from VDD. */
#define LCD_PDD_VLL3_FROM_VDD 0x1U               /**< Drive VLL3 internally from VDD. */
#define LCD_PDD_VLL3_FROM_VIREG 0x3U             /**< Drive VLL3 externally from VDD or drive VLL1 internally from VIREG. */

/* Alternate Clk divider constants (for SetAlternateClkDivider macro) */
#define LCD_PDD_DIVIDE_FACTOR_1 0U               /**< LCD alternate clock divider factor 1. */
#define LCD_PDD_DIVIDE_FACTOR_8 0x1U             /**< LCD alternate clock divider factor 8. */
#define LCD_PDD_DIVIDE_FACTOR_64 0x2U            /**< LCD alternate clock divider factor 64. */
#define LCD_PDD_DIVIDE_FACTOR_512 0x3U           /**< LCD alternate clock divider factor 512. */

/* Clock source constants (for SetClkSource macro). */
#define LCD_PDD_DEFAULT_CLK 0U                   /**< Default clock(system or RTC OSC output) as the LCD clock source. */
#define LCD_PDD_ALTERNATE_CLK 0x40U              /**< Alternate clock(MCGIRCLK output) as the LCD clock source. */

/* Blink mode constants (for SetBlinkMode macro). */
#define LCD_PDD_BLANK_BLINK 0U                   /**< Blank during the blink period. */
#define LCD_PDD_ALTERNATE_BLINK 0x8U             /**< Alternate display during blink period. */

/* Fault detect clock prescaler constants (for SetFaultDetectClkPrescaler
   macro). */
#define LCD_PDD_FAULT_DETECT_PRESCALER_1 0U      /**< Fault detect clock prescaler 1. */
#define LCD_PDD_FAULT_DETECT_PRESCALER_2 0x1U    /**< Fault detect clock prescaler 2. */
#define LCD_PDD_FAULT_DETECT_PRESCALER_4 0x2U    /**< Fault detect clock prescaler 4. */
#define LCD_PDD_FAULT_DETECT_PRESCALER_8 0x3U    /**< Fault detect clock prescaler 8. */
#define LCD_PDD_FAULT_DETECT_PRESCALER_16 0x4U   /**< Fault detect clock prescaler 16. */
#define LCD_PDD_FAULT_DETECT_PRESCALER_32 0x5U   /**< Fault detect clock prescaler 32. */
#define LCD_PDD_FAULT_DETECT_PRESCALER_64 0x6U   /**< Fault detect clock prescaler 64. */
#define LCD_PDD_FAULT_DETECT_PRESCALER_128 0x7U  /**< Fault detect clock prescaler 128. */

/* Fault detect sample width constants (for SetFaultDetectSampleWidth macro). */
#define LCD_PDD_SAMPLE_WIDTH_CLK_4 0U            /**< Sample window width is 4 sample clock cycles. */
#define LCD_PDD_SAMPLE_WIDTH_CLK_8 0x1U          /**< Sample window width is 8 sample clock cycles. */
#define LCD_PDD_SAMPLE_WIDTH_CLK_16 0x2U         /**< Sample window width is 16 sample clock cycles. */
#define LCD_PDD_SAMPLE_WIDTH_CLK_32 0x3U         /**< Sample window width is 32 sample clock cycles. */
#define LCD_PDD_SAMPLE_WIDTH_CLK_64 0x4U         /**< Sample window width is 64 sample clock cycles. */
#define LCD_PDD_SAMPLE_WIDTH_CLK_128 0x5U        /**< Sample window width is 128 sample clock cycles. */
#define LCD_PDD_SAMPLE_WIDTH_CLK_256 0x6U        /**< Sample window width is 256 sample clock cycles. */
#define LCD_PDD_SAMPLE_WIDTH_CLK_512 0x7U        /**< Sample window width is 512 sample clock cycles. */

/* Pin type mode constants (for SetFaultDetectPinType macro). */
#define LCD_PDD_FAULT_FRONTPLANE 0U              /**< Type of the selected pin under fault detect test is frontplane. */
#define LCD_PDD_FAULT_BACKPLANE 0x40U            /**< Type of the selected pin under fault detect test is backplane. */

/* Register index constants (for EnablePinMask, SetPinAsBackplaneMask macros). */
#define LCD_PDD_PIN_RANGE_7_0 0U                 /**< Register 0, 7..0 range of LCDx pin. */
#define LCD_PDD_PIN_RANGE_15_8 0x1U              /**< Register 1, 15..8 range of LCDx pin. */
#define LCD_PDD_PIN_RANGE_23_16 0x2U             /**< Register 2, 23..16 range of LCDx pin. */
#define LCD_PDD_PIN_RANGE_31_24 0x3U             /**< Register 3, 31..24 range of LCDx pin. */
#define LCD_PDD_PIN_RANGE_39_32 0x4U             /**< Register 4, 39..32 range of LCDx pin. */
#define LCD_PDD_PIN_RANGE_47_40 0x5U             /**< Register 5, 47..40 range of LCDx pin. */
#define LCD_PDD_PIN_RANGE_55_48 0x6U             /**< Register 6, 55..48 range of LCDx pin. */
#define LCD_PDD_PIN_RANGE_63_56 0x7U             /**< Register 7, 63..56 range of LCDx pin. */


/* ----------------------------------------------------------------------------
   -- EnableRegulatedVoltage
   ---------------------------------------------------------------------------- */

/**
 * Enables or disables internal voltage regulator.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state of regulated voltage.
 */
#define LCD_PDD_EnableRegulatedVoltage(peripheralBase, State) ( \
    LCD_GCR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       LCD_GCR_REG(peripheralBase)) & (( \
       (uint32_t)(~(uint32_t)LCD_GCR_RVEN_MASK)) & ( \
       (uint32_t)(~(uint32_t)0x40000U))))) | ( \
      (uint32_t)((uint32_t)(State) << LCD_GCR_RVEN_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- SetRegulatedVoltageTrim
   ---------------------------------------------------------------------------- */

/**
 * Sets to adjust the regulated input. The regulated input is changed by 1.5%
 * for each count.
 * @param peripheralBase Peripheral base address.
 * @param TrimValue Regulated voltage trim value[0..15].
 */
#define LCD_PDD_SetRegulatedVoltageTrim(peripheralBase, TrimValue) ( \
    LCD_GCR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       LCD_GCR_REG(peripheralBase)) & (( \
       (uint32_t)(~(uint32_t)LCD_GCR_RVTRIM_MASK)) & ( \
       (uint32_t)(~(uint32_t)0x40000U))))) | ( \
      (uint32_t)((uint32_t)(TrimValue) << LCD_GCR_RVTRIM_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- SetLoadAdjust
   ---------------------------------------------------------------------------- */

/**
 * Sets the LCD module charge pump or a resistor network to supply the LCD
 * voltages and handle different LCD glass capacitance.
 * @param peripheralBase Peripheral base address.
 * @param LoadAdjust Load adjust value. The user should use one from the
 *        enumerated values.
 */
#define LCD_PDD_SetLoadAdjust(peripheralBase, LoadAdjust) ( \
    ((LoadAdjust) == LCD_PDD_LOW_LOAD_RESISTOR_NET) ? ( \
      LCD_GCR_REG(peripheralBase) &= \
       (uint32_t)(( \
        (uint32_t)(~(uint32_t)LCD_GCR_LADJ_MASK)) & (( \
        (uint32_t)(~(uint32_t)LCD_GCR_CPSEL_MASK)) & ( \
        (uint32_t)(~(uint32_t)0x40000U))))) : (((LoadAdjust) == LCD_PDD_HIGH_LOAD_RESISTOR_NET) ? ( \
      LCD_GCR_REG(peripheralBase) = \
       (uint32_t)(( \
        (uint32_t)(( \
         LCD_GCR_REG(peripheralBase)) & (( \
         (uint32_t)(~(uint32_t)LCD_GCR_LADJ_MASK)) & (( \
         (uint32_t)(~(uint32_t)LCD_GCR_CPSEL_MASK)) & ( \
         (uint32_t)(~(uint32_t)0x40000U)))))) | ( \
        (uint32_t)((uint32_t)0x2U << LCD_GCR_LADJ_SHIFT)))) : (((LoadAdjust) == LCD_PDD_FAST_CLK_CHPUMP_8NF) ? ( \
      LCD_GCR_REG(peripheralBase) = \
       (uint32_t)(( \
        (uint32_t)(( \
         LCD_GCR_REG(peripheralBase)) & (( \
         (uint32_t)(~(uint32_t)LCD_GCR_LADJ_MASK)) & ( \
         (uint32_t)(~(uint32_t)0x40000U))))) | ( \
        (uint32_t)((uint32_t)0x1U << LCD_GCR_CPSEL_SHIFT)))) : (((LoadAdjust) == LCD_PDD_MIDDLE_CLK_CHPUMP_6NF) ? ( \
      LCD_GCR_REG(peripheralBase) = \
       (uint32_t)(( \
        (uint32_t)(( \
         LCD_GCR_REG(peripheralBase)) & (( \
         (uint32_t)(~(uint32_t)LCD_GCR_LADJ_MASK)) & ( \
         (uint32_t)(~(uint32_t)0x40000U))))) | (( \
        (uint32_t)((uint32_t)0x1U << LCD_GCR_LADJ_SHIFT)) | ( \
        (uint32_t)((uint32_t)0x1U << LCD_GCR_CPSEL_SHIFT))))) : (((LoadAdjust) == LCD_PDD_MIDDLE_CLK_CHPUMP_4NF) ? ( \
      LCD_GCR_REG(peripheralBase) = \
       (uint32_t)(( \
        (uint32_t)(( \
         LCD_GCR_REG(peripheralBase)) & (( \
         (uint32_t)(~(uint32_t)LCD_GCR_LADJ_MASK)) & ( \
         (uint32_t)(~(uint32_t)0x40000U))))) | (( \
        (uint32_t)((uint32_t)0x2U << LCD_GCR_LADJ_SHIFT)) | ( \
        (uint32_t)((uint32_t)0x1U << LCD_GCR_CPSEL_SHIFT))))) : ( \
      LCD_GCR_REG(peripheralBase) = \
       (uint32_t)(( \
        (uint32_t)(( \
         LCD_GCR_REG(peripheralBase)) | (( \
         (uint32_t)((uint32_t)0x3U << LCD_GCR_LADJ_SHIFT)) | ( \
         (uint32_t)((uint32_t)0x1U << LCD_GCR_CPSEL_SHIFT))))) & ( \
        (uint32_t)(~(uint32_t)0x40000U)))) \
    )))) \
  )

/* ----------------------------------------------------------------------------
   -- SetVoltageSupplyControl
   ---------------------------------------------------------------------------- */

/**
 * Sets the LCD module on external or internal power supply.
 * @param peripheralBase Peripheral base address.
 * @param VoltageSupply Voltage supply control value. The user should use one
 *        from the enumerated values.
 */
#define LCD_PDD_SetVoltageSupplyControl(peripheralBase, VoltageSupply) ( \
    LCD_GCR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       LCD_GCR_REG(peripheralBase)) & (( \
       (uint32_t)(~(uint32_t)LCD_GCR_VSUPPLY_MASK)) & ( \
       (uint32_t)(~(uint32_t)0x40000U))))) | ( \
      (uint32_t)((uint32_t)(VoltageSupply) << LCD_GCR_VSUPPLY_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableInterrupts
   ---------------------------------------------------------------------------- */

/**
 * Enables module frame frequency or fault detection complete interrupt.
 * @param peripheralBase Peripheral base address.
 * @param Mask Mask of interrupts to enable. Use constants from group "Interrupt
 *        masks (for EnableInterrupts, DisableInterrupts macros).".
 */
#define LCD_PDD_EnableInterrupts(peripheralBase, Mask) ( \
    LCD_GCR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(LCD_GCR_REG(peripheralBase) | (uint32_t)(Mask))) & ( \
      (uint32_t)(~(uint32_t)0x40000U))) \
  )

/* ----------------------------------------------------------------------------
   -- DisableInterrupts
   ---------------------------------------------------------------------------- */

/**
 * Disables module frame frequency or fault detection complete interrupt.
 * @param peripheralBase Peripheral base address.
 * @param Mask Mask of interrupts to disable. Use constants from group
 *        "Interrupt masks (for EnableInterrupts, DisableInterrupts macros).".
 */
#define LCD_PDD_DisableInterrupts(peripheralBase, Mask) ( \
    LCD_GCR_REG(peripheralBase) &= \
     (uint32_t)((uint32_t)(~(uint32_t)(Mask)) & (uint32_t)(~(uint32_t)0x40000U)) \
  )

/* ----------------------------------------------------------------------------
   -- SetAlternateClkDivider
   ---------------------------------------------------------------------------- */

/**
 * Sets the LCD module on external or internal power supply.
 * @param peripheralBase Peripheral base address.
 * @param Divider Divide factor value. The user should use one from the
 *        enumerated values.
 */
#define LCD_PDD_SetAlternateClkDivider(peripheralBase, Divider) ( \
    LCD_GCR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       LCD_GCR_REG(peripheralBase)) & (( \
       (uint32_t)(~(uint32_t)LCD_GCR_ALTDIV_MASK)) & ( \
       (uint32_t)(~(uint32_t)0x40000U))))) | ( \
      (uint32_t)((uint32_t)(Divider) << LCD_GCR_ALTDIV_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableInWaitMode
   ---------------------------------------------------------------------------- */

/**
 * Enables or disables module driver, charge pump, resistor bias network, and
 * voltage regulator stop while in Wait mode.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state in wait mode.
 */
#define LCD_PDD_EnableInWaitMode(peripheralBase, State) ( \
    ((State) == PDD_ENABLE) ? ( \
      LCD_GCR_REG(peripheralBase) &= \
       (uint32_t)((uint32_t)(~(uint32_t)LCD_GCR_LCDWAIT_MASK) & (uint32_t)(~(uint32_t)0x40000U))) : ( \
      LCD_GCR_REG(peripheralBase) = \
       (uint32_t)(( \
        (uint32_t)(( \
         LCD_GCR_REG(peripheralBase)) | ( \
         (uint32_t)((uint32_t)0x1U << LCD_GCR_LCDWAIT_SHIFT)))) & ( \
        (uint32_t)(~(uint32_t)0x40000U)))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableInStopMode
   ---------------------------------------------------------------------------- */

/**
 * Enables or disables module driver, charge pump, resistor bias network, and
 * voltage regulator while in Stop mode.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state in stop mode.
 */
#define LCD_PDD_EnableInStopMode(peripheralBase, State) ( \
    ((State) == PDD_ENABLE) ? ( \
      LCD_GCR_REG(peripheralBase) &= \
       (uint32_t)((uint32_t)(~(uint32_t)LCD_GCR_LCDSTP_MASK) & (uint32_t)(~(uint32_t)0x40000U))) : ( \
      LCD_GCR_REG(peripheralBase) = \
       (uint32_t)(( \
        (uint32_t)(( \
         LCD_GCR_REG(peripheralBase)) | ( \
         (uint32_t)((uint32_t)0x1U << LCD_GCR_LCDSTP_SHIFT)))) & ( \
        (uint32_t)(~(uint32_t)0x40000U)))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableDevice
   ---------------------------------------------------------------------------- */

/**
 * Enables LCD module driver system.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state of segment LCD device.
 */
#define LCD_PDD_EnableDevice(peripheralBase, State) ( \
    LCD_GCR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       LCD_GCR_REG(peripheralBase)) & (( \
       (uint32_t)(~(uint32_t)LCD_GCR_LCDEN_MASK)) & ( \
       (uint32_t)(~(uint32_t)0x40000U))))) | ( \
      (uint32_t)((uint32_t)(State) << LCD_GCR_LCDEN_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- SetClkSource
   ---------------------------------------------------------------------------- */

/**
 * Sets clock the default or alternate as the LCD clock source.
 * @param peripheralBase Peripheral base address.
 * @param ClkSource Clock source value. The user should use one from the
 *        enumerated values.
 */
#define LCD_PDD_SetClkSource(peripheralBase, ClkSource) ( \
    LCD_GCR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       LCD_GCR_REG(peripheralBase)) & (( \
       (uint32_t)(~(uint32_t)LCD_GCR_SOURCE_MASK)) & ( \
       (uint32_t)(~(uint32_t)0x40000U))))) | ( \
      (uint32_t)(ClkSource))) \
  )

/* ----------------------------------------------------------------------------
   -- SetClkPrescaler
   ---------------------------------------------------------------------------- */

/**
 * Sets a clock divider to generate the LCD module frame frequency.
 * @param peripheralBase Peripheral base address.
 * @param ClkPrescaler Clock prescaler value[0..7].
 */
#define LCD_PDD_SetClkPrescaler(peripheralBase, ClkPrescaler) ( \
    LCD_GCR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       LCD_GCR_REG(peripheralBase)) & (( \
       (uint32_t)(~(uint32_t)LCD_GCR_LCLK_MASK)) & ( \
       (uint32_t)(~(uint32_t)0x40000U))))) | ( \
      (uint32_t)((uint32_t)(ClkPrescaler) << LCD_GCR_LCLK_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- SetDutyCycle
   ---------------------------------------------------------------------------- */

/**
 * Sets the duty cycle of the LCD module driver.
 * @param peripheralBase Peripheral base address.
 * @param DutyCycle Duty cycle value[0..7].
 */
#define LCD_PDD_SetDutyCycle(peripheralBase, DutyCycle) ( \
    LCD_GCR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       LCD_GCR_REG(peripheralBase)) & (( \
       (uint32_t)(~(uint32_t)LCD_GCR_DUTY_MASK)) & ( \
       (uint32_t)(~(uint32_t)0x40000U))))) | ( \
      (uint32_t)(DutyCycle))) \
  )

/* ----------------------------------------------------------------------------
   -- GetFrameFreqInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Return non-zero if frame frequency interrupt flag is set, otherwise returns
 * zero.
 * @param peripheralBase Peripheral base address.
 */
#define LCD_PDD_GetFrameFreqInterruptFlag(peripheralBase) ( \
    (uint32_t)(LCD_AR_REG(peripheralBase) & LCD_AR_LCDIF_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- ClearFrameFreqInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Clears interrupt flag of frame frequency.
 * @param peripheralBase Peripheral base address.
 */
#define LCD_PDD_ClearFrameFreqInterruptFlag(peripheralBase) ( \
    LCD_AR_REG(peripheralBase) |= \
     LCD_AR_LCDIF_MASK \
  )

/* ----------------------------------------------------------------------------
   -- EnableBlinking
   ---------------------------------------------------------------------------- */

/**
 * Enables or disables LCD module blinking.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state of segment LCD.
 */
#define LCD_PDD_EnableBlinking(peripheralBase, State) ( \
    LCD_AR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       LCD_AR_REG(peripheralBase)) & (( \
       (uint32_t)(~(uint32_t)LCD_AR_BLINK_MASK)) & ( \
       (uint32_t)(~(uint32_t)LCD_AR_LCDIF_MASK))))) | ( \
      (uint32_t)((uint32_t)(State) << LCD_AR_BLINK_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableAlternateMode
   ---------------------------------------------------------------------------- */

/**
 * Enables or disables alternate display mode.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state of segment LCD.
 */
#define LCD_PDD_EnableAlternateMode(peripheralBase, State) ( \
    LCD_AR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       LCD_AR_REG(peripheralBase)) & (( \
       (uint32_t)(~(uint32_t)LCD_AR_ALT_MASK)) & ( \
       (uint32_t)(~(uint32_t)LCD_AR_LCDIF_MASK))))) | ( \
      (uint32_t)((uint32_t)(State) << LCD_AR_ALT_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableBlankDisplayMode
   ---------------------------------------------------------------------------- */

/**
 * Enables or disables blank display mode.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state of segment LCD.
 */
#define LCD_PDD_EnableBlankDisplayMode(peripheralBase, State) ( \
    LCD_AR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       LCD_AR_REG(peripheralBase)) & (( \
       (uint32_t)(~(uint32_t)LCD_AR_BLANK_MASK)) & ( \
       (uint32_t)(~(uint32_t)LCD_AR_LCDIF_MASK))))) | ( \
      (uint32_t)((uint32_t)(State) << LCD_AR_BLANK_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- SetBlinkMode
   ---------------------------------------------------------------------------- */

/**
 * Sets blink mode displayed during the blink period.
 * @param peripheralBase Peripheral base address.
 * @param BlinkMode Blink mode value. The user should use one from the
 *        enumerated values.
 */
#define LCD_PDD_SetBlinkMode(peripheralBase, BlinkMode) ( \
    LCD_AR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       LCD_AR_REG(peripheralBase)) & (( \
       (uint32_t)(~(uint32_t)LCD_AR_BMODE_MASK)) & ( \
       (uint32_t)(~(uint32_t)LCD_AR_LCDIF_MASK))))) | ( \
      (uint32_t)(BlinkMode))) \
  )

/* ----------------------------------------------------------------------------
   -- SetBlinkRate
   ---------------------------------------------------------------------------- */

/**
 * Sets speed at which the LCD blinks.
 * @param peripheralBase Peripheral base address.
 * @param BlinkRate Blink rate value[0..7].
 */
#define LCD_PDD_SetBlinkRate(peripheralBase, BlinkRate) ( \
    LCD_AR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       LCD_AR_REG(peripheralBase)) & (( \
       (uint32_t)(~(uint32_t)LCD_AR_BRATE_MASK)) & ( \
       (uint32_t)(~(uint32_t)LCD_AR_LCDIF_MASK))))) | ( \
      (uint32_t)(BlinkRate))) \
  )

/* ----------------------------------------------------------------------------
   -- SetFaultDetectClkPrescaler
   ---------------------------------------------------------------------------- */

/**
 * Sets fault detect clock prescaler.
 * @param peripheralBase Peripheral base address.
 * @param FaultClkPrescaler Fault detect clock prescaler value[0..7].
 */
#define LCD_PDD_SetFaultDetectClkPrescaler(peripheralBase, FaultClkPrescaler) ( \
    LCD_FDCR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(LCD_FDCR_REG(peripheralBase) & (uint32_t)(~(uint32_t)LCD_FDCR_FDPRS_MASK))) | ( \
      (uint32_t)((uint32_t)(FaultClkPrescaler) << LCD_FDCR_FDPRS_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- SetFaultDetectSampleWidth
   ---------------------------------------------------------------------------- */

/**
 * Sets the sample window width of fault detection in number of cycles.
 * @param peripheralBase Peripheral base address.
 * @param SampleWidth Sample window width value[0..7].
 */
#define LCD_PDD_SetFaultDetectSampleWidth(peripheralBase, SampleWidth) ( \
    LCD_FDCR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(LCD_FDCR_REG(peripheralBase) & (uint32_t)(~(uint32_t)LCD_FDCR_FDSWW_MASK))) | ( \
      (uint32_t)((uint32_t)(SampleWidth) << LCD_FDCR_FDSWW_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableFaultDetect
   ---------------------------------------------------------------------------- */

/**
 * Enables or disables fault detection.
 * @param peripheralBase Peripheral base address.
 * @param State Requested state of fault detection.
 */
#define LCD_PDD_EnableFaultDetect(peripheralBase, State) ( \
    LCD_FDCR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(LCD_FDCR_REG(peripheralBase) & (uint32_t)(~(uint32_t)LCD_FDCR_FDEN_MASK))) | ( \
      (uint32_t)((uint32_t)(State) << LCD_FDCR_FDEN_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- SetFaultDetectPinType
   ---------------------------------------------------------------------------- */

/**
 * Sets the LCD pin to be checked by pull-up or run-time fault detection.
 * @param peripheralBase Peripheral base address.
 * @param PinType Requested pin type.
 */
#define LCD_PDD_SetFaultDetectPinType(peripheralBase, PinType) ( \
    LCD_FDCR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(LCD_FDCR_REG(peripheralBase) & (uint32_t)(~(uint32_t)LCD_FDCR_FDBPEN_MASK))) | ( \
      (uint32_t)(PinType))) \
  )

/* ----------------------------------------------------------------------------
   -- SetFaultDetectPinID
   ---------------------------------------------------------------------------- */

/**
 * Sets the LCD pin to be checked by pull-up or run-time fault detection.
 * @param peripheralBase Peripheral base address.
 * @param DetectPinID Fault detect pin ID value[0..63].
 */
#define LCD_PDD_SetFaultDetectPinID(peripheralBase, DetectPinID) ( \
    LCD_FDCR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(LCD_FDCR_REG(peripheralBase) & (uint32_t)(~(uint32_t)LCD_FDCR_FDPINID_MASK))) | ( \
      (uint32_t)(DetectPinID))) \
  )

/* ----------------------------------------------------------------------------
   -- GetFaultDetectInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Return value of fault detection complete flag.
 * @param peripheralBase Peripheral base address.
 */
#define LCD_PDD_GetFaultDetectInterruptFlag(peripheralBase) ( \
    (uint32_t)(LCD_FDSR_REG(peripheralBase) & LCD_FDSR_FDCF_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- ClearFaultDetectInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Clears flag of fault detection complete.
 * @param peripheralBase Peripheral base address.
 */
#define LCD_PDD_ClearFaultDetectInterruptFlag(peripheralBase) ( \
    LCD_FDSR_REG(peripheralBase) |= \
     LCD_FDSR_FDCF_MASK \
  )

/* ----------------------------------------------------------------------------
   -- GetFaultDetectValue
   ---------------------------------------------------------------------------- */

/**
 * Return how many "one/high" are sampled inside the fault detect sample window.
 * @param peripheralBase Peripheral base address.
 */
#define LCD_PDD_GetFaultDetectValue(peripheralBase) ( \
    (uint8_t)(LCD_FDSR_REG(peripheralBase) & LCD_FDSR_FDCNT_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- EnablePinMask
   ---------------------------------------------------------------------------- */

/**
 * Enables pins for LCD operation.
 * @param peripheralBase Peripheral base address.
 * @param RegIndex The user should use one from the enumerated values.
 * @param PinMask 8 bits mask of pins what are arranged according RegIndex
 *        parameter.
 */
#define LCD_PDD_EnablePinMask(peripheralBase, RegIndex, PinMask) ( \
    ((uint8_t)((uint8_t)(RegIndex) & 0x4U) == 0U) ? ( \
      LCD_PEN_REG(peripheralBase,0U) = \
       (uint32_t)(( \
        (uint32_t)(( \
         LCD_PEN_REG(peripheralBase,0U)) & ( \
         (uint32_t)(~(uint32_t)((uint32_t)0xFFU << (uint8_t)((uint8_t)((uint8_t)(RegIndex) & 0x3U) << 3U)))))) | ( \
        (uint32_t)((uint32_t)(PinMask) << (uint8_t)((uint8_t)((uint8_t)(RegIndex) & 0x3U) << 3U))))) : ( \
      LCD_PEN_REG(peripheralBase,1U) = \
       (uint32_t)(( \
        (uint32_t)(( \
         LCD_PEN_REG(peripheralBase,1U)) & ( \
         (uint32_t)(~(uint32_t)((uint32_t)0xFFU << (uint8_t)((uint8_t)((uint8_t)(RegIndex) & 0x3U) << 3U)))))) | ( \
        (uint32_t)((uint32_t)(PinMask) << (uint8_t)((uint8_t)((uint8_t)(RegIndex) & 0x3U) << 3U))))) \
  )

/* ----------------------------------------------------------------------------
   -- SetPinAsBackplaneMask
   ---------------------------------------------------------------------------- */

/**
 * Sets pins as Enables or disables fault detection.
 * @param peripheralBase Peripheral base address.
 * @param RegIndex The user should use one from the enumerated values.
 * @param PinMask 8 bits mask of pins what are arranged according RegIndex
 *        parameter.
 */
#define LCD_PDD_SetPinAsBackplaneMask(peripheralBase, RegIndex, PinMask) ( \
    ((uint8_t)((uint8_t)(RegIndex) & 0x4U) == 0U) ? ( \
      LCD_BPEN_REG(peripheralBase,0U) = \
       (uint32_t)(( \
        (uint32_t)(( \
         LCD_BPEN_REG(peripheralBase,0U)) & ( \
         (uint32_t)(~(uint32_t)((uint32_t)0xFFU << (uint8_t)((uint8_t)((uint8_t)(RegIndex) & 0x3U) << 3U)))))) | ( \
        (uint32_t)((uint32_t)(PinMask) << (uint8_t)((uint8_t)((uint8_t)(RegIndex) & 0x3U) << 3U))))) : ( \
      LCD_BPEN_REG(peripheralBase,1U) = \
       (uint32_t)(( \
        (uint32_t)(( \
         LCD_BPEN_REG(peripheralBase,1U)) & ( \
         (uint32_t)(~(uint32_t)((uint32_t)0xFFU << (uint8_t)((uint8_t)((uint8_t)(RegIndex) & 0x3U) << 3U)))))) | ( \
        (uint32_t)((uint32_t)(PinMask) << (uint8_t)((uint8_t)((uint8_t)(RegIndex) & 0x3U) << 3U))))) \
  )

/* ----------------------------------------------------------------------------
   -- SetWaveform
   ---------------------------------------------------------------------------- */

/**
 * Sets value of the frontplanes pins for the backplane phase.
 * @param peripheralBase Peripheral base address.
 * @param FrontplanePinIndex Wave form register index[0..63].
 * @param Waveform Wave form value[0..255].
 */
#define LCD_PDD_SetWaveform(peripheralBase, FrontplanePinIndex, Waveform) ( \
    LCD_WF_REG(peripheralBase,(uint8_t)((uint8_t)(FrontplanePinIndex) >> 2U)) = \
     (uint32_t)(( \
      (uint32_t)(( \
       LCD_WF_REG(peripheralBase,(uint8_t)((uint8_t)(FrontplanePinIndex) >> 2U))) & ( \
       (uint32_t)(~(uint32_t)(( \
        (uint32_t)0xFFU) << ( \
        (uint8_t)((uint8_t)((uint8_t)(FrontplanePinIndex) & 0x3U) << 3U))))))) | ( \
      (uint32_t)(( \
       (uint32_t)(Waveform)) << ( \
       (uint8_t)((uint8_t)((uint8_t)(FrontplanePinIndex) & 0x3U) << 3U))))) \
  )

/* ----------------------------------------------------------------------------
   -- GetWaveform
   ---------------------------------------------------------------------------- */

/**
 * Return value of the frontplanes pins for the backplane phase.
 * @param peripheralBase Peripheral base address.
 * @param FrontplanePinIndex Wave form register index[0..63].
 */
#define LCD_PDD_GetWaveform(peripheralBase, FrontplanePinIndex) ( \
    (uint8_t)(( \
     LCD_WF_REG(peripheralBase,(uint8_t)((uint8_t)(FrontplanePinIndex) >> 2U))) >> ( \
     (uint8_t)((uint8_t)((uint8_t)(FrontplanePinIndex) & 0x3U) << 3U))) \
  )

/* ----------------------------------------------------------------------------
   -- SetAlternateWaveform
   ---------------------------------------------------------------------------- */

/**
 * Sets value of the alternate frontplanes pins for the backplane phase.
 * @param peripheralBase Peripheral base address.
 * @param FrontplanePinIndex Wave form register index[0..63].
 * @param Waveform Wave form value[0..15].
 */
#define LCD_PDD_SetAlternateWaveform(peripheralBase, FrontplanePinIndex, Waveform) ( \
    LCD_WF_REG(peripheralBase,(uint8_t)((uint8_t)(FrontplanePinIndex) >> 2U)) = \
     (uint32_t)(( \
      (uint32_t)(( \
       LCD_WF_REG(peripheralBase,(uint8_t)((uint8_t)(FrontplanePinIndex) >> 2U))) & ( \
       (uint32_t)(~(uint32_t)(( \
        (uint32_t)0xFU) << ( \
        (uint8_t)((uint8_t)((uint8_t)(FrontplanePinIndex) & 0x3U) << 3U) + 4U)))))) | ( \
      (uint32_t)(( \
       (uint32_t)(Waveform)) << ( \
       (uint8_t)((uint8_t)((uint8_t)(FrontplanePinIndex) & 0x3U) << 3U) + 4U)))) \
  )

/* ----------------------------------------------------------------------------
   -- GetAlternateWaveform
   ---------------------------------------------------------------------------- */

/**
 * Return value of the alternate frontplanes pins for the backplane phase.
 * @param peripheralBase Peripheral base address.
 * @param FrontplanePinIndex Wave form register index[0..63].
 */
#define LCD_PDD_GetAlternateWaveform(peripheralBase, FrontplanePinIndex) ( \
    (uint8_t)(( \
     (uint8_t)(( \
      (uint8_t)(( \
       LCD_WF_REG(peripheralBase,(uint8_t)((uint8_t)(FrontplanePinIndex) >> 2U))) >> ( \
       (uint8_t)((uint8_t)((uint8_t)(FrontplanePinIndex) & 0x3U) << 3U)))) >> ( \
      4U))) & ( \
     0xFU)) \
  )
#endif  /* #if defined(LCD_PDD_H_) */

/* LCD_PDD.h, eof. */
