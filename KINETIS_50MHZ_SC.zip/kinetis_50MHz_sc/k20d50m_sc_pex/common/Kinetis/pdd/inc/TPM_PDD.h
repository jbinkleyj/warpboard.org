/*
  PDD layer implementation for peripheral type TPM
  (C) 2010 Freescale, Inc. All rights reserved.

  This file is static and it is generated from API-Factory
*/

#if !defined(TPM_PDD_H_)
#define TPM_PDD_H_

/* ----------------------------------------------------------------------------
   -- Test if supported MCU is active
   ---------------------------------------------------------------------------- */

#if !defined(MCU_ACTIVE)
  // No MCU is active
  #error TPM PDD library: No derivative is active. Place proper #include with PDD memory map before including PDD library.
#elif \
      !defined(MCU_MKL04Z4) /* TPM0, TPM1 */ && \
      !defined(MCU_MKL05Z4) /* TPM0, TPM1 */ && \
      !defined(MCU_MKL14Z4) /* TPM0, TPM1, TPM2 */ && \
      !defined(MCU_MKL15Z4) /* TPM0, TPM1, TPM2 */ && \
      !defined(MCU_MKL24Z4) /* TPM0, TPM1, TPM2 */ && \
      !defined(MCU_MKL25Z4) /* TPM0, TPM1, TPM2 */
  // Unsupported MCU is active
  #error TPM PDD library: Unsupported derivative is active.
#endif

#include "PDD_Types.h"

/* ----------------------------------------------------------------------------
   -- Method symbol definitions
   ---------------------------------------------------------------------------- */

/* TPM channel constants */
#define TPM_PDD_CHANNEL_0 0U                     /**< 0 */
#define TPM_PDD_CHANNEL_1 0x1U                   /**< 1 */
#define TPM_PDD_CHANNEL_2 0x2U                   /**< 2 */
#define TPM_PDD_CHANNEL_3 0x3U                   /**< 3 */
#define TPM_PDD_CHANNEL_4 0x4U                   /**< 4 */
#define TPM_PDD_CHANNEL_5 0x5U                   /**< 5 */
#define TPM_PDD_CHANNEL_6 0x6U                   /**< 6 */
#define TPM_PDD_CHANNEL_7 0x7U                   /**< 7 */

/* Prescaler constants */
#define TPM_PDD_DIVIDE_1 0U                      /**< 1 */
#define TPM_PDD_DIVIDE_2 0x1U                    /**< 2 */
#define TPM_PDD_DIVIDE_4 0x2U                    /**< 4 */
#define TPM_PDD_DIVIDE_8 0x3U                    /**< 8 */
#define TPM_PDD_DIVIDE_16 0x4U                   /**< 16 */
#define TPM_PDD_DIVIDE_32 0x5U                   /**< 32 */
#define TPM_PDD_DIVIDE_64 0x6U                   /**< 64 */
#define TPM_PDD_DIVIDE_128 0x7U                  /**< 128 */

/* PWM aligned mode constants */
#define TPM_PDD_EDGE_ALIGNED 0U                  /**< Edge aligned */
#define TPM_PDD_CENTER_ALIGNED TPM_SC_CPWMS_MASK /**< Center aligned */

/* Interrupt flag masks for ClearChannelFlag */
#define TPM_PDD_FLAG_0 TPM_STATUS_CH0F_MASK      /**< 0 */
#define TPM_PDD_FLAG_1 TPM_STATUS_CH1F_MASK      /**< 1 */
#define TPM_PDD_FLAG_2 TPM_STATUS_CH5F_MASK      /**< 2 */
#define TPM_PDD_FLAG_3 TPM_STATUS_CH3F_MASK      /**< 3 */
#define TPM_PDD_FLAG_4 TPM_STATUS_CH4F_MASK      /**< 4 */
#define TPM_PDD_FLAG_5 TPM_STATUS_CH5F_MASK      /**< 5 */

/* Clock source constants. */
#define TPM_PDD_DISABLED 0U                      /**< Disabled */
#define TPM_PDD_SYSTEM 0x8U                      /**< Counter clock */
#define TPM_PDD_EXTERNAL 0x10U                   /**< External clock */

/* Edge and level constants. */
#define TPM_PDD_EDGE_NONE 0U                     /**< Disabled */
#define TPM_PDD_EDGE_RISING 0x4U                 /**< Rising */
#define TPM_PDD_EDGE_FALLING 0x8U                /**< Falling */
#define TPM_PDD_EDGE_BOTH 0xCU                   /**< Both */

/* Output action constants. */
#define TPM_PDD_OUTPUT_NONE 0U                   /**< Disconnect */
#define TPM_PDD_OUTPUT_TOGGLE 0x10U              /**< Toggle */
#define TPM_PDD_OUTPUT_CLEAR 0x20U               /**< Clear */
#define TPM_PDD_OUTPUT_SET 0x30U                 /**< Set */


/* ----------------------------------------------------------------------------
   -- SetPrescaler
   ---------------------------------------------------------------------------- */

/**
 * Sets prescale value.
 * @param peripheralBase Peripheral base address.
 * @param Prescaler New value of the prescaler.
 */
#define TPM_PDD_SetPrescaler(peripheralBase, Prescaler) ( \
    TPM_SC_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       TPM_SC_REG(peripheralBase)) & (( \
       (uint32_t)(~(uint32_t)TPM_SC_PS_MASK)) & ( \
       (uint32_t)(~(uint32_t)TPM_SC_TOF_MASK))))) | ( \
      (uint32_t)(Prescaler))) \
  )

/* ----------------------------------------------------------------------------
   -- SelectPrescalerSource
   ---------------------------------------------------------------------------- */

/**
 * Select clock source.
 * @param peripheralBase Peripheral base address.
 * @param Source New value of the source.
 */
#define TPM_PDD_SelectPrescalerSource(peripheralBase, Source) ( \
    TPM_SC_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       TPM_SC_REG(peripheralBase)) & (( \
       (uint32_t)(~(uint32_t)TPM_SC_CMOD_MASK)) & ( \
       (uint32_t)(~(uint32_t)TPM_SC_TOF_MASK))))) | ( \
      (uint32_t)(Source))) \
  )

/* ----------------------------------------------------------------------------
   -- GetEnableDeviceStatus
   ---------------------------------------------------------------------------- */

/**
 * Returns current state of TPM device.
 * @param peripheralBase Peripheral base address.
 */
#define TPM_PDD_GetEnableDeviceStatus(peripheralBase) ( \
    (uint32_t)(TPM_SC_REG(peripheralBase) & TPM_SC_CMOD_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- SelectPwmAlignMode
   ---------------------------------------------------------------------------- */

/**
 * Configures PWM aligned mode.
 * @param peripheralBase Peripheral base address.
 * @param Mode New value of the mode.
 */
#define TPM_PDD_SelectPwmAlignMode(peripheralBase, Mode) ( \
    TPM_SC_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       TPM_SC_REG(peripheralBase)) & (( \
       (uint32_t)(~(uint32_t)TPM_SC_CPWMS_MASK)) & ( \
       (uint32_t)(~(uint32_t)TPM_SC_TOF_MASK))))) | ( \
      (uint32_t)(Mode))) \
  )

/* ----------------------------------------------------------------------------
   -- GetOverflowInterruptMask
   ---------------------------------------------------------------------------- */

/**
 * Returns overflow interrupt mask.
 * @param peripheralBase Peripheral base address.
 */
#define TPM_PDD_GetOverflowInterruptMask(peripheralBase) ( \
    (uint32_t)(TPM_SC_REG(peripheralBase) & TPM_SC_TOIE_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- EnableOverflowInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables the TPM overflow interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define TPM_PDD_EnableOverflowInterrupt(peripheralBase) ( \
    TPM_SC_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(TPM_SC_REG(peripheralBase) | TPM_SC_TOIE_MASK)) & ( \
      (uint32_t)(~(uint32_t)TPM_SC_TOF_MASK))) \
  )

/* ----------------------------------------------------------------------------
   -- DisableOverflowInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables the TPM overflow interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define TPM_PDD_DisableOverflowInterrupt(peripheralBase) ( \
    TPM_SC_REG(peripheralBase) &= \
     (uint32_t)(( \
      (uint32_t)(~(uint32_t)TPM_SC_TOIE_MASK)) & ( \
      (uint32_t)(~(uint32_t)TPM_SC_TOF_MASK))) \
  )

/* ----------------------------------------------------------------------------
   -- GetOverflowInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Returns overflow interrupt flag bit.
 * @param peripheralBase Peripheral base address.
 */
#define TPM_PDD_GetOverflowInterruptFlag(peripheralBase) ( \
    (uint32_t)(TPM_SC_REG(peripheralBase) & TPM_SC_TOF_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- ClearOverflowInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Clears overflow interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define TPM_PDD_ClearOverflowInterruptFlag(peripheralBase) ( \
    TPM_SC_REG(peripheralBase) |= \
     TPM_SC_TOF_MASK \
  )

/* ----------------------------------------------------------------------------
   -- ReadCounterReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the counter register.
 * @param peripheralBase Peripheral base address.
 */
#define TPM_PDD_ReadCounterReg(peripheralBase) ( \
    TPM_CNT_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- InitializeCounter
   ---------------------------------------------------------------------------- */

/**
 * Writes value 0 to the counter register.
 * @param peripheralBase Peripheral base address.
 */
#define TPM_PDD_InitializeCounter(peripheralBase) ( \
    TPM_CNT_REG(peripheralBase) = \
     0U \
  )

/* ----------------------------------------------------------------------------
   -- WriteModuloReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the modulo register.
 * @param peripheralBase Peripheral base address.
 * @param Value New content of the modulo register.
 */
#define TPM_PDD_WriteModuloReg(peripheralBase, Value) ( \
    TPM_MOD_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadModuloReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the modulo register.
 * @param peripheralBase Peripheral base address.
 */
#define TPM_PDD_ReadModuloReg(peripheralBase) ( \
    TPM_MOD_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- EnableChannelDma
   ---------------------------------------------------------------------------- */

/**
 * Enables the TPM channel DMA.
 * @param peripheralBase Peripheral base address.
 * @param ChannelIdx TPM channel index.
 */
#define TPM_PDD_EnableChannelDma(peripheralBase, ChannelIdx) ( \
    TPM_CnSC_REG(peripheralBase,(ChannelIdx)) = \
     (uint32_t)(( \
      (uint32_t)(TPM_CnSC_REG(peripheralBase,(ChannelIdx)) | TPM_CnSC_DMA_MASK)) & ( \
      (uint32_t)(~(uint32_t)TPM_CnSC_CHF_MASK))) \
  )

/* ----------------------------------------------------------------------------
   -- DisableChannelDma
   ---------------------------------------------------------------------------- */

/**
 * Disables the TPM channel DMA.
 * @param peripheralBase Peripheral base address.
 * @param ChannelIdx TPM channel index.
 */
#define TPM_PDD_DisableChannelDma(peripheralBase, ChannelIdx) ( \
    TPM_CnSC_REG(peripheralBase,(ChannelIdx)) &= \
     (uint32_t)(( \
      (uint32_t)(~(uint32_t)TPM_CnSC_DMA_MASK)) & ( \
      (uint32_t)(~(uint32_t)TPM_CnSC_CHF_MASK))) \
  )

/* ----------------------------------------------------------------------------
   -- SelectChannelEdgeLevel
   ---------------------------------------------------------------------------- */

/**
 * Selects the TPM channel edge and level.
 * @param peripheralBase Peripheral base address.
 * @param ChannelIdx TPM channel index.
 * @param ELSBA_val TPM channel ELSB:ELSA bits.
 */
#define TPM_PDD_SelectChannelEdgeLevel(peripheralBase, ChannelIdx, ELSBA_val) ( \
    TPM_CnSC_REG(peripheralBase,(ChannelIdx)) = \
     (uint32_t)(( \
      (uint32_t)(( \
       TPM_CnSC_REG(peripheralBase,(ChannelIdx))) & (( \
       (uint32_t)(~(uint32_t)((uint32_t)0x3U << 2U))) & ( \
       (uint32_t)(~(uint32_t)TPM_CnSC_CHF_MASK))))) | ( \
      (uint32_t)(ELSBA_val))) \
  )

/* ----------------------------------------------------------------------------
   -- SelectChannelMode
   ---------------------------------------------------------------------------- */

/**
 * Selects the TPM channel mode.
 * @param peripheralBase Peripheral base address.
 * @param ChannelIdx TPM channel index.
 * @param MSBA_val TPM channel MSB:MSA bits.
 */
#define TPM_PDD_SelectChannelMode(peripheralBase, ChannelIdx, MSBA_val) ( \
    TPM_CnSC_REG(peripheralBase,(ChannelIdx)) = \
     (uint32_t)(( \
      (uint32_t)(( \
       TPM_CnSC_REG(peripheralBase,(ChannelIdx))) & (( \
       (uint32_t)(~(uint32_t)((uint32_t)0x3U << 4U))) & ( \
       (uint32_t)(~(uint32_t)TPM_CnSC_CHF_MASK))))) | ( \
      (uint32_t)(MSBA_val))) \
  )

/* ----------------------------------------------------------------------------
   -- GetChannelInterruptMask
   ---------------------------------------------------------------------------- */

/**
 * Returns channel interrupt mask.
 * @param peripheralBase Peripheral base address.
 * @param ChannelIdx TPM channel index.
 */
#define TPM_PDD_GetChannelInterruptMask(peripheralBase, ChannelIdx) ( \
    (uint32_t)(TPM_CnSC_REG(peripheralBase,(ChannelIdx)) & TPM_CnSC_CHIE_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- EnableChannelInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables the TPM channel interrupt.
 * @param peripheralBase Peripheral base address.
 * @param ChannelIdx TPM channel index.
 */
#define TPM_PDD_EnableChannelInterrupt(peripheralBase, ChannelIdx) ( \
    TPM_CnSC_REG(peripheralBase,(ChannelIdx)) = \
     (uint32_t)(( \
      (uint32_t)(TPM_CnSC_REG(peripheralBase,(ChannelIdx)) | TPM_CnSC_CHIE_MASK)) & ( \
      (uint32_t)(~(uint32_t)TPM_CnSC_CHF_MASK))) \
  )

/* ----------------------------------------------------------------------------
   -- DisableChannelInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables the TPM channel interrupt.
 * @param peripheralBase Peripheral base address.
 * @param ChannelIdx TPM channel index.
 */
#define TPM_PDD_DisableChannelInterrupt(peripheralBase, ChannelIdx) ( \
    TPM_CnSC_REG(peripheralBase,(ChannelIdx)) &= \
     (uint32_t)(( \
      (uint32_t)(~(uint32_t)TPM_CnSC_CHIE_MASK)) & ( \
      (uint32_t)(~(uint32_t)TPM_CnSC_CHF_MASK))) \
  )

/* ----------------------------------------------------------------------------
   -- GetChannelInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Returns channel interrupt flag bit.
 * @param peripheralBase Peripheral base address.
 * @param ChannelIdx TPM channel index.
 */
#define TPM_PDD_GetChannelInterruptFlag(peripheralBase, ChannelIdx) ( \
    (uint32_t)(TPM_CnSC_REG(peripheralBase,(ChannelIdx)) & TPM_CnSC_CHF_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- ClearChannelInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Clears channel interrupt flag.
 * @param peripheralBase Peripheral base address.
 * @param ChannelIdx TPM channel index.
 */
#define TPM_PDD_ClearChannelInterruptFlag(peripheralBase, ChannelIdx) ( \
    TPM_CnSC_REG(peripheralBase,(ChannelIdx)) |= \
     TPM_CnSC_CHF_MASK \
  )

/* ----------------------------------------------------------------------------
   -- ReadChannelControlReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the channel status and control register.
 * @param peripheralBase Peripheral base address.
 * @param ChannelIdx TPM channel index.
 */
#define TPM_PDD_ReadChannelControlReg(peripheralBase, ChannelIdx) ( \
    TPM_CnSC_REG(peripheralBase,(ChannelIdx)) \
  )

/* ----------------------------------------------------------------------------
   -- WriteChannelControlReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the channel status and control register.
 * @param peripheralBase Peripheral base address.
 * @param ChannelIdx TPM channel index.
 * @param Value New content of the channel status and control register.
 */
#define TPM_PDD_WriteChannelControlReg(peripheralBase, ChannelIdx, Value) ( \
    TPM_CnSC_REG(peripheralBase,(ChannelIdx)) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadChannelValueReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the channel value register.
 * @param peripheralBase Peripheral base address.
 * @param ChannelIdx TPM channel index.
 */
#define TPM_PDD_ReadChannelValueReg(peripheralBase, ChannelIdx) ( \
    TPM_CnV_REG(peripheralBase,(ChannelIdx)) \
  )

/* ----------------------------------------------------------------------------
   -- WriteChannelValueReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the channel value register.
 * @param peripheralBase Peripheral base address.
 * @param ChannelIdx TPM channel index.
 * @param Value New content of the channel value register.
 */
#define TPM_PDD_WriteChannelValueReg(peripheralBase, ChannelIdx, Value) ( \
    TPM_CnV_REG(peripheralBase,(ChannelIdx)) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- GetChannelFlags
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the capture and compare status register.
 * @param peripheralBase Peripheral base address.
 */
#define TPM_PDD_GetChannelFlags(peripheralBase) ( \
    TPM_STATUS_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- ClearChannelFlags
   ---------------------------------------------------------------------------- */

/**
 * Clears channel interrupt flag.
 * @param peripheralBase Peripheral base address.
 * @param Mask Interrupt flag mask.
 */
#define TPM_PDD_ClearChannelFlags(peripheralBase, Mask) ( \
    TPM_STATUS_REG(peripheralBase) = \
     (uint32_t)((uint32_t)(~(uint32_t)(Mask)) & (uint32_t)0xFFU) \
  )

/* ----------------------------------------------------------------------------
   -- WriteConfigurationReg
   ---------------------------------------------------------------------------- */

/**
 * Writes value to the configuration register.
 * @param peripheralBase Peripheral base address.
 * @param Value New content of the configuration register.
 */
#define TPM_PDD_WriteConfigurationReg(peripheralBase, Value) ( \
    TPM_CONF_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )
#endif  /* #if defined(TPM_PDD_H_) */

/* TPM_PDD.h, eof. */
