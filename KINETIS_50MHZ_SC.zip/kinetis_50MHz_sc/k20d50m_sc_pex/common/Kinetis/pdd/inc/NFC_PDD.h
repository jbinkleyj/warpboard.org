/*
  PDD layer implementation for peripheral type NFC
  (C) 2010 Freescale, Inc. All rights reserved.

  This file is static and it is generated from API-Factory
*/

#if !defined(NFC_PDD_H_)
#define NFC_PDD_H_

/* ----------------------------------------------------------------------------
   -- Test if supported MCU is active
   ---------------------------------------------------------------------------- */

#if !defined(MCU_ACTIVE)
  // No MCU is active
  #error NFC PDD library: No derivative is active. Place proper #include with PDD memory map before including PDD library.
#elif \
      !defined(MCU_MK10F12) /* NFC */ && \
      !defined(MCU_MK20F12) /* NFC */ && \
      !defined(MCU_MK60F12) /* NFC */ && \
      !defined(MCU_MK60F15) /* NFC */ && \
      !defined(MCU_MK61F12) /* NFC */ && \
      !defined(MCU_MK61F15) /* NFC */ && \
      !defined(MCU_MK70F12) /* NFC */ && \
      !defined(MCU_MK70F15) /* NFC */
  // Unsupported MCU is active
  #error NFC PDD library: Unsupported derivative is active.
#endif

#include "PDD_Types.h"

/* ----------------------------------------------------------------------------
   -- Method symbol definitions
   ---------------------------------------------------------------------------- */

/* Interrupt flags constants (for GetInterruptFlags, ClearInterruptFlags
   macros). */
#define NFC_PDD_WERR_INT NFC_ISR_WERR_MASK       /**< Write error flag. */
#define NFC_PDD_DONE_INT NFC_ISR_DONE_MASK       /**< . */
#define NFC_PDD_IDLE_INT NFC_ISR_IDLE_MASK       /**< . */

/* ECC mode */
#define NFC_PDD_ECC_0_ERR 0U                     /**< ECC bypassed */
#define NFC_PDD_ECC_4_ERR 0x20000U               /**< 4 bits error correction */
#define NFC_PDD_ECC_6_ERR 0x40000U               /**< 6 bits error correction */
#define NFC_PDD_ECC_8_ERR 0x60000U               /**< 8 bits error correction */
#define NFC_PDD_ECC_12_ERR 0x80000U              /**< 12 bits error correction */
#define NFC_PDD_ECC_16_ERR 0xA0000U              /**< 16 bits error correction */
#define NFC_PDD_ECC_24_ERR 0xC0000U              /**< 24 bits error correction */
#define NFC_PDD_ECC_32_ERR 0xE0000U              /**< 32 bits error correction */

/* Dma mode */
#define NFC_PDD_DMA_NO 0U                        /**< No DMA after page read */
#define NFC_PDD_DMA_YES 0x100000U                /**< DMA after page read */


/* ----------------------------------------------------------------------------
   -- ReadCMD1Reg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the CMD1 register.
 * @param peripheralBase Peripheral base address.
 */
#define NFC_PDD_ReadCMD1Reg(peripheralBase) ( \
    NFC_CMD1_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteCMD1Reg
   ---------------------------------------------------------------------------- */

/**
 * Writes Value to the CMD1 register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value written to the CMD1 register.
 */
#define NFC_PDD_WriteCMD1Reg(peripheralBase, Value) ( \
    NFC_CMD1_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadCMD2Reg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the CMD2 register.
 * @param peripheralBase Peripheral base address.
 */
#define NFC_PDD_ReadCMD2Reg(peripheralBase) ( \
    NFC_CMD1_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteCMD2Reg
   ---------------------------------------------------------------------------- */

/**
 * Writes Value to the CMD2 register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value written to the CMD2 register.
 */
#define NFC_PDD_WriteCMD2Reg(peripheralBase, Value) ( \
    NFC_CMD2_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadCARReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the CAR register.
 * @param peripheralBase Peripheral base address.
 */
#define NFC_PDD_ReadCARReg(peripheralBase) ( \
    NFC_CAR_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteCARReg
   ---------------------------------------------------------------------------- */

/**
 * Writes Value to the CAR register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value written to the CAR register.
 */
#define NFC_PDD_WriteCARReg(peripheralBase, Value) ( \
    NFC_CAR_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadRARReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the RAR register.
 * @param peripheralBase Peripheral base address.
 */
#define NFC_PDD_ReadRARReg(peripheralBase) ( \
    NFC_RAR_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteRARReg
   ---------------------------------------------------------------------------- */

/**
 * Writes Value to the RAR register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value written to the RAR register.
 */
#define NFC_PDD_WriteRARReg(peripheralBase, Value) ( \
    NFC_RAR_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadRPTReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the RPT register.
 * @param peripheralBase Peripheral base address.
 */
#define NFC_PDD_ReadRPTReg(peripheralBase) ( \
    NFC_RPT_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteRPTReg
   ---------------------------------------------------------------------------- */

/**
 * Writes Value to the RPT register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value written to the RPT register.
 */
#define NFC_PDD_WriteRPTReg(peripheralBase, Value) ( \
    NFC_RPT_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadRAIReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the RAI register.
 * @param peripheralBase Peripheral base address.
 */
#define NFC_PDD_ReadRAIReg(peripheralBase) ( \
    NFC_RAI_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteRAIReg
   ---------------------------------------------------------------------------- */

/**
 * Writes Value to the RAI register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value written to the RAI register.
 */
#define NFC_PDD_WriteRAIReg(peripheralBase, Value) ( \
    NFC_RAI_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadSR1Reg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the SR1 register.
 * @param peripheralBase Peripheral base address.
 */
#define NFC_PDD_ReadSR1Reg(peripheralBase) ( \
    NFC_SR1_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- GetID1
   ---------------------------------------------------------------------------- */

/**
 * First byte returned by read ID command.
 * @param peripheralBase Peripheral base address.
 */
#define NFC_PDD_GetID1(peripheralBase) ( \
    (uint8_t)(( \
     (uint32_t)(NFC_SR1_REG(peripheralBase) & NFC_SR1_ID1_MASK)) >> ( \
     NFC_SR1_ID1_SHIFT)) \
  )

/* ----------------------------------------------------------------------------
   -- GetID2
   ---------------------------------------------------------------------------- */

/**
 * Second byte returned by read ID command.
 * @param peripheralBase Peripheral base address.
 */
#define NFC_PDD_GetID2(peripheralBase) ( \
    (uint8_t)(( \
     (uint32_t)(NFC_SR1_REG(peripheralBase) & NFC_SR1_ID2_MASK)) >> ( \
     NFC_SR1_ID2_SHIFT)) \
  )

/* ----------------------------------------------------------------------------
   -- GetID3
   ---------------------------------------------------------------------------- */

/**
 * Third byte returned by read ID command.
 * @param peripheralBase Peripheral base address.
 */
#define NFC_PDD_GetID3(peripheralBase) ( \
    (uint8_t)(( \
     (uint32_t)(NFC_SR1_REG(peripheralBase) & NFC_SR1_ID3_MASK)) >> ( \
     NFC_SR1_ID3_SHIFT)) \
  )

/* ----------------------------------------------------------------------------
   -- GetID4
   ---------------------------------------------------------------------------- */

/**
 * Fourth byte returned by read ID command.
 * @param peripheralBase Peripheral base address.
 */
#define NFC_PDD_GetID4(peripheralBase) ( \
    (uint8_t)(NFC_SR1_REG(peripheralBase) & NFC_SR1_ID4_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- ReadSR2Reg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the SR2 register.
 * @param peripheralBase Peripheral base address.
 */
#define NFC_PDD_ReadSR2Reg(peripheralBase) ( \
    NFC_SR2_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- GetID5
   ---------------------------------------------------------------------------- */

/**
 * Fifth byte returned by read ID command.
 * @param peripheralBase Peripheral base address.
 */
#define NFC_PDD_GetID5(peripheralBase) ( \
    (uint8_t)(( \
     (uint32_t)(NFC_SR2_REG(peripheralBase) & NFC_SR2_ID5_MASK)) >> ( \
     NFC_SR2_ID5_SHIFT)) \
  )

/* ----------------------------------------------------------------------------
   -- ReadDMA1Reg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the DMA1 register.
 * @param peripheralBase Peripheral base address.
 */
#define NFC_PDD_ReadDMA1Reg(peripheralBase) ( \
    NFC_DMA1_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteDMA1Reg
   ---------------------------------------------------------------------------- */

/**
 * Writes Value to the DMA1 register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value written to the DMA1 register.
 */
#define NFC_PDD_WriteDMA1Reg(peripheralBase, Value) ( \
    NFC_DMA1_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadSWAPReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the SWAP register.
 * @param peripheralBase Peripheral base address.
 */
#define NFC_PDD_ReadSWAPReg(peripheralBase) ( \
    NFC_SWAP_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteSWAPReg
   ---------------------------------------------------------------------------- */

/**
 * Writes Value to the SWAP register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value written to the SWAP register.
 */
#define NFC_PDD_WriteSWAPReg(peripheralBase, Value) ( \
    NFC_SWAP_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadSECSZReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the SECSZ register.
 * @param peripheralBase Peripheral base address.
 */
#define NFC_PDD_ReadSECSZReg(peripheralBase) ( \
    NFC_SECSZ_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteSECSZReg
   ---------------------------------------------------------------------------- */

/**
 * Writes Value to the SECSZ register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value written to the SECSZ register.
 */
#define NFC_PDD_WriteSECSZReg(peripheralBase, Value) ( \
    NFC_SECSZ_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadCFGReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the CFG register.
 * @param peripheralBase Peripheral base address.
 */
#define NFC_PDD_ReadCFGReg(peripheralBase) ( \
    NFC_CFG_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteCFGReg
   ---------------------------------------------------------------------------- */

/**
 * Writes Value to the CFG register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value written to the CFG register.
 */
#define NFC_PDD_WriteCFGReg(peripheralBase, Value) ( \
    NFC_CFG_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadDMA2Reg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the DMA2 register.
 * @param peripheralBase Peripheral base address.
 */
#define NFC_PDD_ReadDMA2Reg(peripheralBase) ( \
    NFC_DMA2_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteDMA2Reg
   ---------------------------------------------------------------------------- */

/**
 * Writes Value to the DMA2 register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value written to the DMA2 register.
 */
#define NFC_PDD_WriteDMA2Reg(peripheralBase, Value) ( \
    NFC_DMA2_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- ReadISRReg
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the ISR register.
 * @param peripheralBase Peripheral base address.
 */
#define NFC_PDD_ReadISRReg(peripheralBase) ( \
    NFC_ISR_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- WriteISRReg
   ---------------------------------------------------------------------------- */

/**
 * Writes Value to the ISR register.
 * @param peripheralBase Peripheral base address.
 * @param Value Value written to the ISR register.
 */
#define NFC_PDD_WriteISRReg(peripheralBase, Value) ( \
    NFC_ISR_REG(peripheralBase) = \
     (uint32_t)(Value) \
  )

/* ----------------------------------------------------------------------------
   -- GetInterruptFlags
   ---------------------------------------------------------------------------- */

/**
 * Returns a value that represents a mask of active (pending) interrupts.
 * @param peripheralBase Peripheral base address.
 * @return Use constants from group "Interrupt flags constants (for
 *         GetInterruptFlags, ClearInterruptFlags macros)." for processing return value.
 */
#define NFC_PDD_GetInterruptFlags(peripheralBase) ( \
    (uint32_t)(( \
     NFC_ISR_REG(peripheralBase)) & ( \
     (uint32_t)(NFC_ISR_WERR_MASK | (NFC_ISR_DONE_MASK | NFC_ISR_IDLE_MASK)))) \
  )

/* ----------------------------------------------------------------------------
   -- ClrInterruptFlags
   ---------------------------------------------------------------------------- */

/**
 * Clears interrupt flags.
 * @param peripheralBase Peripheral base address.
 * @param Mask Mask of interrupt to clear flags. Use constants from group
 *        "Interrupt flags constants (for GetInterruptFlags, ClearInterruptFlags
 *        macros).".
 */
#define NFC_PDD_ClrInterruptFlags(peripheralBase, Mask) ( \
    NFC_ISR_REG(peripheralBase) |= \
     (uint32_t)((uint32_t)((uint32_t)(Mask) >> 29U) << 17U) \
  )

/* ----------------------------------------------------------------------------
   -- EnableInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables interrupts specified by the Mask parameter.
 * @param peripheralBase Peripheral base address.
 * @param Mask Interrupt mask. Use constants from group "Interrupt flags
 *        constants (for GetInterruptFlags, ClearInterruptFlags macros).".
 */
#define NFC_PDD_EnableInterrupt(peripheralBase, Mask) ( \
    NFC_ISR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       NFC_ISR_REG(peripheralBase)) | ( \
       (uint32_t)((uint32_t)((uint32_t)(Mask) >> 29U) << 20U)))) & (( \
      (uint32_t)(~(uint32_t)NFC_ISR_IDLECLR_MASK)) & (( \
      (uint32_t)(~(uint32_t)NFC_ISR_DONECLR_MASK)) & ( \
      (uint32_t)(~(uint32_t)NFC_ISR_WERRCLR_MASK))))) \
  )

/* ----------------------------------------------------------------------------
   -- DisableInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables interrupts specified by the Mask parameter.
 * @param peripheralBase Peripheral base address.
 * @param Mask Interrupt mask. Use constants from group "Interrupt flags
 *        constants (for GetInterruptFlags, ClearInterruptFlags macros).".
 */
#define NFC_PDD_DisableInterrupt(peripheralBase, Mask) ( \
    NFC_ISR_REG(peripheralBase) &= \
     (uint32_t)(( \
      (uint32_t)(~(uint32_t)((uint32_t)((uint32_t)(Mask) >> 29U) << 20U))) & (( \
      (uint32_t)(~(uint32_t)NFC_ISR_IDLECLR_MASK)) & (( \
      (uint32_t)(~(uint32_t)NFC_ISR_DONECLR_MASK)) & ( \
      (uint32_t)(~(uint32_t)NFC_ISR_WERRCLR_MASK))))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableWriteErrorInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables write error interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define NFC_PDD_EnableWriteErrorInterrupt(peripheralBase) ( \
    NFC_ISR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(NFC_ISR_REG(peripheralBase) | NFC_ISR_WERREN_MASK)) & (( \
      (uint32_t)(~(uint32_t)NFC_ISR_IDLECLR_MASK)) & (( \
      (uint32_t)(~(uint32_t)NFC_ISR_DONECLR_MASK)) & ( \
      (uint32_t)(~(uint32_t)NFC_ISR_WERRCLR_MASK))))) \
  )

/* ----------------------------------------------------------------------------
   -- DisableWriteErrorInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables write error interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define NFC_PDD_DisableWriteErrorInterrupt(peripheralBase) ( \
    NFC_ISR_REG(peripheralBase) &= \
     (uint32_t)(( \
      (uint32_t)(~(uint32_t)NFC_ISR_WERREN_MASK)) & (( \
      (uint32_t)(~(uint32_t)NFC_ISR_IDLECLR_MASK)) & (( \
      (uint32_t)(~(uint32_t)NFC_ISR_DONECLR_MASK)) & ( \
      (uint32_t)(~(uint32_t)NFC_ISR_WERRCLR_MASK))))) \
  )

/* ----------------------------------------------------------------------------
   -- GetWriteErrorInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Returns write error interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define NFC_PDD_GetWriteErrorInterruptFlag(peripheralBase) ( \
    (uint32_t)(NFC_ISR_REG(peripheralBase) & NFC_ISR_WERR_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- ClrWriteErrorInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Clears write error interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define NFC_PDD_ClrWriteErrorInterruptFlag(peripheralBase) ( \
    NFC_ISR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(NFC_ISR_REG(peripheralBase) | NFC_ISR_WERRCLR_MASK)) & (( \
      (uint32_t)(~(uint32_t)NFC_ISR_IDLECLR_MASK)) & ( \
      (uint32_t)(~(uint32_t)NFC_ISR_DONECLR_MASK)))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableCmdDoneInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables command done interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define NFC_PDD_EnableCmdDoneInterrupt(peripheralBase) ( \
    NFC_ISR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(NFC_ISR_REG(peripheralBase) | NFC_ISR_DONEEN_MASK)) & (( \
      (uint32_t)(~(uint32_t)NFC_ISR_IDLECLR_MASK)) & (( \
      (uint32_t)(~(uint32_t)NFC_ISR_DONECLR_MASK)) & ( \
      (uint32_t)(~(uint32_t)NFC_ISR_WERRCLR_MASK))))) \
  )

/* ----------------------------------------------------------------------------
   -- DisableCmdDoneInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables command done interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define NFC_PDD_DisableCmdDoneInterrupt(peripheralBase) ( \
    NFC_ISR_REG(peripheralBase) &= \
     (uint32_t)(( \
      (uint32_t)(~(uint32_t)NFC_ISR_DONEEN_MASK)) & (( \
      (uint32_t)(~(uint32_t)NFC_ISR_IDLECLR_MASK)) & (( \
      (uint32_t)(~(uint32_t)NFC_ISR_DONECLR_MASK)) & ( \
      (uint32_t)(~(uint32_t)NFC_ISR_WERRCLR_MASK))))) \
  )

/* ----------------------------------------------------------------------------
   -- GetCmdDoneInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Returns command done interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define NFC_PDD_GetCmdDoneInterruptFlag(peripheralBase) ( \
    (uint32_t)(NFC_ISR_REG(peripheralBase) & NFC_ISR_DONE_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- ClrCmdDoneInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Clears command done interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define NFC_PDD_ClrCmdDoneInterruptFlag(peripheralBase) ( \
    NFC_ISR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(NFC_ISR_REG(peripheralBase) | NFC_ISR_DONECLR_MASK)) & (( \
      (uint32_t)(~(uint32_t)NFC_ISR_IDLECLR_MASK)) & ( \
      (uint32_t)(~(uint32_t)NFC_ISR_WERRCLR_MASK)))) \
  )

/* ----------------------------------------------------------------------------
   -- EnableCmdIdleInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Enables command idle interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define NFC_PDD_EnableCmdIdleInterrupt(peripheralBase) ( \
    NFC_ISR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(NFC_ISR_REG(peripheralBase) | NFC_ISR_IDLEEN_MASK)) & (( \
      (uint32_t)(~(uint32_t)NFC_ISR_IDLECLR_MASK)) & (( \
      (uint32_t)(~(uint32_t)NFC_ISR_DONECLR_MASK)) & ( \
      (uint32_t)(~(uint32_t)NFC_ISR_WERRCLR_MASK))))) \
  )

/* ----------------------------------------------------------------------------
   -- DisableCmdIdleInterrupt
   ---------------------------------------------------------------------------- */

/**
 * Disables command idle interrupt.
 * @param peripheralBase Peripheral base address.
 */
#define NFC_PDD_DisableCmdIdleInterrupt(peripheralBase) ( \
    NFC_ISR_REG(peripheralBase) &= \
     (uint32_t)(( \
      (uint32_t)(~(uint32_t)NFC_ISR_IDLEEN_MASK)) & (( \
      (uint32_t)(~(uint32_t)NFC_ISR_IDLECLR_MASK)) & (( \
      (uint32_t)(~(uint32_t)NFC_ISR_DONECLR_MASK)) & ( \
      (uint32_t)(~(uint32_t)NFC_ISR_WERRCLR_MASK))))) \
  )

/* ----------------------------------------------------------------------------
   -- GetCmdIdleInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Returns command idle interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define NFC_PDD_GetCmdIdleInterruptFlag(peripheralBase) ( \
    (uint32_t)(NFC_ISR_REG(peripheralBase) & NFC_ISR_IDLE_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- ClrCmdIdleInterruptFlag
   ---------------------------------------------------------------------------- */

/**
 * Clears command idle interrupt flag.
 * @param peripheralBase Peripheral base address.
 */
#define NFC_PDD_ClrCmdIdleInterruptFlag(peripheralBase) ( \
    NFC_ISR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(NFC_ISR_REG(peripheralBase) | NFC_ISR_IDLECLR_MASK)) & (( \
      (uint32_t)(~(uint32_t)NFC_ISR_DONECLR_MASK)) & ( \
      (uint32_t)(~(uint32_t)NFC_ISR_WERRCLR_MASK)))) \
  )

/* ----------------------------------------------------------------------------
   -- SetFastFlashTiming
   ---------------------------------------------------------------------------- */

/**
 * Enables fast flash timing.
 * @param peripheralBase Peripheral base address.
 * @param State Enables or disables fast flash timing.
 */
#define NFC_PDD_SetFastFlashTiming(peripheralBase, State) ( \
    NFC_CFG_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(NFC_CFG_REG(peripheralBase) & (uint32_t)(~(uint32_t)NFC_CFG_FAST_MASK))) | ( \
      (uint32_t)((uint32_t)(State) << NFC_CFG_FAST_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- SetEccModeDmaAndVirtPageCount
   ---------------------------------------------------------------------------- */

/**
 * Sets Ecc mode, Dma and virtual page count.
 * @param peripheralBase Peripheral base address.
 * @param Ecc Ecc mode.
 * @param Dma Dma state.
 * @param VirtualPageCount Virtual page count.
 */
#define NFC_PDD_SetEccModeDmaAndVirtPageCount(peripheralBase, Ecc, Dma, VirtualPageCount) ( \
    NFC_CFG_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(( \
       NFC_CFG_REG(peripheralBase)) & (( \
       (uint32_t)(~(uint32_t)NFC_CFG_ECCMODE_MASK)) & (( \
       (uint32_t)(~(uint32_t)NFC_CFG_DMAREQ_MASK)) & ( \
       (uint32_t)(~(uint32_t)NFC_CFG_PAGECNT_MASK)))))) | (( \
      (uint32_t)(Ecc)) | (( \
      (uint32_t)(Dma)) | ( \
      (uint32_t)(VirtualPageCount))))) \
  )

/* ----------------------------------------------------------------------------
   -- DisableEcc
   ---------------------------------------------------------------------------- */

/**
 * Disables ECC.
 * @param peripheralBase Peripheral base address.
 */
#define NFC_PDD_DisableEcc(peripheralBase) ( \
    NFC_CFG_REG(peripheralBase) &= \
     (uint32_t)(~(uint32_t)NFC_CFG_ECCMODE_MASK) \
  )

/* ----------------------------------------------------------------------------
   -- SetSectorSize
   ---------------------------------------------------------------------------- */

/**
 * Sets transfer data size.
 * @param peripheralBase Peripheral base address.
 * @param SectorSize Sector size.
 */
#define NFC_PDD_SetSectorSize(peripheralBase, SectorSize) ( \
    NFC_SECSZ_REG(peripheralBase) = \
     (uint32_t)(SectorSize) \
  )

/* ----------------------------------------------------------------------------
   -- SetVirtualPageCount
   ---------------------------------------------------------------------------- */

/**
 * Sets virtual page count size.
 * @param peripheralBase Peripheral base address.
 * @param Count Virtual page count.
 */
#define NFC_PDD_SetVirtualPageCount(peripheralBase, Count) ( \
    NFC_CFG_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(NFC_CFG_REG(peripheralBase) & (uint32_t)(~(uint32_t)NFC_CFG_PAGECNT_MASK))) | ( \
      (uint32_t)(Count))) \
  )

/* ----------------------------------------------------------------------------
   -- SetRowAddress
   ---------------------------------------------------------------------------- */

/**
 * Sets row address.
 * @param peripheralBase Peripheral base address.
 * @param RowAddress Row address.
 */
#define NFC_PDD_SetRowAddress(peripheralBase, RowAddress) ( \
    NFC_RAR_REG(peripheralBase) = \
     (uint32_t)(RowAddress) \
  )

/* ----------------------------------------------------------------------------
   -- IncRowAddress
   ---------------------------------------------------------------------------- */

/**
 * Adds defined value to the row address.
 * @param peripheralBase Peripheral base address.
 * @param Increment Row address increment.
 */
#define NFC_PDD_IncRowAddress(peripheralBase, Increment) ( \
    NFC_RAR_REG(peripheralBase) = \
     NFC_RAR_REG(peripheralBase) + (uint32_t)(Increment) \
  )

/* ----------------------------------------------------------------------------
   -- SetColAddress
   ---------------------------------------------------------------------------- */

/**
 * Sets row address.
 * @param peripheralBase Peripheral base address.
 * @param ColAddress Column address.
 */
#define NFC_PDD_SetColAddress(peripheralBase, ColAddress) ( \
    NFC_CAR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(NFC_CAR_REG(peripheralBase) & (uint32_t)(~(uint32_t)0xFFFFFFU))) | ( \
      (uint32_t)(ColAddress))) \
  )

/* ----------------------------------------------------------------------------
   -- GetRepeatCount
   ---------------------------------------------------------------------------- */

/**
 * Returns the content of the RPT register.
 * @param peripheralBase Peripheral base address.
 */
#define NFC_PDD_GetRepeatCount(peripheralBase) ( \
    NFC_RPT_REG(peripheralBase) \
  )

/* ----------------------------------------------------------------------------
   -- SetRepeatCount
   ---------------------------------------------------------------------------- */

/**
 * Sets repeat counts.
 * @param peripheralBase Peripheral base address.
 * @param RepeatCount 16-bit repeat count. Determines how many times
 *        NFC_CMD2[CODE] is executed. If 0 or 1, the flash command is executed once.
 */
#define NFC_PDD_SetRepeatCount(peripheralBase, RepeatCount) ( \
    NFC_RPT_REG(peripheralBase) = \
     (uint32_t)(RepeatCount) \
  )

/* ----------------------------------------------------------------------------
   -- SetRowAddressInc
   ---------------------------------------------------------------------------- */

/**
 * Sets row address increment..
 * @param peripheralBase Peripheral base address.
 * @param Increment Row address increment.
 */
#define NFC_PDD_SetRowAddressInc(peripheralBase, Increment) ( \
    NFC_RAI_REG(peripheralBase) = \
     (uint32_t)(Increment) \
  )

/* ----------------------------------------------------------------------------
   -- SetDma1Address
   ---------------------------------------------------------------------------- */

/**
 * Sets Dma1 address.
 * @param peripheralBase Peripheral base address.
 * @param Address Address.
 */
#define NFC_PDD_SetDma1Address(peripheralBase, Address) ( \
    NFC_DMA1_REG(peripheralBase) = \
     (uint32_t)(Address) \
  )

/* ----------------------------------------------------------------------------
   -- SetDma2Address
   ---------------------------------------------------------------------------- */

/**
 * Sets Dma2 address.
 * @param peripheralBase Peripheral base address.
 * @param Address Address.
 */
#define NFC_PDD_SetDma2Address(peripheralBase, Address) ( \
    NFC_DMA2_REG(peripheralBase) = \
     (uint32_t)(Address) \
  )

/* ----------------------------------------------------------------------------
   -- SetDma1
   ---------------------------------------------------------------------------- */

/**
 * Prepares DMA1 for transfer.
 * @param peripheralBase Peripheral base address.
 * @param Address Buffer address. Must be 4 bytes aligned.
 * @param Size Data size. Data are transferred in multiple of 4 bytes.
 */
#define NFC_PDD_SetDma1(peripheralBase, Address, Size) ( \
    (NFC_DMA1_REG(peripheralBase) = \
     (uint32_t)(Address)), \
    (NFC_DMACFG_REG(peripheralBase) = \
     (uint32_t)((uint32_t)((uint32_t)(Size) << NFC_DMACFG_COUNT1_SHIFT) | NFC_DMACFG_ACT1_MASK)) \
  )

/* ----------------------------------------------------------------------------
   -- SetDma2
   ---------------------------------------------------------------------------- */

/**
 * Prepares DMA2 for transfer.
 * @param peripheralBase Peripheral base address.
 * @param Address Buffer address. Must be 8 bytes aligned.
 * @param Size Data size. Data are transferred in multiple of 8 bytes.
 */
#define NFC_PDD_SetDma2(peripheralBase, Address, Size) ( \
    (NFC_DMA2_REG(peripheralBase) = \
     (uint32_t)(Address)), \
    (NFC_DMACFG_REG(peripheralBase) = \
     (uint32_t)((uint32_t)((uint32_t)(Size) << NFC_DMACFG_COUNT2_SHIFT) | NFC_DMACFG_ACT2_MASK)) \
  )

/* ----------------------------------------------------------------------------
   -- SetDma1AndDma2
   ---------------------------------------------------------------------------- */

/**
 * Prepares DMA1 and DMA2 for transfer.
 * @param peripheralBase Peripheral base address.
 * @param Dma1DstAddress Buffer address. Must be 4 bytes aligned.
 * @param Dma1DataSize Data size. Data are transferred in multiple of 4 bytes.
 * @param Dma2DstAddress Buffer address. Must be 8 bytes aligned.
 * @param Dma2DataSize Data size. Data are transferred in multiple of 8 bytes.
 * @param Dma2Offset 256 byte offest from the begin of the active SRAM buffer.
 */
#define NFC_PDD_SetDma1AndDma2(peripheralBase, Dma1DstAddress, Dma1DataSize, Dma2DstAddress, Dma2DataSize, Dma2Offset) ( \
    (NFC_DMA1_REG(peripheralBase) = \
     (uint32_t)(Dma1DstAddress)), \
    ((NFC_DMA2_REG(peripheralBase) = \
     (uint32_t)(Dma2DstAddress)), \
    (NFC_DMACFG_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)((uint32_t)(Dma1DataSize) << NFC_DMACFG_COUNT1_SHIFT)) | (( \
      (uint32_t)((uint32_t)(Dma2DataSize) << NFC_DMACFG_COUNT2_SHIFT)) | (( \
      (uint32_t)((uint32_t)(Dma2Offset) << NFC_DMACFG_OFFSET2_SHIFT)) | (( \
      NFC_DMACFG_ACT1_MASK) | ( \
      NFC_DMACFG_ACT2_MASK))))))) \
  )

/* ----------------------------------------------------------------------------
   -- SetResetCmd
   ---------------------------------------------------------------------------- */

/**
 * Reset command.
 * @param peripheralBase Peripheral base address.
 */
#define NFC_PDD_SetResetCmd(peripheralBase) ( \
    NFC_CMD2_REG(peripheralBase) = \
     0xFF404000U \
  )

/* ----------------------------------------------------------------------------
   -- SetReadIdCmd
   ---------------------------------------------------------------------------- */

/**
 * Read ID command.
 * @param peripheralBase Peripheral base address.
 * @param Address Address.
 * @param Size Requested data size.
 */
#define NFC_PDD_SetReadIdCmd(peripheralBase, Address, Size) ( \
    (NFC_CMD2_REG(peripheralBase) = \
     0x90480400U), \
    ((NFC_RAR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(NFC_RAR_REG(peripheralBase) & (uint32_t)(~(uint32_t)NFC_RAR_BYTE1_MASK))) | ( \
      (uint32_t)(Address)))), \
    (NFC_CFG_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(NFC_CFG_REG(peripheralBase) & (uint32_t)(~(uint32_t)NFC_CFG_IDCNT_MASK))) | ( \
      (uint32_t)((uint32_t)(Size) << NFC_CFG_IDCNT_SHIFT))))) \
  )

/* ----------------------------------------------------------------------------
   -- SetReadPageCmd
   ---------------------------------------------------------------------------- */

/**
 * Prepares NFC to read  up to 4 pages.
 * @param peripheralBase Peripheral base address.
 * @param RowAddress Row address.
 * @param ColAddress Column address.
 * @param BufferNum Buffer number.
 */
#define NFC_PDD_SetReadPageCmd(peripheralBase, RowAddress, ColAddress, BufferNum) ( \
    (NFC_CAR_REG(peripheralBase) = \
     (uint32_t)(ColAddress)), \
    ((NFC_RAR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(NFC_RAR_REG(peripheralBase) & (uint32_t)(~(uint32_t)0xFFFFFFU))) | ( \
      (uint32_t)(RowAddress)))), \
    ((NFC_CMD1_REG(peripheralBase) = \
     0x30000000U), \
    (NFC_CMD2_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)((uint32_t)0x7EE0U << NFC_CMD2_CODE_SHIFT)) | ( \
      (uint32_t)((uint32_t)(BufferNum) << NFC_CMD2_BUFNO_SHIFT)))))) \
  )

/* ----------------------------------------------------------------------------
   -- SetWritePageCmd
   ---------------------------------------------------------------------------- */

/**
 * Prepares NFC to read  up to 4 pages.
 * @param peripheralBase Peripheral base address.
 * @param RowAddress Row address.
 * @param ColAddress Column address.
 * @param BufferNum Buffer number.
 */
#define NFC_PDD_SetWritePageCmd(peripheralBase, RowAddress, ColAddress, BufferNum) ( \
    (NFC_CAR_REG(peripheralBase) = \
     (uint32_t)(ColAddress)), \
    ((NFC_RAR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(NFC_RAR_REG(peripheralBase) & (uint32_t)(~(uint32_t)0xFFFFFFU))) | ( \
      (uint32_t)(RowAddress)))), \
    ((NFC_CMD1_REG(peripheralBase) = \
     0x10700000U), \
    (NFC_CMD2_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)((uint32_t)0x80U << NFC_CMD2_BYTE1_SHIFT)) | (( \
      (uint32_t)((uint32_t)0xFFD8U << NFC_CMD2_CODE_SHIFT)) | ( \
      (uint32_t)((uint32_t)(BufferNum) << NFC_CMD2_BUFNO_SHIFT))))))) \
  )

/* ----------------------------------------------------------------------------
   -- SetEraseBlockCmd
   ---------------------------------------------------------------------------- */

/**
 * Prepares NFC to program up to 4 page.
 * @param peripheralBase Peripheral base address.
 * @param BlockAddress Page address.
 */
#define NFC_PDD_SetEraseBlockCmd(peripheralBase, BlockAddress) ( \
    (NFC_CMD1_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)((uint32_t)0x70U << NFC_CMD1_BYTE3_SHIFT)) | ( \
      (uint32_t)((uint32_t)0xD0U << NFC_CMD1_BYTE2_SHIFT)))), \
    ((NFC_CMD2_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)((uint32_t)0x60U << NFC_CMD2_BYTE1_SHIFT)) | ( \
      (uint32_t)((uint32_t)0x4ED8U << NFC_CMD2_CODE_SHIFT)))), \
    (NFC_RAR_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)(NFC_RAR_REG(peripheralBase) & (uint32_t)(~(uint32_t)0xFFFFFFU))) | ( \
      (uint32_t)(BlockAddress))))) \
  )

/* ----------------------------------------------------------------------------
   -- SetEccModeDmaReqAndPageCount
   ---------------------------------------------------------------------------- */

/**
 * Sets address swap.
 * @param peripheralBase Peripheral base address.
 */
#define NFC_PDD_SetEccModeDmaReqAndPageCount(peripheralBase) ( \
    NFC_SWAP_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)((uint32_t)0x7FFU << NFC_SWAP_ADDR1_SHIFT)) | ( \
      (uint32_t)((uint32_t)0x7FFU << NFC_SWAP_ADDR2_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- DisableAddressSwap
   ---------------------------------------------------------------------------- */

/**
 * Sets address swap.
 * @param peripheralBase Peripheral base address.
 */
#define NFC_PDD_DisableAddressSwap(peripheralBase) ( \
    NFC_SWAP_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)((uint32_t)0x7FFU << NFC_SWAP_ADDR1_SHIFT)) | ( \
      (uint32_t)((uint32_t)0x7FFU << NFC_SWAP_ADDR2_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- SetAddressSwap
   ---------------------------------------------------------------------------- */

/**
 * Sets address swap.
 * @param peripheralBase Peripheral base address.
 * @param Address1 Address 1.
 * @param Address2 Address 2.
 */
#define NFC_PDD_SetAddressSwap(peripheralBase, Address1, Address2) ( \
    NFC_SWAP_REG(peripheralBase) = \
     (uint32_t)(( \
      (uint32_t)((uint32_t)(Address1) << NFC_SWAP_ADDR1_SHIFT)) | ( \
      (uint32_t)((uint32_t)(Address2) << NFC_SWAP_ADDR2_SHIFT))) \
  )

/* ----------------------------------------------------------------------------
   -- StartCommand
   ---------------------------------------------------------------------------- */

/**
 * Starts command execution.
 * @param peripheralBase Peripheral base address.
 */
#define NFC_PDD_StartCommand(peripheralBase) ( \
    NFC_CMD2_REG(peripheralBase) |= \
     NFC_CMD2_BUSY_START_MASK \
  )
#endif  /* #if defined(NFC_PDD_H_) */

/* NFC_PDD.h, eof. */
