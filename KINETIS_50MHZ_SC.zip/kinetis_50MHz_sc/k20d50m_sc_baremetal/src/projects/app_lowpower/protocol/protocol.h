
void  uart_app_init(void);
