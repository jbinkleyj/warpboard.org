/**
 * \brief  Calculates the square root of the value
 * \author  Luis Puebla
 * \param   value
 * \return  (unsigend long)square root
 * \todo    
 * \warning
 */   
unsigned int sqrt_16(unsigned int value);

